window.appInitializer = () => {
  hashProductMap(DukaanData.DUKAAN_CATALOG);
  fetchCouponsAndOffersOnIndex();
  druidStorePageView();
  initProductSplide();

  if (typeof handleNav !== 'undefined') handleNav('home');

  const filteredCategories = DukaanData?.DUKAAN_CATALOG?.filter((category) =>
    isParentCategory(category)
  );

  const { isMobile } = deviceType();

  if (isMobile) {
    if (filteredCategories?.length > 4) {
      document
        .querySelector('.allCategories .viewAllButton')
        .classList.remove('hidden');
    }
  } else if (filteredCategories?.length > 8) {
    document
      .querySelector('.allCategories .viewAllButton')
      .classList.remove('hidden');
  }

  fetchProductCoupons(getProductIdsFromCategories(DukaanData.DUKAAN_CATALOG));

  let loading = false;
  const offsetCount = DukaanData.DUKAAN_CATALOG_PROPS.offset;
  let { offset } = DukaanData.DUKAAN_CATALOG_PROPS;
  let hasMore = true;

  const fetchBestSellers = async () => {
    if (loading) return;
    loading = true;
    // const url = [
    //   `https://staging.store-front.api.dukan.tech/api/store/buyer/${window.DukaanData.DUKAAN_STORE.link}/bestseller/v3/?offset=${offset}`,
    //   `${window.DukaanData.CLIENT_API2_ENDPOINT}/api/store/buyer/${window.DukaanData.DUKAAN_STORE.link}/bestseller/v3/?offset=${offset}`,
    // ];
    const response = await fetch(
      `${window.DukaanData.CLIENT_API2_ENDPOINT}/api/store/buyer/${window.DukaanData.DUKAAN_STORE.link}/bestseller/v3/?offset=${offset}`
    );
    const res = await response?.json();
    const { results: rawResults = [] } = res || {};
    const count = rawResults?.length;
    const results = rawResults?.filter((rR) => rR.products.length > 0);
    hashProductMap(results);
    hashCategory(results);
    renderBestSellers(results, 10);
    // fetchProductCoupons(getProductIdsFromCategories(results));
    if (count < offsetCount) {
      hasMore = false;
      removeScroller({ observeThis: 'bestseller-observer' });
    } else {
      hasMore = true;
      offset += offsetCount;
    }
    loading = false;
  };

  applyScroller({
    loading,
    hasMore,
    cb: fetchBestSellers,
    observeThis: 'bestseller-observer',
    loadPoint: document.querySelector('best-seller-load-point'),
  });

  const categoryWrapper = document.querySelector('.categoryWrapper');
  const nextButton = document.querySelector('.navigation__arrow--next');
  const prevButton = document.querySelector('.navigation__arrow--prev');

  if (categoryWrapper.clientWidth < categoryWrapper.scrollWidth) {
    nextButton.classList.remove('hidden');
  } else {
    nextButton.classList.add('hidden');
  }

  categoryWrapper.addEventListener('scroll', (e) => {
    if (categoryWrapper.scrollLeft === 0) {
      prevButton.classList.add('hidden');
    } else {
      prevButton.classList.remove('hidden');
    }

    if (
      categoryWrapper.clientWidth + categoryWrapper.scrollLeft <
      categoryWrapper.scrollWidth
    ) {
      nextButton.classList.remove('hidden');
    } else {
      nextButton.classList.add('hidden');
    }
  });
};

window.onNextClick = () => {
  const allCategories = document.querySelector('.allCategories');
  const categoryWrapper = document.querySelector('.categoryWrapper');

  if (categoryWrapper.scrollWidth > allCategories.clientWidth) {
    const x = categoryWrapper.clientWidth - 100;
    categoryWrapper.scrollBy({ left: x, behavior: 'smooth' });
  }
};
window.onPrevClick = () => {
  const categoryWrapper = document.querySelector('.categoryWrapper');
  if (categoryWrapper.scrollLeft !== 0) {
    const x = categoryWrapper.clientWidth - 100;

    categoryWrapper.scrollBy({ left: -x, behavior: 'smooth' });
  }
};
