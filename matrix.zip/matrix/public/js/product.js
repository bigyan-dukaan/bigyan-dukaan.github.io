window.SIMILAR_PRODUCT_LIMIT = 0;
window.thumbnailSplide = null;
window.splideCarousel = undefined;

window.scrollToSKUImage = (activeSKU) => {
  const primaryImage = activeSKU?.primary_image;
  const allImages = DukaanData.DUKAAN_PRODUCT?.all_images;
  if (allImages?.length > 0) {
    const index = allImages?.indexOf(primaryImage);
    if (index >= 0) {
      window?.splideCarousel?.go(index);
      window?.thumbnailSplide?.go(index);
    }
  }
};

window.appInitializer = () => {
  const { isMobile } = deviceType();
  SIMILAR_PRODUCT_LIMIT = isMobile ? 6 : 15;
  const productFromServer = DukaanData.DUKAAN_PRODUCT;
  const serializedSKUs = serializeSKUs(productFromServer.skus || []);
  const attributes = getAllProductAttributeValues(serializedSKUs);
  const product = {
    ...productFromServer,
    skus: serializedSKUs,
    attributes,
  };
  window.DukaanData.PRODUCTS_DETAILS = product;
  window.DukaanData.PRODUCTS_MAP = {
    ...(DukaanData.PRODUCTS_MAP || []),
    [product.uuid]: product,
  };
  productPageCommonFnCalls(product);

  document.querySelectorAll('.thumbImageWrapper').forEach((ele) => {
    ele.addEventListener('click', () => {
      document.querySelector('.productImage.active').classList.remove('active');
      ele.querySelector('.productImage ').classList.add('active');
    });
  });

  splideCarousel = new Splide('#splide-pdp-main', {
    type: 'loop',
    delay: '5000',
    autoplay: false,
    pagination: false,
    arrows: false,
    updateOnMove: true,
    breakpoints: {
      992: {
        pagination: false,
        arrows: false,
      },
    },
  });
  splideCarousel.on('click', (e) => {
    playProductVideo(e);
  });
  if (document.querySelector('#splide-product-thumbnail')) {
    window.thumbnailSplide = new Splide('#splide-product-thumbnail', {
      type: 'slide',
      autoplay: false,
      arrows: false,
      fixedWidth: 80,
      fixedHeight: 100,
      rewind: true,
      direction: 'ttb',
      gap: 4,
      height: '100%',
      pagination: false,
      isNavigation: true,
      breakpoints: {
        768: {
          direction: 'ltr',
          arrows: false,
        },
      },
    });

    window.thumbnailSplide.on('click', () => {
      window.pauseAllProductVideos();
    });

    window?.splideCarousel?.sync(window.thumbnailSplide);
    window?.splideCarousel?.mount();
    window?.thumbnailSplide?.mount();
  } else {
    window?.splideCarousel?.mount();
  }
};
