const paramString = new URLSearchParams(window.location.search);
const sortBy = paramString.get('sort_by') || 'bestsellers';
const sortTypeElem = document.querySelector('.sortType');
sortTypeElem.textContent = document.querySelector(
  `.sortLabel input[value="${sortBy}"] + label`
).textContent;
document.querySelector(`.sortLabel input[value="${sortBy}"]`).checked = 'true';

window.getCustomPageSize = () => {
  const { isMobile } = deviceType();
  return isMobile ? 16 : 20;
};

window.shimmerCount = 8;

// window.appInitializer = () => {
//   checkCouponSticky();
//   checkStoreClosedSticky();
//   GAPage();
// };

window.openRelevance = () => {
  document.querySelector('.sortItems').style.display = 'block';
};

window.handleFilterChange = (event, ordering, label) => {
  const sortTypeElement = document.querySelector('.sortType');
  sortTypeElement.textContent = label;
  const inputs = document.querySelectorAll(`input[value=${ordering}]`);
  // eslint-disable-next-line no-return-assign, no-param-reassign
  inputs.forEach((input) => (input.checked = true));
  closeSortModal();
};

window.openPopover = () => {
  document.querySelector('body').style.overflow = 'hidden';
  document.getElementById('popover-content').classList.toggle('hidden');
  document.querySelector('.downArrow').classList.toggle('hidden');
  document.querySelector('.upArrow').classList.toggle('hidden');
};

window.closePopover = () => {
  document.querySelector('body').style.overflow = 'auto';
  document.getElementById('popover-content').classList.toggle('hidden');
  document.querySelector('.downArrow').classList.toggle('hidden');
  document.querySelector('.upArrow').classList.toggle('hidden');
};

window.sortDropDownHandler = (sortByValue) => {
  const sortTypeElement = document.querySelector('.sortType');
  sortTypeElement.textContent = document.querySelector(
    `.sortLabel input[value="${sortByValue}"] + label`
  ).textContent;
  closePopover();
};

window.noFilterDataHandler = () => {
  document
    .querySelector('.filters-layout-wrapper')
    .classList.add('no-filter-state');
  document.querySelector('advanced-filters').classList.add('hidden');
  document
    .querySelector('.custom-mobile-sort-button button:nth-of-type(2)')
    ?.classList.add('hidden');
  document
    .querySelector('.mobile-filter-button-divider')
    ?.classList.add('hidden');
};

const specifiedElement = document.querySelector('.sortContainer');
document.addEventListener('click', (event) => {
  const isClickInside = specifiedElement.contains(event.target);
  if (
    !isClickInside &&
    document.body.style.overflow === 'hidden' &&
    !document.querySelector('.sort-popper .modal-content.hidden')
  )
    closePopover();
});

window.customCounterRender = (str) => `${str}`;
