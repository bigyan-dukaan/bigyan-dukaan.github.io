window.appInitializer = () => {
  const paramString = new URLSearchParams(window.location.search);
  const query = paramString.get('query');
  if (!!query && query.length > 0) {
    document.querySelector('.bottom-header .category-name').textContent = query;
    document.querySelector('.category-header .category-name').textContent =
      query;
  }
};
