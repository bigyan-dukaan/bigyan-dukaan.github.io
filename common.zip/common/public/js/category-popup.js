let enableScrollForCategoryPopup = true;
let scrollTimerForCategoryPopup = null;

window.dknRenderCategoryListPopupItems = (popoverElem) => {
  const categories = [...DukaanData.DUKAAN_CATALOG];
  const categoryTemplate = q$.selectById(
    'dkn-category-popup-item-template'
  ).elem;

  const mountElem = q$.select(
    'category-popup-item-load-point',
    popoverElem
  ).elem;

  mountElem.replaceChildren();
  if (!!categoryTemplate && !!mountElem)
    categories.forEach((category, index) => {
      const categoryCard = document.importNode(categoryTemplate.content, true);
      if (categoryCard) {
        if (index === 0)
          q$.select('.category-popup-item', categoryCard).elem.classList.add(
            'active'
          );

        q$.select(
          '.category-popup-item',
          categoryCard
        ).elem.dataset.categoryPopupItemUuid = category.uuid;
        q$.select(
          '.category-popup-item',
          categoryCard
        ).elem.dataset.categoryPopupItemId = category.id;

        categoryCard
          .querySelector('[data-category-popup-item-scroll-click]')
          .setAttribute(
            'onclick',
            `dknCloseCategoryListPopup(event, '${category.id}', '${category.uuid}')`
          );
        categoryCard
          .querySelector('[data-category-popup-item-link')
          .setAttribute('href', `#${category.id}`);
        categoryCard.querySelector(
          '[data-category-popup-item-name'
        ).textContent = category.name;
        categoryCard.querySelector(
          '[data-category-popup-item-count'
        ).textContent = category.product_count;
      }
      mountElem.appendChild(categoryCard);
    });
};

window.dknHandleScrollToCategorySection = (e, id, uuid) => {
  e.preventDefault();
  const homeCategorySection =
    q$.selectById(id).elem || q$.selectById(uuid).elem;

  // enableScrollForCategoryPopup = false;

  const position = homeCategorySection.offsetTop - 84;
  const catListEl = document.querySelector(`[name="${uuid}"]`);

  window.scrollTo({
    top: position,
    behavior: 'smooth',
  });

  // enableScrollForCategoryPopup = false;
};

window.dknHandleScrollToActiveCategoryItem = () => {
  const activeCategoryItem = q$.select(
    'category-popup-item-load-point .category-popup-item.active'
  ).elem;

  const categoryPopup = q$.select(
    '#categoryPopupWrapper .category-popup-modal .modal-content'
  ).elem;

  categoryPopup.scrollTo({
    top: activeCategoryItem.offsetTop - 16,
    behavior: 'smooth',
  });
};

window.dknHandleCategoryPopupItemActiveState = () => {
  const elems = document.querySelectorAll('.dkn-home-category-sections');

  elems?.forEach((elem) => {
    if (elem.getBoundingClientRect().top < 85 && enableScrollForCategoryPopup) {
      const uniqueId = elem.attributes.id.value;

      const activeCategoryPopupItem =
        document.querySelector(
          `category-popup-item-load-point .category-popup-item[data-category-popup-item-uuid="${uniqueId}"]`
        ) ||
        document.querySelector(
          `category-popup-item-load-point .category-popup-item[data-category-popup-item-id="${uniqueId}"]`
        );

      q$.selectAll(
        'category-popup-item-load-point .category-popup-item'
      ).removeClassAll('active');
      activeCategoryPopupItem?.classList.add('active');
    }
  });

  if (scrollTimerForCategoryPopup) {
    clearTimeout(scrollTimerForCategoryPopup);
    scrollTimerForCategoryPopup = setTimeout(() => {
      enableScrollForCategoryPopup = true;
    }, 200);
  }
};

window.dknHandleCategoryPopupButtonActiveState = (event) => {
  const categoryPopupBtn = document.querySelector(
    '#dkn-category-popup-open-btn'
  );
  if (categoryPopupBtn !== undefined && categoryPopupBtn !== null) {
    if (
      event.target.querySelector('body') &&
      event.target.querySelector('body').getBoundingClientRect().top > -200
    ) {
      categoryPopupBtn.classList.add('active');
    } else {
      categoryPopupBtn.classList.remove('active');
    }
  }
};

window.dknOpenCategoryListPopup = () => {
  const popoverElement = q$.selectById('categoryPopupWrapper').elem;
  popoverElement.replaceChildren();
  const popup = q$.selectById('dkn-category-popup-template').elem;
  const item = document.importNode(popup.content, true);
  dknRenderCategoryListPopupItems(item);
  popoverElement.appendChild(item);
  document.body.style.overflow = 'hidden';

  const openBtn = q$.selectById('dkn-category-popup-open-btn').elem;
  const closeBtn = q$.selectById('dkn-category-popup-close-btn').elem;

  openBtn.classList.add('hidden');
  closeBtn.classList.remove('hidden');

  window.dknHandleCategoryPopupItemActiveState();
  window.dknHandleScrollToActiveCategoryItem();
};

window.dknCloseCategoryListPopup = (event, categoryId, categoryUuid) => {
  const popoverModal = document.getElementById('popover-modal');
  popoverModal.classList.add('display-none');
  document.body.style.overflow = 'initial';

  if (categoryId) {
    window.dknHandleScrollToCategorySection(event, categoryId, categoryUuid);
    window.dknHandleCategoryPopupItemActiveState();
  }

  const openBtn = q$.selectById('dkn-category-popup-open-btn').elem;
  const closeBtn = q$.selectById('dkn-category-popup-close-btn').elem;

  openBtn.classList.remove('hidden');
  closeBtn.classList.add('hidden');
};

window.addEventListener(
  'scroll',
  dknHandleCategoryPopupButtonActiveState,
  true
);
