/* global q$ */
/* eslint-disable no-param-reassign */

// ---------------------------------------------------------------------------------------------------------------------
// Get and Post functions wrapper
// ---------------------------------------------------------------------------------------------------------------------

// const httpGet = async (url, params = {}, options = {}) =>
//   axios.get(url, {
//     data: params,
//     headers: {
//       Authorization: localStorage.al_to
//         ? `Bearer ${localStorage.al_to}`
//         : undefined,
//       'x-requested-with': window?.DukaanData?.DUKAAN_SESSION_ID,
//       ...options?.headers,
//     },
//   });

// const httpPost = async (url, params = {}, options = {}) =>
//   axios.post(url, params, {
//     headers: {
//       Authorization: localStorage.al_to
//         ? `Bearer ${localStorage.al_to}`
//         : undefined,
//       'x-requested-with': window?.DukaanData?.DUKAAN_SESSION_ID,
//       ...options?.headers,
//     },
//   });

// ---------------------------------------------------------------------------------------------------------------------
// Pages urls utils
// ---------------------------------------------------------------------------------------------------------------------

window.dknGoToUrl = (url) => {
  window.location.replace(url);
};

// window.dknGetCategoryPageUrl = (
//   category,
//   baseUrl = DukaanData.DUKAAN_BASE_URL
// ) => `${baseUrl}/categories/${category.slug}`;

window.dknGetBagPageUrl = () => `/${DukaanData.DUKAAN_STORE.link}/bag`;

// ---------------------------------------------------------------------------------------------------------------------
// Common renderers and utility functions
// ---------------------------------------------------------------------------------------------------------------------

const DUKAAN_DEFAULT_IMAGE =
  'https://api.mydukaan.io/static/images/category-def.jpg';

window.dknGetCdnUrl = (imagePath, width, height) => {
  if (!height) {
    height = width;
  }

  let image = imagePath || '';
  if (typeof image !== 'string') return null;
  if (!image) return null;
  if (image.includes('mydukaan-prod.')) {
    image = imagePath.replace('mydukaan-prod.', 'mydukaan-prod-new.');
  }

  if (image.endsWith('.blob') || image.endsWith('.gif')) {
    return image;
  }

  if (image.startsWith('https://dms.mydukaan.io/original/')) {
    if (image.startsWith('https://dms.mydukaan.io/original/jpeg')) {
      return image.replace(
        'https://dms.mydukaan.io/original/jpeg',
        `https://dukaan.b-cdn.net/${width}x${height}/webp`
      );
    }

    return image.replace(
      'https://dms.mydukaan.io/original',
      `https://dukaan.b-cdn.net/${width}x${height}`
    );
  }

  try {
    const imageComponents = image.split('url=');
    image = imageComponents[imageComponents.length - 1] || imageComponents[0];
  } catch {
    //
  }

  image = serializeUrlForCdn(image);
  const oldDomains = [
    'https://storage.googleapis.com/dukaan-export',
    'https://storage.cloud.google.com',
    'https://dukaan-us.s3.amazonaws.com',
    'https://dukaan-core-file-service.s3.ap-southeast-1.amazonaws.com',
    'https://dukaan-core-file-service.s3.amazonaws.com',
    'https://mydukaan-prod-new.s3.amazonaws.com',
    'https://projecteagle.s3.ap-south-1.amazonaws.com',
    'https://dukaan-us.s3.us-west-2.amazonaws.com',
    'https://mydukaan.s3.amazonaws.com',
    'https://s3.ap-southeast-1.wasabisys.com/dukaan-export',
    'https://s3.ap-southeast-1.wasabisys.com/dukaan-media-v3',
    'https://s3.ap-southeast-1.wasabisys.com',
  ];

  const domain = oldDomains.find((item) => image && image.startsWith(item));

  if (domain) {
    const imgPath = image.replace(`${domain}/`, '');

    if (domain === 'https://projecteagle.s3.ap-south-1.amazonaws.com') {
      return `https://dukaan.b-cdn.net/${width}x${height}/webp/projecteagle/${imgPath}`;
    }

    if (image.includes('.gif')) {
      return `https://dukaan.b-cdn.net/original/gif/${imgPath}`;
    }

    if (image.includes('.svg')) {
      return `https://dukaan.b-cdn.net/original/svg/${imgPath}`;
    }

    return `https://dukaan.b-cdn.net/${width}x${height}/webp/${imgPath}`;
  }

  return image;
};

// direct dom function
window.dknImageOnErrorHandler = (event) => {
  const { target } = event;
  target.src = DUKAAN_DEFAULT_IMAGE;
  target.classList.add('dkn-error-img');
};

window.dknImageRenderer = (
  image,
  selector,
  parentElement = document,
  options = {}
) => {
  const {
    imageCdnWidth = 500,
    imageCdnHeight = imageCdnWidth,
    lazyload = true,
  } = options;

  // set default image
  if (!image) {
    q$.selectAll(selector, parentElement).setAttributeAll(
      'src',
      DUKAAN_DEFAULT_IMAGE
    );
    return;
  }

  q$.selectAll(selector, parentElement).setAttributeAll(
    'src',
    dknGetCdnUrl(image, imageCdnWidth, imageCdnHeight)
  );
  q$.selectAll(selector, parentElement).setAttributeAll(
    'onerror',
    'dknImageOnErrorHandler(event)'
  );
  q$.selectAll(selector, parentElement).setAttributeAll('lazyload', lazyload);
};

const dknGetIfColorIsLightOrDark = (color) => {
  if (!color) return { isLight: true, isDark: false };

  // Check the format of the color, HEX or RGB?
  if (color.match(/^rgb/)) {
    // If HEX --> store the red, green, blue values in separate variables
    color = color.match(
      /^rgba?\((\d+),\s*(\d+),\s*(\d+)(?:,\s*(\d+(?:\.\d+)?))?\)$/
    );
    // eslint-disable-next-line prefer-destructuring
    r = color[1];
    // eslint-disable-next-line prefer-destructuring
    g = color[2];
    // eslint-disable-next-line prefer-destructuring
    b = color[3];
  } else {
    // If RGB --> Convert it to HEX: http://gist.github.com/983661
    color = +`0x${color.slice(1).replace(color.length < 5 && /./g, '$&$&')}`;
    r = color >> 16;
    g = (color >> 8) & 255;
    b = color & 255;
  }

  // HSP (Highly Sensitive Poo) equation from http://alienryderflex.com/hsp.html
  hsp = Math.sqrt(0.299 * (r * r) + 0.587 * (g * g) + 0.114 * (b * b));

  // Using the HSP value, determine whether the color is light or dark
  const isLight = hsp > 180;
  const isDark = !isLight;
  return { isLight, isDark };
};

// category renderers and utils
// window.dknCategoryDataRenderer = (category, categoryCard, options = {}) => {
//   const { customLink, imageCdnValue = 500 } = options;
//   const { name, image, id, uuid } = category;

//   q$.selectAll('[data-category-id]', categoryCard).setDataAttributeAll(
//     'categoryId',
//     id
//   );
//   q$.selectAll('[data-category-uuid]', categoryCard).setDataAttributeAll(
//     'categoryUuid',
//     uuid
//   );

//   // add category data
//   q$.selectAll('.dkn-category-card-name', categoryCard).modifyTextContentAll(
//     name
//   );

//   dknImageRenderer(image, '.dkn-category-card-image', categoryCard, {
//     imageCdnWidth: imageCdnValue,
//   });

//   // add custom link if required
//   if (!customLink) {
//     q$.selectAll('.dkn-category-card-link', categoryCard).setAttributeAll(
//       'href',
//       dknGetCategoryPageUrl(category, DukaanData.DUKAAN_BASE_URL)
//     );
//   } else {
//     q$.selectAll('.dkn-category-card-link', categoryCard).setAttributeAll(
//       'href',
//       customLink
//     );
//   }

//   // additional renderer if required
//   if (typeof options?.additionalRenderer === 'function') {
//     options.additionalRenderer({ category, categoryCard, options });
//   }
// };

// ---------------------------------------------------------------------------------------------------------------------
// Product related utils
// ---------------------------------------------------------------------------------------------------------------------

const dknProcessAddOnGroup = (addOnGroup) => {
  const {
    min_selection: minSelection,
    max_selection: maxSelection,
    mandatory: defaultAddOnMandatory,
  } = addOnGroup;
  const mandatory =
    defaultAddOnMandatory || (!!minSelection && minSelection > 1);
  const onlyOneSelection = maxSelection === 1 && minSelection === 1;
  return {
    ...addOnGroup,
    mandatory,
    onlyOneSelection,
  };
};

window.dknGetSerializedAddons = (product = {}) => {
  if (!product) return {};
  const { add_ons: addOnsNonGroup, add_on_groups: addOnGroups = [] } = product;
  const addOnsMandatory = addOnsNonGroup?.length
    ? (addOnsNonGroup || []).reduce(
        (acc, addon) => acc && addon.price === 0,
        true
      )
    : false;

  const rawAddOns = addOnsNonGroup?.length
    ? [
        {
          name: 'Add-Ons',
          add_ons: addOnsNonGroup,
          mandatory: addOnsMandatory,
        },
        ...addOnGroups,
      ]
    : [...addOnGroups];

  const addOns = rawAddOns.map((addOnGroup) =>
    dknProcessAddOnGroup(addOnGroup)
  );
  const addOnsList = addOns.map((group) => group.add_ons).flat();
  return { addOnsList, addOns };
};

window.dknGetFirstSKUKeyWhichIsInStock = (skus) => {
  let key = 0;
  for (let i = 0; i < skus.length; i += 1) {
    if (skus[i].in_stock) {
      key = i;
      break;
    }
  }
  return key;
};

window.dknGetFirstSKUWhichIsInStock = (skus) =>
  skus?.find((sku) => sku.inventory > 0 || sku.inventory === null) || skus[0];

window.dknGetFirstAvailableSKU = (skus) => {
  if (!skus) return [];

  const selectedSKUIndexFromParams = skus.find(
    (sku) => sku.id === DukaanData.DUKAAN_SKU_ID_FROM_PARAMS
  );
  if (selectedSKUIndexFromParams) return selectedSKUIndexFromParams;

  if (window?.storeConfig?.selectFirstSKUInStock === true) {
    return dknGetFirstSKUWhichIsInStock(skus);
  }

  const sortedSKUSBasedOnSellingPrice = [...skus]?.sort(
    (a, b) => a.selling_price - b.selling_price
  );
  const leastPriceSKUInStock = dknGetFirstSKUWhichIsInStock(
    sortedSKUSBasedOnSellingPrice
  );

  return leastPriceSKUInStock || skus[0];
};

const dknGetUniqueAttributeValuesFromSKUs = (skus, attrKey) => {
  const rawValues = skus.map((sku) => sku.new_meta[attrKey].value);
  return uniq(rawValues);
};

const dknGetAvailableSKUByAttributeAndActiveSKU = (
  skus,
  activeSKU,
  attrKeys,
  attrKey,
  attrValue
) =>
  skus.find(
    (sku) =>
      attrKeys.every(
        (key) => sku.new_meta[key].value === activeSKU?.new_meta[key].value
      ) && sku.new_meta[attrKey].value === attrValue
  );

const dknGetFallbackSKUByAttributeAndActiveSKU = (skus, attrKey, attrValue) =>
  skus.find((sku) => sku.new_meta[attrKey].value === attrValue);

const dknGetSKUMetaByAttributeAndActiveSKU = (
  skus,
  activeSKU,
  attrKey,
  attrValue
) => {
  const attributeMap = { ...activeSKU?.new_meta };
  delete attributeMap[attrKey];

  const attrKeys = Object.keys(attributeMap);

  const mainSKU = dknGetAvailableSKUByAttributeAndActiveSKU(
    skus,
    activeSKU,
    attrKeys,
    attrKey,
    attrValue
  );

  const fallbackSKU = mainSKU
    ? undefined
    : dknGetFallbackSKUByAttributeAndActiveSKU(skus, attrKey, attrValue);

  return {
    sku: mainSKU || fallbackSKU,
    fallbackSKU,
    isFallback: !mainSKU,
  };
};

window.dknGetAllProductAttributeValues = (skus) => {
  if (!skus) return {};
  const allSKUAttributes = Object.keys(skus[0]?.new_meta || {});

  return allSKUAttributes.reduce((acc, attribute) => {
    acc[attribute] = dknGetUniqueAttributeValuesFromSKUs(skus, attribute);
    return acc;
  }, {});
};

const dknGetProductAttributesByActiveSKU = (skus, activeSKU) => {
  const allAttributes = dknGetAllProductAttributeValues(skus);
  const allAttrKeys = Object.keys(allAttributes);
  return allAttrKeys.reduce((acc, attrKey) => {
    const {
      attributeLabel,
      master_attribute: masterAttribute,
      type,
    } = activeSKU.new_meta[attrKey];
    const values = allAttributes[attrKey].map((attrValue) => {
      const skuMeta = dknGetSKUMetaByAttributeAndActiveSKU(
        skus,
        activeSKU,
        attrKey,
        attrValue
      );
      return {
        value: attrValue,
        ...skuMeta,
      };
    });

    acc.push({
      values,
      master_attribute: masterAttribute,
      type,
      attributeLabel,
    });
    return acc;
  }, []);
};

const MASTER_ATTRIBUTE_MAP = {
  SIZE: 'size',
  COLOR: 'color',
};

window.dknCheckIfValueIsHexCode = (value) => {
  const hexCodeRegex = /^#([A-Fa-f0-9]{6}|[A-Fa-f0-9]{3})$/;
  const valueIsHexCode = hexCodeRegex.test(value || '');
  return valueIsHexCode;
};

window.dknGetAttributesFromSKU = (sku) =>
  sku?.attributes?.reduce((acc, attribute) => {
    const masterAttribute = attribute.master_attribute;
    const valueIsHexCode = dknCheckIfValueIsHexCode(attribute?.value || '');
    const type = valueIsHexCode
      ? MASTER_ATTRIBUTE_MAP.COLOR
      : MASTER_ATTRIBUTE_MAP.SIZE;

    acc[masterAttribute] = {
      ...attribute,
      attributeLabel:
        masterAttribute.toLowerCase() === 'color picker' &&
        type === MASTER_ATTRIBUTE_MAP.COLOR
          ? type
          : masterAttribute,
      type,
    };
    return acc;
  }, {});

window.dknSerializeSKUs = (skus) =>
  skus.map((sku) => ({
    ...sku,
    meta: getAttributesFromSKU(sku),
    new_meta: dknGetAttributesFromSKU(sku),
    inventory_quantity: sku.inventory,
    in_stock: sku.inventory === null || sku.inventory > 0,
  }));

window.dknGetActiveSKUFromUUID = (activeSkuUuid, skus) =>
  skus?.find((sku) => sku.uuid === activeSkuUuid) || {};

const dknSerializeProductData = (product) => {
  let serializedSKUs = dknSerializeSKUs(product?.skus || []);
  if (typeof getFormattedSKUS === 'function' && serializedSKUs?.length) {
    serializedSKUs = getFormattedSKUS(serializedSKUs);
  }
  if (typeof customSKUSerializer === 'function' && serializedSKUs?.length) {
    serializedSKUs = customSKUSerializer(serializedSKUs);
  }
  const attributes = dknGetAllProductAttributeValues(serializedSKUs);
  const { addOnsList = [], addOns = [] } =
    dknGetSerializedAddons(product) || {};
  let finalProduct = {
    ...product,
    ...languageSerializer(product),
    skus: serializedSKUs,
    attributes,
    addOnsList,
    addOns,
    skusApi: true,
  };
  if (typeof window?.getBundleSerializedProduct === 'function') {
    finalProduct = getBundleSerializedProduct(finalProduct);
  }
  return finalProduct;
};

window.dknAddProductsToProductsMap = (products = []) => {
  if (!products?.length) return;

  const productsMap = products?.reduce((map, product) => {
    if (!product) return map;
    map[product.uuid] = dknSerializeProductData(product);
    return map;
  }, {});

  DukaanData.PRODUCTS_MAP = {
    ...(DukaanData.PRODUCTS_MAP || {}),
    ...(productsMap || {}),
  };
};

// ---------------------------------------------------------------------------------------------------------------------
// quantity field renderer utils
// ---------------------------------------------------------------------------------------------------------------------

window.dknHandleProductQtyValueChange = (productContext) => {
  const { key, productUUID, skuUUID } = productContext;
  if (!productUUID) {
    return;
  }
  const product = DukaanData.PRODUCTS_MAP[productUUID];
  const activeSKU = dknGetActiveSKUFromUUID(skuUUID, product?.skus);
  if (!activeSKU) {
    if (typeof errorCallbackForQtyValueChange === 'function') {
      errorCallbackForQtyValueChange();
    }
    return;
  }

  // for maintaining min max value of input field
  const quantityInput = q$.selectById(
    `dkn-product-qty-${productUUID}-${key}`
  ).elem;
  if (quantityInput?.value) {
    if (Number(quantityInput.value) < Number(quantityInput.min)) {
      quantityInput.value = quantityInput.min;
    }
    if (Number(quantityInput.value) > Number(quantityInput.max)) {
      quantityInput.value = quantityInput.max;
      if (typeof enqueueSnackbar !== 'undefined') {
        enqueueSnackbar(
          DukaanData.DUKAAN_LANGUAGE.THE_SELLER_HAS_ONLY__INVENTORYQTY_OF_THESE_AVAILABLE.injectText(
            {
              inventoryQty: quantityInput.max,
            }
          ),
          true
        );
      }
    }
  }

  // re-render action buttons
  const actionButtonsWrapper = q$.selectById(
    `dkn-product-action-buttons-${productUUID}-${key}`
  ).elem;
  dknRenderActionButtons(productContext, actionButtonsWrapper);
};

window.dknChangeQuantityFieldValue = (productContext, qtyToAdd) => {
  const { key, productUUID } = productContext;
  const quantityInput = q$.selectById(
    `dkn-product-qty-${productUUID}-${key}`
  ).elem;
  if (qtyToAdd) {
    const quantity = Number(quantityInput.value) + Number(qtyToAdd || 1);
    quantityInput.value = quantity;
    if (typeof window?.customQuantityTextRenderer === 'function') {
      window.customQuantityTextRenderer(productContext, quantity);
    }
  }
  dknHandleProductQtyValueChange(productContext);
};

window.dknQuantityFieldAdditionalRenderer = (productContext, parentElement) => {
  const { key, productUUID, skuUUID, addonString } = productContext;
  const controlUpArrow = q$.select(
    '.dkn-increase-product-qty-input',
    parentElement
  ).elem;
  const controlDownArrow = q$.select(
    '.dkn-decrease-product-qty-input',
    parentElement
  ).elem;

  if (controlUpArrow) {
    controlUpArrow.setAttribute(
      'onclick',
      `dknChangeQuantityFieldValue({key: '${key}', productUUID: '${productUUID}',skuUUID: '${skuUUID}', addonString: '${addonString}'}, 1)`
    );
  }

  if (controlDownArrow) {
    controlDownArrow.setAttribute(
      'onclick',
      `dknChangeQuantityFieldValue({key: '${key}', productUUID: '${productUUID}', skuUUID: '${skuUUID}', addonString: '${addonString}'}, -1)`
    );
  }
};

// ---------------------------------------------------------------------------------------------------------------------
// variant form utils
// ---------------------------------------------------------------------------------------------------------------------

const dknSizeVariantSerializer = (sizes) => {
  let sizeAttr = [...(sizes || [])];
  if (typeof sortSkuBySizes !== 'undefined' && Boolean(sizeAttr?.length)) {
    sizeAttr = sortSkuBySizes(sizeAttr);
  }
  return sizeAttr;
};

const dknColorVariantSerializer = (colors) => colors;

window.dknGetSizeVariantHeading = ({ attrLabel }) => {
  const headingText = attrLabel
    ? DukaanData.DUKAAN_LANGUAGE.SELECT__ATTRIBUTE.injectText({
        attribute: attrLabel,
      })
    : DukaanData.DUKAAN_LANGUAGE.SELECT__ATTRIBUTE.injectText({
        attribute: DukaanData.DUKAAN_LANGUAGE.SIZE,
      });
  return headingText;
};

const dknGetColorVariantHeading = ({ attrLabel }) => {
  const headingText = attrLabel
    ? DukaanData.DUKAAN_LANGUAGE.SELECT__ATTRIBUTE.injectText({
        attribute: attrLabel,
      })
    : DukaanData.DUKAAN_LANGUAGE.SELECT__ATTRIBUTE.injectText({
        attribute: DukaanData.DUKAAN_LANGUAGE.COLOR,
      });
  return headingText;
};

const dknGetSingleColorVariantItem = (
  productContext,
  attributeKey,
  attributeValue,
  options
) => {
  const { key, productUUID, skuUUID } = productContext;
  const {
    templateId = 'dkn-color-variant-item-template',
    checkFieldByDefault = false,
    errorCallback = () => {},
  } = options || {};

  if (!attributeValue || !productUUID || !templateId) {
    if (typeof errorCallback === 'function') {
      errorCallback();
    }
    return null;
  }

  const activeSKU = dknGetActiveSKUFromUUID(
    skuUUID,
    DukaanData.PRODUCTS_MAP[productUUID]?.skus
  );

  const uniqueId = `${attributeKey}-${attributeValue}-${productUUID}-${key}`;
  const colorItem = q$.selectById(templateId).getTemplateContent().elem;
  const colorInput = q$.select('.dkn-variant-input', colorItem).elem;
  const colorLabel = q$.select('.dkn-variant-label', colorItem).elem;
  const colorSVG = q$.select('.dkn-color-variant-tick-svg', colorItem).elem;
  const colorBgElement = q$.select(
    '.dkn-color-variant-bg-color',
    colorItem
  ).elem;

  q$.selectAll('.dkn-color-variant-value', colorItem).modifyTextContentAll(
    attributeValue
  );
  q$.selectAll('.dkn-variant-primary-image', colorItem).setAttributeAll(
    'src',
    getCdnUrl(activeSKU?.primary_image, 100)
  );
  colorInput.setAttribute('name', attributeKey);
  colorInput.setAttribute('id', uniqueId);
  colorInput.setAttribute('value', `${attributeValue}`);
  dknSetProductVariantClickListener(colorInput, productContext);

  colorLabel?.setAttribute('for', uniqueId);

  if (colorBgElement) {
    colorBgElement.style.setProperty('background', `${attributeValue}`);
  }

  // default checked state
  if (checkFieldByDefault) {
    colorInput.checked = true;
  }

  // svg color for tick color
  const { isLight } = dknGetIfColorIsLightOrDark(attributeValue);

  if (colorSVG) {
    colorSVG.setAttribute('color', isLight ? '#1a181e' : '#ffffff');
    q$.select('path', colorSVG).elem.style.setProperty(
      'color',
      `${isLight ? '#1a181e' : '#ffffff'}`
    );
  }

  return colorItem;
};

window.dknGetSingleSizeVariantItem = (
  productContext,
  attributeKey,
  attributeValue,
  options
) => {
  const { key, productUUID, skuUUID, inStock } = productContext;
  const {
    templateId = 'dkn-color-variant-item-template',
    checkFieldByDefault = false,
    errorCallback = () => {},
  } = options || {};

  if (!attributeValue || !productUUID) {
    if (typeof errorCallback === 'function') {
      errorCallback();
    }
    return null;
  }

  const activeSKU = dknGetActiveSKUFromUUID(
    skuUUID,
    DukaanData.PRODUCTS_MAP[productUUID]?.skus
  );
  const uniqueId = `${attributeKey}-${attributeValue}-${productUUID}-${key}`;
  const sizeItem = q$.selectById(templateId).getTemplateContent().elem;
  const sizeInput = q$.select('.dkn-variant-input', sizeItem).elem;
  const sizeLabel = q$.select('.dkn-variant-label', sizeItem).elem;
  sizeInput.setAttribute('name', attributeKey);
  sizeInput.setAttribute('id', uniqueId);
  sizeInput.setAttribute('value', `${attributeValue}`);
  sizeLabel?.setAttribute('for', uniqueId);
  sizeLabel?.setAttribute('title', attributeValue);
  if (!inStock) {
    sizeInput?.classList?.add('dkn-variant-out-of-stock');
    sizeLabel?.classList?.add('dkn-variant-out-of-stock');
  }

  q$.selectAll('.dkn-size-variant-value', sizeItem).modifyTextContentAll(
    attributeValue
  );
  q$.selectAll('.dkn-variant-primary-image', sizeItem).setAttributeAll(
    'src',
    getCdnUrl(activeSKU?.primary_image, 100)
  );

  const {
    selling_price: sellingPrice = null,
    original_price: originalPrice = null,
  } = activeSKU || {};
  if (originalPrice && sellingPrice) {
    q$.selectAll(
      '.dkn-size-variant-selling-price',
      sizeItem
    ).modifyTextContentAll(formatMoney(sellingPrice));
    const discount = getDiscountPercentValue(sellingPrice, originalPrice);
    if (discount) {
      const discountText =
        typeof customDiscountFormatter === 'function'
          ? customDiscountFormatter(discount)
          : `(${discount}% OFF)`;
      q$.selectAll('.dkn-size-variant-discount', sizeItem)
        .modifyTextContentAll(discountText)
        .removeClassAll('hidden');
      q$.selectAll('.dkn-size-variant-original-price', sizeItem)
        .modifyTextContentAll(formatMoney(originalPrice))
        .removeClassAll('hidden');
      q$.selectAll('.dkn-size-variant-savings-text', sizeItem)
        .modifyTextContentAll(
          `Save ${formatMoney(originalPrice - sellingPrice)}`
        )
        .removeClassAll('hidden');
    } else {
      q$.selectAll('.dkn-size-variant-discount', sizeItem).addClassAll(
        'hidden'
      );
      q$.selectAll('.dkn-size-variant-original-price', sizeItem).addClassAll(
        'hidden'
      );
      q$.selectAll('.dkn-size-variant-savings-text', sizeItem).addClassAll(
        'hidden'
      );
    }
  }

  if (typeof customSizeVariantFormatter === 'function') {
    customSizeVariantFormatter(sizeItem, activeSKU, {
      attributeValue,
      attributeKey,
    });
  }

  dknSetProductVariantClickListener(sizeInput, productContext);

  if (checkFieldByDefault) {
    sizeInput.checked = true;
  }
  return sizeItem;
};

const dknGetAddonVariantHeading = ({ attrLabel }) => attrLabel || 'Add-Ons';

const dknRenderAddonGroups = (
  productContext,
  addOnGroups,
  mountElement,
  config
) => {
  const { addonString } = productContext;
  addOnGroups.forEach((addOnGroup) => {
    if (!addOnGroup?.add_ons?.length) return;

    // variant section
    const variantSection = q$
      .selectById(config.variantSectionTemplateId)
      .getTemplateContent().elem;

    // variant section list
    const variantSectionList = q$.select(
      '.dkn-variant-section-list',
      variantSection
    ).elem;

    variantSectionList.classList.add(`dkn-variant-section-addon-list`);

    // select variant text
    const headingText = config.getVariantHeadingFn({
      attrLabel: addOnGroup.name,
    });
    q$.selectAll(
      '.dkn-variant-section-heading',
      variantSection
    ).modifyTextContentAll(headingText);

    if (config?.showSelectLabel === false) {
      q$.selectAll('.dkn-variant-section-heading', variantSection).addClassAll(
        'hidden'
      );
    }

    if (addOnGroup?.mandatory) {
      q$.selectAll(
        '.dkn-variant-mandatory-symbol',
        variantSection
      ).removeClassAll('hidden');
    } else {
      q$.selectAll('.dkn-variant-mandatory-symbol', variantSection).addClassAll(
        'hidden'
      );
    }
    addOnGroup?.add_ons?.forEach((addon) => {
      const addonItem = config.getSingleItemFn(productContext, 'addon', addon, {
        templateId: config.singleItemTemplateId,
        checkFieldByDefault: addonString?.includes(addon.uuid) || false,
      });
      variantSectionList.appendChild(addonItem);
    });

    mountElement.appendChild(variantSection);
  });
};

const dknGetSingleAddonVariantItem = (
  productContext,
  attributeKey,
  attributeData,
  options
) => {
  const { key, productUUID } = productContext;
  const {
    templateId = 'dkn-addon-variant-item-template',
    checkFieldByDefault = false,
    errorCallback = () => {},
  } = options || {};

  if (!productUUID) {
    if (typeof errorCallback === 'function') {
      errorCallback();
    }
    return null;
  }

  const { uuid: attributeValue, name: addonName, price } = attributeData;
  const uniqueId = `${attributeKey}-${attributeValue}-${productUUID}-${key}`;
  const addonItem = q$.selectById(templateId).getTemplateContent().elem;
  const addonInput = q$.select('.dkn-variant-input', addonItem).elem;
  const addonLabel = q$.select('.dkn-variant-label', addonItem).elem;
  addonInput.setAttribute('name', attributeKey);
  addonInput.setAttribute('id', uniqueId);
  addonInput.setAttribute('data-addon-uuid', `${attributeValue}`);
  addonInput.setAttribute('value', `${attributeValue}`);
  addonLabel?.setAttribute('for', uniqueId);
  q$.selectAll('.dkn-addon-variant-name', addonItem).modifyTextContentAll(
    addonName
  );
  q$.selectAll('.dkn-addon-variant-price', addonItem).modifyTextContentAll(
    formatMoney(price)
  );

  dknSetProductVariantClickListener(addonInput, productContext);

  if (checkFieldByDefault) {
    addonInput.checked = true;
  }
  return addonItem;
};

const dknSetProductVariantClickListener = (attributeItem, productContext) => {
  const { key, productUUID, skuUUID, addonString } = productContext;
  attributeItem.setAttribute(
    'onclick',
    `dknHandleProductVariantClick(event, {key: '${key}', productUUID: '${productUUID}', skuUUID: '${skuUUID}', addonString: '${addonString}'})`
  );
};

const dknGetProductVariantsConfig = ({
  getCustomVariantsConfig:
    providedGetCustomVariantsConfig = window.getCustomVariantsConfig,
  ...productContext
}) => {
  // custom config if exists
  const customConfig =
    typeof providedGetCustomVariantsConfig === 'function'
      ? providedGetCustomVariantsConfig(productContext)
      : {};

  const finalConfig = {
    ...customConfig,
    size: {
      variantSerializer: dknSizeVariantSerializer,
      getVariantHeadingFn: dknGetSizeVariantHeading,
      getSingleItemFn: dknGetSingleSizeVariantItem,
      singleItemTemplateId: 'dkn-size-variant-item-template',
      variantSectionTemplateId: 'dkn-size-variant-section-template',
      isMandatoryField: true,
      showSelectLabel: true,
      ...customConfig?.size,
    },
    color: {
      variantSerializer: dknColorVariantSerializer,
      getVariantHeadingFn: dknGetColorVariantHeading,
      getSingleItemFn: dknGetSingleColorVariantItem,
      singleItemTemplateId: 'dkn-color-variant-item-template',
      variantSectionTemplateId: 'dkn-color-variant-section-template',
      isMandatoryField: true,
      showSelectLabel: true,
      ...customConfig?.color,
    },
    addon: {
      variantSerializer: () => {},
      getVariantHeadingFn: dknGetAddonVariantHeading,
      getSingleItemFn: dknGetSingleAddonVariantItem,
      singleItemTemplateId: 'dkn-addon-variant-item-template',
      variantSectionTemplateId: 'dkn-variant-section-template',
      showSelectLabel: true,
      ...customConfig?.addon,
    },
  };
  return finalConfig;
};

const dknGetActiveSKUKey = (skuUUID, addonString) => {
  if (!addonString) return skuUUID;
  const addOnUUIDs = addonString.split(',');
  const productKey = [skuUUID, addOnUUIDs.sort().join('__')]
    .filter((element) => !!element)
    .join('::');
  return productKey;
};

const dknGetBagProductBasedOnSKUAndAddons = (
  productUUID,
  activeSkuUuid,
  addonString
) => {
  const productKey =
    dknGetActiveSKUKey(activeSkuUuid, addonString) || activeSkuUuid;
  const bagProduct = getBagProductBySkuAndProductUuid(productUUID, productKey);
  return bagProduct;
};

window.dknInitializeSelectDropdown = (parentElement = document) => {
  const selectFieldWrappers = q$.selectAll(
    '.dkn-custom-dropdown-field-wrapper',
    parentElement
  ).elem;
  selectFieldWrappers?.forEach((selectFieldWrapper) => {
    const selectFieldDropdown = selectFieldWrapper?.nextElementSibling;
    const randomNo = Math.floor(Math.random() * 1000);
    selectFieldWrapper.setAttribute(
      'id',
      `dkn-custom-dropdown-field-wrapper-${randomNo}`
    );
    selectFieldDropdown.setAttribute(
      'id',
      `dkn-custom-dropdown-list-${randomNo}`
    );
    selectFieldWrapper.setAttribute(
      'onclick',
      `dknHandleSelectFieldClick('${randomNo}')`
    );
    const selectItems = q$.selectAll(
      '.dkn-custom-dropdown-list-item-value',
      selectFieldDropdown
    ).elem;
    selectItems.forEach((item) => {
      if (item?.checked) {
        const selectedValue = q$.select(
          '.dkn-custom-dropdown-selected-value',
          selectFieldWrapper
        );
        if (!selectedValue?.elem) return;

        const { variantType } = selectedValue.elem.dataset || {};
        if (variantType === 'color') {
          selectedValue.elem.style.setProperty('background', `${item?.value}`);
        } else {
          selectedValue.modifyTextContent(item?.value);
        }
      }
    });
  });
};

window.dknHandleSelectFieldClick = (randomNo) => {
  q$.selectAll('.dkn-custom-dropdown-list').addClassAll('d-none');
  q$.selectById(`dkn-custom-dropdown-list-${randomNo}`).removeClass('d-none');
};

window.dknHandleOutsideClickForSelect = (event, parentElement = document) => {
  const { target } = event;
  let dropdownElementClicked = false;
  const selectFieldWrappers = q$.selectAll(
    '.dkn-custom-dropdown-field-wrapper',
    parentElement
  ).elem;

  selectFieldWrappers?.forEach((selectFieldWrapper) => {
    if (
      selectFieldWrapper?.contains(target) ||
      selectFieldWrapper?.nextElementSibling?.contains(target)
    ) {
      dropdownElementClicked = true;
    }
  });

  // hide all dropdowns
  if (!dropdownElementClicked) {
    q$.selectAll('.dkn-custom-dropdown-list').addClassAll('d-none');
  }
};

window.dknHandleProductVariantClick = (event, productContext) => {
  const { key, productUUID, skuUUID } = productContext;
  if (!productUUID) return;

  const product = DukaanData.PRODUCTS_MAP[productUUID];
  const activeSKU = dknGetActiveSKUFromUUID(skuUUID, product?.skus);

  if (!activeSKU) return;

  q$.selectAll('.variant-form-error-text').addClassAll('hidden');
  const formData = new FormData(
    q$.select(`form#dkn-variant-form-${productUUID}-${key}`).elem
  );
  const data = [...formData.entries()].reduce(
    (acc, [formElementKey, value]) => {
      if (formElementKey === 'addon') {
        acc[formElementKey] = [...(acc[formElementKey] || []), value];
      } else {
        acc[formElementKey] = value;
      }
      return acc;
    },
    {}
  );
  const addonString = data?.addon?.join(',');
  productContext = { ...productContext, addonString };

  // render product details
  const productDetailsElement = q$.select('.dkn-product-page-information').elem;
  if (productDetailsElement) {
    reRenderProductDetails(productDetailsElement, activeSKU, product);
  }

  // render product variant form
  const variantFormElement = q$.select(
    `form#dkn-variant-form-${productUUID}-${key}`
  ).elem;
  variantFormElement.innerHTML = '';
  const renderAddons = DukaanData.DUKAAN_STORE.store_category === 6;
  dknRenderProductVariantForm(productContext, variantFormElement, {
    renderAddons,
  });

  // render external fields first
  const externalQuantityFieldElement = q$.selectById(
    `dkn-product-qty-wrapper-${productUUID}-${key}`
  ).elem;
  if (externalQuantityFieldElement) {
    dknRenderProductQuantityInputField(
      productContext,
      externalQuantityFieldElement
    );
  }

  // render add to bag buttons
  const actionButtonWrappers = q$.selectAll(
    `#dkn-product-action-buttons-${productUUID}-${key}`
  ).elem;
  actionButtonWrappers.forEach((actionButtonsWrapperElement) => {
    dknRenderActionButtons(productContext, actionButtonsWrapperElement);
  });

  if (typeof handleModalChanges === 'function')
    handleModalChanges(product, activeSKU);

  if (typeof handleCustomProductVariantChange === 'function')
    handleCustomProductVariantChange(product, activeSKU, productContext);

  dknViewContentEvent(activeSKU, product);

  fetchCouponsAndOffersOnPDP({ sku: activeSKU });

  const addToWishlistElements = q$.selectAll(
    `#dkn-product-wishlist-button-${productUUID}-${key}`
  ).elem;

  addToWishlistElements?.forEach((addToWishlistElement) => {
    addToWishlistElement.dataset.productUuid = productUUID;
    addToWishlistElement.dataset.skuUuid = skuUUID;
    addToWishlistElement.dataset.key = key;
    addToWishlistButtonRenderer(addToWishlistElement);
  });
};

// ---------------------------------------------------------------------------------------------------------------------
// add to bag renderer utils
// ---------------------------------------------------------------------------------------------------------------------

window.dknHandleAddToBagButtonWithQtyFieldClick = (
  event,
  skuUUID,
  productUUID,
  orderedQty,
  { qtyToAdd, addEventName, addonString, hasAppendQty = false }
) => {
  if (!Number(orderedQty) || hasAppendQty) {
    addToBag(event, skuUUID, productUUID, {
      qtyToAdd: Number(qtyToAdd),
      addEventName,
      addonString,
    });
  } else {
    addToBag(event, skuUUID, productUUID, {
      qtyToUpdate: Number(qtyToAdd),
      addEventName,
      addonString,
    });
  }
};

window.dknProductDataRenderer = (productContext, parentElement, options) => {
  const { key, productUUID, skuUUID } = productContext;
  const product = DukaanData.PRODUCTS_MAP[productUUID];
  const activeSKU = product?.skus?.find((sku) => sku.uuid === skuUUID) || {};
  const { imageCdnValue = window?.DukaanData?.PRODUCT_IMAGE_CDN_SIZE || 700 } =
    options || {};
  const {
    id,
    uuid,
    name,
    slug,
    description,
    meta,
    unit,
    base_qty: baseQty,
  } = product;

  const sellingPrice = activeSKU?.selling_price || product?.selling_price;
  const originalPrice = activeSKU?.original_price || product?.original_price;
  const inStock = activeSKU?.in_stock || product?.in_stock;
  const inventory = activeSKU?.inventory || product?.inventory;
  const image =
    activeSKU && !activeSKU?.primary_image?.includes('category-def.jpg')
      ? activeSKU?.primary_image
      : product?.image;

  const discountPercent = getDiscountPercentValue(sellingPrice, originalPrice);
  const foodTypeIcon =
    typeof getFoodTypeIcon === 'function' ? getFoodTypeIcon(meta) : null;

  // adding relevant data attributes
  q$.selectAll('[data-product-id]', parentElement).setDataAttributeAll(
    'productId',
    id
  );
  q$.selectAll('[data-product-uuid]', parentElement).setDataAttributeAll(
    'productUuid',
    uuid
  );

  parentElement.setAttribute('id', `dkn-product-data-parent-${uuid}-${key}`);

  // adding relevant data to all elements of product card
  q$.selectAll('.dkn-product-link', parentElement).setAttributeAll(
    'href',
    getProductPageUrl(product)
  );

  q$.selectAll(
    '.dkn-product-name, .dkn-product-card-name',
    parentElement
  ).modifyTextContentAll(name);

  dknImageRenderer(
    image,
    '.dkn-product-image, .dkn-product-card-image',
    parentElement,
    {
      imageCdnWidth: imageCdnValue,
    }
  );

  q$.selectAll(
    '.dkn-product-image, .dkn-product-card-image',
    parentElement
  ).setAttributeAll('data-image-src', image);

  if (inventory) {
    q$.selectAll(
      '.dkn-product-inventory-count-wrapper',
      parentElement
    ).removeClassAll('hidden');
    q$.selectAll(
      '.dkn-product-inventory-count',
      parentElement
    ).modifyTextContentAll(inventory);
  } else {
    q$.selectAll(
      '.dkn-product-inventory-count-wrapper',
      parentElement
    ).addClassAll('hidden');
  }

  if (description) {
    const santizedDescription = HtmlSanitizer?.SanitizeHtml(description);
    if (santizedDescription) {
      q$.selectAll(
        '.dkn-product-description, .dkn-product-card-description',
        parentElement
      ).modifyInnerHTMLAll(santizedDescription);
    }
  } else {
    q$.selectAll(
      '.dkn-product-description, .dkn-product-card-description',
      parentElement
    ).addClassAll('hidden');
  }

  if (foodTypeIcon) {
    q$.selectAll(
      '.dkn-product-food-type-icon, .dkn-product-card-food-type-icon',
      parentElement
    )
      .modifyInnerHTMLAll(getFoodTypeIcon(meta))
      .removeClassAll('hidden');
  } else {
    q$.selectAll(
      '.dkn-product-food-type-icon, .dkn-product-card-food-type-icon',
      parentElement
    ).addClassAll('hidden');
  }

  if (unit) {
    const unitText = `${DukaanData.DUKAAN_LANGUAGE.PER}${
      baseQty === 1 ? '' : ` ${baseQty}`
    } ${unit}`;

    if (unitText) {
      q$.selectAll(
        '.dkn-product-item-unit, .dkn-product-card-item-unit',
        parentElement
      ).modifyTextContentAll(unitText);
    }
  }

  // brands related rendering
  if (product?.brands?.length) {
    const { logo, name: brandName } = product.brands[0];

    // brand logo
    dknImageRenderer(
      logo,
      '.dkn-product-brand-image, .dkn-product-card-brand-image',
      parentElement,
      {
        imageCdnWidth: 100,
      }
    );

    // brand name
    if (brandName) {
      q$.selectAll(
        '.dkn-product-brand-name, .dkn-product-card-brand-name',
        parentElement
      ).modifyTextContentAll(brandName);
    } else {
      q$.selectAll(
        '.dkn-product-brand-name, ..dkn-product-card-brand-name',
        parentElement
      ).addClassAll('hidden');
    }
  } else {
    q$.selectAll(
      '.dkn-product-brand-details, .dkn-product-card-brand-name',
      parentElement
    ).addClassAll('hidden');
  }

  // pricing related rendering
  q$.selectAll(
    '.dkn-product-selling-price, .dkn-product-card-selling-price',
    parentElement
  ).modifyTextContentAll(formatMoney(sellingPrice));

  if (discountPercent > 0) {
    q$.selectAll(
      '.dkn-product-original-price, .dkn-product-card-original-price',
      parentElement
    )
      .modifyTextContentAll(formatMoney(originalPrice))
      .removeClassAll('hidden');

    let discountText = '';
    if (options?.getCustomDiscountText) {
      discountText = options.getCustomDiscountText(discountPercent);
    } else {
      discountText = `${discountPercent}% OFF`;
    }

    q$.selectAll(
      '.dkn-product-discount, .dkn-product-card-discount',
      parentElement
    )
      .modifyTextContentAll(discountText)
      .removeClassAll('hidden');

    q$.selectAll('.dkn-product-you-save-text', parentElement)
      .modifyTextContentAll(
        `You save ${formatMoney(originalPrice - sellingPrice)}.`
      )
      .removeClassAll('hidden');
  } else {
    q$.selectAll(
      '.dkn-product-original-price, .dkn-product-card-original-price',
      parentElement
    ).addClassAll('hidden');
    q$.selectAll(
      '.dkn-product-discount, .dkn-product-card-discount',
      parentElement
    ).addClassAll('hidden');
  }

  if (inventory <= 10 && inventory) {
    q$.selectAll('.dkn-stock-left-message', parentElement)
      .removeClassAll('hidden')
      .modifyTextContentAll(
        `${DukaanData.DUKAAN_LANGUAGE.ONLY__INVENTORY_LEFT_IN_STOCK_HURRY_UP}!`.injectText(
          {
            inventory,
          }
        )
      );
  } else {
    q$.selectAll('.dkn-stock-left-message', parentElement).addClassAll(
      'hidden'
    );
  }

  if (inStock) {
    q$.selectAll('.dkn-product-stock-text', parentElement)
      .modifyTextContent(DukaanData.DUKAAN_LANGUAGE.IN_STOCK)
      .addClassAll('text-c-green')
      .removeClassAll('text-c-red');
  } else {
    q$.selectAll('.dkn-product-stock-text', parentElement)
      .modifyTextContent(DukaanData.DUKAAN_LANGUAGE.OUT_OF_STOCK)
      .removeClassAll('text-c-green')
      .addClassAll('text-c-red');
  }

  // calling custom renderer if it exists
  if (options?.additionalRenderer) {
    options.additionalRenderer(productContext, parentElement, options);
  }
};

// window.dknProductCardRenderer = (productContext, mountElem, options) => {
//   const { templateId = 'dkn-product-card-template', productCardClasses = [] } =
//     options;

//   const productCardTemplate = window.q$
//     .selectById(templateId)
//     .getTemplateContent().elem;

//   const productCard = q$.select('.dkn-product-card', productCardTemplate);

//   // add custom classes to product card
//   if (productCardClasses?.length) {
//     productCard.classList.add(...productCardClasses);
//   }

//   // add hash for product card image size optimzation
//   const randomHashForProductCard = generateRandomString(10);
//   window.q$
//     .selectAll('.dkn-product-card-image', productCard)
//     .setAttributeAll('data-hash', randomHashForProductCard);

//   // render add to bag button
//   const showAddToBagButton =
//     window.DukaanData?.DUKAAN_THEME_DATA?.meta?.advanced?.product
//       ?.showAddToBagOnProductCard;
//   const addToBagElement = window.q$.select(
//     'add-to-bag-button-with-variants',
//     productCard
//   ).elem;
//   if (addToBagElement) {
//     if (
//       (typeof showAddToBagButton !== 'undefined' && showAddToBagButton) ||
//       typeof showAddToBagButton === 'undefined'
//     ) {
//       addToBagButtonWithVariantsRenderer(addToBagElement);
//     } else {
//       addToBagElement.classList.add('hidden');
//     }
//   }

//   // render product data
//   dknProductDataRenderer(productContext, productCard, options);

//   mountElem.appendChild(productCard);

//   // product card image size optimzation
//   if (typeof window.getCustomProductCardImageUrl !== 'function') {
//     const productCardImages = mountElem.querySelectorAll(
//       `[data-hash="${randomHashForProductCard}"]`
//     );
//     productCardImages.forEach((productCardImage) => {
//       const finalImage = productCardImage?.dataset?.imageSrc;
//       if (!finalImage) return;

//       let imageUrl = window.getCdnUrl(
//         finalImage,
//         window?.DukaanData?.PRODUCT_IMAGE_CDN_SIZE || 700
//       );

//       imageUrl = window.getCustomProductCardImageUrl(finalImage, {
//         imageElement: productCardImage,
//       });

//       productCardImage.setAttribute('src', imageUrl);
//     });
//   }
// };

// ---------------------------------------------------------------------------------------------------------------------
// product variant form renderer
// ---------------------------------------------------------------------------------------------------------------------

window.dknRenderProductVariantForm = (
  productContext,
  variantFormElement,
  options
) => {
  const { key, productUUID, skuUUID, productCard } = productContext;
  const {
    renderAddons = false,
    // eslint-disable-next-line no-unused-vars
    additionalRenderer = null,
    renderActiveSKUStateByDefault = true,
  } = options || {};
  const variantsConfig = dknGetProductVariantsConfig(productContext);
  const { definedMasterAttribute = '' } =
    DukaanData?.DUKAAN_STORE?.additional_meta || {};

  const activeProduct = DukaanData.PRODUCTS_MAP[productUUID];
  const { skus, addOns = [] } = activeProduct;

  // check if the product has any attributes or addons
  if (
    !(skus[0]?.attributes?.length > 0 || addOns?.length > 0) ||
    !variantFormElement
  ) {
    return;
  }

  const activeSKU =
    dknGetActiveSKUFromUUID(skuUUID, activeProduct?.skus) ||
    dknGetFirstAvailableSKU(activeProduct?.skus);

  const serializedAttributes = dknGetProductAttributesByActiveSKU(
    activeProduct.skus,
    activeSKU
  );

  variantFormElement.setAttribute(
    'id',
    `dkn-variant-form-${productUUID}-${key}`
  );

  const defaultMasterAttribute = serializedAttributes?.[0];
  const masterAttribute = definedMasterAttribute
    ? serializedAttributes.find(
        (s) => s.master_attribute === definedMasterAttribute
      ) || defaultMasterAttribute
    : defaultMasterAttribute;

  serializedAttributes?.forEach((attribute) => {
    if (!attribute?.values?.length > 0) return;

    const attrKey = attribute.master_attribute;
    let config = variantsConfig[attribute.type];
    if (variantsConfig?.hasAttributeKeyBasedMapping) {
      config =
        variantsConfig?.[attrKey?.toLowerCase()] ||
        variantsConfig[attribute.type];
    }
    // variant section
    const variantSection = q$
      .selectById(config.variantSectionTemplateId)
      .getTemplateContent().elem;

    q$.select('.dkn-variant-section', variantSection).addClass(
      `dkn-${attribute.type}-variant-section`,
      `dkn-${removeWhiteSpace(
        attribute.attributeLabel.toLowerCase()
      )}-attr-section`
    );
    // variant section list
    const variantSectionList = q$.select(
      '.dkn-variant-section-list',
      variantSection
    ).elem;
    variantSectionList.classList.add(
      `dkn-variant-section-${attribute.type}-list`,
      `${attribute.type}-selection-list`
    );
    const headingText = config.getVariantHeadingFn({
      attrLabel: attribute.attributeLabel,
    });
    q$.selectAll(
      '.dkn-variant-section-heading',
      variantSection
    ).modifyTextContentAll(headingText);

    if (config?.showSelectLabel === false) {
      q$.selectAll('.dkn-variant-section-heading', variantSection).addClassAll(
        'hidden'
      );
    }

    // serialize attribute if required
    let attrList = attribute.values || [];
    if (typeof config.variantSerializer === 'function') {
      attrList = config.variantSerializer(attrList);
    }

    q$.selectAll(
      '.dkn-active-variant-value',
      variantSection
    ).modifyTextContentAll(activeSKU?.new_meta[attrKey]?.value);

    if (activeSKU.inventory) {
      q$.selectAll(
        '.dkn-active-variant-inventory-left',
        variantSection
      ).modifyTextContentAll(`Last ${activeSKU.inventory} left`);
    } else {
      q$.selectAll(
        '.dkn-active-variant-inventory-left',
        variantSection
      ).addClassAll('hidden');
    }
    attrList?.forEach((attributeItem) => {
      // don't render variants if they don't exist for master attribute
      if (
        attributeItem.isFallback &&
        masterAttribute.master_attribute !== attrKey
      )
        return;

      const attrItem = config.getSingleItemFn(
        {
          key,
          productUUID,
          skuUUID: attributeItem.sku.uuid,
          inStock:
            attributeItem.sku.inventory === null ||
            attributeItem.sku.inventory > 0,
        },
        attrKey,
        attributeItem.value,
        {
          templateId: config.singleItemTemplateId,
          checkFieldByDefault:
            activeSKU?.new_meta[attrKey]?.value === attributeItem.value &&
            renderActiveSKUStateByDefault,
          variantSectionList,
        }
      );
      variantSectionList.appendChild(attrItem);
    });

    if (typeof config?.variantSectionAdditionalRenderer === 'function') {
      config?.variantSectionAdditionalRenderer(
        variantSectionList,
        { key, productUUID, productCard },
        {
          attrKey,
          attrValue: activeSKU?.new_meta[attrKey]?.value,
        }
      );
    }

    // append variant section to the form
    variantFormElement.appendChild(variantSection);
  });

  if (addOns?.length > 0 && renderAddons) {
    dknRenderAddonGroups(
      productContext,
      addOns,
      variantFormElement,
      variantsConfig.addon
    );
  }

  // initialize drop downs if present
  dknInitializeSelectDropdown(variantFormElement);

  // render size chart if present
  if (window?.DukaanData?.SIZE_CHART_LIST?.length > 0) {
    if (typeof renderSizeChart !== 'undefined') renderSizeChart();
  }

  if (typeof window?.initVariantSliders === 'function') {
    initVariantSliders();
  }

  if (typeof productVariantFormAdditionalRenderer === 'function') {
    productVariantFormAdditionalRenderer(
      productContext,
      variantFormElement,
      options
    );
  }
};

// ---------------------------------------------------------------------------------------------------------------------
// quantity field renderer
// ---------------------------------------------------------------------------------------------------------------------

window.dknRenderProductQuantityInputField = (
  productContext,
  quantityField,
  options
) => {
  const { key, productUUID, skuUUID, addonString } = productContext;
  const product = DukaanData.PRODUCTS_MAP[productUUID];
  const activeSKU = product?.skus?.find((sku) => sku.uuid === skuUUID) || {};
  const bagProduct = dknGetBagProductBasedOnSKUAndAddons(
    productUUID,
    activeSKU.uuid,
    addonString
  );

  const quantityInput = q$.select('.dkn-product-qty-input', quantityField).elem;
  const quantityLabel = q$.select('.dkn-product-qty-label', quantityField).elem;

  const allowedAddToBagQty = window?.DukaanData?.allowedAddToBagQty;
  const defaultInventoryValue = allowedAddToBagQty || 99;
  const inventory = Math.min(
    activeSKU.inventory_quantity || 99,
    defaultInventoryValue
  );

  const hasAppendQty = quantityInput.dataset.appendQty;

  const defaultFieldValue = hasAppendQty ? 1 : bagProduct?.ordered_qty || 1;
  quantityInput.setAttribute('id', `dkn-product-qty-${productUUID}-${key}`);
  quantityLabel?.setAttribute('for', `dkn-product-qty-${productUUID}-${key}`);
  quantityLabel?.setAttribute(
    'id',
    `dkn-product-qty-label-${productUUID}-${key}`
  );
  quantityField.setAttribute(
    'id',
    `dkn-product-qty-wrapper-${productUUID}-${key}`
  );
  quantityInput.value = defaultFieldValue;
  quantityInput.setAttribute('max', `${inventory}`);
  quantityInput.setAttribute('min', '1');
  quantityInput.setAttribute(
    'onkeyup',
    `dknHandleProductQtyValueChange({key: '${key}', productUUID: '${productUUID}',skuUUID: '${skuUUID}', addonString: '${addonString}'})`
  );

  if (typeof window?.customQuantityTextRenderer === 'function') {
    window.customQuantityTextRenderer(
      productContext,
      defaultFieldValue,
      quantityField
    );
  }

  dknQuantityFieldAdditionalRenderer(productContext, quantityField, options);
};

// ---------------------------------------------------------------------------------------------------------------------
// action buttons renderer
// ---------------------------------------------------------------------------------------------------------------------

window.dknRenderActionButtons = (productContext, mountElem, options = {}) => {
  const { key, productUUID, skuUUID, addonString } = productContext;
  if (!mountElem || !productUUID) return;
  const {
    renderActiveSKUStateByDefault = true,
    renderFunctions = {},
    additionalRenderer = () => {},
  } = options || {};
  mountElem.setAttribute(
    'id',
    `dkn-product-action-buttons-${productUUID}-${key}`
  );
  const addToBagEventName = options?.addToBagEventName;
  const addToBagElement = q$.select('add-to-bag-button', mountElem).elem;
  const addToBagWithVariantsElement = q$.select(
    'add-to-bag-button-with-variants',
    mountElem
  ).elem;
  const addToBagElementWithExternalFieldElement = q$.select(
    'add-to-bag-button-with-external-quantity-input',
    mountElem
  ).elem;
  if (addToBagElement) {
    addToBagElement.dataset.productUuid = productUUID;
    if (renderActiveSKUStateByDefault) {
      addToBagElement.dataset.skuUuid = skuUUID;
    } else {
      addToBagElement.dataset.skuUuid = null;
    }
    addToBagElement.dataset.addOns = addonString;
    addToBagElement.dataset.key = key;
    addToBagElement.setAttribute(
      'id',
      `dkn-variant-form-add-to-bag-${productUUID}-${key}`
    );
    if (addToBagEventName) {
      addToBagElement.dataset.addEvent = addToBagEventName;
    }
    addToBagButtonRenderer(addToBagElement);
  }
  if (addToBagWithVariantsElement) {
    addToBagWithVariantsElement.dataset.productUuid = productUUID;
    addToBagWithVariantsElement.dataset.skuUuid = skuUUID;
    addToBagWithVariantsElement.dataset.addOns = addonString;
    addToBagWithVariantsElement.dataset.key = key;
    addToBagWithVariantsElement.setAttribute(
      'id',
      `dkn-variant-form-add-to-bag-${productUUID}-${key}`
    );
    if (addToBagEventName) {
      addToBagWithVariantsElement.dataset.addEvent = addToBagEventName;
    }
    addToBagButtonWithVariantsRenderer(addToBagWithVariantsElement);
  }

  if (addToBagElementWithExternalFieldElement) {
    addToBagElementWithExternalFieldElement.dataset.productUuid = productUUID;
    addToBagElementWithExternalFieldElement.dataset.skuUuid = skuUUID;
    addToBagElementWithExternalFieldElement.dataset.addOns = addonString;
    addToBagElementWithExternalFieldElement.dataset.key = key;
    addToBagElementWithExternalFieldElement.setAttribute(
      'id',
      `dkn-variant-form-add-to-bag-${productUUID}-${key}`
    );
    if (addToBagEventName) {
      addToBagElementWithExternalFieldElement.dataset.addEvent =
        addToBagEventName;
    }
    dknAddToBagButtonWithExternalQtyFieldRenderer(
      addToBagElementWithExternalFieldElement
    );
  }

  const buyNowElement = q$.select('buy-now-button-load-point', mountElem).elem;
  if (buyNowElement) {
    buyNowElement.dataset.productUuid = productUUID;
    if (renderActiveSKUStateByDefault) {
      buyNowElement.dataset.skuUuid = skuUUID;
    } else {
      buyNowElement.dataset.skuUuid = null;
    }
    buyNowElement.dataset.addOns = addonString;
    buyNowElement.dataset.key = key;
    buyNowElement.setAttribute(
      'id',
      `dkn-variant-form-buy-now-${productUUID}-${key}`
    );
    if (typeof renderFunctions?.buyNowButtonRendererFn === 'function') {
      renderFunctions.buyNowButtonRendererFn(buyNowElement);
    } else {
      buyNowButtonRenderer(buyNowElement);
    }
  }

  const addToWishlistElement = q$.select(
    'wishlist-button-load-point',
    mountElem
  ).elem;

  if (addToWishlistElement) {
    addToWishlistElement.setAttribute(
      'id',
      `dkn-product-wishlist-button-${productUUID}-${key}`
    );
    addToWishlistElement.dataset.productUuid = productUUID;
    addToWishlistElement.dataset.skuUuid = skuUUID;
    addToWishlistElement.dataset.key = key;
    addToWishlistButtonRenderer(addToWishlistElement);
  }

  const notifyMeElement = q$.select(
    'notify-me-button-load-point',
    mountElem
  ).elem;

  if (notifyMeElement) {
    notifyMeElement.setAttribute(
      'id',
      `dkn-product-wishlist-button-${productUUID}-${key}`
    );
    notifyMeElement.dataset.productUuid = productUUID;
    notifyMeElement.dataset.skuUuid = skuUUID;
    notifyMeElement.dataset.key = key;
    notifyMeButtonRenderer(notifyMeElement);
  }

  if (typeof additionalRenderer === 'function') {
    additionalRenderer(productContext, mountElem, options);
  }
};

// window.dknRenderProductSection = (productContext, selectors) => {
//   const {
//     productDetailsWrapperElement = null,
//     variantFormWrapperElement = null,
//     actionButtonsWrapperElement = null,
//     quantityFieldWrapperElement = null,
//     actionButtonTemplateId = null,
//   } = selectors || {};

//   variantFormWrapperElement.innerHTML = '';

//   if (actionButtonTemplateId) {
//     actionButtonsWrapperElement.innerHTML = '';
//     const actionButtons = q$
//       .selectById(actionButtonTemplateId)
//       .getTemplateContent().elem;
//     actionButtonsWrapperElement.appendChild(actionButtons);
//   }

//   // render data of product page
//   if (productDetailsWrapperElement) {
//     dknProductDataRenderer(productContext, productDetailsWrapperElement);
//   }

//   // render variant form
//   if (variantFormWrapperElement) {
//     dknRenderProductVariantForm(productContext, variantFormWrapperElement);
//   }

//   // render quantity field
//   // note: quantity field needs to be present in the dom before add to bag is rendered
//   if (quantityFieldWrapperElement) {
//     dknRenderProductQuantityInputField(
//       productContext,
//       quantityFieldWrapperElement
//     );
//   }

//   // render buttons
//   if (actionButtonsWrapperElement) {
//     dknRenderActionButtons(productContext, actionButtonsWrapperElement);
//   }
// };

// ---------------------------------------------------------------------------------------------------------------------
// add to bag renderers
// ---------------------------------------------------------------------------------------------------------------------

window.dknAddToBagButtonWithExternalQtyFieldRenderer = (mountElement) => {
  mountElement.innerHTML = '';
  const addonString = mountElement.dataset.addOns || '';
  const productUUID = mountElement.dataset.productUuid;
  const skuUUID = mountElement.dataset.skuUuid;
  const uniqueKey = mountElement.dataset.key;
  const hasAppendQty = !!mountElement.dataset.appendQty;
  const addToBagTemplateId =
    mountElement.dataset.addToBagTemplateId ||
    'add-to-bag-button-with-external-quantity-input';
  const addEventName = mountElement.dataset.addEvent || '';
  const productKey = getActiveSKUKey(skuUUID, addonString) || skuUUID;
  const product = getBagProductBySkuAndProductUuid(productUUID, productKey);
  const skuDetails = getProductDetailsBySkuAndProductUuid(productUUID, skuUUID);

  const addToBagButtonTemplate = document.getElementById(addToBagTemplateId);

  const element = document.importNode(addToBagButtonTemplate.content, true);

  const withoutCartButton = element.querySelector(
    '.dkn-add-to-bag-button-without-cart'
  );
  const goToBagButton = element.querySelector('.dkn-go-to-bag-button');
  const quantityFieldWrapper = q$.selectById(
    `dkn-product-qty-wrapper-${productUUID}-${uniqueKey}`
  ).elem;

  if (skuDetails?.inventory !== null && skuDetails?.inventory === 0) {
    const outStockTemplateID = mountElement.dataset.outStockTemplateId
      ? mountElement.dataset.outStockTemplateId
      : 'out-of-stock-button';
    const OutOfStockTemplate = document.getElementById(outStockTemplateID);

    if (quantityFieldWrapper) {
      quantityFieldWrapper.classList.add('hidden');
    }

    if (OutOfStockTemplate !== null) {
      const button = document.importNode(OutOfStockTemplate.content, true);
      mountElement.appendChild(button);
    } else {
      withoutCartButton.classList.add('hidden');
      goToBagButton.classList.add('hidden');
      mountElement.innerHTML = `<div class='out-of-stock-text fB a-c j-c c-red'>${DukaanData.DUKAAN_LANGUAGE.OUT_OF_STOCK}</div>`;
    }
    mountElement.classList.add('min-w-full');
    return;
  }

  if (quantityFieldWrapper) {
    quantityFieldWrapper.classList.remove('hidden');
  }

  mountElement.classList.remove('min-w-full');
  const qtyToAdd = Number(
    q$.selectById(`dkn-product-qty-${productUUID}-${uniqueKey}`)?.elem?.value ||
      product?.ordered_qty ||
      1
  );

  if (
    product?.ordered_qty > 0 &&
    product?.ordered_qty === qtyToAdd &&
    !hasAppendQty
  ) {
    withoutCartButton.classList.add('hidden');
    goToBagButton.classList.remove('hidden');
    goToBagButton.addEventListener('click', () => {
      dknGoToUrl(dknGetBagPageUrl());
    });
  } else {
    goToBagButton.classList.add('hidden');
    withoutCartButton.classList.remove('hidden');
    withoutCartButton.setAttribute(
      'onclick',
      `dknHandleAddToBagButtonWithQtyFieldClick(event, '${skuUUID}', '${productUUID}', '${product?.ordered_qty}', {qtyToAdd: '${qtyToAdd}', addEventName: '${addEventName}', addonString: '${addonString}', hasAppendQty: ${hasAppendQty}})`
    );
  }

  mountElement.appendChild(element);
};

// reviews and ratings utils
// const dknRenderSingleStar = (props) => {
//   const {
//     mountElem,
//     starWidth,
//     starHeight,
//     svgFillColor,
//     customClass = 'not-overlapped',
//     isFilled = true,
//     viewBoxWidth = 24,
//     filledStarTemplateId,
//     unFilledStarTemplateId,
//   } = props;
//   if (isFilled) {
//     const filledStar = q$
//       .selectById(filledStarTemplateId)
//       .getTemplateContent().elem;
//     const filledSvg = q$.select('svg', filledStar).elem;
//     filledSvg.setAttribute('width', starWidth);
//     filledSvg.setAttribute('height', starHeight);
//     filledSvg.setAttribute('color', svgFillColor);
//     filledSvg.setAttribute('viewBox', `0 0 ${viewBoxWidth} 24`);
//     filledSvg.classList.add(customClass);
//     mountElem.appendChild(filledStar);
//     return;
//   }
//   const unFilledStar = q$
//     .selectById(unFilledStarTemplateId)
//     .getTemplateContent().elem;
//   const unfilledSvg = q$.select('svg', unFilledStar).elem;
//   unfilledSvg.setAttribute('width', starWidth);
//   unfilledSvg.setAttribute('height', starHeight);
//   unfilledSvg.setAttribute('color', svgFillColor);
//   unfilledSvg.setAttribute('viewBox', `0 0 ${viewBoxWidth} 24`);
//   unfilledSvg.classList.add(customClass);
//   mountElem.appendChild(unFilledStar);
// };

// window.dknSingleProductRatingsAndReviewsInfoRenderer = (
//   ratingsData,
//   mountElem,
//   options
// ) => {
//   const { rating_average: avgRating = 0, total_count: totalRatingCount = 0 } =
//     ratingsData || {};

//   if (!avgRating || !totalRatingCount) return;

//   mountElem.classList.remove('d-none');
//   const {
//     reviewInfoTemplateId = 'dkn-product-review-template',
//     linkToReviewsPlugin = null,
//     svgFillColor = '#FAB73B',
//     filledStarTemplateId = 'dkn-filled-star-template',
//     unFilledStarTemplateId = 'dkn-unfilled-star-template',
//     singleStarWrapperTemplateId = 'dkn-single-star-wrapper-template',
//   } = options;

//   const element = q$.selectById(reviewInfoTemplateId).getTemplateContent().elem;

//   const { isMobile } = deviceType();
//   const { starHeight = isMobile ? 10 : 16, starWidth = isMobile ? 10 : 16 } =
//     options;

//   const starListWrapperElement = q$.select(
//     '.dkn-product-star-list-wrapper',
//     element
//   ).elem;

//   if (starListWrapperElement) {
//     const fullStarValue = Math.floor(avgRating);
//     const halfStarValue = avgRating - fullStarValue;

//     for (let i = 0; i < 5; i += 1) {
//       const singleStarWrapperContent = q$
//         .selectById(singleStarWrapperTemplateId)
//         .getTemplateContent().elem;
//       const singleStarWrapper = q$.select(
//         '.dkn-single-star-wrapper',
//         singleStarWrapperContent
//       ).elem;
//       if (i < fullStarValue) {
//         dknRenderSingleStar({
//           mountElem: singleStarWrapper,
//           starWidth,
//           starHeight,
//           svgFillColor,
//           isFilled: true,
//           filledStarTemplateId,
//           unFilledStarTemplateId,
//         });
//         starListWrapperElement.appendChild(singleStarWrapperContent);
//       } else if (fullStarValue !== 0 && i === fullStarValue) {
//         dknRenderSingleStar({
//           mountElem: singleStarWrapper,
//           starWidth,
//           starHeight,
//           svgFillColor,
//           isFilled: false,
//           filledStarTemplateId,
//           unFilledStarTemplateId,
//         });
//         starListWrapperElement.appendChild(singleStarWrapperContent);
//         dknRenderSingleStar({
//           mountElem: singleStarWrapper,
//           starWidth: Math.floor(starWidth * halfStarValue),
//           starHeight,
//           svgFillColor,
//           isFilled: true,
//           customClass: 'overlapped',
//           viewBoxWidth: Math.floor(starWidth * halfStarValue),
//           filledStarTemplateId,
//           unFilledStarTemplateId,
//         });
//         singleStarWrapper.classList.add('overlapped-stars');
//         starListWrapperElement.appendChild(singleStarWrapperContent);
//       } else {
//         dknRenderSingleStar({
//           mountElem: singleStarWrapper,
//           starWidth,
//           starHeight,
//           svgFillColor,
//           isFilled: false,
//           filledStarTemplateId,
//           unFilledStarTemplateId,
//         });
//         starListWrapperElement.appendChild(singleStarWrapperContent);
//       }
//     }
//   }

//   const reviewRatingValueTextElem = q$.select(
//     '.dkn-product-rating-value-text',
//     element
//   ).elem;

//   if (reviewRatingValueTextElem) {
//     reviewRatingValueTextElem.textContent = Number(avgRating.toFixed(1));
//   }

//   const reviewCountTextElem = q$.select(
//     '.dkn-product-review-count-text',
//     element
//   ).elem;
//   if (reviewCountTextElem) {
//     if (typeof options.getCustomReviewsCountText !== 'undefined') {
//       reviewCountTextElem.textContent =
//         options.getCustomReviewsCountText(totalRatingCount);
//     } else {
//       reviewCountTextElem.textContent = totalRatingCount;
//     }

//     if (linkToReviewsPlugin) {
//       reviewCountTextElem.setAttribute('href', linkToReviewsPlugin);
//     }
//   }
//   mountElem.appendChild(element);
// };
