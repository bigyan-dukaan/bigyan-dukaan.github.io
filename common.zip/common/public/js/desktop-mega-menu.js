window.showMenuDropdown = (event, parentId, index) => {
  const { target } = event;
  if (index === '0') {
    q$.selectAll(`.second-menu-item-list ul.menu-items-list`).addClassAll(
      'hidden'
    );
    q$.selectAll(`.third-menu-item-list ul.menu-items-list`).addClassAll(
      'hidden'
    );
    q$.selectAll(`.first-menu-item-list ul li`).removeClassAll(
      'active-nav-item'
    );
    q$.selectAll(`.second-menu-item-list ul li`).removeClassAll(
      'active-nav-item'
    );
    q$.selectAll(`.third-menu-item-list ul li`).removeClassAll(
      'active-nav-item'
    );
  } else if (index === '1') {
    q$.selectAll(`.third-menu-item-list ul.menu-items-list`).addClassAll(
      'hidden'
    );
    q$.selectAll(`.second-menu-item-list ul li`).removeClassAll(
      'active-nav-item'
    );
    q$.selectAll(`.third-menu-item-list ul li`).removeClassAll(
      'active-nav-item'
    );
  } else if (index === '2') {
    q$.selectAll(`.third-menu-item-list ul li`).removeClassAll(
      'active-nav-item'
    );
  }
  target.classList.add('active-nav-item');
  q$.select(
    `ul.menu-items-list[data-parent-dropdown-id="${parentId}"]`
  ).removeClass('hidden');
};

// on hover
window.handleMenuStates = () => {
  const menuItems = document.querySelectorAll(
    '.header-section-nav-item:not(.header-section-nav-item-hamburger)'
  );

  let i = 0;
  for (i = 0; i < menuItems.length; i += 1) {
    menuItems[i].addEventListener('mouseenter', (event) => {
      document.querySelectorAll('.header-menu-item-dropdown')?.forEach((el) => {
        el?.classList.add('hidden');
      });
      const { target: parentMenuItem } = event;

      const menuId = parentMenuItem.dataset.menuId || '';
      const menuDropDown = document.getElementById(menuId);

      if (menuDropDown) {
        menuDropDown.classList.remove('hidden');
        menuDropDown.style.position = 'absolute';
        menuDropDown.style.top = `calc(100% - 8px)`;
        menuDropDown.style.left = `${
          parentMenuItem.getBoundingClientRect().left
        }px`;
      }
      document.addEventListener('mousemove', (e) => {
        const { target: hoverTarget } = e;
        const mainHeader = document.querySelector('.header-section-menu-list');
        if (
          !(
            menuDropDown?.contains(hoverTarget) ||
            mainHeader?.contains(hoverTarget)
          )
        ) {
          menuDropDown?.classList?.add('hidden');
          document.removeEventListener('mousemove', () => {}, true);
        }
      });
    });
  }
};
