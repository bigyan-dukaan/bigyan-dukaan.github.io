window.TOTAL_REVIEW_PAGES = 0;
window.ACTIVE_REVIEW_PAGE = 1;
window.ACTIVE_STAR_FILTER = '';
window.ACTIVE_SORT_FILTER = '-created_at';
window.PRODUCT_REVIEW_IMAGES = [];
window.currentUserReviewId = 0;
window.editingReview = false;
window.isReviewRatingsPresent = false;
window.ratingColors = ['#F17A54', '#FBB851', '#F6D757', '#B7EA83', '#76DB98'];
window.sortMapping = {
  '-created_at': window.DukaanData?.DUKAAN_LANGUAGE.NEWEST_FIRST,
  created_at: window.DukaanData?.DUKAAN_LANGUAGE.OLDEST_FIRST,
  '-rating': window.DukaanData?.DUKAAN_LANGUAGE.HIGHEST_RATED,
  rating: window.DukaanData?.DUKAAN_LANGUAGE.LOWEST_RATED,
};
window.singleStar = (fill, width = 24, customClass = 'not-overlapped') =>
  `<svg class=${customClass} width="${width}" height="24" viewBox="0 0 ${width} 24" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M12 20.0196L17.9971 23.808C18.9434 24.4056 20.1104 23.5175 19.8594 22.3919L18.2675 15.2508L23.567 10.4454C24.4022 9.68877 23.9557 8.25246 22.855 8.15519L15.879 7.5362L13.1502 0.796791C12.7193 -0.265597 11.2807 -0.265597 10.8498 0.796791L8.12099 7.5362L1.14504 8.15519C0.044341 8.25246 -0.402216 9.68877 0.432966 10.4454L5.73251 15.2508L4.1406 22.3919C3.88956 23.5175 5.05664 24.4056 6.00286 23.808L12 20.0196Z" fill="${fill}" /></svg>`;
window.reviewsTemplate = document.getElementById('ratings-container');
window.reviewsContainer = document.importNode(reviewsTemplate.content, true);

window.mainReviewFetchCall = (firstCall = false, callback) => {
  customTag('ratings-plugin', (element) =>
    fetchProductReviewStats(firstCall, element, callback)
  );
};

window.renderReviewsPlugin = () => {
  editingReview = false;
  axios
    .get(
      `https://apps.mydukaan.io/public/v2/apps/store/${DukaanData.DUKAAN_STORE.id}/`
    )
    .then((res) => {
      const { store_apps_list: appList } = res?.data;
      const availablePlugins = appList?.reduce((acc, item) => {
        if (item.isActive) {
          acc[item._id] = item;
        }
        return acc;
      }, {});
      isReviewRatingsPresent = !!(
        !!availablePlugins && availablePlugins[APP_IDS.REVIEWS_AND_RATINGS]
      );
      if (isReviewRatingsPresent) {
        mainReviewFetchCall(true);
        if (typeof fetchQuestions === 'function') fetchQuestions(1, true);
      } else {
        document
          .getElementById('ratings-plugin-container')
          ?.classList?.add('hidden');
      }

      const urlParams = new URLSearchParams(window.location.search);
      const openByDefault = !!urlParams.get('rating');
      if (openByDefault) {
        initDukaanAuth(() => {
          openWriteReviewModal(false, { openedFromParams: true });
        });
      }
    })
    .catch((e) => {
      document
        .getElementById('ratings-plugin-container')
        ?.classList?.add('hidden');
    });
};

window.fetchProductReviewStats = (firstFetchCall, mountElem, callback) => {
  mountElem.append(reviewsContainer);
  const product_id =
    window?.reviewProduct?.id || window.DukaanData.DUKAAN_PRODUCT.id;
  const headers = {};
  if (localStorage && localStorage.al_to) {
    headers.Authorization = `Bearer ${localStorage.al_to}`;
  }
  headers['Content-Type'] = 'application/json';
  fetch(
    `${window.DukaanData.CLIENT_API_ENDPOINT}/api/product/buyer/${product_id}/product/review/stats/`,
    {
      method: 'get',
      headers,
    }
  )
    .then((res) => res.json())
    .then((res) => {
      const reviewStats = res?.data || {};
      if (
        !reviewStats?.rating_data?.length &&
        window?.pluginsConfig?.hideReviewsPlugin &&
        firstFetchCall
      ) {
        document
          .getElementById('ratings-plugin-container')
          ?.classList?.add('hidden');
        return;
      }
      window.DukaanData.RATINGS_DATA = reviewStats;
      createRatingsSection(reviewStats);
      if (typeof customReviewsInfoRenderer !== 'undefined') {
        customReviewsInfoRenderer(reviewStats);
      } else {
        renderReviewsInfoPDP(reviewStats);
      }
      fetchProductReviews(1, null, null, firstFetchCall);

      const ratingsProductImage = document.querySelector(
        '.ratings-product-image'
      );
      const ratingsProductName = document.querySelector(
        '.ratings-product-name'
      );

      if (window.reviewProduct) {
        if (ratingsProductImage) {
          ratingsProductImage.src = getCdnUrl(reviewProduct.image, 100);
        }
        if (ratingsProductName) {
          ratingsProductName.textContent = reviewProduct.name;
        }
      }

      if (callback) callback(reviewStats);
    });
};

window.returnStarList = (ratingAverage, options) =>
  dknGetStarListElement(ratingAverage, options || {});
window.renderReviewsInfoPDP = (reviewStats) => {
  const ratingStarsInfo = document.getElementById('rating-info-pdp');

  if (ratingStarsInfo) {
    const customerRatingsText = `${reviewStats?.total_count || 0} 
      ${
        reviewStats?.total_count > 1
          ? DukaanData.DUKAAN_LANGUAGE.CUSTOMER_RATINGS
          : DukaanData.DUKAAN_LANGUAGE.CUSTOMER_RATING
      }`;
    ratingStarsInfo.querySelector('.rating-info-star-list').appendChild(
      returnStarList(reviewStats?.rating_average || 0, {
        starWidth: 24,
        starHeight: 24,
      })
    );
    ratingStarsInfo.querySelector('.scroll-to-plugin').textContent =
      customerRatingsText;
  }
};

window.renderRatingsStats = (reviewStats) => {
  for (let i = 1; i <= 5; i += 1) {
    const ratingData = reviewStats.rating_data.filter((e) => e.rating === i);
    let ratingPercent = 0;
    if (ratingData && ratingData.length > 0) {
      ratingPercent = Math.round(
        (ratingData[0].count * 100) / reviewStats.total_count
      );
    }
    q$.selectById(`total-stars-${i}`).modifyTextContent(
      `${i} ${window.pluralize(i, DukaanData.DUKAAN_LANGUAGE.STAR)}`
    );
    q$.selectById(`percent-${i}`).modifyTextContent(`${ratingPercent}%`);
    q$.selectById(`bg-progress-${i}`).addClass('w-100');
    if (q$.selectById(`progress-${i}`).elem) {
      q$.selectById(`progress-${i}`).elem.style.backgroundColor =
        window.ratingColors[i - 1];
      q$.selectById(`progress-${i}`).elem.style.width = `${ratingPercent}%`;
    }
  }
};

window.createRatingsSection = (reviewStats) => {
  if (typeof customCustomerRatingTextRenderer !== 'undefined') {
    customCustomerRatingTextRenderer(reviewStats);
  } else {
    q$.select('.customerRatingText').modifyTextContent(
      `${DukaanData.DUKAAN_LANGUAGE.CUSTOMER_RATINGS}`
    );
  }

  q$.selectById('rating-container')
    .modifyInnerHTML(null)
    .elem.appendChild(
      returnStarList(reviewStats?.rating_average, {
        starWidth: 24,
        starHeight: 24,
      })
    );

  if (reviewStats.rating_average)
    document.getElementById('rating-value').innerHTML = `${Number(
      reviewStats?.rating_average?.toFixed(1)
    )} out of 5`;
  else {
    document.getElementById('rating-value').classList.add('hidden');
    document.getElementById('rating-value').innerHTML = '';
  }

  const customerRatingsText = `${reviewStats.total_count} 
  ${
    reviewStats.total_count > 1
      ? DukaanData.DUKAAN_LANGUAGE.CUSTOMER_RATINGS
      : DukaanData.DUKAAN_LANGUAGE.CUSTOMER_RATING
  }`;

  q$.selectById('rating-count').modifyInnerHTML(customerRatingsText);

  if (typeof customRatingsStatsRenderer !== 'undefined') {
    customRatingsStatsRenderer(reviewStats);
  } else {
    renderRatingsStats(reviewStats);
  }

  if (reviewStats.review == null && reviewStats.rating_data.length > 0)
    document.getElementById('create-review-button').classList.remove('hidden');
  else document.getElementById('create-review-button').classList.add('hidden');

  if (typeof customRatingsStatsRenderer !== 'undefined') {
    customRatingsStatsRenderer(reviewStats);
  }
};

window.createPaginationList = (page) => {
  if (TOTAL_REVIEW_PAGES <= 1) {
    document.getElementById('pagination-list').classList.add('hidden');
    document.getElementById('pagination-list').innerHTML = '';
    return;
  }
  document.getElementById('pagination-list').classList.remove('hidden');
  document.getElementById('pagination-list').innerHTML = '';

  let startIdx = 1;
  let endIdx = 1;
  if (TOTAL_REVIEW_PAGES <= 5) {
    endIdx = TOTAL_REVIEW_PAGES;
  } else if (page <= 5) {
    startIdx = 1;
    endIdx = 5;
  } else {
    startIdx = page - 2;
    if (page === TOTAL_REVIEW_PAGES) {
      endIdx = page;
      startIdx = page - 4;
    } else if (page === TOTAL_REVIEW_PAGES - 1) {
      endIdx = TOTAL_REVIEW_PAGES;
      startIdx = page - 3;
    } else endIdx = page + 2;
  }
  let pagesHTML = '';
  if (page > 1 && TOTAL_REVIEW_PAGES > 1) {
    pagesHTML += `<div class="review-nav-link flex d-row a-center j-start" onclick="fetchProductReviews(${
      page - 1
    })"><svg width="12" height="12" viewBox="0 0 12 12" fill="none" xmlns="http://www.w3.org/2000/svg" color="var(--primary)" spacing="mr-2"><path fill-rule="evenodd" clip-rule="evenodd" d="M8.41689 10.2919C8.66914 10.0396 8.69208 9.6449 8.48569 9.36675L8.41689 9.28706L5.13016 6L8.41689 2.71294C8.66914 2.46069 8.69208 2.06596 8.48569 1.7878L8.41689 1.70811C8.16464 1.45586 7.76991 1.43292 7.49175 1.63931L7.41206 1.70811L3.62258 5.49758C3.37033 5.74983 3.3474 6.14457 3.55379 6.42273L3.62258 6.50242L7.41206 10.2919C7.68953 10.5694 8.13941 10.5694 8.41689 10.2919Z" fill="var(--primary)"></path></svg>${
      DukaanData.DUKAAN_LANGUAGE.PREVIOUS
    }</div>`;
  } else {
    pagesHTML += `<div class="review-nav-link"></div>`;
  }
  pagesHTML += `<div id="reviews-pages" class="flex">`;
  for (let i = startIdx; i <= endIdx; i += 1) {
    if (page === i) {
      pagesHTML += `<li class="active" onclick="fetchProductReviews(${i})">${i}</li>`;
    } else {
      pagesHTML += `<li onclick="fetchProductReviews(${i})">${i}</li>`;
    }
  }
  pagesHTML += `</div>`;
  if (page !== TOTAL_REVIEW_PAGES && TOTAL_REVIEW_PAGES !== 0) {
    pagesHTML += `<div class="review-nav-link flex d-row a-center j-end" onclick="fetchProductReviews(${
      page + 1
    })">${
      DukaanData.DUKAAN_LANGUAGE.NEXT
    } <svg width="12" height="12" viewBox="0 0 12 12" fill="none" xmlns="http://www.w3.org/2000/svg" color="var(--primary)" ><path fill-rule="evenodd" clip-rule="evenodd" d="M3.58311 10.2919C3.33086 10.0396 3.30792 9.6449 3.51431 9.36675L3.58311 9.28706L6.86984 6L3.58311 2.71294C3.33086 2.46069 3.30792 2.06596 3.51431 1.7878L3.58311 1.70811C3.83536 1.45586 4.23009 1.43292 4.50825 1.63931L4.58794 1.70811L8.37742 5.49758C8.62967 5.74983 8.6526 6.14457 8.44621 6.42273L8.37742 6.50242L4.58794 10.2919C4.31047 10.5694 3.86059 10.5694 3.58311 10.2919Z" fill="var(--primary)"></path></svg></div>`;
  } else {
    pagesHTML += `<div class="review-nav-link"></div>`;
  }
  document.getElementById('pagination-list').innerHTML = pagesHTML;
};

window.createReviewsList = (reviews) => {
  const reviewListWrapper = document.getElementById('reviews-list');
  reviewListWrapper.innerHTML = '';
  reviewListWrapper.classList.add('hidden');
  if (reviews && reviews.length > 0) {
    if (document.getElementById('rating-info-pdp'))
      document.getElementById('rating-info-pdp').classList.remove('hidden');
    reviewListWrapper.classList.remove('hidden');
    document.querySelector('.filters-container').classList.remove('hidden');
    document.getElementById('no-reviews-cta').classList.add('hidden');
    let countIndex = -1;
    const allImagesWithReviews = reviews
      .map((review) => {
        const { images } = review;
        return (
          images?.map((image) => {
            countIndex += 1;
            return {
              id: countIndex,
              image,
              review,
            };
          }) || []
        );
      })
      .flat();

    reviews.forEach((review, index) => {
      const {
        full_name: fullName,
        verified_purchase: verifiedPurchase,
        created_at,
        description,
        reply,
        reply_date,
        images: imageFromProps,
      } = review;
      const reviewItemTemplate = document.getElementById('review-item');
      const reviewItem = document.importNode(reviewItemTemplate.content, true);
      reviewItem.querySelector('.reviewer-name').textContent = fullName;

      if (verifiedPurchase) {
        if (typeof customReviewsVerifiedBadgeRenderer !== 'undefined') {
          customReviewsVerifiedBadgeRenderer(reviewItem);
        } else {
          reviewItem
            .querySelector('.verified-badge')
            .classList.remove('hidden');
        }
      }
      const starList = reviewItem.querySelector('.review-stars');
      for (let i = 1; i <= 5; i++) {
        const starTemplate = document.getElementById('star');
        const star = document.importNode(starTemplate.content, true);

        if (i <= review.rating) {
          star.querySelector('svg').classList.add('overlapped');
          starList.append(star);
        } else {
          star.querySelector('svg').classList.add('not-overlapped');
          q$.selectAll('path', star)?.elem?.forEach((el) => {
            el.style.fill = '#D9D9D9';
          });
          starList.append(star);
        }
      }
      reviewItem.querySelector('.review-date').textContent =
        dateFormatter(created_at);

      const images = imageFromProps?.map((img) => {
        const info = allImagesWithReviews.find((data) => data.image === img);
        return { image: img, id: info?.id };
      });

      if (!!images && images.length > 0) {
        const imagesContainer = reviewItem.querySelector(
          '.review-images-container'
        );
        imagesContainer.classList.remove('hidden');
        images.map(({ image, id }) => {
          const imgTag = document.createElement('img');
          imgTag.setAttribute('src', `${getCdnUrl(image, 50)}`);
          imgTag.classList.add('review-image');
          imgTag.classList.add('cursor-pointer');
          imgTag.setAttribute(
            'onclick',
            `handleImagesWithReviewModalOpen(${id})`
          );
          imagesContainer.append(imgTag);
        });
      }

      if (description) {
        reviewItem.querySelector('.review-desc').classList.remove('hidden');
        reviewItem.querySelector('.review-desc').textContent = description;
      }

      if (
        localStorage &&
        localStorage.al_to &&
        JSON.parse(decodeBase64(localStorage.al_to.split('.')[1])).buyer_id ===
          review.buyer
      ) {
        currentUserReviewId = review.id;
        reviewItem.querySelector('.review-actions').classList.remove('hidden');
      }

      if (reply) {
        reviewItem
          .querySelector('.review-reply-wrapper')
          .classList.remove('hidden');
        reviewItem.querySelector('.seller-name').textContent =
          window?.DukaanData?.DUKAAN_STORE?.name;
        reviewItem.querySelector('.seller-reply').textContent = reply;
        reviewItem.querySelector('.seller-reply-date').textContent =
          dateFormatter(reply_date);
      }
      reviewListWrapper.append(reviewItem);
    });
  }
};

window.createImagesModal = (allImagesWithReviews) => {
  const { isMobile } = deviceType();
  const sliceSize = isMobile ? 4 : 6;
  if (allImagesWithReviews && allImagesWithReviews.length > 0) {
    window.DukaanData.ALL_IMAGES_WITH_REVIEWS = allImagesWithReviews;
    const userImageContainer = document.getElementById('user-images-container');
    userImageContainer.classList.remove('hidden');
    q$.select('.user-photos-title', userImageContainer).modifyTextContent(
      `${DukaanData.DUKAAN_LANGUAGE.CUSTOMER_PHOTOS} (${allImagesWithReviews.length})`
    );
    const imagesList = userImageContainer.querySelector('.images-container');
    imagesList.innerHTML = '';
    allImagesWithReviews.slice(0, sliceSize).map((review, key) => {
      const { image, id } = review;
      const imgOuterDiv = document.createElement('div');
      const imgTag = document.createElement('img');
      imgTag.setAttribute('src', `${getCdnUrl(image, 200)}`);
      imgOuterDiv.classList.add('user-photo');
      imgOuterDiv.append(imgTag);
      imagesList.append(imgOuterDiv);
      if (key === sliceSize - 1 && allImagesWithReviews.length > sliceSize) {
        const overlay = document.createElement('div');
        const countText = document.createElement('div');
        countText.classList.add('count-text');
        countText.textContent = `+${allImagesWithReviews.length - sliceSize}`;
        const viewAllText = document.createElement('div');
        viewAllText.classList.add('view-all-text');
        viewAllText.textContent = DukaanData.DUKAAN_LANGUAGE.VIEW_ALL;
        overlay.append(countText);
        overlay.append(viewAllText);
        overlay.setAttribute('onclick', 'handleAllImagesModalOpen()');
        imgOuterDiv.append(overlay);
        overlay.classList.add('review-image-overlay');
      } else
        imgTag.setAttribute(
          'onclick',
          `handleImagesWithReviewModalOpen(${id})`
        );
    });
  } else {
    const userImageContainer = document.getElementById('user-images-container');
    userImageContainer.classList.add('hidden');
  }
};

window.handleAllImagesModalOpen = () => {
  document.getElementsByTagName('body')[0].style.overflow = 'hidden';
  const allImagesWithReviews = window.DukaanData.ALL_IMAGES_WITH_REVIEWS;
  const allImagesModal = document.getElementById('all-images-modal');
  allImagesModal.classList.remove('hidden');
  document.getElementsByTagName('body')[0].style.overflow = 'hidden';
  const imagesContainer = allImagesModal.querySelector(
    '.modal-images-container'
  );
  imagesContainer.innerHTML = '';
  allImagesModal.querySelector(
    '.all-images-heading'
  ).textContent = `All customer photos (${allImagesWithReviews.length})`;
  allImagesWithReviews.map(({ image, id }) => {
    const imgOuterDiv = document.createElement('div');
    const imgTag = document.createElement('img');
    imgTag.setAttribute('src', `${getCdnUrl(image, 400)}`);
    imgOuterDiv.classList.add('user-photo-modal');
    imgOuterDiv.setAttribute(
      'onclick',
      `handleImagesWithReviewModalOpen(${id})`
    );
    imgOuterDiv.append(imgTag);
    imagesContainer.append(imgOuterDiv);
  });
};

window.handleAllImagesModalClose = () => {
  document.getElementById('all-images-modal').classList.add('hidden');
  document.getElementsByTagName('body')[0].style.overflow = 'auto';
};

window.handleImagesWithReviewModalOpen = (index) => {
  document.getElementsByTagName('body')[0].style.overflow = 'hidden';
  handleAllImagesModalClose();

  const { isMobile } = deviceType();
  if (!isMobile) renderDesktopModalReview(index);
  else renderMobileModalReview(index);
};

window.renderMobileModalReview = (index) => {
  const allImagesWithReviews = window.DukaanData.ALL_IMAGES_WITH_REVIEWS;
  const mobileModal = document.getElementById('review-detail-modal-mobile');
  mobileModal.classList.remove('hidden');
  const splideList = mobileModal.querySelector('.splide__list');

  let splideListHTML = '';

  allImagesWithReviews.map(({ image }) => {
    const imageTag = `<li class="splide__slide">
            <img loading="lazy" src="${getCdnUrl(image, 800)}"
              alt="" />
          </li>`;
    splideListHTML += imageTag;
  });
  splideList.innerHTML = splideListHTML;
  renderMobileModalReviewData(index);
  const mobileReviewSplide = new Splide('#review-detail-carousel-mobile', {
    pagination: false,
  });

  window.mobileReviewSplide = mobileReviewSplide;
  mobileReviewSplide.mount();
  mobileReviewSplide.go(index);
  mobileReviewSplide.on('move', () => {
    renderMobileModalReviewData(mobileReviewSplide.index);
  });
};

window.renderMobileModalReviewData = (index) => {
  const allImagesWithReviews = window.DukaanData.ALL_IMAGES_WITH_REVIEWS;
  const mobileModal = document.getElementById('review-detail-modal-mobile');

  const { review = {}, id } = allImagesWithReviews[index];

  const {
    full_name: fullName,
    verified_purchase: verifiedPurchase,
    created_at,
    description,
    reply,
    reply_date,
    images: imageFromProps,
  } = review;
  const reviewItem = mobileModal.querySelector('.sticky-review-details');
  reviewItem.querySelector('.mobile-reviewer-name').textContent = fullName;

  const images = imageFromProps?.map((img) => {
    const info = allImagesWithReviews?.find((data) => data?.image === img);
    return { image: img, id: info?.id };
  });

  if (verifiedPurchase) {
    reviewItem.querySelector('.verified-badge').classList.remove('hidden');
  }
  const starList = reviewItem.querySelector('.review-stars');
  starList.innerHTML = '';
  for (let i = 1; i <= 5; i++) {
    const starTemplate = document.getElementById('star');
    const star = document.importNode(starTemplate.content, true);

    if (i <= review.rating) {
      starList.append(star);
    } else {
      q$.selectAll('path', star)?.elem?.forEach((el) => {
        el.style.fill = '#D9D9D9';
      });
      starList.append(star);
    }
  }
  const thumbnailsList = mobileModal.querySelector('.thumbnail-list-mobile');

  if (!!images && images.length > 0) {
    thumbnailsList.innerHTML = '';
    images.map(({ id, image }) => {
      const liEle = document.createElement('li');
      liEle.classList.add('thumbnail-item');
      liEle.classList.add(`thumbnail-item-${id}`);
      if (index === id) liEle.classList.add(`thumbnail-is-active`);
      const imgEle = document.createElement('img');
      imgEle.setAttribute('src', `${getCdnUrl(image, 100)}`);
      liEle.append(imgEle);
      liEle.addEventListener('click', () => {
        mobileReviewSplide.go(id);
      });
      thumbnailsList.append(liEle);
    });
  }
  reviewItem.querySelector('.review-date').textContent =
    dateFormatter(created_at);
  if (description) {
    const canShowMore = description?.length > 120;
    const descEle = reviewItem.querySelector('.review-desc');
    descEle.classList.add('mobile-desc');
    descEle.classList.remove('hidden');
    descEle.textContent = description;

    if (canShowMore) {
      descEle.classList.add('line-clamp');
      const showMore = reviewItem.querySelector('.show-more');
      showMore.innerHTML = '';
      showMore.innerHTML = `<div class="flex d-row a-center j-start" id="show-more-toggle" onclick="handleTextShowMoreToggle(event)" >
    <div id="show-text">See more</div><div class="show-svg"><svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
    <path fill-rule="evenodd" clip-rule="evenodd" d="M2.55806 5.55806C2.80214 5.31398 3.19786 5.31398 3.44194 5.55806L8 10.1161L12.5581 5.55806C12.8021 5.31398 13.1979 5.31398 13.4419 5.55806C13.686 5.80214 13.686 6.19786 13.4419 6.44194L8.44194 11.4419C8.19786 11.686 7.80214 11.686 7.55806 11.4419L2.55806 6.44194C2.31398 6.19786 2.31398 5.80214 2.55806 5.55806Z" fill="white"/>
    </svg>
    </div>    
    </div>
    <div class="flex d-row a-center j-start hidden" id="show-less-toggle" onclick="handleTextShowLessToggle(event)" >
    <div id="show-text">See less</div><div class="show-svg"><svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
    <path fill-rule="evenodd" clip-rule="evenodd" d="M2.55806 5.55806C2.80214 5.31398 3.19786 5.31398 3.44194 5.55806L8 10.1161L12.5581 5.55806C12.8021 5.31398 13.1979 5.31398 13.4419 5.55806C13.686 5.80214 13.686 6.19786 13.4419 6.44194L8.44194 11.4419C8.19786 11.686 7.80214 11.686 7.55806 11.4419L2.55806 6.44194C2.31398 6.19786 2.31398 5.80214 2.55806 5.55806Z" fill="white"/>
    </svg>
    </div>    
    </div>`;
      reviewItem.append(showMore);
    }
  }
};

window.handleTextShowMoreToggle = (event) => {
  const parentEle = event.target.parentElement.parentNode.parentNode.parentNode;
  parentEle.querySelector('.review-desc').classList.remove('line-clamp');
  parentEle.querySelector('#show-more-toggle').classList.add('hidden');
  parentEle.querySelector('#show-less-toggle').classList.remove('hidden');
};

window.handleTextShowLessToggle = (event) => {
  const parentEle =
    event.target.parentElement.parentNode.parentNode.parentNode.parentNode;
  parentEle.querySelector('.review-desc').classList.add('line-clamp');
  parentEle.querySelector('#show-more-toggle').classList.remove('hidden');
  parentEle.querySelector('#show-less-toggle').classList.add('hidden');
};

window.renderDesktopModalReview = (index) => {
  const allImagesWithReviews = window.DukaanData.ALL_IMAGES_WITH_REVIEWS;
  const imagesWithReviewsModal = document.getElementById(
    'review-detail-modal-desktop'
  );
  imagesWithReviewsModal.classList.remove('hidden');

  const splideList = imagesWithReviewsModal.querySelector('.splide__list');

  let splideListHTML = '';

  allImagesWithReviews.map(({ image }) => {
    const imageTag = `<li class="splide__slide">
            <img loading="lazy" src="${getCdnUrl(image, 800)}"
              alt="" />
          </li>`;
    splideListHTML += imageTag;
  });
  splideList.innerHTML = splideListHTML;

  renderDesktopModalReviewData(index);
  const reviewSplide = new Splide('#review-detail-carousel-images', {
    pagination: false,
  });

  window.reviewSplide = reviewSplide;

  reviewSplide.mount();
  reviewSplide.go(index);
  reviewSplide.on('move', () => {
    renderDesktopModalReviewData(reviewSplide.index);
  });
};

window.renderDesktopModalReviewData = (index) => {
  const allImagesWithReviews = window.DukaanData.ALL_IMAGES_WITH_REVIEWS;
  const imagesWithReviewsModal = document.getElementById(
    'review-detail-modal-desktop'
  );

  const { review = {}, id } = allImagesWithReviews[index];

  const {
    full_name: fullName,
    verified_purchase: verifiedPurchase,
    created_at,
    description,
    reply,
    reply_date,
    images: imageFromProps,
  } = review;
  const reviewItem = imagesWithReviewsModal.querySelector(
    '.review-item-wrapper'
  );
  reviewItem.querySelector('.desktop-reviewer-name').textContent = fullName;

  const images = imageFromProps?.map((img) => {
    const info = allImagesWithReviews.find((data) => data.image === img);
    return { image: img, id: info?.id };
  });

  if (verifiedPurchase) {
    reviewItem.querySelector('.verified-badge').classList.remove('hidden');
  }
  const starList = reviewItem.querySelector('.review-stars');
  starList.innerHTML = '';
  for (let i = 1; i <= 5; i++) {
    const starTemplate = document.getElementById('star');
    const star = document.importNode(starTemplate.content, true);

    if (i <= review.rating) {
      starList.append(star);
    } else {
      q$.selectAll('path', star)?.elem?.forEach((el) => {
        el.style.fill = '#D9D9D9';
      });
      starList.append(star);
    }
  }
  const thumbnailsList =
    imagesWithReviewsModal.querySelector('.thumbnail-list');

  if (!!images && images.length > 0) {
    thumbnailsList.innerHTML = '';
    images.map(({ id, image }) => {
      const liEle = document.createElement('li');
      liEle.classList.add('thumbnail-item');
      liEle.classList.add(`thumbnail-item-${id}`);
      if (index === id) liEle.classList.add(`thumbnail-is-active`);
      const imgEle = document.createElement('img');
      imgEle.setAttribute('src', `${getCdnUrl(image, 100)}`);
      liEle.append(imgEle);
      liEle.addEventListener('click', () => {
        reviewSplide.go(id);
      });
      thumbnailsList.append(liEle);
    });
  }
  reviewItem.querySelector('.review-date').textContent =
    dateFormatter(created_at);
  if (description) {
    reviewItem.querySelector('.review-desc').classList.remove('hidden');
    reviewItem.querySelector('.review-desc').textContent = description;
  }
};

window.handleImagesWithReviewModalClose = () => {
  document.getElementsByTagName('body')[0].style.overflow = 'auto';
  const { isMobile } = deviceType();
  if (!isMobile)
    document
      .getElementById('review-detail-modal-desktop')
      .classList.add('hidden');
  else
    document
      .getElementById('review-detail-modal-mobile')
      .classList.add('hidden');
};

window.fetchProductReviews = (
  page,
  ordering,
  rating,
  firstFetchCall = false
) => {
  if (!firstFetchCall) {
    const element = document.getElementById('reviews-list');
    const y = element.getBoundingClientRect().top + window.scrollY;
    window.scroll({
      top: y - 250,
      behavior: 'smooth',
    });
  }

  if (!page) {
    page = ACTIVE_REVIEW_PAGE;
  }
  if (!ordering) {
    ordering = ACTIVE_SORT_FILTER;
  }
  if (!rating) {
    rating = ACTIVE_STAR_FILTER;
  }
  if (rating == -1) {
    ACTIVE_STAR_FILTER = '';
    rating = ACTIVE_STAR_FILTER;
  }
  document.getElementById('filter-sort-title').innerHTML =
    sortMapping[ordering];

  const sortItems = document.querySelectorAll('.time-dropdown-item');
  sortItems.forEach((item) => {
    if (item.classList.contains(`value-${ordering}`)) {
      item.classList.add('time-dropdown-item-bold');
      item.querySelector('.selected').classList.remove('hidden');
      item.querySelector('.not-selected').classList.add('hidden');
    } else {
      item.classList.remove('time-dropdown-item-bold');
      item.querySelector('.selected').classList.add('hidden');
      item.querySelector('.not-selected').classList.remove('hidden');
    }
  });
  const starItems = document.querySelectorAll('.rating-dropdown-item');
  starItems.forEach((item) => {
    if (item.classList.contains(`value-${rating === '' ? -1 : rating}`)) {
      item.classList.add('rating-dropdown-item-bold');
      item.querySelector('.selected').classList.remove('hidden');
      item.querySelector('.not-selected').classList.add('hidden');
    } else {
      item.classList.remove('rating-dropdown-item-bold');
      item.querySelector('.selected').classList.add('hidden');
      item.querySelector('.not-selected').classList.remove('hidden');
    }
  });
  if (rating === 1) {
    document.getElementById(
      'filter-star-title'
    ).innerHTML = `1 ${DukaanData.DUKAAN_LANGUAGE.STAR}`;
  } else if (rating === '') {
    document.getElementById('filter-star-title').innerHTML =
      DukaanData.DUKAAN_LANGUAGE.ALL_RATINGS;
  } else {
    document.getElementById(
      'filter-star-title'
    ).innerHTML = `${rating} ${DukaanData.DUKAAN_LANGUAGE.STARS}`;
  }
  const product_id =
    window?.reviewProduct?.id || window.DukaanData.DUKAAN_PRODUCT.id;
  // product_id = 36751700;
  const headers = {};
  headers['Content-Type'] = 'application/json';
  if (localStorage && localStorage.al_to)
    headers.Authorization = `Bearer ${localStorage.al_to}`;

  // loading state for reviews list
  const reviewList = document.getElementById('reviews-list');
  reviewList.innerHTML = '';
  const bounceLoaderTemp = document.getElementById('reviews-loader-elem');
  const bounceLoader = document.importNode(bounceLoaderTemp.content, true);
  bounceLoader.querySelector('.bounceLoader')?.classList.remove('hidden');
  document.getElementById('pagination-list').classList.add('hidden');
  reviewList.appendChild(bounceLoader);

  // 'Content-Type': 'application/x-www-form-urlencoded',
  fetch(
    `${window.DukaanData.CLIENT_API_ENDPOINT}/api/product/buyer/${product_id}/product/review/?page_size=5&page=${page}&ordering=${ordering}&rating=${rating}&question=false`,
    {
      method: 'get',
      headers,
    }
  )
    .then((res) => res.json())
    .then((res) => {
      const reviews = res?.results;
      let count = -1;
      const allImagesWithReviews = reviews
        .map((review) => {
          const { images } = review;
          return (
            images?.map((image) => {
              count += 1;
              return {
                id: count,
                image,
                review,
              };
            }) || []
          );
        })
        .flat();

      if (res?.count > 0) {
        document.getElementById('no-review-container').classList.add('hidden');
        document.getElementById(
          'reviews-title'
        ).innerHTML = `${DukaanData.DUKAAN_LANGUAGE.CUSTOMER_REVIEWS} (${res?.count})`;
        q$.select('.reviews-count').modifyTextContent(res?.count);
        const reviewStats = window.DukaanData.RATINGS_DATA;
        if (reviewStats.review == null && reviewStats.rating_data.length > 0)
          document
            .getElementById('create-review-button')
            .classList.remove('hidden');
      } else {
        q$.select('.reviews-count').modifyTextContent('0');
        document
          .getElementById('no-review-container')
          .classList.remove('hidden');
        document.getElementById('reviews-title').innerHTML =
          DukaanData.DUKAAN_LANGUAGE.NO_REVIEWS;
        document.getElementById('no-reviews-cta').classList.remove('hidden');
        document.getElementById('create-review-button').classList.add('hidden');
        if (firstFetchCall) {
          document.querySelector('.filters-container').classList.add('hidden');
        }
      }
      TOTAL_REVIEW_PAGES = Math.ceil((res?.count || 0) / 5);
      ACTIVE_REVIEW_PAGE = page;
      ACTIVE_SORT_FILTER = ordering;
      ACTIVE_STAR_FILTER = rating;
      createReviewsList(reviews);
      createPaginationList(page);
      createImagesModal(allImagesWithReviews);
      const currentBuyerId =
        localStorage && localStorage.al_to
          ? JSON.parse(decodeBase64(localStorage.al_to.split('.')[1])).buyer_id
          : null;
      const currentBuyerReview = reviews.filter(
        (el) => el.buyer === currentBuyerId
      )[0];
      if (localStorage && localStorage.al_to && currentBuyerReview) {
        window.DukaanData.RATINGS_DATA_CLIENT = {
          review: { ...currentBuyerReview },
        };
      }
      if (window.DukaanData?.RATINGS_DATA_CLIENT?.review) {
        document.querySelector('.no-reviews-cta-btn').classList.add('hidden');
        document.querySelector(
          '.no-reviews-cta-text'
        ).innerHTML = `${DukaanData.DUKAAN_LANGUAGE.YOU_HAVE_ALREADY_REVIEWED_THIS_PRODUCT}!`;
      }
    });
};

window.RATING_TEXT_MAP = () => {
  const ratingMap = {
    1: DukaanData.DUKAAN_LANGUAGE.HATED_IT,
    2: DukaanData.DUKAAN_LANGUAGE.DIDNT_LIKE_IT,
    3: DukaanData.DUKAAN_LANGUAGE.JUST_OK,
    4: DukaanData.DUKAAN_LANGUAGE.LIKED_IT,
    5: DukaanData.DUKAAN_LANGUAGE.LOVED_IT,
  };
  return ratingMap;
};

window.setActiveRatingValue = (index) => {
  const ratingsData = window.DukaanData.RATINGS_DATA;
  const prevIndex = (ratingsData?.review?.rating || 0) - 1;
  if (!editingReview || (editingReview && index !== prevIndex)) {
    document.getElementById('review-submit-btn').classList.remove('disabled');
  } else document.getElementById('review-submit-btn').classList.add('disabled');
  index = Number(index);
  const tooltip = document.querySelector(`.tooltip-${index}`);
  tooltip?.classList.remove('hidden');
  const parentEle = document.getElementById('rm-rating-div');
  parentEle.querySelector('.rating-meaning-text').textContent =
    RATING_TEXT_MAP()[index + 1];
  const starList = parentEle.querySelectorAll('.not-selected-star');
  starList.forEach((star, key) => {
    if (key <= index) {
      star.classList.add('selected-rating-star');
    } else if (star.classList.contains('selected-rating-star'))
      star.classList.remove('selected-rating-star');
  });
  document.getElementById('rating-input').value = index + 1;
  setTimeout(() => {
    tooltip.classList.add('hidden');
  }, 500);
};

window.handleTextValueChange = (event) => {
  if (editingReview) {
    const ratingsData = window.DukaanData.RATINGS_DATA;

    if (event) {
      const prevName = ratingsData?.review[event?.target?.name];
      if (event.target.value !== prevName)
        document
          .getElementById('review-submit-btn')
          .classList.remove('disabled');
    }
  }
  const lengthText = document.querySelector('.rm-max-length-text');
  if (lengthText) {
    lengthText.textContent = `${event.target.value.length}/500`;
  }
};

// this function will return array of images without null values
window.getProductReviewImages = () =>
  PRODUCT_REVIEW_IMAGES.filter((el) => !!el);

window.updateReviewImageLimit = () => {
  if (getProductReviewImages().length >= 4) {
    document.querySelector('.rm-form-add-pic-wrap input').disabled = true;
  } else {
    document.querySelector('.rm-form-add-pic-wrap input').disabled = false;
  }
};

window.updateReviewImageCount = () => {
  const productImgsCount = document.querySelector(
    '.product-images-upload-count'
  );
  if (getProductReviewImages().length >= 1) {
    productImgsCount.classList.remove('hidden');
    productImgsCount.textContent = `(${getProductReviewImages().length}/4)`;
  } else {
    productImgsCount.classList.add('hidden');
  }
};

window.checkReviewImageUpdated = (isUploading = false) => {
  const ratingsData = window.DukaanData.RATINGS_DATA;
  const prevImages = ratingsData?.review?.images;
  // if (!prevImages) return;

  if (
    JSON.stringify(getProductReviewImages()) !== JSON.stringify(prevImages) &&
    !isUploading
  ) {
    document.getElementById('review-submit-btn').classList.remove('disabled');
  } else {
    document.getElementById('review-submit-btn').classList.add('disabled');
  }
};

window.handleImageUploadForReview = (event) => {
  const imageObj = event.target.files[0];

  if (!imageObj) return;

  const reader = new FileReader();
  reader.addEventListener(
    'load',
    () => {
      // pushing empty string for updating the count
      PRODUCT_REVIEW_IMAGES.push(' ');
      // rendering local base64 image
      renderProductReviewImages(reader.result, true);
      // image is uploading so disabling the submit / update btn
      checkReviewImageUpdated(true);
      // disabling the upload btn until we get the res
      document.querySelector('.rm-form-add-pic-wrap input').disabled = true;
    },
    false
  );

  if (imageObj) {
    reader.readAsDataURL(imageObj);
  }

  const fd = new FormData();
  fd.append('file', imageObj);
  axios({
    method: 'post',
    url: `https://dms.mydukaan.io/api/media/upload/`,
    data: fd,
    headers: {
      'Content-Type': 'multipart/form-data',
    },
  })
    .then((res) => {
      const result = res.data;
      document.querySelector('.rm-form-add-pic-wrap input').disabled = false;

      if (result && result.data && result.data.cdnURL) {
        const fileUrl = result.data.cdnURL;
        // updating the array with actual url once we get
        PRODUCT_REVIEW_IMAGES[PRODUCT_REVIEW_IMAGES.length - 1] = fileUrl;

        // rendering image from api
        const reviewImages = document.querySelectorAll('.product-review-img');
        reviewImages[reviewImages.length - 1].setAttribute(
          'src',
          getCdnUrl(fileUrl, 400)
        );

        // check image update for edit and enabling the submit / update btn
        checkReviewImageUpdated(false);
      } else {
        handleImageUploadFailed();
      }
    })
    .catch((err) => {
      handleImageUploadFailed();
    });
};

window.handleImageUploadFailed = () => {
  // remove the last element from array
  PRODUCT_REVIEW_IMAGES.shift();
  // remove the last rendered review image card
  const reviewImages = document.querySelectorAll('.review-image-card');
  reviewImages[reviewImages.length - 1].remove();

  // updating count and limit
  updateReviewImageLimit();
  updateReviewImageCount();
};

window.renderProductReviewImages = (
  reviewImage = '',
  isLocalPreviewImage = false
) => {
  const reviewImgsContainer = document.querySelector('.display-review-images');
  const productReviewImgCard = document.importNode(
    document.querySelector('#product-review-images').content,
    true
  );

  productReviewImgCard
    .querySelector('img')
    .setAttribute(
      'src',
      isLocalPreviewImage
        ? reviewImage
        : `${getCdnUrl(
            reviewImage ||
              PRODUCT_REVIEW_IMAGES[PRODUCT_REVIEW_IMAGES.length - 1],
            100
          )}`
    );

  productReviewImgCard
    .querySelector('svg')
    .setAttribute('id', PRODUCT_REVIEW_IMAGES.length - 1);

  reviewImgsContainer.appendChild(productReviewImgCard);

  // updating count and limit
  updateReviewImageLimit();
  updateReviewImageCount();
};

window.handleDeleteProductReviewImages = (event) => {
  const { parentNode } = event.currentTarget;
  const closeUploadingImgId = event.currentTarget.id;

  PRODUCT_REVIEW_IMAGES[closeUploadingImgId] = null;

  parentNode.remove();

  // check for image update on edit
  checkReviewImageUpdated();

  // updating count and limit
  updateReviewImageLimit();
  updateReviewImageCount();
};

const addParamMessage = () => {
  const urlParams = new URLSearchParams(window.location.search);
  const paramSuccessMessage = urlParams.get('message');

  const message = document.querySelectorAll('.review-success-message');
  message.forEach((m) => {
    if (paramSuccessMessage) {
      m.classList.remove('hidden');
      m.textContent = paramSuccessMessage;
    } else {
      m.classList.add('hidden');
      m.textContent = '';
    }
  });
};

window.handleReviewSubmit = (event) => {
  event.preventDefault();
  const reviewFormData = new FormData(
    document.querySelector('form#review-form')
  );
  const payload = [...reviewFormData.entries()].reduce((acc, [key, value]) => {
    acc[key] = value;
    return acc;
  }, {});
  payload.rating = Number(payload.rating);
  payload.images = getProductReviewImages() || [];

  // if (!!payload.images) payload['images'] = [];

  if (
    document.querySelectorAll('.rm-rating-star.selected-rating-star').length <=
    0
  ) {
    const starsWrapper = document.getElementById('rm-rating-star-wrapper');
    starsWrapper.classList.add('error-field');
    starsWrapper.classList.add('shake');
    setTimeout(() => starsWrapper.classList.remove('shake'), 800);
    document.getElementById('review-helper-text').textContent =
      DukaanData.DUKAAN_LANGUAGE.STARS_ARE_REQUIRED;
    return;
  }

  if (payload.full_name.trim() === '') {
    const formDiv = document.getElementById('full_name-input').parentNode;
    formDiv.classList.add('error-field');
    formDiv.classList.add('shake');
    setTimeout(() => formDiv.classList.remove('shake'), 800);
    document.getElementById('full_name-helper-text').textContent =
      DukaanData.DUKAAN_LANGUAGE.NAME_IS_REQUIRED;
    return;
  }

  document.getElementById('review-submit-btn')?.classList.add('disabled');

  if (localStorage && localStorage.al_to && !editingReview) {
    axios
      .post(
        `${window.DukaanData.CLIENT_API_ENDPOINT}/api/product/buyer/${
          window?.reviewProduct?.id || window.DukaanData.DUKAAN_PRODUCT.id
        }/product/review/`,
        payload,
        {
          headers: {
            Authorization: `Bearer ${localStorage.al_to}`,
            'x-requested-with': window?.DukaanData?.DUKAAN_SESSION_ID,
          },
        }
      )
      .then((res) => {
        document
          .getElementById('review-submit-btn')
          .classList.remove('disabled');

        const urlParams = new URLSearchParams(window.location.search);
        const paramSuccessMessage = urlParams.get('message');
        if (paramSuccessMessage) {
          addParamMessage();
        } else {
          closeWriteReviewModal();
          enqueueSnackbar(
            DukaanData.DUKAAN_LANGUAGE.REVIEW_POSTED_SUCCESSFULLY,
            true,
            'success'
          );
        }
        mainReviewFetchCall();
        window.DukaanData.RATINGS_DATA_CLIENT = { review: { ...payload } };
      })
      .catch((e) => console.log(e));
  }

  if (editingReview) {
    axios
      .patch(
        `${window.DukaanData.CLIENT_API_ENDPOINT}/api/product/buyer/${
          window?.reviewProduct?.id || window.DukaanData.DUKAAN_PRODUCT.id
        }/product/review/${currentUserReviewId}/`,
        payload,
        {
          headers: {
            Authorization: `Bearer ${localStorage.al_to}`,
          },
        }
      )
      .then((res) => {
        closeWriteReviewModal();
        mainReviewFetchCall();
        enqueueSnackbar(
          DukaanData.DUKAAN_LANGUAGE.REVIEW_UPDATED_SUCCESSFULLY,
          true,
          'success'
        );
      })
      .catch((e) => console.log(e));
  }
};

window.openWriteReviewModal = (
  isEditing = false,
  { openedFromParams = false } = {}
) => {
  document.getElementsByTagName('body')[0].style.overflow = 'hidden';
  const reviewModal = document.getElementById('write-review-modal');
  reviewModal.classList.remove('hidden');
  if (openedFromParams) {
    const urlParams = new URLSearchParams(window.location.search);
    const paramRating = urlParams.get('rating');
    const paramReview = urlParams.get('review');
    const paramName = urlParams.get('name');
    // const paramCoupon = urlParams.get('coupon');

    const paramObject = {
      full_name: paramName,
      description: paramReview,
    };

    const reviewFormData = new FormData(
      document.querySelector('form#review-form')
    );
    const payload = [...reviewFormData.entries()].reduce(
      (acc, [key, value]) => {
        acc[key] = value;
        return acc;
      },
      {}
    );
    Object.entries(payload).forEach(([key]) => {
      if (key === 'rating') {
        setActiveRatingValue(parseInt(paramRating, 10) - 1);
        return;
      }
      if (document.getElementById(`${key}-input`)) {
        document.getElementById(`${key}-input`).value = paramObject[key] || '';
      }
    });
  }

  if (isEditing) {
    editingReview = true;
    const ratingsData = window.DukaanData.RATINGS_DATA;
    reviewModal.querySelectorAll('.write-review-heading').forEach(
      // eslint-disable-next-line no-return-assign
      (heading) =>
        (heading.textContent = DukaanData.DUKAAN_LANGUAGE.EDIT_REVIEW)
    );
    reviewModal.querySelector('.review-submit-btn').textContent =
      DukaanData.DUKAAN_LANGUAGE.UPDATE;

    // render rating images
    if (ratingsData?.review?.images && ratingsData?.review?.images.length > 0) {
      ratingsData?.review?.images.forEach((img) => {
        PRODUCT_REVIEW_IMAGES.push(img);
        renderProductReviewImages(img);
      });
    }

    const reviewFormData = new FormData(
      document.querySelector('form#review-form')
    );
    const payload = [...reviewFormData.entries()].reduce(
      (acc, [key, value]) => {
        acc[key] = value;
        return acc;
      },
      {}
    );
    const { review = {} } = ratingsData || {};
    Object.entries(payload).forEach(([key, value]) => {
      if (key === 'rating') setActiveRatingValue(review.rating - 1);
      if (document.getElementById(`${key}-input`))
        document.getElementById(`${key}-input`).value = review[key];
    });
  }
};

window.closeWriteReviewModal = () => {
  document.getElementsByTagName('body')[0].style.overflow = 'auto';
  document.getElementById('write-review-modal').classList.add('hidden');
  // clearing all input fields on closing the review modal
  PRODUCT_REVIEW_IMAGES = [];
  document.querySelector('.display-review-images').innerHTML = null;

  document.querySelector('#full_name-input').value = '';
  document.querySelector('#description-input').value = '';
  document.querySelector('.rating-meaning-text').textContent = '';
  document
    .querySelectorAll('.rm-rating-star')
    .forEach((el) => el.classList.remove('selected-rating-star'));
};

window.handleButtonClick = () => {
  initDukaanAuth(successCallBack.bind(this, !!localStorage.getItem('al_to')));
};

window.successCallBack = (isLoggedInOnClick) => {
  const commonHandler = (ratingsData) => {
    const {
      can_write_review: canWriteReview,
      review_verified_purchase_only: reviewVerifiedPurchaseOnly,
    } = ratingsData;
    const canReview = canWriteReview;
    const purchaseRequired = reviewVerifiedPurchaseOnly || false;
    if (purchaseRequired && !canReview) {
      enqueueSnackbar(
        `${DukaanData.DUKAAN_LANGUAGE.YOU_NEED_TO_PURCHASE_THE_PRODUCT_FIRST}!`,
        true,
        'error'
      );
    } else if (!canReview) {
      enqueueSnackbar(`You've already reviewed this product!`, true, 'error');
    } else {
      openWriteReviewModal();
    }
  };
  if (isLoggedInOnClick) {
    commonHandler(window.DukaanData.RATINGS_DATA);
  } else {
    mainReviewFetchCall(false, commonHandler);
  }
};

window.openDeleteModal = () => {
  document.getElementsByTagName('body')[0].style.overflow = 'hidden';
  document.getElementById('review-delete-modal').classList.remove('hidden');
};

window.closeDeleteModal = () => {
  document.getElementsByTagName('body')[0].style.overflow = 'auto';
  document.getElementById('review-delete-modal').classList.add('hidden');
};

window.deleteReview = () => {
  const headers = {};
  if (localStorage && localStorage.al_to)
    headers.Authorization = `Bearer ${localStorage.al_to}`;
  axios
    .delete(
      `${window.DukaanData.CLIENT_API_ENDPOINT}/api/product/buyer/${
        window?.reviewProduct?.id || window.DukaanData.DUKAAN_PRODUCT.id
      }/product/review/${currentUserReviewId}/`,
      { headers }
    )
    .then((res) => {
      closeDeleteModal();
      enqueueSnackbar(
        DukaanData.DUKAAN_LANGUAGE.REVIEW_DELETED_SUCCESSFULLY,
        true,
        'success'
      );
      editingReview = false;
      mainReviewFetchCall();
    })
    .catch((e) => console.log(e));
};

if (!window.reviewRendered) {
  renderReviewsPlugin();
}
