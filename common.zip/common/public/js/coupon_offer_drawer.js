window.toggleShowHideState = (event, code) => {
  const { parentNode } = event.target.parentElement;
  const couponDetails = parentNode.querySelector(`.details`);
  const upArrowDetails = parentNode.querySelector(`.details-up-arrow`);
  const downArrowDetails = parentNode.querySelector(`.details-down-arrow`);
  if (couponDetails.classList.contains('hidden')) {
    couponDetails.classList.remove('hidden');
    upArrowDetails.classList.remove('hidden');
    downArrowDetails.classList.add('hidden');
  } else {
    couponDetails.classList.add('hidden');
    upArrowDetails.classList.add('hidden');
    downArrowDetails.classList.remove('hidden');
  }
};

window.handleCloseDrawer = () => {
  const modal = document.getElementById('coupon-offers-drawer');
  modal.classList.add('hidden');
};

window.handleDrawerOpen = () => {
  const modal = document.getElementById('coupon-offers-drawer');
  modal.classList.remove('hidden');
  fetchCoupons({
    successCallback: () => {
      couponListRenderer();
      offerListRenderer();
    },
  });
};
