window.appInitializer = () => {
  const navButtonWishlist = document.querySelector(
    '.dkn-wishlist-page-navigation-button'
  );
  if (navButtonWishlist) navButtonWishlist.classList.add('is-active');

  q$.selectAll('.dkn-wishlist-nav_inactive').addClassAll('hidden');
  q$.selectAll('.dkn-wishlist-nav_active').removeClassAll('hidden');

  const wishlistPageSectionLoadPoint = window.q$.select(
    'dkn-wishlist-page-section'
  ).elem;

  if (!wishlistPageSectionLoadPoint) return;
  const wishlistPageSectionTemplate = window.q$
    .selectById('dkn-wishlist-page-section-template')
    .getTemplateContent().elem;

  if (!wishlistPageSectionTemplate) return;
  wishlistPageSectionLoadPoint.innerHTML = '';
  wishlistPageSectionLoadPoint.appendChild(wishlistPageSectionTemplate);

  let loading = false;
  let productsRendereredCount = 0;
  let hasMore = true;
  let pageNumber = 1;

  const wishlistedProductListLoadPoint = window.q$.select(
    'dkn-wishlisted-product-list-load-point'
  ).elem;

  if (!wishlistedProductListLoadPoint) return;

  const dknFetchWishlistedProducts = () => {
    if (loading) return;
    loading = true;
    // not loggedin
    if (!localStorage?.al_to) {
      window.totalWishlistCountRenderer({ totalProductsCount: 0 });
      wishlistedProductListLoadPoint.classList.add('hidden');
      window.showNoProductsLottie();
      return;
    }

    const headers = {};
    if (localStorage && localStorage.al_to)
      headers.Authorization = `Bearer ${localStorage.al_to}`;
    headers['Content-Type'] = 'application/json';
    headers['x-requested-with'] = window?.DukaanData?.DUKAAN_SESSION_ID;

    fetch(
      `${window.DukaanData.CLIENT_API_ENDPOINT}/api/store/buyer/wishlist/${window.DukaanData.DUKAAN_STORE.id}/products/?page=${pageNumber}`,
      {
        method: 'GET',
        headers,
      }
    )
      .then((res) => res.json())
      .then((resp) => {
        let products = resp?.results;
        products = window.languageSerializer(products);
        const totalProductsCount = resp?.count;

        const dknSerializeProductData = (product) => {
          let serializedSKUs = window.dknSerializeSKUs(product?.skus || []);

          if (
            DukaanData.PRODUCTS_MAP &&
            product.uuid in DukaanData.PRODUCTS_MAP
          ) {
            serializedSKUs = [
              ...DukaanData.PRODUCTS_MAP[product.uuid].skus,
              ...serializedSKUs,
            ];
          }

          const attributes = dknGetAllProductAttributeValues(serializedSKUs);
          const { addOnsList = [], addOns = [] } =
            window.dknGetSerializedAddons(product) || {};

          return {
            ...product,
            ...window.languageSerializer(product),
            skus: serializedSKUs,
            attributes,
            addOnsList,
            addOns,
            skusApi: false,
          };
        };

        DukaanData.PRODUCTS_MAP = {
          ...(DukaanData.PRODUCTS_MAP || {}),
        };
        products.reduce((map, product) => {
          if (!product) return map;
          DukaanData.PRODUCTS_MAP[product.uuid] =
            dknSerializeProductData(product);
          return map;
        }, {});

        if (pageNumber === 1) {
          wishlistedProductListLoadPoint.innerHTML = '';
        }
        window.totalWishlistCountRenderer({ totalProductsCount });
        window.wishlistedProductsRenderer(
          wishlistedProductListLoadPoint,
          products
        );

        productsRendereredCount += products.length;

        if (totalProductsCount <= productsRendereredCount) {
          hasMore = false;
          window.removeScroller({ observeThis: 'wishlist-observer' });
        } else {
          hasMore = true;
          pageNumber += 1;
        }
        loading = false;
      })
      .catch((err) => {
        console.log(`dknFetchWishlistedProducts ${err}`);
        window.totalWishlistCountRenderer({ totalProductsCount: 0 });
        wishlistedProductListLoadPoint.classList.add('hidden');
        window.showNoProductsLottie();
      });
  };

  window.applyScroller({
    loading,
    hasMore,
    cb: dknFetchWishlistedProducts,
    observeThis: 'wishlist-observer',
    loadPoint: window.q$.select('dkn-wishlisted-product-list-load-point').elem,
  });
  dknFetchWishlistedProducts();
};

window.dknAddProductsToProductsMap = (products = []) => {
  if (!products?.length) return;

  const productsMap = products?.reduce((map, product) => {
    if (!product) return map;
    map[product.uuid] = dknSerializeProductData(product);
    return map;
  }, {});

  DukaanData.PRODUCTS_MAP = {
    ...(DukaanData.PRODUCTS_MAP || {}),
    ...(productsMap || {}),
  };
};

window.wishlistedProductsRenderer = (
  mountElement,
  products,
  options = {
    additionalRenderer: window.wishlistCardAdditionalRenderer,
    getCustomDiscountText: window.customDiscountText,
  }
) => {
  products.forEach((product) => {
    if (!product?.skus?.[0]?.uuid) return;

    const productContext = {
      key: 'wishlist-card',
      productUUID: product.uuid,
      skuUUID: product.skus[0].uuid,
      wishlistID: product.wishlist_id,
    };
    const parentElementtemp = window.q$
      .selectById('dkn-wishlist-card-template')
      .getTemplateContent().elem;

    const parentElement = window.q$.select(
      '.dkn-wishlist-card',
      parentElementtemp
    ).elem;

    window.dknProductDataRenderer(productContext, parentElement, options);
    mountElement.appendChild(parentElement);
  });
  const productIds = products.map((product) => product.id);
  window.fetchProductCoupons(productIds);
  window.fetchRatingsDataFromProductIds(productIds, mountElement, {
    reviewInfoTemplateId:
      window.productCardReviewTemplateId ||
      'dkn-product-review-with-count-template',
    getCustomReviewsCountText: window.getCustomReviewsCountText,
    starHeight: window.productCardStarHeight,
    starWidth: window.productCardStarWidth,
  });
};

window.wishlistCardAdditionalRenderer = (
  productContext,
  parentElement,
  options
) => {
  const { productUUID, skuUUID, wishlistID } = productContext;
  const product = window.DukaanData.PRODUCTS_MAP[productUUID];
  const activeSKU = product?.skus?.find((sku) => sku.uuid === skuUUID) || {};

  parentElement.setAttribute('data-wishlist-id', wishlistID);
  parentElement.setAttribute('data-sku-uuid', skuUUID);

  const productVariantInfoElem = window.q$.select(
    '.dkn-product-variant-info',
    parentElement
  ).elem;
  if (productVariantInfoElem) {
    productVariantInfoElem.classList.remove('hidden');

    const attributes = activeSKU?.attributes;
    const newMeta = activeSKU?.new_meta;
    const newMetaKeys = Object.keys(newMeta);

    if (!newMetaKeys.length) {
      const baseQtyTemplate = window.q$
        .selectById('dkn-product-variant-info-base-qty-item-template')
        .getTemplateContent().elem;
      const baseQtyElem = window.q$.select(
        '.dkn-product-variant-info-base-qty-item',
        baseQtyTemplate
      ).elem;
      if (baseQtyElem) {
        const baseQty = product?.base_qty;
        const unit = product?.unit ? product.unit : '';
        baseQtyElem.textContent = `${baseQty} ${unit}`;
        productVariantInfoElem.appendChild(baseQtyTemplate);
      }
    } else {
      attributes.forEach((attribute) => {
        if (newMeta[attribute.master_attribute].type === 'size') {
          const sizeItemTemplate = window.q$
            .selectById('dkn-product-variant-info-size-item-template')
            .getTemplateContent().elem;

          const sizeItemElem = window.q$.select(
            '.dkn-product-variant-info-size-item',
            sizeItemTemplate
          ).elem;

          sizeItemElem.textContent = newMeta[attribute.master_attribute].value;
          productVariantInfoElem.appendChild(sizeItemTemplate);
        }
        if (newMeta[attribute.master_attribute].type === 'color') {
          const colorItemTemplate = window.q$
            .selectById('dkn-product-variant-info-color-item-template')
            .getTemplateContent().elem;

          const colorItemElem = window.q$.select(
            '.dkn-product-variant-info-color-item',
            colorItemTemplate
          ).elem;

          colorItemElem.style.backgroundColor =
            newMeta[attribute.master_attribute].value;

          productVariantInfoElem.appendChild(colorItemTemplate);
        }
      });
    }
  }

  window.q$.select('.wishlist-card-overlay', parentElement).addClass('hidden');
  window.q$
    .selectAll('.dkn-delete-wishlist-button', parentElement)
    .setAttributeAll(
      'onclick',
      `handleDeleteWishlistButtonClick(${wishlistID})`
    );

  // first seen in uppercase
  const categoryName = product?.categories?.[0]?.name;
  if (categoryName) {
    window.q$
      .select('.dkn-category-name', parentElement)
      .modifyTextContent(categoryName);
  }
  // first seen in healthxp
  const brandImage = product?.brand?.logo;
  if (brandImage) {
    window.dknImageRenderer(
      brandImage,
      '.dkn-product-brand-logo',
      parentElement,
      {
        imageCdnWidth: 100,
      }
    );
  }

  // move to bag button renderer
  const moveToBagElement = window.q$.select(
    'move-to-bag-button',
    parentElement
  );
  if (moveToBagElement.elem) {
    moveToBagElement.setDataAttribute('productUuid', productUUID);
    moveToBagElement.setDataAttribute('skuUuid', skuUUID);
    moveToBagElement.setDataAttribute(
      'addToBagTemplateId',
      'dkn-move-to-bag-button-template'
    );
    moveToBagElement.setDataAttribute(
      'outStockTemplateId',
      'dkn-move-to-bag-out-of-stock-button-template'
    );
    window.addToBagButtonRenderer(moveToBagElement.elem);
  }
};

window.afterAddToBagCall = (productUUID, skuUUID) => {
  const wishlistCardElem = window.q$.select(
    `.dkn-wishlist-card[data-sku-uuid="${skuUUID}"]`
  ).elem;

  if (wishlistCardElem) {
    const wishlistID = wishlistCardElem.dataset.wishlistId;
    window.handleDeleteWishlistButtonClick(wishlistID, {
      showSnackbar: false,
    });
  }
};

window.customDiscountText = (discountPercent) => `(${discountPercent}% OFF)`;
window.customTotalWishlistCount = (totalWishlistCount) =>
  `${
    window.DukaanData.DUKAAN_LANGUAGE.MY_WISHLIST || 'My wishlist'
  } (${totalWishlistCount})`;

window.handleDeleteWishlistButtonClick = (
  wishlistID,
  options = {
    showSnackbar: true,
  }
) => {
  if (!wishlistID) {
    window.enqueueSnackbar(
      DukaanData.DUKAAN_LANGUAGE.FAILED_TO_REMOVE_PRODUCT_FROM_WISHLIST,
      true,
      'error'
    );
    return;
  }

  const wishlistCard = window.q$.select(`[data-wishlist-id="${wishlistID}"]`);
  const wishlistCardElem = wishlistCard.elem;

  if (wishlistCardElem) {
    const cardOverlay = window.q$.select(
      '.wishlist-card-overlay',
      wishlistCardElem
    );
    cardOverlay.removeClass('hidden');
    cardOverlay.addClass('wishlist-card-overlay-delete');

    window.dknDeleteWishlistProduct({
      wishlistID,
      successCb: () => {
        document.querySelector(`[data-wishlist-id="${wishlistID}"]`).remove();
        window.updateTotalWishlistCount();
        if (options.showSnackbar) {
          window.enqueueSnackbar(
            DukaanData.DUKAAN_LANGUAGE.PRODUCT_REMOVED_FROM_WISHLIST,
            true,
            'success'
          );
        }
      },
      errorCb: ({ err }) => {
        // console.log(err);
        cardOverlay.addClass('hidden');
        cardOverlay.removeClass('wishlist-card-overlay-delete');
        if (options.showSnackbar) {
          window.enqueueSnackbar(
            DukaanData.DUKAAN_LANGUAGE.FAILED_TO_REMOVE_PRODUCT_FROM_WISHLIST,
            true,
            'error'
          );
        }
      },
    });
  }
};

window.updateTotalWishlistCount = () => {
  const totalWishlistCountElems = window.q$.selectAll(
    '.dkn-total-wishlist-count'
  ).elem;

  const updatedWishlistCount =
    totalWishlistCountElems[0].dataset.wishlistCount - 1;
  if (updatedWishlistCount === 0) {
    window.showNoProductsLottie();
  }
  window.totalWishlistCountRenderer({
    totalProductsCount: updatedWishlistCount,
  });
};

window.showNoProductsLottie = () => {
  const wishlistsSectionElement = document.querySelector(
    '.dkn-wishlist-page-section'
  );
  wishlistsSectionElement.innerHTML = '';

  const noWishlistsFoundElement = document.getElementById('no-wishlists-found');
  noWishlistsFoundElement.classList.remove('hidden');
  noWishlistsFoundElement.classList.add('dkn-wishlist-page-section');
};

window.totalWishlistCountRenderer = ({
  totalProductsCount,
  options = {},
} = {}) => {
  // setting the count on page render + updating the data attr.
  const totalWishlistCountElems = window.q$.selectAll(
    '.dkn-total-wishlist-count'
  );

  if (!totalProductsCount) {
    totalWishlistCountElems.addClassAll('hidden');
    window.showNoProductsLottie();
  } else {
    let totalWishlistCountText = '';
    totalWishlistCountElems.removeClassAll('hidden');

    if (typeof window.getCustomTotalWishlistCountText !== 'function') {
      totalWishlistCountText = `${
        window.DukaanData.DUKAAN_LANGUAGE.WISHLIST || 'Wishlist'
      } (${totalProductsCount})`;
    } else {
      totalWishlistCountText =
        window.getCustomTotalWishlistCountText(totalProductsCount);
    }
    totalWishlistCountElems.modifyInnerHTMLAll(totalWishlistCountText);

    totalWishlistCountElems.setAttributeAll(
      'data-wishlist-count',
      totalProductsCount
    );
  }
};
