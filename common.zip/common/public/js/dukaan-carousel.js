window.dknUpdateCarouselState = (carouselId, index) => {
  index = Number(index);
  const carouselWrapper = q$.selectById(carouselId).elem;
  carouselWrapper.setAttribute('data-selected-index', `${index}`);
  const selectedThumbnail = q$.select(
    `.dkn-thumbnail-${index}`,
    carouselWrapper
  ).elem;

  const mainImage = q$.select('.dkn-carousel-main-image', carouselWrapper).elem;
  if (!mainImage || !selectedThumbnail) return;
  mainImage.setAttribute('src', selectedThumbnail?.src);
  q$.select('.dkn-carousel-main-link', carouselWrapper).setAttribute(
    'href',
    selectedThumbnail.dataset.bannerLink
  );

  const thumbnails = q$.selectAll(
    '.dkn-thumbnail.active',
    carouselWrapper
  ).elem;

  thumbnails?.forEach((thumbnailItem) => {
    thumbnailItem.classList.remove('active');
    thumbnailItem.classList.add('white-overlay');
  });

  if (selectedThumbnail) {
    selectedThumbnail.classList.remove('white-overlay');
    selectedThumbnail.classList.add('active');
  }
  const { totalSlides } = carouselWrapper.dataset;
  q$.select('.dkn-carousel-prev-button', carouselWrapper).removeClass(
    'inactive-icon'
  );
  q$.select('.dkn-carousel-next-button', carouselWrapper).removeClass(
    'inactive-icon'
  );
  if (index === 0) {
    q$.select('.dkn-carousel-prev-button', carouselWrapper).addClass(
      'inactive-icon'
    );
  } else if (index === Number(totalSlides) - 1) {
    q$.select('.dkn-carousel-next-button', carouselWrapper).addClass(
      'inactive-icon'
    );
  }

  const controlDots = q$.selectAll(`.dkn-control-dots`, carouselWrapper).elem;
  controlDots?.forEach((controlDot) => controlDot.classList.remove('active'));
  q$.select(`.dkn-control-dot-${index}`, carouselWrapper).addClass('active');

  const slideList = q$.selectAll(`.dkn-carousel-slide`, carouselWrapper).elem;
  slideList?.forEach((slide, i) => {
    slide.style.transform = `translateX(${100 * (i - index)}%)`;
  });
};

window.dknHandlePrevClickForCarousel = (carouselId) => {
  const carouselWrapper = q$.selectById(carouselId).elem;
  let index = Number(carouselWrapper.dataset.selectedIndex) - 1;

  if (index >= 0) {
    q$.select(
      '.dkn-carousel-thumbnail-wrapper',
      carouselWrapper
    ).elem?.scrollBy({ left: -130, behavior: 'smooth' });
    dknUpdateCarouselState(carouselId, index);
  } else {
    index = 0;
    q$.select('.dkn-carousel-prev-button', carouselWrapper).addClass(
      'inactive-icon'
    );
    carouselWrapper.setAttribute('data-selected-index', `${index}`);
  }
};

window.dknHandleNextClickForCarousel = (carouselId) => {
  const carouselWrapper = q$.selectById(carouselId).elem;
  const { totalSlides } = carouselWrapper.dataset;
  let index = Number(carouselWrapper.dataset.selectedIndex) + 1;

  if (index < totalSlides && index >= 0) {
    q$.select(
      '.dkn-carousel-thumbnail-wrapper',
      carouselWrapper
    ).elem?.scrollBy({ left: +130, behavior: 'smooth' });
    dknUpdateCarouselState(carouselId, index);
  } else {
    index = totalSlides - 1;
    q$.select('.dkn-carousel-next-button', carouselWrapper).addClass(
      'inactive-icon'
    );
    carouselWrapper.setAttribute('data-selected-index', `${index}`);
  }
};

window.dknHandleCarouselScrollRight = (carouselId) => {
  const carouselWrapper = q$.selectById(carouselId).elem;
  const { totalSlides } = carouselWrapper.dataset;
  let index = Number(carouselWrapper.dataset.selectedIndex) + 1;
  if (index < totalSlides) {
    dknUpdateCarouselState(carouselId, index);
  } else {
    index = totalSlides - 1;
    carouselWrapper.setAttribute('data-selected-index', `${index}`);
  }
};

window.dknHandleCarouselScrollLeft = (carouselId) => {
  const carouselWrapper = q$.selectById(carouselId).elem;
  let index = Number(carouselWrapper.dataset.selectedIndex) - 1;
  if (index >= 0) {
    dknUpdateCarouselState(carouselId, index);
  } else {
    index = 0;
    carouselWrapper.setAttribute('data-selected-index', `${index}`);
  }
};

window.dknHandleThumbnailsScroll = (e) => {
  const { target } = e;
  const { carouselId } = target.dataset;
  const carouselWrapper = q$.selectById(carouselId).elem;
  if (target.scrollLeft === 0)
    q$.select('.dkn-carousel-prev-button', carouselWrapper).addClass(
      'inactive-icon'
    );
  else
    q$.select('.dkn-carousel-prev-button', carouselWrapper).removeClass(
      'inactive-icon'
    );

  if (target.scrollWidth - 30 <= target.clientWidth + target.scrollLeft)
    q$.select('.dkn-carousel-next-button', carouselWrapper).addClass(
      'inactive-icon'
    );
  else
    q$.select('.dkn-carousel-next-button', carouselWrapper).removeClass(
      'inactive-icon'
    );
};

window.dknHandleCarouselGesture = (carouselId) => {
  const carouselWrapper = q$.selectById(carouselId).elem;
  const { touchendX, touchstartX } = carouselWrapper.dataset;
  if (touchendX < touchstartX) {
    dknHandleCarouselScrollRight(carouselId);
  }
  if (touchendX > touchstartX) {
    dknHandleCarouselScrollLeft(carouselId);
  }
};

window.dknHandleCarouselTouchEnd = (e) => {
  const { carouselId } = e.target.dataset;
  const carouselWrapper = q$.selectById(carouselId).elem;
  carouselWrapper.dataset.touchendX = e.changedTouches[0].screenX;
  dknHandleCarouselGesture(carouselId);
};

window.dknHandleCarouselTouchStart = (e) => {
  const { carouselId } = e.target.dataset;
  const carouselWrapper = q$.selectById(carouselId).elem;
  carouselWrapper.dataset.touchstartX = e.changedTouches[0].screenX;
};

window.initDukaanCarousel = (carouselId, options) => {
  const { defaultIndex = 0 } = options || {};
  const { isMobile } = deviceType();

  const carouselWrapper = q$.selectById(carouselId).elem;
  if (!carouselWrapper) return;

  carouselWrapper.setAttribute('data-selected-index', '0');
  const thumbnails = q$.selectAll('.dkn-thumbnail', carouselWrapper).elem;
  carouselWrapper.setAttribute('data-total-slides', `${thumbnails?.length}`);
  const thumbnailWrapper = q$.select(
    '.dkn-carousel-thumbnail-wrapper',
    carouselWrapper
  ).elem;
  thumbnailWrapper?.setAttribute('data-carousel-id', carouselId);

  const slidesWrapper = q$.select(
    '.dkn-carousel-slide-wrapper',
    carouselWrapper
  ).elem;

  thumbnailWrapper?.addEventListener('scroll', dknHandleThumbnailsScroll);
  if (isMobile && slidesWrapper) {
    slidesWrapper.setAttribute('data-carousel-id', carouselId);

    slidesWrapper.addEventListener('touchstart', dknHandleCarouselTouchStart, {
      passive: true,
    });
    slidesWrapper.addEventListener('touchend', dknHandleCarouselTouchEnd, {
      passive: true,
    });
  }
  if (thumbnails?.length > 1) {
    q$.select('.dkn-carousel-prev-button', carouselWrapper).removeClass(
      'hidden'
    );
    q$.select('.dkn-carousel-next-button', carouselWrapper).removeClass(
      'hidden'
    );
  }

  dknUpdateCarouselState(carouselId, defaultIndex);
};

window.dknLoopCarousel = (carouselId) => {
  const carouselWrapper = q$.selectById(carouselId).elem;
  if (!carouselWrapper) return;
  let { selectedIndex } = carouselWrapper.dataset;
  selectedIndex = Number(selectedIndex);
  selectedIndex += 1;
  const totalSlides = Number(carouselWrapper.dataset.totalSlides);
  if (totalSlides === 1) return;
  if (selectedIndex === totalSlides) {
    selectedIndex = 0;
  }
  dknUpdateCarouselState(carouselId, selectedIndex);
};
