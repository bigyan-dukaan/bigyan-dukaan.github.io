document
  .querySelector('[data-button="store-locator"]')
  ?.classList.add('active');

window.fetchStoreLocatorData = () => {
  fetch(
    `https://store-locator.apps.mydukaan.io/store/${DukaanData.DUKAAN_STORE.link}`,
    {
      headers: {
        'Content-Type': 'application/json',
        'x-requested-with': window?.DukaanData?.DUKAAN_SESSION_ID,
        // 'Content-Type': 'application/x-www-form-urlencoded',
      },
    }
  )
    .then((res) => res.json())
    .then((res) => {
      const stores = res?.data?.stores;
      renderStoreLocatorCard(stores);
      renderStoreLocatorFilters(stores);
    })
    .catch(() => {});
};

window.convertTo12HrsFormat = (time) => {
  const date = new Date(`April 14, 22 ${time}`);
  return date.toLocaleString('en-US', {
    hour: 'numeric',
    minute: 'numeric',
    hour12: true,
  });
};

window.getStoreTiming = (timing) => {
  const { day, from_time, to_time } = timing;
  return `${day.substring(0, 3)}, ${convertTo12HrsFormat(
    from_time
  )} - ${convertTo12HrsFormat(to_time)}`;
};

window.getMapLocation = (lat, long) =>
  `https://www.google.com/maps/search/?api=1&query=${lat}%2C${long}`;

window.renderStoreLocatorCard = (stores) => {
  if (stores?.length === 0) return;

  const cardTemplate = document.getElementById('store-locator-card');
  const storeCardWrapper = document.querySelector(
    '.store-locator__cards-wrapper'
  );
  storeCardWrapper.innerHTML = '';

  stores?.map((store) => {
    const { store_details: storeDetails, store_timings } = store;
    const {
      store_name,
      store_address,
      city,
      state,
      pin_code,
      contact_number,
      latitude,
      longitude,
    } = storeDetails;
    const storeCard = document.importNode(cardTemplate.content, true);
    storeCard.querySelector('.store-locator__card').dataset.state = state;
    storeCard.querySelector('.store-locator__card').dataset.city = city;
    storeCard.querySelector('.store-locator__card').dataset.pincode = pin_code;

    storeCard.querySelector('.store-locator__card-title').textContent =
      store_name;
    storeCard.querySelector('.store-locator__card-address').textContent = `${
      store_address || ''
    }${city ? ',' : ''} ${city || ''}${state ? ',' : ''} ${state || ''} ${
      pin_code || ''
    }`;
    const timingTitle = storeCard.querySelector(
      '.store-locator__card-sub-title'
    );
    const timingList = storeCard.querySelector('.store-locator__timing-list');
    store_timings.map((timing) => {
      if (timing.online) {
        const timeTemplate = document.getElementById('timing-li');
        const timeli = document.importNode(timeTemplate.content, true);
        timeli.querySelector('.store-locator__card-timing').textContent =
          getStoreTiming(timing);
        timingList.appendChild(timeli);
        timingTitle.classList.remove('hidden');
      }
    });
    if (contact_number) {
      storeCard.querySelector('.store-locator__card-contact-no').textContent =
        contact_number;
      storeCard
        .querySelector('.store-locator__card-contact-no')
        .setAttribute('href', `tel:${contact_number}`);
    } else {
      storeCard.querySelector('.contact-no-title').classList.add('hidden');
    }
    if (latitude && longitude) {
      storeCard
        .querySelector('.store-locator__card-direction')
        .setAttribute('href', getMapLocation(latitude, longitude));
      storeCard
        .querySelector('.store-locator__card-direction')
        .classList.remove('hidden');
    }
    storeCardWrapper.appendChild(storeCard);
  });
};

window.renderStoreLocatorFilters = (stores) => {
  if (stores?.length === 0) return;
  // filter templatesd
  const pincodeFilterTemplate = document.getElementById(
    'pincode-filter-template'
  );
  const cityFilterTemplate = document.getElementById('city-filter-template');
  const stateFilterTemplate = document.getElementById('state-filter-template');

  // filter load points
  const stateFilterLoadPoints = document.querySelectorAll(
    'state-filter-load-point'
  );
  const cityFilterLoadPoints = document.querySelectorAll(
    'city-filter-load-point'
  );
  const pincodeFilterLoadPoints = document.querySelectorAll(
    'pincode-filter-load-point'
  );

  // get unique values
  const uniqueStates = [
    ...new Set(stores.map((store) => store.store_details.state.toLowerCase())),
  ];
  const uniqueCities = [
    ...new Set(stores.map((store) => store.store_details.city)),
  ];
  const uniquePincodes = [
    ...new Set(stores.map((store) => store.store_details.pin_code)),
  ];

  // appending states

  if (stateFilterTemplate) {
    stateFilterLoadPoints.forEach((item) => {
      uniqueStates.forEach((state) => {
        const stateFilterCard = document.importNode(
          stateFilterTemplate?.content,
          true
        );

        stateFilterCard.querySelector('.state-label p').textContent = state;
        stateFilterCard.querySelector('.state-label input').value = state;
        const trimState = state.replace(/\s/g, '');
        stateFilterCard
          .querySelector('.state-label input')
          .classList.add(`state-${trimState}`);
        item.appendChild(stateFilterCard);
      });
    });
  }

  // appending cities
  if (cityFilterTemplate) {
    cityFilterLoadPoints.forEach((item) => {
      uniqueCities.forEach((city) => {
        const cityFilterCard = document.importNode(
          cityFilterTemplate?.content,
          true
        );
        cityFilterCard.querySelector('.city-label p').textContent = city;
        cityFilterCard.querySelector('.city-label input').value = city;
        const trimCity = city.replace(/\s/g, '');
        cityFilterCard
          .querySelector('.city-label input')
          .classList.add(`city-${trimCity}`);
        item.appendChild(cityFilterCard);
      });
    });
  }
  // appending Pincode
  if (pincodeFilterTemplate) {
    pincodeFilterLoadPoints.forEach((item) => {
      uniquePincodes.forEach((pincode) => {
        const pincodeFilterCard = document.importNode(
          pincodeFilterTemplate?.content,
          true
        );
        pincodeFilterCard.querySelector('.pincode-label p').textContent =
          pincode;
        pincodeFilterCard.querySelector('.pincode-label input').value = pincode;
        pincodeFilterCard
          .querySelector('.pincode-label input')
          .classList.add(`pincode-${pincode}`);
        item.appendChild(pincodeFilterCard);
      });
    });
  }
};
window.openSelectDropdown = (key) => {
  const selectList = document.getElementById(`sl-${key}-list`);
  selectList.classList.remove('hidden');
};
window.closeSelectDropdown = (key) => {
  const selectList = document.getElementById(`sl-${key}-list`);
  selectList.classList.add('hidden');
};
window.handleSearchClear = () => {
  document.getElementById('search-field').value = '';
  const storeCardsList = document.querySelectorAll('.store-locator-card');
  storeCardsList.forEach((storeCard) => {
    storeCard.classList.remove('hidden');
  });
  document.querySelector('.sl-search-close-icon').classList.add('hidden');
};
window.handleSearchStores = (event) => {
  const data = event.target.value;

  const storeCardsList = document.querySelectorAll('.store-locator-card');

  if (data === '') {
    handleSearchClear();
  } else {
    document.querySelector('.sl-search-close-icon').classList.remove('hidden');
    storeCardsList.forEach((storeCard) => {
      const innerText = storeCard.innerText.toLowerCase();
      if (!innerText.includes(data.toLowerCase()) && data !== '')
        storeCard.classList.add('hidden');
    });
  }
};
window.chipRenderer = (value, name) => {
  const chipTemplate = document.getElementById('filter-chip');
  const chipCardDiv = document.importNode(chipTemplate.content, true);
  const chipCard = chipCardDiv.querySelector('.sl-filter-chip');
  chipCard.classList.add(`${name}-${removeWhiteSpace(value)}-chip`);
  chipCard.querySelector('.chip-text').textContent = value;
  chipCard
    .querySelector('.chip-close-icon')
    .setAttribute('onclick', `handleChipClear("${name}", "${value}")`);
  chipCard.setAttribute('data-name', name);
  chipCard.setAttribute('data-value', value);
  return chipCard;
};
window.handleChipClear = (name, value) => {
  const parentEle = document.querySelector(
    `.${name}-${removeWhiteSpace(value)}-chip`
  );
  document
    .querySelectorAll(`.${name}-${removeWhiteSpace(value)}`)
    .forEach((field) => (field.checked = false));
  parentEle.classList.add('hidden');
  handleSLFilterChange();
};
window.handleSLFilterChange = () => {
  const clearAllText = document.querySelector('.sl-clear-all-text');
  if (clearAllText.classList.contains('hidden')) {
    clearAllText.classList.remove('hidden');
  }

  const filtersFormData = new FormData(
    document.querySelector('form#sl-filters')
  );
  const cities = filtersFormData.getAll('city') || [];
  const pincodes = filtersFormData.getAll('pincode') || [];
  const state = filtersFormData.get('state') || '';

  const chipsWrapper = document.getElementById('sl-chips-wrapper');
  chipsWrapper.classList.remove('hidden');
  chipsWrapper.innerHTML = '';

  if (state !== '') chipsWrapper.append(chipRenderer(state, 'state'));

  if (cities.length > 0)
    cities.map((city) => chipsWrapper.append(chipRenderer(city, 'city')));

  if (pincodes.length > 0)
    pincodes.map((pincode) =>
      chipsWrapper.append(chipRenderer(pincode, 'pincode'))
    );

  const storeCardsList = document.querySelectorAll('.store-locator-card');

  storeCardsList.forEach((storeCard) => {
    const dataSet = storeCard.dataset;

    storeCard.classList.remove('hidden');
    if (!(cities.length === 0 && pincodes.length === 0 && state === ''))
      if (
        !(
          (dataSet.city && cities.indexOf(dataSet.city) >= 0) ||
          (dataSet.pincode && pincodes.indexOf(dataSet.pincode) >= 0) ||
          dataSet.state.toLowerCase() === state.toLowerCase()
        )
      )
        storeCard.classList.add('hidden');
  });
};

window.handleClearSLFilters = () => {
  const form = document.getElementById('sl-filters');
  form.reset();
  document.querySelector('.sl-clear-all-text').classList.add('hidden');
  const storeCardsList = document.querySelectorAll('.store-locator-card');
  document.getElementById('sl-chips-wrapper').innerHTML = '';

  storeCardsList.forEach((storeCard) => {
    storeCard.classList.remove('hidden');
  });
  closeSLFilterModal();
};
window.openSLFilterModal = () => {
  document.getElementById('sl-filter-modal').classList.remove('hidden');
};

window.closeSLFilterModal = () => {
  document.getElementById('sl-filter-modal').classList.add('hidden');
};

window.appInitializer = () => {
  document.addEventListener('click', (event) => {
    const targetElement = event.target;
    const stateDropdownList = document.getElementById('sl-state-list');
    const cityDropdownList = document.getElementById('sl-city-list');
    const pincodeDropdownList = document.getElementById('sl-pincode-list');

    const stateWrapper = document.querySelector('.sl-state-label');
    const cityWrapper = document.querySelector('.sl-city-label');
    const pincodeWrapper = document.querySelector('.sl-pincode-label');
    if (!stateWrapper && !cityWrapper && !pincodeWrapper) return;
    if (!stateWrapper?.contains(targetElement)) {
      if (!stateDropdownList?.classList.contains('hidden'))
        closeSelectDropdown('state');
    }
    if (!cityWrapper?.contains(targetElement)) {
      if (!cityDropdownList?.classList.contains('hidden'))
        closeSelectDropdown('city');
    }

    if (!pincodeWrapper?.contains(targetElement)) {
      if (!pincodeDropdownList?.classList.contains('hidden'))
        closeSelectDropdown('pincode');
    }
  });
  fetchStoreLocatorData();
};
window.handleListToggle = (key) => {
  const upArrow = document.querySelector(`.up-arrow-${key}`);
  const downArrow = document.querySelector(`.down-arrow-${key}`);
  const listItem = document.getElementById(`filter-items-${key}`);

  if (upArrow.classList.contains('hidden')) {
    downArrow.classList.add('hidden');
    upArrow.classList.remove('hidden');
    listItem.classList.remove('hidden');
  } else {
    downArrow.classList.remove('hidden');
    upArrow.classList.add('hidden');
    listItem.classList.add('hidden');
  }
};
