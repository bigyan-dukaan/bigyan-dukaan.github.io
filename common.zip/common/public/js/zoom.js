window.wrapper =
  document.getElementById('mainImgContainer') ||
  document.querySelector('.mainImgContainer');
window.images = document.querySelectorAll('.mainImg:not(.video-thumbnail)');
window.imageZoom = (e, img) => {
  const rect = e.target.getBoundingClientRect();
  const x = e.clientX - rect.left; // x position within the element.
  const y = e.clientY - rect.top; // y position within the element.
  if (img) {
    img.style.transformOrigin = `${x}px ${y}px`;
    img.style.transform = 'scale(2)';
  }
};

window.imageZoomOut = (e, img) => {
  img.style.transformOrigin = `center center`;
  img.style.transform = 'scale(1)';
};

if (wrapper && window.innerWidth > 1024) {
  images.forEach((image) => {
    wrapper.addEventListener('mousemove', (e) => imageZoom(e, image), false);
    wrapper.addEventListener(
      'mouseleave',
      (e) => imageZoomOut(e, image),
      false
    );
  });
}
