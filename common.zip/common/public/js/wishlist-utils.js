window.dknInitWishlistPlugin = () => {
  if (window?.ACTIVE_APPS_LIST?.WISHLIST) {
    window.q$
      .selectAll('.dkn-wishlist-page-navigation-button')
      .removeClassAll('hidden');

    window.dknFetchWishlistedProductIDs({
      wishlistName: 'wishlist',
      successCallback: () => {
        window.dknRenderWishlistButtons();
      },
      errorCallback: () => {
        window.dknHideWishlistLoadPoints();
      },
    });
    window.dknFetchWishlistedProductIDs({
      wishlistName: 'notify_when_in_stock',
      successCallback: () => {
        window.dknRenderNotifyMeButtons();
      },
      errorCallback: () => {
        window.dknHideNotifyMeLoadPoints();
      },
    });
  } else {
    window.q$
      .selectAll('.dkn-wishlist-page-navigation-button')
      .addClassAll('hidden');
    window.dknHideWishlistLoadPoints();
    window.dknHideNotifyMeLoadPoints();
  }
};

window.dknRenderWishlistButtons = (productListMountElem) => {
  if (window?.ACTIVE_APPS_LIST?.WISHLIST) {
    window.q$
      .selectAll('wishlist-button-load-point', productListMountElem)
      .removeClassAll('hidden');

    window.q$
      .selectAll('wishlist-button-load-point', productListMountElem)
      .elem.forEach((element) =>
        window.dknRenderAddToWishlistButtonType(element)
      );
  } else {
    window.dknHideWishlistLoadPoints(productListMountElem);
  }
};

window.dknRenderNotifyMeButtons = (productListMountElem) => {
  if (window?.ACTIVE_APPS_LIST?.WISHLIST) {
    window.q$
      .selectAll('notify-me-button-load-point', productListMountElem)
      .removeClassAll('hidden');

    window.q$
      .selectAll('notify-me-button-load-point', productListMountElem)
      .elem.forEach((element) => window.dknRenderNotifyMeButtonType(element));
  } else {
    window.dknHideNotifyMeLoadPoints(productListMountElem);
  }
};

window.dknFetchWishlistedProductIDs = ({
  successCallback,
  wishlistName = 'wishlist',
} = {}) => {
  // not loggedin
  if (!localStorage?.al_to) {
    window.DukaanData.WISHLISTED_PRODUCT_IDS = {
      wishlist: [],
      notify_when_in_stock: [],
    };
    if (successCallback) successCallback();
    return;
  }

  const headers = {};
  if (localStorage && localStorage.al_to)
    headers.Authorization = `Bearer ${localStorage.al_to}`;
  headers['Content-Type'] = 'application/json';
  headers['x-requested-with'] = window?.DukaanData?.DUKAAN_SESSION_ID;
  fetch(
    `${window.DukaanData.CLIENT_API_ENDPOINT}/api/store/buyer/wishlist/?store_id=${window.DukaanData.DUKAAN_STORE.id}&wishlist_name=${wishlistName}`,
    {
      method: 'GET',
      headers,
    }
  )
    .then((res) => res.json())
    .then((resp) => {
      const products = resp?.results || [];
      DukaanData.WISHLISTED_PRODUCT_IDS ||= {};
      DukaanData.WISHLISTED_PRODUCT_IDS[wishlistName] = [...products];
    })
    .catch(() => {
      DukaanData.WISHLISTED_PRODUCT_IDS ||= {};
      DukaanData.WISHLISTED_PRODUCT_IDS[wishlistName] = [];
    })
    .finally(() => {
      successCallback();
    });
};

window.dknHideWishlistLoadPoints = (productListMountElem) => {
  window.q$
    .selectAll('wishlist-button-load-point', productListMountElem)
    .addClassAll('hidden');
};

window.dknHideNotifyMeLoadPoints = (productListMountElem) => {
  window.q$
    .selectAll('notify-me-button-load-point', productListMountElem)
    .addClassAll('hidden');
};

window.dknReRenderAllAddToWishlistButton = () => {
  const wishlistBtnElems = window.q$.selectAll(
    `wishlist-button-load-point`
  ).elem;
  window.dknReRenderWishlistButtons(wishlistBtnElems);
};

window.dknReRenderWishlistButtons = (wishlistBtnElems) => {
  window.dknFetchWishlistedProductIDs({
    wishlistName: 'wishlist',
    successCallback: () => {
      wishlistBtnElems.forEach((wishlistBtnElem) => {
        window.dknRenderAddToWishlistButtonType(wishlistBtnElem);
      });
    },
  });
};

window.dknReRenderNotifyMeButtons = (wishlistBtnElems) => {
  window.dknFetchWishlistedProductIDs({
    wishlistName: 'notify_when_in_stock',
    successCallback: () => {
      wishlistBtnElems.forEach((wishlistBtnElem) => {
        window.dknRenderNotifyMeButtonType(wishlistBtnElem);
      });
    },
  });
};

window.dknRenderAddToWishlistButtonType = (element) => {
  const skuUUID = element.dataset.skuUuid;
  if (skuUUID) {
    window.addToWishlistButtonRenderer(element);
  } else {
    window.addToWishlistButtonWithVariantsRenderer(element);
  }
};

// rendering logic
// render btn that might contain variants
window.addToWishlistButtonWithVariantsRenderer = (mountElement) => {
  if (!window?.ACTIVE_APPS_LIST?.WISHLIST) {
    return;
  }
  mountElement.innerHTML = '';
  const productUUID = mountElement.dataset.productUuid;
  const templateID = mountElement.dataset.templateId;
  const product = window.DukaanData.PRODUCTS_MAP[productUUID];
  const productID = product?.id;
  const skuID = product?.skus[0]?.id;
  const wishlistedVariants = window.dknGetWishlistedVariantBySkuAndProductId({
    productID,
    wishlistName: 'wishlist',
  });
  const wishlistID = wishlistedVariants?.[0]?.id;
  const isWishlisted = !!wishlistedVariants?.length;
  const addToWishlistButtonTemplate = document.getElementById(templateID);
  const element = document.importNode(
    addToWishlistButtonTemplate.content,
    true
  );

  const selectedBtn = element.querySelector(
    '[data-wishlist-button-state="selected"]'
  );
  const unSelectedBtn = element.querySelector(
    '[data-wishlist-button-state="unselected"]'
  );
  /* 
    isWishlisted check is done at product level, if any of the variant is wishlisted then 
    the product is considered wishlisted true from perspective of icon filled/unfilled
  */
  if (isWishlisted) {
    selectedBtn.classList.remove('hidden');
    unSelectedBtn?.classList.add('hidden');

    selectedBtn.setAttribute(
      'onclick',
      `addToWishlist(event, '', '${productUUID}', { wishlistID: '${wishlistID}', skuID: '' })`
    );
  } else {
    unSelectedBtn?.classList?.remove('hidden');
    selectedBtn?.classList.add('hidden');

    unSelectedBtn?.setAttribute(
      'onclick',
      `addToWishlist(event, '', '${productUUID}', { wishlistID: '', skuID: '${skuID}' })`
    );
  }
  mountElement.appendChild(element);
};

// render btn inside pdp or modal
window.addToWishlistButtonRenderer = (mountElement) => {
  if (!window?.ACTIVE_APPS_LIST?.WISHLIST) {
    return;
  }
  mountElement.innerHTML = '';
  const productUUID = mountElement.dataset.productUuid;
  const skuUUID = mountElement.dataset.skuUuid;
  const templateID = mountElement.dataset.templateId;
  const product = window?.DukaanData?.PRODUCTS_MAP?.[productUUID];
  if (!product) return;
  const skuDetails = window.getProductDetailsBySkuAndProductUuid(
    productUUID,
    skuUUID
  );
  const productID = product?.id;
  const skuID = skuDetails?.id || product?.skus[0]?.id;
  const wishlistedVariant = window.dknGetWishlistedVariantBySkuAndProductId({
    productID,
    skuID,
    wishlistName: 'wishlist',
  });
  const wishlistID = wishlistedVariant?.[0]?.id;
  const isWishlisted = !!wishlistedVariant?.length;

  const addToWishlistButtonTemplate = document.getElementById(templateID);
  const element = document.importNode(
    addToWishlistButtonTemplate.content,
    true
  );

  const selectedBtn = element.querySelector(
    '[data-wishlist-button-state="selected"]'
  );
  const unSelectedBtn = element.querySelector(
    '[data-wishlist-button-state="unselected"]'
  );

  if (isWishlisted) {
    selectedBtn.classList.remove('hidden');
    unSelectedBtn?.classList.add('hidden');

    selectedBtn.setAttribute(
      'onclick',
      `addToWishlist(event, '${skuUUID}', '${productUUID}', { wishlistID: '${wishlistID}', skuID: '' })`
    );
  } else {
    unSelectedBtn?.classList?.remove('hidden');
    selectedBtn?.classList.add('hidden');

    unSelectedBtn?.setAttribute(
      'onclick',
      `addToWishlist(event, '${skuUUID}', '${productUUID}', { wishlistID: '', skuID: '${skuID}' })`
    );
  }
  mountElement.appendChild(element);
};

window.dknRenderNotifyMeButtonType = (element) => {
  const productUUID = element.dataset.productUuid;
  const skuUUID = element.dataset.skuUuid;

  const product = window.DukaanData.PRODUCTS_MAP[productUUID];
  const isOutOfStock =
    product?.product_type === PRODUCT_TYPES.BUNDLE
      ? product?.in_stock === false ||
        product?.skus.some((s) => s?.inventory === 0) ||
        false
      : product?.in_stock === false ||
        !product?.skus?.some((s) => s.inventory === null || s.inventory > 0);

  if (product && !isOutOfStock) {
    element.classList.add('hidden');
    return;
  }

  if (skuUUID) {
    window.notifyMeButtonRenderer(element);
  } else {
    window.notifyMeButtonWithVariantsRenderer(element);
  }

  if (!element.classList.contains('hidden')) {
    const sibling = element.parentElement.querySelector(
      'add-to-bag-button-with-external-quantity-input'
    );
    if (sibling) {
      sibling.classList.add('hidden');
    }
  }
};

// rendering logic
// render btn that might contain variants
window.notifyMeButtonWithVariantsRenderer = (mountElement) => {
  if (!window?.ACTIVE_APPS_LIST?.WISHLIST) {
    return;
  }
  mountElement.innerHTML = '';
  const productUUID = mountElement.dataset.productUuid;
  const templateID = mountElement.dataset.templateId;
  const product = window.DukaanData.PRODUCTS_MAP[productUUID];
  const productID = product?.id;
  const skuID = product?.skus[0]?.id;
  const wishlistedVariants = window.dknGetWishlistedVariantBySkuAndProductId({
    productID,
    wishlistName: 'notify_when_in_stock',
  });
  const wishlistID = wishlistedVariants?.[0]?.id;
  const isWishlisted = !!wishlistedVariants?.length;
  const addToWishlistButtonTemplate = document.getElementById(templateID);
  const element = document.importNode(
    addToWishlistButtonTemplate.content,
    true
  );

  const selectedBtn = element.querySelector(
    '[data-notify-me-button-state="selected"]'
  );
  const unSelectedBtn = element.querySelector(
    '[data-notify-me-button-state="unselected"]'
  );
  /*
    isWishlisted check is done at product level, if any of the variant is wishlisted then
    the product is considered wishlisted true from perspective of icon filled/unfilled
  */

  if (isWishlisted) {
    selectedBtn.classList.remove('hidden');
    unSelectedBtn?.classList.add('hidden');

    selectedBtn.setAttribute(
      'onclick',
      `notifyMe(event, '', '${productUUID}', { wishlistID: '${wishlistID}', skuID: '' })`
    );
  } else {
    unSelectedBtn?.classList?.remove('hidden');
    selectedBtn?.classList.add('hidden');

    unSelectedBtn?.setAttribute(
      'onclick',
      `notifyMe(event, '', '${productUUID}', { wishlistID: '', skuID: '${skuID}' })`
    );
  }
  mountElement.appendChild(element);
};

// render btn inside pdp or modal
window.notifyMeButtonRenderer = (mountElement) => {
  if (!window?.ACTIVE_APPS_LIST?.WISHLIST) {
    return;
  }
  mountElement.innerHTML = '';
  const productUUID = mountElement.dataset.productUuid;
  const skuUUID = mountElement.dataset.skuUuid;
  const templateID = mountElement.dataset.templateId;
  const product = window?.DukaanData?.PRODUCTS_MAP?.[productUUID];
  if (!product) return;
  const skuDetails = window.getProductDetailsBySkuAndProductUuid(
    productUUID,
    skuUUID
  );
  const productID = product?.id;
  const skuID = skuDetails?.id || product?.skus[0]?.id;
  const wishlistedVariant = window.dknGetWishlistedVariantBySkuAndProductId({
    productID,
    skuID,
    wishlistName: 'notify_when_in_stock',
  });
  const wishlistID = wishlistedVariant?.[0]?.id;
  const isWishlisted = !!wishlistedVariant?.length;

  const addToWishlistButtonTemplate = document.getElementById(templateID);
  const element = document.importNode(
    addToWishlistButtonTemplate.content,
    true
  );

  const selectedBtn = element.querySelector(
    '[data-notify-me-button-state="selected"]'
  );
  const unSelectedBtn = element.querySelector(
    '[data-notify-me-button-state="unselected"]'
  );

  if (isWishlisted) {
    selectedBtn.classList.remove('hidden');
    unSelectedBtn?.classList.add('hidden');

    selectedBtn.setAttribute(
      'onclick',
      `notifyMe(event, '${skuUUID}', '${productUUID}', { wishlistID: '${wishlistID}', skuID: '' })`
    );
  } else {
    unSelectedBtn?.classList?.remove('hidden');
    selectedBtn?.classList.add('hidden');

    unSelectedBtn?.setAttribute(
      'onclick',
      `notifyMe(event, '${skuUUID}', '${productUUID}', { wishlistID: '', skuID: '${skuID}' })`
    );
  }
  mountElement.appendChild(element);
};

// btn onclick handler
window.addToWishlist = (
  event,
  skuUUID,
  productUUID,
  { wishlistID = '', skuID = '' }
) => {
  const { skipSKULengthCheckForWishlist } =
    window?.DukaanData?.DUKAAN_STORE?.additional_meta || {};
  window.initDukaanAuth(
    async () => {
      let activeProduct = window.DukaanData.PRODUCTS_MAP[productUUID];
      if (!activeProduct?.skusApi) {
        const target = event.currentTarget;
        activeProduct = await window.retrieveProductSku(productUUID, target);
      }
      const skus = activeProduct?.skus;
      const defaultSKU = skus[0];

      const wishlistBtnElems = document.querySelectorAll(
        `wishlist-button-load-point[data-product-uuid ='${productUUID}']`
      );

      // clicking from index page
      if (!skuUUID) {
        if (skus.length === 1 || skipSKULengthCheckForWishlist) {
          if (wishlistID) {
            window.dknHandleRemoveFromWishlist(wishlistID, wishlistBtnElems);
          }
          if (skuID) {
            if (skuID === 'undefined') {
              skuID = defaultSKU.id;
            }
            window.dknHandleAddToWishlist(skuID, wishlistBtnElems);
          }
          return;
        }
        if (skus.length > 1) {
          // const variantSelectionFormAdditionalRenderer = (
          //   variantSelectionForm
          // ) => {
          //   const addToWishlistElement = variantSelectionForm.querySelector(
          //     'wishlist-button-load-point'
          //   );
          //   addToWishlistElement.classList.remove('hidden');
          //   addToWishlistElement.dataset.productUuid = activeProduct.uuid;
          //   addToWishlistElement.dataset.skuUuid = defaultSKU.uuid;
          //   window.addToWishlistButtonRenderer(addToWishlistElement);
          // };
          const variantModal = document.querySelector(
            'product-variant-selection-modal'
          );
          window.handleVariantModalChange(
            variantModal,
            { value: productUUID },
            {
              // variantSelectionFormTemplateId: 'wishlist-variant-selection-form',
              // variantSelectionFormAdditionalRenderer,
              // buttonTemplateId: `[data-template-id="modal-wishlist-button-template"]`,
              actionButtonTemplateId: 'dkn-wishlist-action-button-template',
            }
          );
          window.handleBodyOverflow();
        }
        // clicking from pdp or modal
      } else {
        if (wishlistID) {
          window.dknHandleRemoveFromWishlist(wishlistID, wishlistBtnElems);
        }
        if (skuID) {
          window.dknHandleAddToWishlist(skuID, wishlistBtnElems);
        }
        // if (!defaultSKU) return;
      }
    },
    () => window.reRenderAllAddToWishlistButton()
  );
};

// btn onclick handler
window.notifyMe = (
  event,
  skuUUID,
  productUUID,
  { wishlistID = '', skuID = '' }
) => {
  const { skipSKULengthCheckForWishlist } =
    window?.DukaanData?.DUKAAN_STORE?.additional_meta || {};
  window.initDukaanAuth(
    async () => {
      let activeProduct = window.DukaanData.PRODUCTS_MAP[productUUID];
      if (
        !activeProduct?.skusApi &&
        activeProduct.product_type !== PRODUCT_TYPES.BUNDLE
      ) {
        const target = event.currentTarget;
        activeProduct = await window.retrieveProductSku(productUUID, target);
      }
      const skus = activeProduct?.skus;
      const defaultSKU = skus[0];

      const wishlistBtnElems = document.querySelectorAll(
        `notify-me-button-load-point[data-product-uuid ='${productUUID}']`
      );

      // clicking from index page
      if (!skuUUID) {
        if (skus.length === 1 || skipSKULengthCheckForWishlist) {
          if (wishlistID) {
            window.dknHandleDontNotifyMe(wishlistID, wishlistBtnElems);
          }
          if (skuID) {
            if (skuID === 'undefined') {
              skuID = defaultSKU.id;
            }
            window.dknHandleNotifyMe(skuID, wishlistBtnElems);
          }
          return;
        }
        if (skus.length > 1) {
          // const variantSelectionFormAdditionalRenderer = (
          //   variantSelectionForm
          // ) => {
          //   const addToWishlistElement = variantSelectionForm.querySelector(
          //     'wishlist-button-load-point'
          //   );
          //   addToWishlistElement.classList.remove('hidden');
          //   addToWishlistElement.dataset.productUuid = activeProduct.uuid;
          //   addToWishlistElement.dataset.skuUuid = defaultSKU.uuid;
          //   window.addToWishlistButtonRenderer(addToWishlistElement);
          // };
          const variantModal = document.querySelector(
            'product-variant-selection-modal'
          );
          window.handleVariantModalChange(
            variantModal,
            { value: productUUID },
            {
              // variantSelectionFormTemplateId: 'wishlist-variant-selection-form',
              // variantSelectionFormAdditionalRenderer,
              // buttonTemplateId: `[data-template-id="modal-wishlist-button-template"]`,
              actionButtonTemplateId: 'dkn-wishlist-action-button-template',
            }
          );
          window.handleBodyOverflow();
        }
        // clicking from pdp or modal
      } else {
        if (wishlistID) {
          window.dknHandleDontNotifyMe(wishlistID, wishlistBtnElems);
        }
        if (skuID) {
          window.dknHandleNotifyMe(skuID, wishlistBtnElems);
        }
        // if (!defaultSKU) return;
      }
    },
    () => {
      if (typeof window.reRenderAllAddToWishlistButton === 'function') {
        window.reRenderAllAddToWishlistButton();
      }
      window.notifyMe(event, skuUUID, productUUID, { wishlistID, skuID });
    }
  );
};

// api handlers
window.dknHandleAddToWishlist = (skuId, wishlistBtnElems) => {
  window.dknAddWishlistProduct({
    skuID: skuId,
    successCb: () => {
      window.dknReRenderWishlistButtons(wishlistBtnElems);
      window.enqueueSnackbar(
        DukaanData.DUKAAN_LANGUAGE.PRODUCT_ADDED_TO_WISHLIST,
        true,
        'success'
      );
    },
    errorCb: ({ err }) => {
      window.enqueueSnackbar(
        DukaanData.DUKAAN_LANGUAGE.FAILED_TO_ADD_PRODUCT_TO_WISHLIST,
        true,
        'error'
      );
    },
  });
};

window.dknHandleRemoveFromWishlist = (wishlistId, wishlistBtnElems) => {
  window.dknDeleteWishlistProduct({
    wishlistID: wishlistId,
    successCb: () => {
      window.dknReRenderWishlistButtons(wishlistBtnElems);
      window.enqueueSnackbar(
        DukaanData.DUKAAN_LANGUAGE.PRODUCT_REMOVED_FROM_WISHLIST,
        true,
        'success'
      );
    },
    errorCb: ({ err }) => {
      window.enqueueSnackbar(
        DukaanData.DUKAAN_LANGUAGE.FAILED_TO_REMOVE_PRODUCT_FROM_WISHLIST,
        true,
        'error'
      );
    },
  });
};

window.dknHandleNotifyMe = (skuId, wishlistBtnElems) => {
  window.dknNotifyMeApiCallback({
    skuID: skuId,
    successCb: () => {
      window.dknReRenderNotifyMeButtons(wishlistBtnElems);
      window.enqueueSnackbar(
        "We'll notify you once the product is in stock",
        true,
        'success'
      );
    },
    errorCb: ({ err }) => {
      window.enqueueSnackbar(
        'Failed to process request. Try again after sometime',
        true,
        'error'
      );
    },
  });
};

window.dknHandleDontNotifyMe = (wishlistId, wishlistBtnElems) => {
  window.dknDontNotifyMeApiCallback({
    wishlistID: wishlistId,
    successCb: () => {
      window.dknReRenderNotifyMeButtons(wishlistBtnElems);
      window.enqueueSnackbar(
        'Product successfully removed from notify list',
        true,
        'success'
      );
    },
    errorCb: ({ err }) => {
      window.enqueueSnackbar(
        'Failed to process request. Try again after sometime',
        true,
        'error'
      );
    },
  });
};

// api actions

window.dknAddWishlistProduct = ({ skuID, successCb, errorCb } = {}) => {
  const headers = {};
  if (localStorage && localStorage.al_to)
    headers.Authorization = `Bearer ${localStorage.al_to}`;
  headers['Content-Type'] = 'application/json';
  headers['x-requested-with'] = window?.DukaanData?.DUKAAN_SESSION_ID;

  const storeID = window.DukaanData.DUKAAN_STORE.id;

  fetch(`${window.DukaanData.CLIENT_API_ENDPOINT}/api/store/buyer/wishlist/`, {
    method: 'POST',
    body: JSON.stringify({
      store: storeID,
      product_sku: Number(skuID),
    }),
    headers,
  })
    .then((res) => {
      if (!res.ok) {
        throw new Error('failed to add wishlist');
      }
      return res.json();
    })
    .then(() => {
      successCb();
    })
    .catch((err) => {
      errorCb({ err });
    });
};

window.dknDeleteWishlistProduct = ({ wishlistID, successCb, errorCb }) => {
  const headers = {};
  if (localStorage && localStorage.al_to)
    headers.Authorization = `Bearer ${localStorage.al_to}`;
  headers['Content-Type'] = 'application/json';
  headers['x-requested-with'] = window?.DukaanData?.DUKAAN_SESSION_ID;

  fetch(
    `${window.DukaanData.CLIENT_API_ENDPOINT}/api/store/buyer/wishlist/${wishlistID}/`,
    {
      method: 'DELETE',
      headers,
    }
  )
    .then((res) => {
      if (!res.ok) {
        throw new Error('failed to delete from wishlist');
      }
      return res.json();
    })
    .then(() => {
      successCb();
    })
    .catch((err) => {
      errorCb({ err });
    });
};

window.dknNotifyMeApiCallback = ({ skuID, successCb, errorCb } = {}) => {
  const headers = {};
  if (localStorage && localStorage.al_to)
    headers.Authorization = `Bearer ${localStorage.al_to}`;
  headers['Content-Type'] = 'application/json';
  headers['x-requested-with'] = window?.DukaanData?.DUKAAN_SESSION_ID;

  const storeID = window.DukaanData.DUKAAN_STORE.id;

  fetch(
    `${window.DukaanData.CLIENT_API_ENDPOINT}/api/store/buyer/wishlist/?wishlist_name=notify_when_in_stock`,
    {
      method: 'POST',
      body: JSON.stringify({
        store: storeID,
        product_sku: Number(skuID),
        wishlist_name: 'notify_when_in_stock',
      }),
      headers,
    }
  )
    .then((res) => {
      if (!res.ok) {
        throw new Error('failed to add wishlist');
      }
      return res.json();
    })
    .then(() => {
      successCb();
    })
    .catch((err) => {
      errorCb({ err });
    });
};

window.dknDontNotifyMeApiCallback = ({ wishlistID, successCb, errorCb }) => {
  const headers = {};
  if (localStorage && localStorage.al_to)
    headers.Authorization = `Bearer ${localStorage.al_to}`;
  headers['Content-Type'] = 'application/json';
  headers['x-requested-with'] = window?.DukaanData?.DUKAAN_SESSION_ID;

  fetch(
    `${window.DukaanData.CLIENT_API_ENDPOINT}/api/store/buyer/wishlist/${wishlistID}/?wishlist_name=notify_when_in_stock`,
    {
      method: 'DELETE',
      headers,
    }
  )
    .then((res) => {
      if (!res.ok) {
        throw new Error('failed to delete from wishlist');
      }
      return res.json();
    })
    .then(() => {
      successCb();
    })
    .catch((err) => {
      errorCb({ err });
    });
};

// helper fns
window.dknGetWishlistedVariantBySkuAndProductId = ({
  productID,
  skuID,
  wishlistName = 'wishlist',
}) => {
  const products =
    window.DukaanData?.WISHLISTED_PRODUCT_IDS?.[wishlistName] || [];
  if (typeof productID === 'string') {
    productID = Number(productID);
  }
  if (!skuID) {
    return products?.filter((product) => product?.product_id === productID);
  }
  if (typeof skuID === 'string') {
    skuID = Number(skuID);
  }
  return products?.filter(
    (product) =>
      product?.product_id === productID && product?.product_sku_id === skuID
  );
};
