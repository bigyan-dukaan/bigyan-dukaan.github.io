/* 360 IMAGE VIEWER FLOW (refer vu theme for implementation reference) :
    1. define template for 360 image viewer items like - canvas(required), button & loader element
    2. call the init function after renderering product card with required params
    3. add css for canvas's width and height since that will be used afterwards for renderering canvas
*/

/**
 * Initializer function for 360 image viewer
 * @param {Object} productCard - product card element
 * @param {Array} images - 360 product card images
 * @param {Object} options - object containing info required for rendering {
 *  clickHandlerTargetSelector, - css selector for on click handler element
 *  percentageTextSelector, - css selector for percentage text element
 *  elementToReplace - element that will be replaced with the 360Image canvas, generally will be product-card-image
 * }
 */
window.dkn360ImageViewerInit = (productCard, images, options = {}) => {
  if (!images?.length) {
    return;
  }
  const dkn360ImageViewerLoadPoints = window.q$.selectAll(
    'dkn-360-image-viewer',
    productCard
  ).elem;
  if (!dkn360ImageViewerLoadPoints.length) {
    return;
  }

  const DKN_360_IMAGE_VIEWER_TEMPLATE_ID = 'dkn-360-image-viewer-template';
  const PERCENTAGE_TEXT_SELECTOR = '.dkn-360-image-viewer-percentage';
  const ICON_360_SELECTOR = '.dkn-360-icon';
  const CLICK_HANDLER_TARGET_SELECTOR = '.dkn-product-card-image-wrapper';
  const ELEMENT_TO_REPLACE_SELECTOR = '.dkn-product-card-image';

  const {
    clickHandlerTargetSelector,
    percentageTextSelector,
    elementToReplace,
  } = options;

  // Get the product UUID from the productCard
  const productUUID = productCard
    .getAttribute('data-product-uuid')
    .replace(/-/g, '_');

  dkn360ImageViewerLoadPoints.forEach((mountElem) => {
    mountElem.innerHTML = '';
    const templateID =
      mountElem.dataset.templateId || DKN_360_IMAGE_VIEWER_TEMPLATE_ID;
    const dkn360ImageViewerTemplate = document.getElementById(templateID);
    const element = document.importNode(
      dkn360ImageViewerTemplate.content,
      true
    );

    // Create a unique handler name using the product UUID
    const handlerName = `dkn360ImageViewHandler_${productUUID}`;

    window[handlerName] = (evt) => {
      const target = evt.currentTarget;
      const canvas = target.querySelector('canvas');

      // canvas-unsupported
      if (!canvas || !canvas.getContext) {
        return;
      }

      // get client width & height and then hide the canvas until it's drawn
      canvas.classList.remove('hidden');
      const canvasWidth = canvas.clientWidth;
      const canvasHeight = canvas.clientHeight;
      canvas.width = canvasWidth;
      canvas.height = canvasHeight;
      canvas.classList.add('hidden');

      let xInitial = null;
      let xLast = null;
      let animation = null;
      let newFrame;
      let currentImage = 0;
      let showPercentText = `Loading 0`;

      const icon360 = target.querySelector(ICON_360_SELECTOR);
      const percentageElem = target.querySelector(
        percentageTextSelector || PERCENTAGE_TEXT_SELECTOR
      );

      icon360?.classList?.add('hidden');
      percentageElem?.classList?.remove('hidden');

      const loadedImages = [];

      // utils for on click handler
      const showPercent = (progress) => {
        showPercentText = `Loading ${Math.round(progress)}%`;
        percentageElem.textContent = showPercentText;
      };

      const loadImages = () =>
        new Promise((resolve) => {
          images.forEach((image) => {
            const img = new Image();
            img.src = image;
            img.addEventListener(
              'load',
              () => {
                // Add the loaded image to the array to be used later.
                loadedImages.push(img);
                // Resolve the promise, if all the images have been loaded. Otherwise, draw the loading bar to show the progress.
                if (loadedImages.length === images.length) {
                  resolve();
                } else {
                  showPercent((loadedImages.length * 100) / images.length);
                  // drawLoadingBar((loadedImages.length * 100) / images.length);
                }
              },
              false
            );
          });
        });

      const drawImage = (frame) => {
        const ctx = canvas.getContext('2d');
        // Clear the canvas before starting to draw
        ctx.clearRect(0, 0, canvasWidth, canvasHeight);

        // Get the image element to draw on canvas from the pre-loaded images array.
        const newImage = loadedImages.filter(
          (img) => img.src.indexOf(images[frame]) > -1
        )[0];

        // Resize the image depending on the canvas's size.
        const imageSizeScale = newImage.width / newImage.height;
        let newWidth = canvasWidth;
        let newHeight = newWidth / imageSizeScale;

        if (newHeight > canvasHeight) {
          newHeight = canvasHeight;
          newWidth = newHeight * imageSizeScale;
        }

        // Draw the image on canvas
        ctx.drawImage(newImage, 0, 0, newWidth, newHeight);
        currentImage = frame;
      };

      // event listeners
      const handleMouseDown = (event) => {
        xInitial = event.pageX;
      };

      const handleTouchStart = (event) => {
        xInitial = event.touches[0].pageX;
      };

      const animationFrame = () => {
        drawImage(newFrame);
        animation = requestAnimationFrame(animationFrame);
      };

      const handleMouseMove = (event) => {
        if (xInitial !== null) {
          const delta = event.pageX - (!xLast ? xInitial : xLast);
          xLast = event.pageX;

          let startingFrame = currentImage;
          if (currentImage === loadedImages.length - 1) {
            startingFrame = 0;
          } else if (currentImage === 0) {
            startingFrame = loadedImages.length - 1;
          }

          let moveFrame = startingFrame;
          if (delta > 0) {
            moveFrame = startingFrame - 1;
          } else if (delta < 0) {
            moveFrame = startingFrame + 1;
          }

          newFrame = Math.min(Math.max(moveFrame, 0), loadedImages.length - 1);

          if (animation === null) {
            animation = requestAnimationFrame(animationFrame);
          }
        }
      };

      const handleTouchMove = (event) => handleMouseMove(event.touches[0]);

      const handleMouseUp = () => {
        xInitial = null;
        xLast = null;
        if (animation) cancelAnimationFrame(animation);
        animation = null;
      };

      loadImages(percentageElem)
        .then(() => {
          canvas.addEventListener('mousedown', handleMouseDown, false);
          canvas.addEventListener('touchstart', handleTouchStart, false);
          canvas.addEventListener('mousemove', handleMouseMove, false);
          canvas.addEventListener('touchmove', handleTouchMove, false);
          canvas.addEventListener('mouseup', handleMouseUp, false);
          canvas.addEventListener('touchend', handleMouseUp, false);
          drawImage(0);
        })
        .finally(() => {
          target.removeAttribute('onclick'); // remove onclick handler
          target
            .querySelector(elementToReplace || ELEMENT_TO_REPLACE_SELECTOR)
            ?.classList?.add('hidden');
          canvas.classList.remove('hidden');
          canvas.classList.add('show');
          percentageElem?.classList?.add('hidden');
        });
    };

    // Set the unique handler name in the onclick attribute
    window.q$
      .select(
        clickHandlerTargetSelector || CLICK_HANDLER_TARGET_SELECTOR,
        productCard
      )
      .setAttribute('onclick', `${handlerName}(event)`);

    mountElem.appendChild(element);
  });
};
