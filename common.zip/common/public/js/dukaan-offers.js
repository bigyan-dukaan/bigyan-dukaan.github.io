window.getBNPLOfferData = (discount) => {
  const name =
    DukaanData.DUKAAN_LANGUAGE.EXTRA__DISCOUNT_OFF_ON_BNPL.injectText({
      discount: `${Number(discount)}%`,
    });
  // `Extra ${Number(discount)}% off on BNPL`;
  const desc =
    DukaanData.DUKAAN_LANGUAGE.GET_EXTRA__DISCOUNT_OFF_ON_BUY_NOW_PAY_LATER_PAYMENTS.injectText(
      {
        discount: `${Number(discount)}%`,
      }
    );
  // `Get extra ${Number(discount)}% off on Buy Now Pay Later payments.`;
  const offerIcon =
    background === 'light' ? OFFERS_ICONS.BNPL : DARK_DIM_OFFERS_ICONS.BNPL;
  const mobileName = DukaanData.DUKAAN_LANGUAGE.EXTRA__DISCOUNT_OFF.injectText({
    discount: `${Number(discount)}%`,
  });
  // `extra ${Number(discount)}% off`;
  const mobileDesc = DukaanData.DUKAAN_LANGUAGE.ON_BUY_NOW_PAY_LATER_PAYMENT;
  return { name, desc, offerIcon, mobileDesc, mobileName };
};

window.getDiscountProviderArray = (providers, background) =>
  providers
    .map((discountProvider) => getOffersData(discountProvider, background))
    .filter((offer) => offer.OfferIcon !== null);

window.getDiscountsArray = (discountProviders, showMobiKwik, background) => {
  let discounts = [];

  if (discountProviders) {
    const { bnpl_providers: bnplProviders, upi } = discountProviders;
    if (upi?.length > 0)
      discounts.push(getDiscountProviderArray(upi, background));
    if (bnplProviders?.length > 0)
      discounts.push(getDiscountProviderArray(bnplProviders, background));
  }

  const simpl = discountProviders?.bnpl_providers?.find(
    (provider) => provider.provider === DISCOUNT_PROVIDERS.SIMPL
  );

  if (simpl && simpl?.extra_offers && simpl.extra_offers[0]) {
    discounts.push({
      offerName: simpl?.extra_offers[0]?.title,
      offerDescription: simpl?.extra_offers[0]?.description,
      details: simpl?.extra_offers[0]?.details,
      mobileOfferName: `${
        DukaanData.DUKAAN_LANGUAGE.TWENTY_CASHBACK_UPTO__AMOUNT
      } ${formatMoney(200)}`,
      mobileOfferDesc: DukaanData.DUKAAN_LANGUAGE.ON_USING_SIMPLE_PAY_LATER,
      OfferIcon:
        background === 'light'
          ? OFFERS_ICONS.SIMPL
          : DARK_DIM_OFFERS_ICONS.SIMPL,
    });
  }

  discounts = discounts
    .flat()
    .map((discount, key) => ({ ...discount, id: key }));

  // if (showMobiKwik) {
  //   discounts.push(FREECHARGE_OFFER);
  //   discounts.push(OLA_MONEY_OFFER);
  //   discounts.push(MOBIKWIK_OFFER);
  // }

  return [...discounts];
};

// const getIsDarkLuxuryTheme = (pageLayout, background) => {
//   // eslint-disable-next-line react-hooks/rules-of-hooks
//   const { route } = useRouter();

//   const isPathLight = getIncludedRoutes(route, [
//     '/orders',
//     '/bag',
//     '/account',
//     '/addresses',
//   ]);

//   const isWhite =
//     pageLayout === THEMES.LUXURY &&
//     !isPathLight &&
//     (background === THEME_VARIANTS.DARK || background === THEME_VARIANTS.DIM);

//   return isWhite;
// };

// const isLuxuryTheme = (pageLayout) => pageLayout === THEMES.LUXURY;

window.getOfferDetails = (mode, discountProvider) => {
  const details = [];
  const {
    expiry_date: expiryDate,
    max_discount: maxDiscount,
    min_order_value: minOrderValue,
  } = discountProvider;

  // details.push(`Offer Valid Only on ${mode} Payment mode.`);
  details.push(
    DukaanData.DUKAAN_LANGUAGE.OFFERS_VALID_ONLY_ON__MODE_PAYMENT_MODE.injectText(
      {
        mode,
      }
    )
  );

  if (minOrderValue && minOrderValue > 0)
    details.push(
      DukaanData.DUKAAN_LANGUAGE.OFFER_VALID_ON_ORDER_ABOVE__MINORDERVALUE.injectText(
        {
          minOrderValue: formatMoney(minOrderValue),
        }
      )
    );

  // `Offer Valid on order above ${formatMoney(minOrderValue)}.`);

  if (maxDiscount && maxDiscount > 0)
    details.push(
      `${DukaanData.DUKAAN_LANGUAGE.MAXIMUM_INSTANT_DISCOUNT_OF__MAXDISCOUNT.injectText(
        {
          maxDiscount: formatMoney(maxDiscount),
        }
      )}`
    );

  // Maximum Instant discount of ${formatMoney(maxDiscount)}.`);

  if (expiryDate !== null)
    details.push(
      DukaanData.DUKAAN_LANGUAGE.OFFER_VALID_TILL__EXPIRYDATE.injectText({
        expiryDate: moment(expiryDate, '').format('MMMM Do YYYY, ha'),
      })
      // `Offer Valid till ${moment(expiryDate, '').format('MMMM Do YYYY, ha')}`
    );

  details.push(`${DukaanData.DUKAAN_LANGUAGE.OTHER_TANDC_MAY_APPLY}.`);

  return details;
};

window.getOffersData = (discountProvider, background) => {
  const {
    discount: initialDiscount,
    provider,
    payment_method: paymentMethod,
  } = discountProvider;

  const discount = Number(initialDiscount).toFixed(1);

  let offerName = '';
  let offerDescription = '';
  let OfferIcon = null;
  let details = [];
  let mobileOfferName = '';
  let mobileOfferDesc = '';

  if (initialDiscount === 0) {
    return {
      offerName,
      offerDescription,
      OfferIcon,
      details,
      mobileOfferDesc,
      mobileOfferName,
    };
  }

  if (provider && provider === DISCOUNT_PROVIDERS.SIMPL) {
    const { name, desc, offerIcon, mobileName, mobileDesc } = getBNPLOfferData(
      discount,
      background
    );
    offerName = name;
    offerDescription = desc;
    OfferIcon = offerIcon;
    details = getOfferDetails('Buy Now Pay Later', discountProvider);
    mobileOfferName = mobileName;
    mobileOfferDesc = mobileDesc;
  }
  if (paymentMethod !== null && paymentMethod === DISCOUNT_PAYMENT_METHOD.UPI) {
    const { name, desc, offerIcon, mobileName, mobileDesc } = getUPIOfferData(
      discount,
      background
    );
    offerName = name;
    offerDescription = desc;
    OfferIcon = offerIcon;
    details = getOfferDetails('UPI', discountProvider);
    mobileOfferName = mobileName;
    mobileOfferDesc = mobileDesc;
  }

  return {
    offerName,
    offerDescription,
    OfferIcon,
    details,
    mobileOfferDesc,
    mobileOfferName,
  };
};

// const getShowOffersValue = (showMobiKwik, discountProviders) => {
//   const showOffers =
//     showMobiKwik ||
//     (discountProviders &&
//       !isEmpty(discountProviders) &&
//       (!isEmpty(discountProviders.bnpl_providers) ||
//         !isEmpty(discountProviders.upi)));

//   return showOffers;
// };

window.getUPIOfferData = (discount, background) => {
  // `Extra ${Number(discount)}% off on UPI`;
  const name =
    DukaanData.DUKAAN_LANGUAGE.Extra__DISCOUNT__OFF_ON__UPI__.injectText({
      discount: Number(discount),
    });
  // `Get extra ${Number(discount)}% off on UPI payments.`;
  const desc =
    DukaanData.DUKAAN_LANGUAGE.GET_EXTRA__DISCOUNT_OFF_ON_UPI_PAYMENETS.injectText(
      { discount: `${Number(discount)}%` }
    );
  const offerIcon =
    background === 'light' ? OFFERS_ICONS.UPI : DARK_DIM_OFFERS_ICONS.UPI;
  const mobileName = DukaanData.DUKAAN_LANGUAGE.EXTRA__DISCOUNT_OFF.injectText({
    discount: Number(discount),
  });
  // `Extra ${Number(discount)}% off`;
  const mobileDesc = DukaanData.DUKAAN_LANGUAGE.ON_UPI_PAYMENTS;
  return { name, desc, offerIcon, mobileName, mobileDesc };
};

window.offerListRenderer = () => {
  const offerList = window.DukaanData.DUKAAN_PAYMENT_OFFERS;

  if (!offerList || offerList.length === 0) {
    return null;
  }

  const offerListWrapper = document.getElementById('offers-list');
  offerListWrapper.innerHTML = '';

  const offersHeader = document.createElement('div');
  offersHeader.innerHTML = `<div class="coupons-header">${DukaanData.DUKAAN_LANGUAGE.PAYMENT_OFFERS}</div>`;
  offerListWrapper.append(offersHeader);

  offerList?.forEach((offer) => {
    const {
      offerName,
      offerDescription,
      OfferIcon,
      details: offerDetails,
      id,
    } = offer;
    const offerTemplate = document.getElementById('offer');
    const offerCard = document.importNode(offerTemplate.content, true);
    offerCard.querySelector('.offer-icon').innerHTML = OfferIcon;
    offerCard.querySelector('.offer-name').textContent = offerName;
    offerCard.querySelector('.offer-desc').textContent = offerDescription;
    const offerDetailsWrapper = offerCard.getElementById('details-wrapper');
    const offerDetailsCard = offerCard.getElementById('offer-details');
    offerDetailsWrapper.innerHTML = '';
    offerDetailsCard.innerHTML = '';

    if (offerDetails.length > 0) {
      const headingEle = document.createElement('div');
      headingEle.className = 'flex d-row a-center j-start cursor-pointer';
      headingEle.innerHTML = `
      <div onclick="toggleShowHideState(event)" class="details-heading">Details</div>
      <svg onclick="toggleShowHideState(event)" id="${id}-details-down-arrow" class="details-down-arrow" style="padding: 2px;" width="16" height="16"
        viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
        <path fill-rule="evenodd" clip-rule="evenodd"
          d="M13.1382 6.19526C12.8779 5.93491 12.4558 5.93491 12.1954 6.19526L8.00016 10.3905L3.8049 6.19526C3.54455 5.93491 3.12244 5.93491 2.86209 6.19526C2.60174 6.45561 2.60174 6.87772 2.86209 7.13807L7.52876 11.8047C7.78911 12.0651 8.21122 12.0651 8.47157 11.8047L13.1382 7.13807C13.3986 6.87772 13.3986 6.45561 13.1382 6.19526Z"
          fill="#808080" />
      </svg>
      <svg onclick="toggleShowHideState(event)" id="${id}-details-up-arrow" class="hidden details-up-arrow" width="16" height="16" viewBox="0 0 24 24"><g fill="none" fill-rule="evenodd"><g fill="var(--black-12)" fill-rule="nonzero"><g><g><g><path transform="translate(6, 8)" d="M11.1387 5.80474C10.8784 6.06509 10.4563 6.06509 10.1959 5.80474L6.00065 1.60948L1.80539 5.80474C1.54504 6.06509 1.12293 6.06509 0.86258 5.80474C0.602231 5.54439 0.602231 5.12228 0.86258 4.86193L5.52925 0.195262C5.7896 -0.0650878 6.21171 -0.0650878 6.47206 0.195262L11.1387 4.86193C11.3991 5.12228 11.3991 5.54439 11.1387 5.80474Z"></path></g></g></g></g></g></svg>`;
      offerDetailsWrapper.append(headingEle);
      offerDetails.forEach((offerDetail) => {
        const offerDetailTemplate = document.getElementById('details-item');
        const ofrDetails = document.importNode(
          offerDetailTemplate.content,
          true
        );
        ofrDetails.querySelector('.detail-text').textContent = offerDetail;
        offerDetailsCard.append(ofrDetails);
        offerDetailsCard.classList.add('hidden');
      });
      offerDetailsWrapper.append(offerDetailsCard);
    }

    offerListWrapper.append(offerCard);
  });
  return undefined;
};

window.handleShowMoreToggle = () => {
  const offerList = window.DukaanData.DUKAAN_PAYMENT_OFFERS;
  const availableOffersList = document.getElementById('offers-list-wrapper');
  desktopOfferItemRenderer(availableOffersList, offerList.slice(2));
  document.getElementById('show-more-toggle').classList.add('hidden');
  document.getElementById('show-less-toggle').classList.remove('hidden');
};

window.handleShowLessToggle = () => {
  const offerList = window.DukaanData.DUKAAN_PAYMENT_OFFERS;
  const availableOffersList = document.getElementById('offers-list-wrapper');
  availableOffersList.innerHTML = '';
  const headingEle = document.createElement('div');
  headingEle.innerHTML = `<div class="offer-heading-desktop">Payment Offers</div>`;
  availableOffersList.appendChild(headingEle);
  desktopOfferItemRenderer(availableOffersList, offerList.slice(0, 2));
  document.getElementById('show-less-toggle').classList.add('hidden');
  document.getElementById('show-more-toggle').classList.remove('hidden');
};

window.desktopOffersRenderer = (mountElem) => {
  const offerList = window.DukaanData.DUKAAN_PAYMENT_OFFERS;

  if (!offerList || offerList.length === 0) {
    document.getElementById('payment-offers-wrapper').classList.add('hidden');
    return null;
  }
  const offersTemplate = document.getElementById(
    'available-offers-list-wrapper'
  );
  const offersWrapper = document.importNode(offersTemplate.content, true);
  mountElem.append(offersWrapper);
  const toggleWrapper = document.getElementById('offers-toggle-wrapper');
  const canShowMore = offerList.length > 2;
  const availableOffersList = document.getElementById('offers-list-wrapper');
  availableOffersList.classList.remove('hidden');
  availableOffersList.innerHTML = '';
  availableOffersList.style = `
  margin-top: 24px;
  border-top: 1px solid var(--black-90);
  border-bottom: 1px solid var(--black-90);
  padding-top: 24px;
  padding-bottom: 24px;`;

  const headingEle = document.createElement('div');
  headingEle.innerHTML = `<div class="offer-heading-desktop">${DukaanData.DUKAAN_LANGUAGE.PAYMENT_OFFERS}</div>`;
  availableOffersList.appendChild(headingEle);

  if (canShowMore) {
    toggleWrapper.style.marginTop = '16px';
    toggleWrapper.innerHTML = `<div class="flex d-row a-center j-start" id="show-more-toggle" onclick="handleShowMoreToggle()" >
    <div id="show-text">Show more</div><div class="show-svg"><svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
    <path fill-rule="evenodd" clip-rule="evenodd" d="M2.55806 5.55806C2.80214 5.31398 3.19786 5.31398 3.44194 5.55806L8 10.1161L12.5581 5.55806C12.8021 5.31398 13.1979 5.31398 13.4419 5.55806C13.686 5.80214 13.686 6.19786 13.4419 6.44194L8.44194 11.4419C8.19786 11.686 7.80214 11.686 7.55806 11.4419L2.55806 6.44194C2.31398 6.19786 2.31398 5.80214 2.55806 5.55806Z" fill="#1A181E"/>
    </svg>
    </div>    
    </div>
    <div class="flex d-row a-center j-start hidden" id="show-less-toggle" onclick="handleShowLessToggle()" >
    <div id="show-text">Show less</div><div class="show-svg"><svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
    <path fill-rule="evenodd" clip-rule="evenodd" d="M2.55806 5.55806C2.80214 5.31398 3.19786 5.31398 3.44194 5.55806L8 10.1161L12.5581 5.55806C12.8021 5.31398 13.1979 5.31398 13.4419 5.55806C13.686 5.80214 13.686 6.19786 13.4419 6.44194L8.44194 11.4419C8.19786 11.686 7.80214 11.686 7.55806 11.4419L2.55806 6.44194C2.31398 6.19786 2.31398 5.80214 2.55806 5.55806Z" fill="#1A181E"/>
    </svg>
    </div>    
    </div>`;
  }

  desktopOfferItemRenderer(availableOffersList, offerList.slice(0, 2));
  return undefined;
};

window.desktopOfferItemRenderer = (availableOffersList, offerList) => {
  offerList.forEach((offer) => {
    const { OfferIcon, offerDescription, id } = offer;
    const desktopOfferItemTemplate =
      document.getElementById('offer-item-desktop');
    const desktopOfferItem = document.importNode(
      desktopOfferItemTemplate.content,
      true
    );
    document.body.append(offerDetailModalRenderer(offer));
    desktopOfferItem.querySelector('.offer-icon-desktop').innerHTML = OfferIcon;
    desktopOfferItem.querySelector(
      '.offer-desc-desktop'
    ).innerHTML = `${offerDescription} <span class="know-more-desktop cursor-pointer" 
    onclick="handleOpenModal(event, ${id})">${DukaanData.DUKAAN_LANGUAGE.KNOW_MORE}</span>`;

    availableOffersList.appendChild(desktopOfferItem);
  });
};

window.offerDetailModalRenderer = (offer) => {
  const {
    OfferIcon,
    offerName,
    offerDescription,
    details: offerDetails,
    id,
  } = offer;
  const modalTemplate = document.getElementById('offer-modal');
  const modalOfferCard = document.importNode(modalTemplate.content, true);
  const modal = modalOfferCard.querySelector('.modal');
  modal.setAttribute('id', `offer-modal-${id}`);
  modal.setAttribute('onclick', `handleCloseOfferModal(${id})`);
  modalOfferCard.querySelector('.offer-icon').innerHTML = OfferIcon;
  modalOfferCard.querySelector('.offer-name').textContent = offerName;
  modalOfferCard.querySelector('.offer-desc').textContent = offerDescription;
  modalOfferCard
    .querySelector('.close-offer-icon')
    .setAttribute('onclick', `handleCloseOfferModal(${id})`);
  const offerDetailsWrapper = modalOfferCard.getElementById('details-wrapper');
  const offerDetailsCard = modalOfferCard.getElementById('offer-details');
  offerDetailsWrapper.innerHTML = '';
  offerDetailsCard.innerHTML = '';

  if (offerDetails.length > 0) {
    const headingEle = document.createElement('div');
    headingEle.className = 'flex d-row a-center j-start cursor-pointer';
    headingEle.innerHTML = `<div class="details-heading">${DukaanData.DUKAAN_LANGUAGE.DETAILS}</div>`;
    offerDetailsWrapper.append(headingEle);
    offerDetails.forEach((offerDetail) => {
      const offerDetailTemplate = document.getElementById('details-item');
      const offerDetailsBox = document.importNode(
        offerDetailTemplate.content,
        true
      );
      offerDetailsBox.querySelector('.detail-text').textContent = offerDetail;
      offerDetailsCard.append(offerDetailsBox);
    });
  }

  offerDetailsWrapper.append(offerDetailsCard);

  return modalOfferCard;
};

window.handleOpenModal = (event, id) => {
  document.getElementById(`offer-modal-${id}`).classList.remove('hidden');
  document.getElementsByTagName('body')[0].style.overflow = 'hidden';
};

window.handleCloseOfferModal = (id) => {
  document.getElementById(`offer-modal-${id}`).classList.add('hidden');
  document.getElementsByTagName('body')[0].style.overflow = 'auto';
};

window.mobileOffersRenderer = (mountElem) => {
  const offerList = window.DukaanData.DUKAAN_PAYMENT_OFFERS;

  if (!offerList || offerList.length === 0) {
    document.getElementById('payment-offers-wrapper').classList.add('hidden');
    return null;
  }
  const mobileOfferTemplate = document.getElementById(
    'available-offers-list-mobile-wrapper'
  );
  const mobileOfferDiv = document.importNode(mobileOfferTemplate.content, true);
  mountElem.append(mobileOfferDiv);
  mobileOffersDataRenderer(offerList);
  return undefined;
};

window.mobileOffersDataRenderer = (offerList) => {
  const mainDiv = document.getElementById('available-offers-list-mobile');
  mainDiv.querySelector('.offer-heading-mobile').textContent =
    DukaanData.DUKAAN_LANGUAGE.PAYMENT_OFFERS;
  const availableOffersList = document.getElementById(
    'offers-list-wrapper-mobile'
  );
  availableOffersList.innerHTML = '';
  mobileOfferItemRenderer(availableOffersList, offerList);
};

window.mobileOfferItemRenderer = (availableOffersList, offerList) => {
  offerList.forEach((offer) => {
    const { OfferIcon, mobileOfferName, mobileOfferDesc, id } = offer;

    document.body.append(offerDetailModalRenderer(offer));
    const mobileOfferItemTemplate =
      document.getElementById('offer-item-mobile');
    const mobileOfferItem = document.importNode(
      mobileOfferItemTemplate.content,
      true
    );
    const offerDiv = mobileOfferItem.querySelector('.offer-mobile');
    offerDiv.setAttribute('onclick', `handleOpenModal(event, ${id})`);
    mobileOfferItem.querySelector('.offer-icon-mobile').innerHTML = OfferIcon;
    mobileOfferItem.querySelector(
      '.offer-title-mobile'
    ).textContent = `${mobileOfferName}`;
    mobileOfferItem.querySelector(
      '.offer-desc-mobile'
    ).textContent = `${mobileOfferDesc}`;

    availableOffersList.appendChild(mobileOfferItem);
  });
};
