/* global q$ */
/* eslint-disable no-param-reassign */

window.categoryCardRenderer = (
  mountElem,
  category,
  options = {
    templateId: 'dkn-category-card-template',
    customCardHref: false,
  }
) => {
  const { templateId, customCardHref } = options;
  const { name, image, id, uuid } = category;
  const categoryCard = q$.selectById(templateId).getTemplateContent().elem;

  q$.selectAll('[data-category-id]', categoryCard).setDataAttributeAll(
    'categoryId',
    id
  );
  q$.selectAll('[data-category-uuid]', categoryCard).setDataAttributeAll(
    'categoryUuid',
    uuid
  );

  window.q$
    .selectAll('.dkn-category-card-name', categoryCard)
    .modifyTextContentAll(name);
  window.q$
    .selectAll('.dkn-category-card-image', categoryCard)
    .setAttributeAll('src', window.getCdnUrl(image, 500));
  window.q$
    .selectAll('.dkn-category-card-image', categoryCard)
    .setAttributeAll('onerror', 'imageOnError(event)');
  if (!customCardHref) {
    window.q$
      .selectAll('.dkn-category-card-link', categoryCard)
      .setAttributeAll(
        'href',
        window.getCategoryCardLink(category, DukaanData.DUKAAN_BASE_URL)
      );
  } else {
    window.q$
      .selectAll('.dkn-category-card-link', categoryCard)
      .setAttributeAll('href', category?.slug);
  }

  if (typeof options?.additionalRenderer === 'function') {
    options.additionalRenderer({ category, categoryCard });
  }
  mountElem.appendChild(categoryCard);
};

window.productDataRenderer = (parentElement, options = {}) => {
  const { key, product, activeSKU } = options;
  const {
    id,
    uuid,
    name,
    slug,
    image,
    description,
    meta,
    unit,
    base_qty: baseQty,
    inventory,
    categories,
  } = product;

  const sellingPrice = activeSKU?.selling_price || product?.selling_price;
  const originalPrice = activeSKU?.original_price || product?.original_price;
  const inStock = activeSKU?.in_stock || product?.in_stock;

  const discountPercent = window.getDiscountPercentValue(
    sellingPrice,
    originalPrice
  );
  const foodTypeIcon = window.getFoodTypeIcon(meta);

  // adding relevant data attributes
  q$.selectAll('[data-product-id]', parentElement).setDataAttributeAll(
    'productId',
    id
  );
  q$.selectAll('[data-product-uuid]', parentElement).setDataAttributeAll(
    'productUuid',
    uuid
  );

  parentElement.setAttribute('id', `dkn-product-data-parent-${uuid}-${key}`);

  // adding relevant data to all elements of product card
  q$.selectAll('a', parentElement).setAttributeAll(
    'href',
    window.getProductPageUrl(product)
  );

  q$.selectAll('.dkn-product-name', parentElement).modifyTextContentAll(name);

  q$.selectAll('.dkn-product-image', parentElement).setAttributeAll(
    'src',
    window.getCdnUrl(image, 700)
  );

  q$.selectAll('.dkn-product-image', parentElement).setAttributeAll(
    'onerror',
    'window.imageOnError(event)'
  );

  if (description) {
    const santizedDescription = HtmlSanitizer?.SanitizeHtml(description);
    if (santizedDescription) {
      q$.selectAll(
        '.dkn-product-description',
        parentElement
      ).modifyInnerHTMLAll(santizedDescription);
    }
  } else {
    q$.selectAll('.dkn-product-description', parentElement).addClassAll(
      'hidden'
    );
  }

  if (foodTypeIcon) {
    q$.selectAll(
      '.dkn-product-food-type-icon',
      parentElement
    ).modifyInnerHTMLAll(window.getFoodTypeIcon(meta));
    q$.selectAll('.dkn-product-food-type-icon', parentElement).removeClassAll(
      'hidden'
    );
  } else {
    q$.selectAll('.dkn-product-food-type-icon', parentElement).addClassAll(
      'hidden'
    );
  }

  let unitText = '';
  if (activeSKU?.meta?.size) {
    unitText = `${activeSKU.meta.size.attributeLabel}: ${activeSKU.meta.size.value}`;
  } else if (unit) {
    unitText = `${DukaanData.DUKAAN_LANGUAGE.PER}${
      baseQty === 1 ? '' : ` ${baseQty}`
    } ${unit}`;
  }
  if (unitText) {
    q$.selectAll('.dkn-product-item-unit', parentElement).modifyTextContentAll(
      unitText
    );
  }

  // pricing related rendering
  q$.selectAll(
    '.dkn-product-selling-price',
    parentElement
  ).modifyTextContentAll(window.formatMoney(sellingPrice));
  if (discountPercent > 0) {
    q$.selectAll(
      '.dkn-product-original-price',
      parentElement
    ).modifyTextContentAll(window.formatMoney(originalPrice));

    let discountText = '';
    if (options.getCustomDiscountText) {
      discountText = options.getCustomDiscountText(discountPercent);
    } else {
      discountText = `${discountPercent}% OFF`;
    }
    q$.selectAll('.dkn-product-discount', parentElement).modifyTextContentAll(
      discountText
    );
    q$.selectAll(
      '.dkn-product-you-save-text',
      parentElement
    ).modifyTextContentAll(
      `You save ${formatMoney(originalPrice - sellingPrice)}.`
    );
    q$.selectAll('.dkn-product-you-save-text', parentElement).removeClassAll(
      'hidden'
    );
    q$.selectAll('.dkn-product-original-price', parentElement).removeClassAll(
      'hidden'
    );
    q$.selectAll('.dkn-product-discount', parentElement).removeClassAll(
      'hidden'
    );
  } else {
    q$.selectAll('.dkn-product-original-price', parentElement).addClassAll(
      'hidden'
    );
    q$.selectAll('.dkn-product-discount', parentElement).addClassAll('hidden');
  }

  const stockLeftMessage = q$.select(
    '.dkn-stock-left-message',
    parentElement
  ).elem;
  if (stockLeftMessage) {
    if (inventory <= 10 && inventory) {
      stockLeftMessage.classList.remove('hidden');
      stockLeftMessage.textContent =
        `${DukaanData.DUKAAN_LANGUAGE.ONLY__INVENTORY_LEFT_IN_STOCK_HURRY_UP}!`.injectText(
          {
            inventory,
          }
        );
    } else {
      stockLeftMessage.classList.add('hidden');
      stockLeftMessage.textContent = ``;
    }
  }
  const stockText = q$.select('.dkn-product-stock-text', parentElement).elem;
  if (stockText) {
    if (inStock) {
      stockText.textContent = DukaanData.DUKAAN_LANGUAGE.IN_STOCK;
      stockText.classList.add('text-c-green');
      stockText.classList.remove('text-c-red');
    } else {
      stockText.textContent = DukaanData.DUKAAN_LANGUAGE.OUT_OF_STOCK;
      stockText.classList.remove('text-c-green');
      stockText.classList.add('text-c-red');
    }
  }

  // brands related rendering
  if (product?.brands?.length) {
    const { logo, name: brandName } = product.brands[0];

    // brand logo
    if (logo) {
      q$.selectAll('.dkn-product-brand-image', parentElement).setAttributeAll(
        'src',
        window.getCdnUrl(logo, 100)
      );
    } else {
      q$.selectAll('.dkn-product-brand-image', parentElement).setAttributeAll(
        'onerror',
        'window.imageOnError(event)'
      );
    }

    // brand name
    if (brandName) {
      q$.selectAll(
        '.dkn-product-brand-name',
        parentElement
      ).modifyTextContentAll(brandName);
    } else {
      q$.selectAll('.dkn-product-brand-name', parentElement).addClassAll(
        'hidden'
      );
    }
  } else {
    q$.selectAll('.dkn-product-brand-details', parentElement).addClassAll(
      'hidden'
    );
  }

  // category name
  if (
    q$.selectAll('.dkn-product-category-name', parentElement) &&
    categories &&
    categories.length > 0
  ) {
    if (typeof options.getCustomCategoryNameText !== 'undefined') {
      q$.selectAll(
        '.dkn-product-category-name',
        parentElement
      ).modifyTextContentAll(
        options.getCustomCategoryNameText(categories[0]?.name)
      );
    } else {
      q$.selectAll(
        '.dkn-product-category-name',
        parentElement
      ).modifyTextContentAll(`${categories[0]?.name}`);
    }
  }

  // calling custom renderer if it exists
  if (options.additionalRenderer) {
    options.additionalRenderer(parentElement, product, options);
  }
};

window.renderAddToBagOnProductCard = () => {
  const showAddToBagButton =
    window.DukaanData?.DUKAAN_THEME_DATA?.meta?.advanced?.product
      ?.showAddToBagOnProductCard;

  const addToBagElement = q$.select(
    'add-to-bag-button-with-variants', // need to rename this to dkn format later
    parentElement
  ).elem;

  if (addToBagElement) {
    if (
      (typeof showAddToBagButton !== 'undefined' && showAddToBagButton) ||
      typeof showAddToBagButton === 'undefined'
    ) {
      addToBagButtonWithVariantsRenderer(addToBagElement);
    } else {
      addToBagElement.classList.add('hidden');
    }
  }
};
