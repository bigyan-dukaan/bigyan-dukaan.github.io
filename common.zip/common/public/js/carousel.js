window.imageSlides = document.getElementsByClassName('slide');
window.g = document.getElementsByClassName('thumbImageWrapper');

window.currentSlide = 0;
window.maxSlide = imageSlides.length - 1;

Array.from(imageSlides).forEach((slide, index) => {
  slide.style.transform = `translateX(${index * 100}%)`;
});

for (let i = 0, len = g.length; i < len; i++) {
  // eslint-disable-next-line no-loop-func
  (function (index) {
    g[i].onclick = function () {
      if (typeof pauseAllProductVideos !== 'undefined') pauseAllProductVideos();
      if (index > currentSlide) {
        if (currentSlide !== maxSlide) {
          currentSlide = index;
        }

        Array.from(imageSlides).forEach((slide, idx) => {
          slide.style.transform = `translateX(${100 * (idx - currentSlide)}%)`;
        });
      } else {
        if (currentSlide !== 0) {
          currentSlide = index;
        }

        Array.from(imageSlides).forEach((slide, idx) => {
          slide.style.transform = `translateX(${100 * (idx - currentSlide)}%)`;
        });
      }
    };
  })(i);
}
