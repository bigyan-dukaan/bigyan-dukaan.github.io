/* eslint-disable no-param-reassign */
window.paginationTemplate = document.getElementById('pagination');
window.paginationEl = document.querySelector('pagination');
if (paginationEl && paginationTemplate) {
  paginationEl.appendChild(paginationTemplate.content.cloneNode(true));
}
window.adFiltersTemplate = document.getElementById('advanced-filters');
window.adFiltersEl = document.querySelector('advanced-filters');
window.isShowMoreDisabled = Boolean(
  adFiltersEl.hasAttribute('disable-show-more-btn')
);
if (window.innerWidth <= 992) adFiltersEl.classList.add('hidden');
if (adFiltersEl && adFiltersTemplate) {
  adFiltersEl.appendChild(adFiltersTemplate.content.cloneNode(true));
}
window.leftArrow = document.getElementById('left-arrow');
window.rightArrow = document.getElementById('right-arrow');
window.changeStringArrayToNumberArray = (arr) => arr.map((val) => Number(val));
window.filterForm = document.getElementById('advance-filter-form');
window.selectedFilterWrapper = document.querySelector('filter-tags');
window.showMoreFilterButton = document.getElementById('show-more-filters');
window.filterCheckbox = document.getElementById('filter-checkbox');
window.productListWrapper = document.querySelector('category-cards');
window.pageNumberCountForInfiniteScroll = 1;
window.ADV_FILTERS_RENDERED_PRODUCTS = 0;

filterForm.addEventListener('change', () => {
  window.checkboxes = document.querySelectorAll(
    '.advance-filter__checkbox-container input:checked'
  );
  if (!checkboxes.length)
    selectedFilterWrapper.classList.remove('advance-filter__tags--mb-16');
});

window.serializeStringValues = (str) => {
  if (typeof str === 'string') return str.replace(/"/g, '\\"');
  return str;
};

window.showMoreButtonState = {};
let sortCategories = true;

window.filterCategoryParams = {
  CATEGORY_IDS: 'category_ids',
  SIZE: 'size',
  COLOR: 'color',
  PRICE_RANGES: 'price_ranges',
  PAGE_NUMBER: 'page_number',
  SORT_BY: 'sort_by',
  ATTRIBUTES_VALUE: 'sku_attrs',
  PRODUCT_ATTRS: 'product_attrs',
  QUERY: 'query',
  SHOW_PRODUCTS_HAVING_BRAND: 'show_products_having_brand',
  BRAND_IDS: 'brands',
  PAGE_TYPE: 'page_type',
};

window.filterBlockAttributes = {
  [filterCategoryParams.ATTRIBUTES_VALUE]: [],
  [filterCategoryParams.PRODUCT_ATTRS]: [],
};

window.defaultSortByValue = '';

window.getPayloadDataFromFilters = () => {
  const formValues = new FormData(filterForm);
  const payload = {};
  payload[filterCategoryParams.ATTRIBUTES_VALUE] = {};
  payload[filterCategoryParams.PRODUCT_ATTRS] = {};
  // eslint-disable-next-line no-restricted-syntax
  for (const key of formValues.keys()) {
    if (key === filterCategoryParams.CATEGORY_IDS) {
      payload[key] = window?.advanceFiltersConfig?.searchTapConfig?.hasSearchtap
        ? formValues.getAll(key)
        : changeStringArrayToNumberArray(formValues.getAll(key));
    } else if (key === filterCategoryParams.BRAND_IDS) {
      payload[key] = window?.advanceFiltersConfig?.searchTapConfig?.hasSearchtap
        ? formValues.getAll(key)
        : changeStringArrayToNumberArray(formValues.getAll(key));
    } else if (
      filterBlockAttributes[filterCategoryParams.ATTRIBUTES_VALUE].includes(key)
    ) {
      payload[filterCategoryParams.ATTRIBUTES_VALUE][key] =
        formValues.getAll(key);
    } else if (
      filterBlockAttributes[filterCategoryParams.PRODUCT_ATTRS].includes(key)
    ) {
      const serializedValues = formValues
        .getAll(key)
        .filter((item) => item && item !== 'null');
      if (serializedValues?.length > 0) {
        payload[filterCategoryParams.PRODUCT_ATTRS][key] = serializedValues;
      }
    } else {
      payload[key] = formValues.getAll(key);
    }
  }
  return payload;
};

window.sortByClickHandler = (sortType, callback = () => {}) => {
  const payload = getPayloadData();
  payload[filterCategoryParams.SORT_BY] = sortType;
  payload[filterCategoryParams.PAGE_NUMBER] = 1;
  const url = new URL(window.location);
  url.searchParams.set(filterCategoryParams.SORT_BY, sortType);
  url.searchParams.set(filterCategoryParams.PAGE_NUMBER, 1);
  window.history.replaceState({}, '', url);
  getProductCards(payload, 1);
  callback(sortType);
};

window.advFiltersCategoryProductsRenderer = (products) => {
  let productsList = products;
  if (typeof getModifiedProducts !== 'undefined') {
    productsList = window.getModifiedProducts(products);
  }

  productsList.forEach((product) => {
    window.productCardRenderer(productListWrapper, product, {
      templateId:
        window.productCardTemplateId || 'advance-filter__product-card',
      getCustomDiscountText: window.getCustomDiscountText,
      additionalRenderer: (productCard, item) => {
        if (typeof window.productCardAdditionalRenderer === 'function') {
          window.productCardAdditionalRenderer(productCard, item);
        }
        if (
          typeof window.bundleProductAdditionalRenderer === 'function' &&
          item.product_type === 2
        ) {
          bundleProductAdditionalRenderer(productCard, item);
        }
      },
      productCardClasses: window.advFiltersProductCardClasses,
    });
  });
  const productIds = productsList.map((product) => product.id);
  window.fetchProductCoupons(productIds);
  for (let i = 0; i < productIds.length; i += 30) {
    window.fetchRatingsDataFromProductIds(
      productIds.slice(i, i + 30),
      productListWrapper,
      {
        reviewInfoTemplateId:
          window.productCardReviewTemplateId ||
          'dkn-product-review-with-count-template',
        getCustomReviewsCountText: window.getCustomReviewsCountText,
        starHeight: window.productCardStarHeight,
        starWidth: window.productCardStarWidth,
        beforeRenderingReviewsFn: window.beforeRenderingReviewsFn,
      }
    );
  }

  if (typeof dknRenderWishlistButtons !== 'undefined')
    window.dknRenderWishlistButtons(productListWrapper);
};

window.handleFormValueChange = (changedAttribute, value, label) => {
  // const formValues = new FormData(filterForm);
  const paramString = new URLSearchParams(window.location.search);
  // paramString.delete(changedAttribute);
  // paramString.set(filterCategoryParams.PAGE_NUMBER, 1);
  // const changedAttributeValues = formValues.getAll(changedAttribute);
  // changedAttributeValues.forEach((changedValue) => {
  //   paramString.append(changedAttribute, changedValue);
  // });

  if (
    changedAttribute === filterCategoryParams.CATEGORY_IDS ||
    changedAttribute === filterCategoryParams.BRAND_IDS
  ) {
    getFiltersData({ successCallback: true });
  } else {
    const inputCheckbox = document.querySelector(
      `.advance-filter__checkbox-container input[value="${serializeStringValues(
        value
      )}"]`
    );
    if (inputCheckbox && inputCheckbox.checked)
      filterTagRenderer(changedAttribute, value, label || value);
  }
  const payload = getPayloadData();
  paramString.set('filters', JSON.stringify(payload));
  window.history.replaceState(
    {},
    '',
    `${window.location.origin}${
      window.location.pathname
    }?${paramString.toString()}`
  );
  getProductCards(payload, 1);
  scrollToTop();
};

window.tagClickHandler = (property, value) => {
  const inputCheckbox = document.querySelector(
    `.advance-filter__checkbox-container input[value="${serializeStringValues(
      value
    )}"]`
  );
  const clickedTag = document.querySelector(
    `.tag-wrapper[data-value='${value}']`
  );
  if (inputCheckbox && inputCheckbox.checked) inputCheckbox.checked = false;
  clickedTag.remove();
  handleFormValueChange(property, value);
};

window.filterTagRenderer = (name, value, text) => {
  if (!selectedFilterWrapper) return;
  const selectedTag = document.getElementById('filter-tag');
  const selectedTagButton = selectedTag.content.cloneNode(true);
  selectedTagButton.querySelector('.tag-wrapper').dataset.value = value;
  selectedTagButton.querySelector('.tag-wrapper').dataset.name = name;
  selectedTagButton.querySelector('.tag-label').textContent = text || value;
  selectedTagButton
    .querySelector('button')
    .addEventListener('click', () => tagClickHandler(name, value));
  selectedFilterWrapper.appendChild(selectedTagButton);
};

window.showMoreButtonRenderer = (filterType, totalCount, checkboxWrapper) => {
  const showMoreButton = showMoreFilterButton.content.cloneNode(true);
  const buttonElement = showMoreButton.querySelector('.show-more-button');
  buttonElement.textContent = `+${totalCount - 5} more`;
  buttonElement.addEventListener('click', () => {
    const hiddenFilter = checkboxWrapper.querySelectorAll(
      '.advance-filter__checkbox-container.hidden'
    );
    hiddenFilter.forEach((ele) => {
      ele.classList.remove('hidden');
    });
    buttonElement.classList.add('hidden');
    showMoreButtonState[filterType] = true;
  });
  checkboxWrapper.appendChild(showMoreButton);
};

window.getAttributeFiltersPayload = (pageType) => {
  const { category_ids: categoryIds, brands } = window.getPayloadData();

  switch (pageType) {
    case 'search':
      return {
        category_ids: categoryIds,
        brands,
      };
    case 'category':
      return { brands };

    case 'brand':
      return {
        category_ids: categoryIds,
      };

    case 'all_brands':
      return {
        category_ids: categoryIds,
        brands,
      };
    default:
      return {};
  }
};

window.categoryLinkItemRenderer = (category) => {
  const { name, id, slug } = category;
  const categoryId = DukaanData?.DUKAAN_CATEGORY?.id;
  const categoryItemContent = window.q$
    .selectById('advance-filter-category-link-template')
    .getTemplateContent().elem;
  const categoryItem = window.q$.select(
    '.advance-filter-category-link',
    categoryItemContent
  ).elem;
  categoryItem.setAttribute(
    'href',
    `${DukaanData.DUKAAN_BASE_URL}/categories/${slug}`
  );
  categoryItem.textContent = name;
  if (id === categoryId) {
    categoryItem.classList.add('active');
  }
  return categoryItem;
};

window.setCategoryLevelData = ({
  currentCategory,
  siblingCategories,
  subCategories,
  parentCategory,
}) => {
  parentCategory.push({ ...currentCategory, child: subCategories });
  parentCategory.push(...siblingCategories);
  return parentCategory;
};

window.getSerializedCategories = () => {
  let parentCategories = DukaanData?.DUKAAN_CATEGORY?.parent_categories || [];
  parentCategories = parentCategories.sort((a, b) => a.depth - b.depth);
  let siblingCategories = DukaanData?.DUKAAN_CATEGORY?.sibling_categories || [];
  siblingCategories = siblingCategories.filter(
    (category) => category.id !== DukaanData?.DUKAAN_CATEGORY.id
  );
  const subCategories = DukaanData?.DUKAAN_CATEGORY?.sub_categories || [];
  const currentCategory = DukaanData?.DUKAAN_CATEGORY || [];

  if (
    !parentCategories.length &&
    !subCategories.length &&
    !siblingCategories.length
  )
    return [];

  // creates the tree for the category page we are on
  let categoryTreeData = window.setCategoryLevelData({
    currentCategory,
    siblingCategories,
    subCategories,
    parentCategory: [],
  });

  for (let x = 0; x < parentCategories.length; x += 1) {
    // adds the lowest level of category data to the child of the category higher up in the three
    categoryTreeData = [
      {
        ...parentCategories[x],
        child: categoryTreeData,
      },
    ];
  }

  return categoryTreeData;
};

window.renderCategoryTreeList = ({ categories, mountElem, count }) => {
  if (!categories?.length) return;
  categories?.forEach((category) => {
    count += 1;
    const categoryItem = window.categoryLinkItemRenderer(category);
    categoryItem.classList.add('flex', 'd-column', `node-count-${count}`);
    if (category?.child?.length) {
      window.renderCategoryTreeList({
        categories: category.child,
        mountElem: categoryItem,
        count,
      });
    }
    mountElem.appendChild(categoryItem);
  });
};

window.handleOneFilterTypeSearchClear = ({
  formId,
  rawFilterData: filterData,
  filterKey,
  fieldsRendererFunction,
}) => {
  if (formId) {
    window.q$.select(
      `form#${formId} .advance-filter__filter-search-input`
    ).elem.value = '';
  }
  const mountElem = window.q$.selectById(`adv-filters-${filterKey}`).elem;
  mountElem.innerHTML = null;
  fieldsRendererFunction({
    filterData,
    filterKey,
    mountElem,
  });
};

window.handleOneFilterTypeSearchChange = ({
  event,
  rawFilterData,
  filterKey,
  fieldsRendererFunction,
  valueFromForm,
}) => {
  const value = event?.target?.value || valueFromForm || '';
  if (value) {
    window.q$
      .selectById(`filter-search-input-close-icon-${filterKey}`)
      .removeClass('hidden');
  } else {
    window.q$
      .selectById(`filter-search-input-close-icon-${filterKey}`)
      .addClass('hidden');
    window.handleOneFilterTypeSearchClear({
      rawFilterData,
      filterKey,
      fieldsRendererFunction,
    });
    return;
  }

  const filteredData = window.searchForQueryInFilterData({
    query: value,
    rawFilterData,
  });

  const mountElem = window.q$.selectById(`adv-filters-${filterKey}`).elem;
  window.q$.select('.show-more-button', mountElem).addClass('hidden');

  const filterItems = mountElem.querySelectorAll(
    '.advance-filter__checkbox-container'
  );

  filterItems.forEach((item) => {
    const inputVal = window.q$.select('input', item).elem.value;
    if (filteredData?.indexOf(inputVal) !== -1) {
      item.classList.remove('hidden');
    } else {
      item.classList.add('hidden');
    }
  });
};
window.searchForQueryInFilterData = ({ rawFilterData, query }) => {
  query = query.toLowerCase();
  if (!query?.length) return rawFilterData;
  let filterData = rawFilterData.filter(
    (dataItem) =>
      String(dataItem?.key)?.toLowerCase()?.includes(query) ||
      String(dataItem?.name)?.toLowerCase()?.includes(query)
  );
  filterData = filterData?.map((filter) => String(filter.key));
  return filterData;
};

window.renderSearchFieldInOneFilterType = ({
  mountElem,
  title,
  rawFilterData,
  filterKey,
  fieldsRendererFunction,
}) => {
  const formId = `search-form-for-${filterKey}`;
  const config = {
    formId,
    rawFilterData,
    filterKey,
    fieldsRendererFunction,
  };
  const searchInputWrapper = window.q$
    .selectById('search-input-in-filters-template')
    .getTemplateContent().elem;
  window.q$.select('form', searchInputWrapper).setAttribute('id', formId);
  window.q$
    .select('.advance-filter__filter-search-input', searchInputWrapper)
    .elem.addEventListener('keyup', (event) => {
      window.handleOneFilterTypeSearchChange({
        event,
        ...config,
      });
    });

  const closeIcon = window.q$.select(
    '.advance-filter__filter-search-input-close-icon',
    searchInputWrapper
  ).elem;
  closeIcon.setAttribute('id', `filter-search-input-close-icon-${filterKey}`);
  closeIcon.addEventListener('click', () => {
    window.handleOneFilterTypeSearchClear(config);
    closeIcon.classList.add('hidden');
  });

  window.q$
    .select('.advance-filter__filter-search-input', searchInputWrapper)
    .setAttribute('placeholder', `Search by ${title.toLowerCase()}`);
  mountElem.appendChild(searchInputWrapper);
};

window.renderFiltersBlock = ({
  filterData,
  title,
  filterKey,
  mountElem,
  renderSearchField,
  countForShowingSearchField,
  fieldsRendererFunction,
}) => {
  const filterBlock = document.getElementById('filter-block');
  const categoriesBlock = filterBlock.content.cloneNode(true);
  q$.select(
    '.advance-filter__block, .advance-filter__block-container',
    categoriesBlock
  ).addClass(`advance-filter-${removeWhiteSpace(filterKey)}`);
  categoriesBlock.querySelector('.block-title').textContent = title;
  const checkboxWrapper = categoriesBlock.querySelector(
    '.filter-checkbox-wrapper'
  );
  checkboxWrapper.setAttribute('id', `adv-filters-${filterKey}`);
  const searchBoxWrapper = categoriesBlock.querySelector('.search-box-wrapper');

  if (searchBoxWrapper) {
    if (renderSearchField && filterData.length > countForShowingSearchField) {
      window.renderSearchFieldInOneFilterType({
        mountElem: searchBoxWrapper,
        rawFilterData: filterData,
        filterKey,
        title,
        fieldsRendererFunction,
      });
    } else {
      searchBoxWrapper.classList.add('hidden');
    }
  }

  fieldsRendererFunction({
    filterData,
    filterKey,
    mountElem: checkboxWrapper,
  });

  mountElem.appendChild(categoriesBlock);
};

window.renderCheckFieldsSection = ({ filterData, filterKey, mountElem }) => {
  const paramString = new URLSearchParams(window.location.search);
  const filtersDataFromParams = JSON.parse(paramString.get('filters'));
  const selectedFields = filtersDataFromParams?.[filterKey];

  filterData = filterData.sort((a, b) => {
    if (
      selectedFields?.includes(`${a.key}`) &&
      !selectedFields?.includes(`${b.key}`)
    )
      return -1;
    if (
      !selectedFields?.includes(`${a.key}`) &&
      selectedFields?.includes(`${b.key}`)
    )
      return 1;
    return 0;
  });

  filterData.forEach(({ key, name = key }, index) => {
    const checkbox = filterCheckbox.content.cloneNode(true);
    const input = checkbox.querySelector('input');
    input.setAttribute('value', key);
    input.setAttribute('name', filterKey);
    checkbox.querySelector('.advance-filter__checkbox-text').textContent = name;
    // input.addEventListener('change', () => {
    //   const filterCtas = document.getElementById('filter-ctas');
    //   if (
    //     window.getComputedStyle(filterCtas).getPropertyValue('display') ===
    //     'flex'
    //   )
    //     return;
    //   const changedAttribute = input.getAttribute('name');

    //   handleFormValueChange(
    //     changedAttribute,
    //     input.getAttribute('value'),
    //     input.nextElementSibling.textContent
    //   );
    //   const relatedTag = document.querySelector(
    //     `.tag-wrapper[data-value="${serializeStringValues(input.value)}"]`
    //   );
    //   if (!input.checked && Boolean(relatedTag)) relatedTag.remove();
    // });

    if (selectedFields?.length && selectedFields?.includes(key)) {
      input.checked = true;
      if (
        !document.querySelector(
          `.tag-wrapper[data-value="${serializeStringValues(key)}"]`
        )
      ) {
        window.filterTagRenderer(filterKey, key, name);
      }
    }
    if (index > 4 && !showMoreButtonState[filterKey] && !isShowMoreDisabled) {
      checkbox
        .querySelector('.advance-filter__checkbox-container')
        .classList.add('hidden');
    }
    mountElem.appendChild(checkbox);
  });

  if (
    filterData.length > 5 &&
    !showMoreButtonState[filterKey] &&
    !isShowMoreDisabled
  ) {
    window.showMoreButtonRenderer(filterKey, filterData.length, mountElem);
  }
};

window.getDukaanFiltersData = async () => {
  const { page_type: pageType, params } = window.getPageTypeAndParams();
  const pageTypeFiltersPayload = { page_type: pageType, ...params };
  const attributeFiltersPayload = {
    ...params,
    ...getAttributeFiltersPayload(pageType),
  };

  if (
    pageType === 'all_brands' &&
    attributeFiltersPayload?.brands?.length > 0
  ) {
    attributeFiltersPayload[
      filterCategoryParams.SHOW_PRODUCTS_HAVING_BRAND
    ] = false;
  }

  const requests = [
    fetch(
      `${window.DukaanData.DUKAAN_ADVANCED_SEARCH_API_BASE_URL}/api/advanced-search-page-filters/${DukaanData.DUKAAN_STORE.id}/`,
      {
        method: 'post',
        body: JSON.stringify(pageTypeFiltersPayload),
        headers: {
          'Content-Type': 'application/json',
          'x-requested-with': window?.DukaanData?.DUKAAN_SESSION_ID,
        },
      }
    ).catch(() => {}),
    fetch(
      `${window.DukaanData.DUKAAN_ADVANCED_SEARCH_API_BASE_URL}/api/advanced-search-filters/${DukaanData.DUKAAN_STORE.id}/`,
      {
        method: 'post',
        body: JSON.stringify(attributeFiltersPayload),
        headers: {
          'Content-Type': 'application/json',
          'x-requested-with': window?.DukaanData?.DUKAAN_SESSION_ID,
        },
      }
    ).catch(() => {}),
  ];

  return Promise.all(requests)
    .then((responses) => Promise.all(responses.map((res) => res.json())))
    .then(([pageSpecificRes, filterDataRes]) => ({
      pageSpecificData: pageSpecificRes?.data,
      filterData: filterDataRes?.data,
    }))
    .catch(() => {});
};

window.getKeyNameCountPair = (items) =>
  items?.map((item) => ({
    key: item.label,
    name: item.label,
    count: item.value,
  }));

window.getSearchTapDiscountValue = (min, max) => {
  const discountValues = [];

  if (min === 0 && max === 0) return discountValues;

  const minValue = Math.floor(min);
  const maxValue = Math.ceil(max);
  for (let i = minValue; i < maxValue; i += 10) {
    discountValues.push({ key: `${i}-${i + 10}`, name: `${i}% - ${i + 10}%` });
  }
  return discountValues;
};

window.getFiltersData = ({ successCallback = () => {}, overrides = {} }) => {
  const { page_type: pageType } = window.getPageTypeAndParams();
  const request = window?.advanceFiltersConfig?.searchTapConfig?.hasSearchtap
    ? getSearchTapFiltersData(overrides)
    : getDukaanFiltersData();

  request
    .then((resData) => {
      const { pageSpecificData = {}, filterData: data = {} } = resData || {};
      const { brands = [], categories = [] } = pageSpecificData || {};
      const {
        countForShowingSearchField,
        renderSearchField,
        showProductAttrKeys = true,
      } = window.advanceFiltersConfig;
      let hideFilter = true;
      let filterWrapper = q$.selectById('advance-filter-form').elem;
      if (typeof getFilterWrapperElement === 'function') {
        filterWrapper = getFilterWrapperElement();
      }

      // makes existing data empty
      if (selectedFilterWrapper) selectedFilterWrapper.innerHTML = null;
      // removes filter elements from the DOM on render
      const filterBlocksList = filterWrapper.querySelectorAll(
        '.advance-filter__block-container'
      );
      filterBlocksList.forEach((item) => {
        item.remove();
      });

      // removes shimmers
      filterWrapper
        .querySelectorAll('.block-container:not(:first-of-type)')
        .forEach((el) => el.remove());

      const filterBlock = document.getElementById('filter-block');
      const skuAttr = data?.sku_attrs || {};
      const productAttr = data?.product_attrs || {};
      const paramString = new URLSearchParams(window.location.search);
      const filtersDataFromParams =
        JSON.parse(paramString.get('filters')) || {};
      const categoriesList = window.getSerializedCategories();
      let customFilterRenderers = {};
      if (typeof getAdvanceFiltersItemRenderers === 'function') {
        customFilterRenderers = getAdvanceFiltersItemRenderers();
      }
      if (pageType === 'category' && categoriesList.length) {
        hideFilter = false;
        const categoriesBlock = filterBlock.content.cloneNode(true);
        q$.select(
          '.advance-filter__block, .advance-filter__block-container',
          categoriesBlock
        ).addClass(`advance-filter-category-tree`);
        categoriesBlock.querySelector('.block-title').textContent =
          DukaanData.DUKAAN_LANGUAGE.CATEGORY || 'Category';
        const checkboxWrapper = categoriesBlock.querySelector(
          '.filter-checkbox-wrapper'
        );
        window.renderCategoryTreeList({
          categories: categoriesList,
          mountElem: checkboxWrapper,
          count: 0,
        });
        filterWrapper.appendChild(categoriesBlock);
      }

      if (
        categories?.length &&
        pageType !== 'category' &&
        DukaanData.DUKAAN_PAGE_KEY !== 'bundle'
      ) {
        hideFilter = false;
        const selectedCategories =
          filtersDataFromParams?.[filterCategoryParams.CATEGORY_IDS] || [];

        // Sorting Selected elements to the front
        if (sortCategories) {
          categories.sort((a, b) => {
            if (
              selectedCategories?.includes(`${a.id}`) &&
              !selectedCategories?.includes(`${b.id}`)
            )
              return -1;
            if (
              !selectedCategories?.includes(`${a.id}`) &&
              selectedCategories?.includes(`${b.id}`)
            )
              return 1;
            return 0;
          });
          sortCategories = !sortCategories;
        }

        window.renderFiltersBlock({
          filterData: categories,
          title: DukaanData.DUKAAN_LANGUAGE.CATEGORY || 'Categories',
          filterKey: filterCategoryParams.CATEGORY_IDS,
          mountElem: filterWrapper,
          renderSearchField,
          countForShowingSearchField,
          fieldsRendererFunction: renderCheckFieldsSection,
        });
      }

      if (brands?.length) {
        hideFilter = false;
        window.renderFiltersBlock({
          filterData: brands,
          title: DukaanData.DUKAAN_LANGUAGE.BRAND || 'Brands',
          filterKey: filterCategoryParams.BRAND_IDS,
          mountElem: filterWrapper,
          renderSearchField,
          countForShowingSearchField,
          fieldsRendererFunction: renderCheckFieldsSection,
        });
      }

      const skuAttrKeys = Object.keys(skuAttr);
      filterBlockAttributes[filterCategoryParams.ATTRIBUTES_VALUE] = [
        ...skuAttrKeys,
      ];
      if (skuAttrKeys.length) {
        hideFilter = false;
        skuAttrKeys.forEach((key) => {
          const skuAttrBlock = filterBlock.content.cloneNode(true);
          q$.select(
            '.advance-filter__block, .advance-filter__block-container',
            skuAttrBlock
          ).addClass(
            `advance-filter-${
              filterCategoryParams.ATTRIBUTES_VALUE
            }-${removeWhiteSpace(key)}`
          );
          const selectedAttrValue =
            filtersDataFromParams?.[filterCategoryParams.ATTRIBUTES_VALUE]?.[
              key
            ];
          skuAttrBlock.querySelector('.block-title').textContent =
            key.toLowerCase() === 'color picker' ? 'Color' : key;
          const checkboxWrapper = skuAttrBlock.querySelector(
            '.filter-checkbox-wrapper'
          );
          const isColor = dknCheckIfValueIsHexCode(skuAttr[key]?.[0]?.key);
          if (isColor) {
            checkboxWrapper.classList.add(
              'advance-filter__color-checkbox-wrapper'
            );
          }
          const selectedSkuAttr =
            filtersDataFromParams?.[filterCategoryParams.ATTRIBUTES_VALUE]?.[
              key
            ];
          skuAttr[key].sort((a, b) => {
            if (
              selectedSkuAttr?.includes(`${a.key}`) &&
              !selectedSkuAttr?.includes(`${b.key}`)
            )
              return -1;
            if (
              !selectedSkuAttr?.includes(`${a.key}`) &&
              selectedSkuAttr?.includes(`${b.key}`)
            )
              return 1;
            return 0;
          });
          skuAttr[key].forEach((value, index) => {
            const checkbox = filterCheckbox.content.cloneNode(true);
            const input = checkbox.querySelector('input');
            input.setAttribute('value', value.key);
            input.setAttribute('name', key);
            if (!isColor) {
              checkbox.querySelector(
                '.advance-filter__checkbox-text'
              ).textContent = value.key;
            } else {
              const colorDot = checkbox.querySelector(
                '.advance-filter__color-dot'
              );
              colorDot.style.backgroundColor = value.key;
              colorDot.classList.remove('hidden');
              colorDot.nextElementSibling.textContent = getColorName(
                value.key
              )?.color;
            }
            if (
              selectedAttrValue?.length &&
              selectedAttrValue?.includes(value.key)
            ) {
              input.checked = true;
              if (
                !document.querySelector(
                  `.tag-wrapper[data-value="${serializeStringValues(
                    value.key
                  )}"]`
                )
              )
                filterTagRenderer(
                  key,
                  value.key,
                  isColor ? getColorName(value.key)?.color : value.key
                );
            }
            if (index > 4 && !showMoreButtonState[key] && !isShowMoreDisabled) {
              checkbox
                .querySelector('.advance-filter__checkbox-container')
                .classList.add('hidden');
            }
            if (typeof customFilterRenderers?.[key] === 'function') {
              customFilterRenderers[key](key, value, checkbox);
            }
            checkboxWrapper.appendChild(checkbox);
          });
          if (
            skuAttr[key].length > 5 &&
            !showMoreButtonState[key] &&
            !isShowMoreDisabled
          ) {
            showMoreButtonRenderer(key, skuAttr[key].length, checkboxWrapper);
          }
          filterWrapper.appendChild(skuAttrBlock);
        });
      }
      if (
        data?.min_selling_price !== data?.max_selling_price &&
        data?.max_selling_price
      ) {
        hideFilter = false;
        const selectedPrices =
          filtersDataFromParams?.[filterCategoryParams.PRICE_RANGES];
        const minSP = data?.min_selling_price ? data.min_selling_price : 1;
        const maxSP = data.max_selling_price;
        let noOfPriceRanges = 5;
        let difference = Math.floor(Number(maxSP - minSP) / 5 + 1);
        let lowerRange = minSP;
        const factor = window?.advanceFiltersConfig?.roundFieldsToHundred
          ? 100
          : window?.advanceFiltersConfig?.priceFieldRoundingFactor;
        if (factor) {
          if (difference < factor) {
            difference = factor;
            noOfPriceRanges = 1;
          } else {
            difference = Math.round(difference / factor) * factor;
            lowerRange = Math.round(lowerRange / factor) * factor;
          }
        }
        if (difference < 1) {
          difference = maxSP - minSP;
          noOfPriceRanges = 1;
        } else if (difference > 10) {
          difference = Math.round(difference / 10) * 10;
          lowerRange = Math.round(lowerRange / 10) * 10;
        }
        const priceRanges = [];
        for (let i = 1; i <= noOfPriceRanges; i += 1) {
          priceRanges.push({
            key: `${formatMoney(lowerRange)} - ${formatMoney(
              lowerRange + difference
            )}`,
            lowerRange,
            upperRange: lowerRange + difference,
          });
          lowerRange += difference;
        }

        const pricesBlock = filterBlock.content.cloneNode(true);
        q$.select(
          '.advance-filter__block, .advance-filter__block-container',
          pricesBlock
        ).addClass(`advance-filter-${filterCategoryParams.PRICE_RANGES}`);
        pricesBlock.querySelector('.block-title').textContent =
          DukaanData.DUKAAN_LANGUAGE.PRICE || 'Price';
        const checkboxWrapper = pricesBlock.querySelector(
          '.filter-checkbox-wrapper'
        );
        priceRanges.forEach(({ key, lowerRange, upperRange }) => {
          const checkbox = filterCheckbox.content.cloneNode(true);
          const input = checkbox.querySelector('input');
          input.setAttribute('value', `${lowerRange}-${upperRange}`);
          input.setAttribute('name', filterCategoryParams.PRICE_RANGES);
          if (
            selectedPrices?.length &&
            selectedPrices?.includes(`${lowerRange}-${upperRange}`)
          ) {
            input.checked = true;
            if (
              !document.querySelector(
                `.tag-wrapper[data-value="${`${lowerRange}-${upperRange}`}"]`
              )
            )
              filterTagRenderer(
                filterCategoryParams.PRICE_RANGES,
                `${lowerRange}-${upperRange}`,
                key
              );
          }
          checkbox.querySelector('.advance-filter__checkbox-text').textContent =
            key;
          checkboxWrapper.appendChild(checkbox);
        });
        filterWrapper.appendChild(pricesBlock);
      }
      const productAttrKeys = Object.keys(productAttr);
      filterBlockAttributes[filterCategoryParams.PRODUCT_ATTRS] = [
        ...productAttrKeys,
      ];
      if (showProductAttrKeys && productAttrKeys.length) {
        productAttrKeys.forEach((key) => {
          if (productAttr[key]?.length === 0) {
            return;
          }
          hideFilter = false;
          const productAttrBlock = filterBlock.content.cloneNode(true);
          q$.select(
            '.advance-filter__block, .advance-filter__block-container',
            productAttrBlock
          ).addClass(
            `advance-filter-${
              filterCategoryParams.PRODUCT_ATTRS
            }-${removeWhiteSpace(key)}`
          );
          const selectedAttrValue =
            filtersDataFromParams?.[filterCategoryParams.PRODUCT_ATTRS]?.[key];
          productAttrBlock.querySelector('.block-title').textContent = key;
          const checkboxWrapper = productAttrBlock.querySelector(
            '.filter-checkbox-wrapper'
          );
          productAttr[key].forEach((value, index) => {
            if (value?.key?.length > 0) {
              const checkbox = filterCheckbox.content.cloneNode(true);
              const input = checkbox.querySelector('input');
              input.setAttribute('value', value.key);
              input.setAttribute('name', key);
              checkbox.querySelector(
                '.advance-filter__checkbox-text'
              ).textContent = value?.name || value.key;
              if (
                selectedAttrValue?.length &&
                selectedAttrValue?.includes(value.key)
              ) {
                input.checked = true;
                if (
                  !document.querySelector(
                    `.tag-wrapper[data-value="${serializeStringValues(
                      value.key
                    )}"]`
                  )
                )
                  filterTagRenderer(key, value.key, value?.name || value.key);
              }
              if (index > 4 && !showMoreButtonState[key] && !isShowMoreDisabled)
                checkbox
                  .querySelector('.advance-filter__checkbox-container')
                  .classList.add('hidden');
              checkboxWrapper.appendChild(checkbox);
            }
          });
          if (
            productAttr[key].length > 5 &&
            !showMoreButtonState[key] &&
            !isShowMoreDisabled
          ) {
            showMoreButtonRenderer(
              key,
              productAttr[key].length,
              checkboxWrapper
            );
          }
          filterWrapper.appendChild(productAttrBlock);
        });
      }

      if (typeof window?.advFiltersAdditionalRenderer === 'function') {
        window?.advFiltersAdditionalRenderer(data);
      }

      if (hideFilter) {
        window.q$.select('advanced-filters').addClass('d-none');
      } else {
        window.q$.select('advanced-filters').removeClass('d-none');
      }
      if (hideFilter && typeof noFilterDataHandler !== 'undefined') {
        noFilterDataHandler();
      }

      if (!hideFilter && typeof hasFilterDataHandler !== 'undefined') {
        hasFilterDataHandler();
      }
      const selectedSortingOrder =
        paramString.get(filterCategoryParams.SORT_BY) || defaultSortByValue;
      if (typeof selectedSortingOrder === 'string') {
        if (
          document.querySelector(
            `.advance-filter__radio-container input[value='${selectedSortingOrder}']`
          )
        ) {
          document.querySelector(
            `.advance-filter__radio-container input[value='${selectedSortingOrder}']`
          ).checked = true;
        }
      }
    })
    .then(() => {
      const filterCheckboxInternal = document.querySelectorAll(
        '.advance-filter__checkbox-container input[type="checkbox"]'
      );

      filterCheckboxInternal.forEach((el) => {
        el.addEventListener('change', () => {
          const filterCtas = document.getElementById('filter-ctas');
          if (
            window.getComputedStyle(filterCtas).getPropertyValue('display') ===
            'flex'
          )
            return;
          const changedAttribute = el.getAttribute('name');

          handleFormValueChange(
            changedAttribute,
            el.getAttribute('value'),
            el.nextElementSibling.textContent
          );
          const relatedTag = document.querySelector(
            `.tag-wrapper[data-value="${serializeStringValues(el.value)}"]`
          );
          if (!el.checked && Boolean(relatedTag)) relatedTag.remove();
        });
      });
    })
    .then(successCallback)
    .catch((e) => {
      console.log(e);
      if (typeof enqueueSnackbar !== 'undefined') {
        enqueueSnackbar(
          DukaanData.DUKAAN_LANGUAGE.SOMETHING_WENT_WRONG,
          true,
          'error'
        );
      }
    });
};

window.getNumericFacetForm = (data) =>
  data?.map((rangeString) => {
    const [from, to] = rangeString.split('-');
    return `[${from},${to}]`;
  });

window.getProductCards = (payload, pageNo = 1) => {
  const PAYLOAD = DukaanData.DUKAAN_FILTERS_PAYLOAD || {};
  const storeData = DukaanData.DUKAAN_STORE;
  const { isMobile } = deviceType();
  const getPageSize = () => {
    if (typeof getCustomPageSize !== 'undefined') {
      return getCustomPageSize();
    }
    return isMobile ? 16 : 24;
  };
  const pageSize = getPageSize();
  // if (!sortCategories) {
  //   const shimmers =
  //     typeof shimmerCount !== 'undefined' && typeof shimmerCount === 'number'
  //       ? shimmerCount
  //       : 6;
  //   for (let i = 0; i < shimmers; i++) {
  //     const cardShimmer = document
  //       .getElementById('category-card-shimmer')
  //       .content.cloneNode(true);
  //     productListWrapper.appendChild(cardShimmer);
  //   }
  // }

  if (payload === null) {
    payload = { ...PAYLOAD };
    scrollToView = true;
  } else DukaanData.DUKAAN_FILTERS_PAYLOAD = payload;

  const { page_type: pageType, params } = window.getPageTypeAndParams();
  payload = { ...payload, ...params };

  if (pageType === 'search') {
    document
      .querySelectorAll('.advance-filter__product-query')
      ?.forEach((ele) => {
        ele.textContent = params.query;
      });
  }

  if (pageType === 'all_brands' && payload?.brands?.length > 0) {
    payload[filterCategoryParams.SHOW_PRODUCTS_HAVING_BRAND] = false;
  }

  if (!payload?.[filterCategoryParams.SORT_BY]?.length) {
    delete payload[filterCategoryParams.SORT_BY];
  }

  const finalPayload = {
    ...payload,
    page_size: pageSize,
    offset: (pageNo - 1) * pageSize,
    show_out_of_stock_products:
      window?.customAdvanceFiltersConfig?.showOutOfStockProducts || false,
    push_oos_products_to_bottom:
      window?.customAdvanceFiltersConfig?.pushOosProductsToBottom || false,
    continue_selling_when_oos:
      window?.customAdvanceFiltersConfig?.continueSellingWhenOos || false,
    additional_keys: window?.customAdvanceFiltersConfig?.additionalKeys || [],
    fuzziness_factor: window?.customAdvanceFiltersConfig?.fuzzinessFactor,
  };

  let request;

  if (pageNo === 1) {
    window.ADV_FILTERS_RENDERED_PRODUCTS = 0;
  }

  if (window?.advanceFiltersConfig?.searchTapConfig?.hasSearchtap) {
    const modifiedPayload = getSearchTapPayload(finalPayload);
    request = axios
      .post(
        `https://${window?.advanceFiltersConfig?.searchTapConfig?.publicApiValue}.searchtap.net/v2`,
        modifiedPayload,
        {
          headers: {
            'Content-Type': 'application/json',
            Authorization: `Bearer ${window?.advanceFiltersConfig?.searchTapConfig?.publicBearerToken}`,
          },
        }
      )
      .then(({ data }) => {
        const rawProducts = data?.results || [];
        const finalProductsList = rawProducts.map((p) => ({
          ...p,
          categories: p?.categories?.map((c, i) => ({
            id: +(p?.categories_path_list?.[i] || 0),
            name: c,
          })),
        }));

        return {
          products: finalProductsList,
          total_count: data.totalHits,
        };
      });
  } else {
    request = axios
      .post(
        `${window.DukaanData.DUKAAN_ADVANCED_SEARCH_API_BASE_URL}/api/advanced-search/${storeData.id}/`,
        finalPayload,
        {
          headers: {
            'x-requested-with': window?.DukaanData?.DUKAAN_SESSION_ID,
          },
        }
      )
      .then((res) => res.data.data);
  }

  request
    .then((data) => {
      const { products, total_count: totalCount } = data;
      const filterTitleRender =
        typeof customCounterRender !== 'undefined'
          ? customCounterRender
          : (str) => `(${str})`;

      document
        .querySelectorAll('.advance-filter__product-count')
        ?.forEach((ele) => {
          ele.textContent = filterTitleRender(totalCount);
        });
      const countDivElements = document.querySelectorAll(
        '.category-product-count'
      );
      countDivElements?.forEach((countDiv) => {
        countDiv.textContent = `(${totalCount} ${pluralize(
          totalCount,
          'item'
        )})`;
        countDiv.classList.remove('hidden');
      });
      const paginationWrapper = document.getElementById('pagination-wrapper');
      paginationWrapper.classList.add('hidden');

      let finalProducts = [];
      DukaanData.PRODUCTS_MAP = {
        ...DukaanData.PRODUCTS_MAP,
        ...products?.reduce((map, product) => {
          const serializedSKUs = serializeSKUs(product.skus || []);
          const attributes = getAllProductAttributeValues(serializedSKUs);
          let serializedProduct = {
            ...product,
            skus: serializedSKUs,
            attributes,
          };
          if (typeof window?.getBundleSerializedProduct === 'function') {
            serializedProduct = getBundleSerializedProduct(serializedProduct);
            map[product.uuid] = serializedProduct;
            if (window?.advanceFiltersConfig?.showSkusOnBundlesPage) {
              finalProducts.push(
                ...(serializedProduct?.skus?.map((sku) => ({
                  ...serializedProduct,
                  skus: [sku],
                })) || [])
              );
            } else {
              finalProducts.push(serializedProduct);
            }
          } else {
            map[product.uuid] = serializedProduct;
          }

          return map;
        }, {}),
      };
      if (finalProducts?.length === 0) finalProducts = products;
      renderAdvFiltersProductCards({
        products: window.languageSerializer(finalProducts),
        totalCount,
        pageNo,
        pageSize,
        payload,
      });
      if (typeof getProductCardsAdditionalRenderer === 'function')
        window.getProductCardsAdditionalRenderer(finalProducts);
    })
    .catch((e) => {
      console.log(e);
    });
};

window.renderAdvFiltersProductCards = ({
  products,
  totalCount,
  pageNo,
  pageSize,
  payload,
}) => {
  const { pagination, observerId = 'advance-filters-product-list-observer' } =
    window.advanceFiltersConfig;
  if (!products.length && pageNo === 1) {
    productListWrapper.innerHTML = null;
    const noProductTemplate = document
      .getElementById(
        window.location.pathname.includes('/search')
          ? 'no-search-result-found'
          : 'no-product-found'
      )
      .content.cloneNode(true);
    productListWrapper.appendChild(noProductTemplate);
    return;
  }
  if (pageNo === 1 && !pagination) {
    productListWrapper.innerHTML = null;
  }

  if (pagination) {
    productListWrapper.innerHTML = null;
  }
  advFiltersCategoryProductsRenderer(window.languageSerializer(products));
  if (pagination) {
    createPagination(pageSize, totalCount, pageNo);
  } else {
    const noOfPages = Math.ceil(Number(totalCount / pageSize));
    const currentEventObserver = document.getElementById(observerId);
    if (pageNo < noOfPages) {
      if (currentEventObserver) {
        currentEventObserver?.remove();
      }

      const newObserverElement = document.createElement('div');
      newObserverElement.setAttribute('id', observerId);
      productListWrapper.appendChild(newObserverElement);

      const observerElement = document.getElementById(observerId);

      const observer = new IntersectionObserver(
        (entries) => {
          if (entries[0].isIntersecting) {
            getProductCards(payload, pageNo + 1);
          }
        },
        {
          threshold: 1,
        }
      );
      observer.observe(observerElement);
    } else {
      currentEventObserver?.remove();
    }
  }

  const {
    page_type: pageType,
    params: { query },
  } = window.getPageTypeAndParams();
  window.ADV_FILTERS_RENDERED_PRODUCTS += products.length;

  if (
    pageType === 'category' &&
    typeof window.dknCategoryPageListViewEvent === 'function'
  ) {
    window.dknCategoryPageListViewEvent({
      category: window.DukaanData.DUKAAN_CATEGORY,
      listName: window.DukaanData.DUKAAN_CATEGORY.name,
      listId: window.DukaanData.DUKAAN_CATEGORY.id,
      numberOfItems: window.ADV_FILTERS_RENDERED_PRODUCTS,
      totalNumberOfItems: totalCount,
      pageNumber: pageNo,
    });
  }

  if (
    pageType === 'search' &&
    typeof window.dknSearchPageListViewEvent === 'function'
  ) {
    window.dknSearchPageListViewEvent({
      listName: '',
      listId: '',
      numberOfItems: window.ADV_FILTERS_RENDERED_PRODUCTS,
      pageNumber: pageNo,
      searchTerm: query,
    });
  }
};

window.renderPageNoItem = (index, isSelected) => {
  const pageNoItemTemplate = document.getElementById('page-no-item');
  const pageNoItem = document.importNode(pageNoItemTemplate.content, true);
  pageNoItem.querySelector('.page-number').textContent = index;
  pageNoItem.querySelector('.page-number-tag').addEventListener('click', () => {
    const url = new URL(window.location);
    url.searchParams.set(filterCategoryParams.PAGE_NUMBER, index);
    window.history.replaceState({}, '', url);
    getProductCards(null, index);
    scrollToTop();
  });
  if (isSelected)
    pageNoItem.querySelector('.page-number-tag').classList.add('active');

  return pageNoItem;
};

window.handleLeftArrowClick = (totalProductCount, selectedIndex) => {
  totalProductCount = Number(totalProductCount);
  selectedIndex = Number(selectedIndex);
  if (selectedIndex <= 0) {
    if (leftArrow.classList.contains('active'))
      leftArrow.classList.remove('active');
  } else {
    leftArrow.classList.add('active');
    const url = new URL(window.location);
    url.searchParams.set(filterCategoryParams.PAGE_NUMBER, selectedIndex);
    window.history.replaceState({}, '', url);
    getProductCards(null, selectedIndex);
    scrollToTop();
  }
};

window.handleRightArrowClick = (
  totalProductCount,
  selectedIndex,
  noOfPages
) => {
  totalProductCount = Number(totalProductCount);
  selectedIndex = Number(selectedIndex);
  noOfPages = Number(noOfPages);
  if (selectedIndex > noOfPages) {
    if (rightArrow.classList.contains('active'))
      rightArrow.classList.remove('active');
  } else {
    rightArrow.classList.add('active');
    const url = new URL(window.location);
    url.searchParams.set(filterCategoryParams.PAGE_NUMBER, selectedIndex);
    window.history.replaceState({}, '', url);
    getProductCards(null, selectedIndex);
    scrollToTop();
  }
};

window.createPagination = (pageSize, totalProductCount, selectedIndex) => {
  totalProductCount = Number(totalProductCount);
  if (totalProductCount < pageSize) return;

  const paginationWrapper = document.getElementById('pagination-wrapper');
  paginationWrapper.classList.remove('hidden');

  const pageListWrapper = document.getElementById('page-numbers-list');
  pageListWrapper.innerHTML = '';

  selectedIndex = Number(selectedIndex);
  const noOfPages = Math.ceil(Number(totalProductCount / pageSize));

  const firstIndex = 1;
  let lastIndex = 4;
  let secondIndex = 2;
  let lastSecondIndex = 3;
  let showDotsLeft = false;
  let showDotsRight = false;

  if (noOfPages <= 4) {
    for (let i = 1; i <= noOfPages; i++) {
      pageListWrapper.append(
        renderPageNoItem(i, i === selectedIndex, totalProductCount)
      );
      rightArrow.classList.add('hidden');
      leftArrow.classList.add('hidden');
    }
  } else {
    if (noOfPages > 4) {
      leftArrow.querySelector('.active').classList.remove('hidden');
      leftArrow
        .querySelector('.active')
        .setAttribute(
          'onclick',
          `handleLeftArrowClick(${totalProductCount}, ${selectedIndex - 1})`
        );
      rightArrow.querySelector('.active').classList.remove('hidden');
      rightArrow
        .querySelector('.active')
        .setAttribute(
          'onclick',
          `handleRightArrowClick(${totalProductCount}, ${
            selectedIndex + 1
          } , "${noOfPages}")`
        );
      rightArrow.classList.remove('hidden');
      leftArrow.classList.remove('hidden');

      if (selectedIndex === 1) {
        if (!leftArrow.querySelector('.active').classList.contains('hidden'))
          leftArrow.querySelector('.disabled').classList.remove('hidden');
        leftArrow.querySelector('.active').classList.add('hidden');
      } else {
        leftArrow.querySelector('.active').classList.remove('hidden');
        leftArrow.querySelector('.disabled').classList.add('hidden');
      }

      if (selectedIndex === noOfPages) {
        if (!rightArrow.querySelector('.active').classList.contains('hidden')) {
          rightArrow.querySelector('.disabled').classList.remove('hidden');
          rightArrow.querySelector('.active').classList.add('hidden');
        }
      } else {
        rightArrow.querySelector('.active').classList.remove('hidden');
        rightArrow.querySelector('.disabled').classList.add('hidden');
      }

      lastIndex = noOfPages;
      if (selectedIndex >= 4) {
        if (selectedIndex >= noOfPages - 2) {
          secondIndex = noOfPages - 2;
          lastSecondIndex = noOfPages - 1;
        } else {
          lastSecondIndex = noOfPages - 1;
          secondIndex = selectedIndex;
        }
      }
    }

    if (secondIndex - 1 !== firstIndex) showDotsLeft = true;

    if (
      (secondIndex < lastSecondIndex && secondIndex + 1 !== lastSecondIndex) ||
      (lastSecondIndex === 3 && lastIndex > 4)
    )
      showDotsRight = true;

    pageListWrapper.append(
      renderPageNoItem(
        firstIndex,
        firstIndex === selectedIndex,
        totalProductCount
      )
    );

    const leftThreeDotsTemplate = document.getElementById('three-dots');
    const leftThreeDots = document.importNode(
      leftThreeDotsTemplate.content,
      true
    );

    const rightThreeDotsTemplate = document.getElementById('three-dots');
    const rightThreeDots = document.importNode(
      rightThreeDotsTemplate.content,
      true
    );

    if (showDotsLeft) pageListWrapper.append(leftThreeDots);

    pageListWrapper.append(
      renderPageNoItem(
        secondIndex,
        secondIndex === selectedIndex,
        totalProductCount
      )
    );

    if (showDotsRight && lastSecondIndex > 4)
      pageListWrapper.append(rightThreeDots);
    pageListWrapper.append(
      renderPageNoItem(
        lastSecondIndex,
        lastSecondIndex === selectedIndex,
        totalProductCount
      )
    );

    if (showDotsRight && lastSecondIndex < 4)
      pageListWrapper.append(rightThreeDots);

    pageListWrapper.append(
      renderPageNoItem(
        lastIndex,
        lastIndex === selectedIndex,
        totalProductCount
      )
    );
  }
};

window.formResetHandler = () => {
  // const url = new URL(window.location);
  const paramString = new URLSearchParams(window.location.search);
  const selectSortBy =
    paramString.get(filterCategoryParams.SORT_BY) || defaultSortByValue;
  const query =
    decodeURIComponent(paramString.get(filterCategoryParams.QUERY) || '') || '';

  let payload = {
    [filterCategoryParams.SORT_BY]: selectSortBy,
  };
  if (query) {
    payload = { ...payload, [filterCategoryParams.QUERY]: query };
  }
  paramString.set('filters', JSON.stringify(payload));
  window.history.replaceState(
    {},
    '',
    `${window.location.origin}${
      window.location.pathname
    }?${paramString.toString()}`
  );
  filterForm.reset();
  getFiltersData({
    successCallback: true,
  });
  if (selectedFilterWrapper) selectedFilterWrapper.innerHTML = null;
  getProductCards(payload, 1);
  scrollToTop();
};

window.applyFilterHandler = () => {
  const payload = getPayloadData();
  const paramString = new URLSearchParams(window.location.search);
  payload[filterCategoryParams.PAGE_NUMBER] = 1;
  paramString.set('filters', JSON.stringify(payload));
  window.history.replaceState(
    {},
    '',
    `${window.location.origin}${
      window.location.pathname
    }?${paramString.toString()}`
  );
  getProductCards(payload, 1);
  mobileFilterToggler();
  scrollToTop();
};

window.mobileSortToggler = () =>
  document
    .querySelector('.advance-filter__mobile-sort')
    .classList.toggle('hidden');

window.mobileFilterToggler = () =>
  document.querySelector('advanced-filters').classList.toggle('hidden');

document
  .getElementById('close-filter')
  .addEventListener('click', mobileFilterToggler);
document
  .querySelector('.advance-filter__sort-close-button')
  .addEventListener('click', mobileSortToggler);
document
  .getElementById('submit-filter-cta')
  .addEventListener('click', applyFilterHandler);
document.getElementById('clear-filter-cta').addEventListener('click', () => {
  formResetHandler();
  mobileFilterToggler();
});
const mobileSortForm = document.querySelector('#mobile-sort-filter');
mobileSortForm.addEventListener('submit', (e) => {
  e.preventDefault();
  const formValues = new FormData(mobileSortForm);
  const sortingOrder = formValues.get(filterCategoryParams.SORT_BY);
  const payload = getPayloadData();
  payload[filterCategoryParams.PAGE_NUMBER] = 1;
  payload[filterCategoryParams.SORT_BY] = sortingOrder;
  const url = new URL(window.location);
  url.searchParams.set(filterCategoryParams.PAGE_NUMBER, 1);
  url.searchParams.set(filterCategoryParams.SORT_BY, sortingOrder);
  window.history.replaceState({}, '', url);
  getProductCards(payload, 1);
  mobileSortToggler();
  scrollToTop();
});
mobileSortForm.addEventListener('reset', () => {
  const payload = getPayloadData();
  payload[filterCategoryParams.SORT_BY] = defaultSortByValue;
  payload[filterCategoryParams.PAGE_NUMBER] = 1;
  const url = new URL(window.location);
  url.searchParams.set(filterCategoryParams.PAGE_NUMBER, 1);
  url.searchParams.set(filterCategoryParams.SORT_BY, defaultSortByValue);
  window.history.replaceState({}, '', url);
  getProductCards(payload, 1);
  mobileSortToggler();
  scrollToTop();
});
document
  .querySelector('.advance-filter__bottom-filter-wrapper .filter-btn')
  .addEventListener('click', mobileFilterToggler);
document
  .querySelector('.advance-filter__bottom-filter-wrapper .sort-btn')
  .addEventListener('click', mobileSortToggler);
document
  .getElementById('clear-filters')
  .addEventListener('click', formResetHandler);

window.advanceFiltersConfig = {
  pagination: true,
  observerId: 'advance-filters-product-list-observer',
};

window.getPageTypeAndParams = () => {
  const paramString = new URLSearchParams(window.location.search);
  const query =
    decodeURIComponent(paramString.get(filterCategoryParams.QUERY) || '') || '';
  const allBrands = paramString.get(
    filterCategoryParams.SHOW_PRODUCTS_HAVING_BRAND
  );
  const categoryId = DukaanData?.DUKAAN_CATEGORY?.id || null;
  const brandId = DukaanData?.DUKAAN_BRAND?.id || null;
  let customParams = {};
  if (window?.advanceFiltersConfig?.searchFields) {
    customParams = { search_fields: window.advanceFiltersConfig.searchFields };
  }
  if (typeof getLanguagesAdditionalFields === 'function') {
    customParams = {
      ...customParams,
      additional_search_fields: getLanguagesAdditionalFields() || [],
    };
  }

  if (DukaanData.DUKAAN_PAGE_KEY === 'bundle') {
    const { productIds = [], categoryIds = [] } = getBundleApplicablityData(
      DukaanData.DUKAAN_PRODUCT
    );
    return {
      page_type: '',
      params: { category_ids: categoryIds, product_ids: productIds },
    };
  }

  // for search page
  if (query) {
    return {
      page_type: 'search',
      params: {
        ...customParams,
        query,
      },
    };
  }

  // for /categories/:categoryslug page
  if (categoryId) {
    return {
      page_type: 'category',
      params: { category_ids: [categoryId] },
    };
  }

  // for /brands/:brandslug page
  if (brandId) {
    return { page_type: 'brand', params: { brands: [brandId] } };
  }

  // for /brands page of bighaat
  if (allBrands === 'true') {
    return {
      page_type: 'all_brands',
      params: { show_products_having_brand: true },
    };
  }

  // if all checks fail
  return {
    page_type: '',
    params: {},
  };
};

window.getPayloadData = () => {
  const payload = getPayloadDataFromFilters();
  const paramString = new URLSearchParams(window.location.search);
  const selectSortBy =
    paramString.get(filterCategoryParams.SORT_BY) || defaultSortByValue;
  payload[filterCategoryParams.SORT_BY] = selectSortBy;
  return payload;
};

window.scrollToTop = () => {
  if (typeof customScrollToTop !== 'undefined') {
    window.customScrollToTop();
    return;
  }
  const element = document.querySelector('category-cards');
  element?.scrollIntoView();
  // const y = element.getBoundingClientRect().top;
  // const currentScrollPosition =
  //   document.documentElement.scrollTop || document.body.scrollTop;
  // if (currentScrollPosition > y)
  //   window.scroll({
  //     top: y,
  //     behavior: 'smooth',
  //   });
};
