window.appInitializer = () => {
  window.dknRenderCouponPageSection();
  window.checkCouponSticky();
  window.checkStoreClosedSticky();
  window.GAPage();
};

window.dknRenderCouponPageSection = () => {
  const couponPageSectionLoadPoint = window.q$.select(
    'dkn-coupon-page-section'
  ).elem;
  if (!couponPageSectionLoadPoint) return;

  const couponPageSectionTemplate = window.q$
    .selectById('dkn-coupon-page-section-template')
    .getTemplateContent().elem;

  if (couponPageSectionTemplate) {
    couponPageSectionLoadPoint.innerHTML = '';
    couponPageSectionLoadPoint.appendChild(couponPageSectionTemplate);
  } else {
    const couponPageSectionDefaultTemplate = window.q$
      .selectById('dkn-coupon-page-section-default-template')
      .getTemplateContent().elem;
    couponPageSectionLoadPoint.appendChild(couponPageSectionDefaultTemplate);
  }
  window.fetchCouponProducts();
};

window.fetchCouponProducts = ({ ordering = '', page = 1 } = {}) => {
  fetch(
    `${window.DukaanData.CLIENT_API_ENDPOINT}/api/product/buyer/${DukaanData.DUKAAN_STORE.uuid}/product-list/v2/coupon/${DukaanData.DUKAAN_CATEGORY.uuid}/?ordering=${ordering}&search=&page=${page}&pop_fields=category_data,store_data`,
    {
      headers: {
        'Content-Type': 'application/json',
        'x-requested-with': window?.DukaanData?.DUKAAN_SESSION_ID,
      },
    }
  )
    .then((res) => res.json())
    .then((res) => {
      const products = res?.results;
      const totalProductsCount = res?.count;
      if (!products.length && page === 1) {
        window.q$.selectById('no-coupon-products-found').removeClass('hidden');
        window.q$.select('.dkn-coupon-page-section').addClass('hidden');
        return;
      }

      DukaanData.PRODUCTS_MAP = {
        ...DukaanData.PRODUCTS_MAP,
        ...products.reduce((map, product) => {
          const serializedSKUs = window.serializeSKUs(product.skus || []);
          const attributes =
            window.getAllProductAttributeValues(serializedSKUs);
          // eslint-disable-next-line no-param-reassign
          map[product.uuid] = {
            ...product,
            skus: serializedSKUs,
            attributes,
            coupon_data:
              DukaanData.DUKAAN_CATEGORY.discount_type ===
              window.DISCOUNT_TYPES.BXGY
                ? [{ ...DukaanData.DUKAAN_CATEGORY }]
                : [],
          };
          return map;
        }, {}),
      };
      const mountElem = window.q$.select('dkn-coupon-products-list').elem;
      if (page === 1) {
        mountElem.innerHTML = null;
      }
      window.renderCategoryProducts(
        mountElem,
        res.results,
        window.couponPageProductCardTemplateId ||
          window.productCardTemplateId ||
          'category-product-card-template'
      );
      window.q$
        .selectAll('.dkn-total-coupon-products-count')
        .modifyTextContentAll(`${totalProductsCount} items`);

      if (!res?.next) {
        document.querySelector('#category-products-obeserver')?.remove();
      }
    })
    .catch((err) => {
      console.log(`fetchCouponProducts error : ${err}`);
    });
};
