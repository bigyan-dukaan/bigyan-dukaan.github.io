window.blogPageNumber = 1;

window.fetchAllBlogs = () => {
  const fetchUrl = `${window.DukaanData.CLIENT_API_ENDPOINT}/api/store/buyer/${window.DukaanData.DUKAAN_STORE.link}/blogs/?page=${blogPageNumber}`;

  fetch(fetchUrl, {
    method: 'get',
    headers: {
      'Content-Type': 'application/json',
      'x-requested-with': window?.DukaanData?.DUKAAN_SESSION_ID,
    },
  })
    .then((res) => res.json())
    .then((res) => {
      const blogs = res?.results || [];
      const next = res?.next || null;
      renderBlogsList(blogs, next);
    })
    .catch((e) => console.log(e));
};

window.formatBlogTime = (time) => {
  const months = [
    'Jan',
    'Feb',
    'Mar',
    'Apr',
    'May',
    'Jun',
    'Jul',
    'Aug',
    'Sep',
    'Oct',
    'Nov',
    'Dec',
  ];
  const date = new Date(time);
  const yyyy = date.getFullYear();
  let mm = months[date.getMonth()];
  let dd = date.getDate();

  if (dd < 10) dd = `0${dd}`;
  if (mm < 10) mm = `0${mm}`;

  return `${dd} ${mm} ${yyyy}`;
};

window.renderBlogsList = (blogs, nextUrl) => {
  const blogsListWrapper = document.querySelector('.blogs-card-container');
  const blogCardTemplate = document.getElementById('blog-card');

  const shimmerElems = document.querySelectorAll('.blog-card-shimmer');
  if (shimmerElems) {
    shimmerElems.forEach((elem) => elem.remove());
  }

  blogs?.forEach((blog) => {
    const blogCard = document.importNode(blogCardTemplate.content, true);
    const { title, featured_image, content, link } = blog;
    const imageSource =
      featured_image ||
      'https://api-enterprise.mydukaan.io/static/images/category-def.jpg';
    const blogUrl = `${DukaanData.DUKAAN_BASE_URL}/blog/${link}`;
    blogCard.querySelector('a').setAttribute('href', `${blogUrl}`);
    blogCard
      .querySelector('.blog-image img')
      .setAttribute('src', `${getCdnUrl(imageSource, 500)}`);
    blogCard.querySelector('.heading').textContent = title;
    blogCard.querySelector('.blog-date').textContent = formatBlogTime(
      blog.created_at
    );
    const desc = blogCard.querySelector('.description');
    // desc.innerHTML = content;
    const parsedText =
      new DOMParser().parseFromString(content || '', 'text/html')
        .documentElement.textContent || '';
    desc.innerText = parsedText.slice(0, 1000);
    blogsListWrapper.appendChild(blogCard);
  });

  const currentEventObserver = document.getElementById(
    'blog-list-observer-elem'
  );

  if (nextUrl) {
    blogPageNumber += 1;
    if (currentEventObserver) {
      currentEventObserver?.remove();
    }

    const newObserverElement = document.createElement('div');
    newObserverElement.setAttribute('id', 'blog-list-observer-elem');
    blogsListWrapper.appendChild(newObserverElement);

    const observerElement = document.getElementById('blog-list-observer-elem');

    const observer = new IntersectionObserver(
      (entries) => {
        if (entries[0].isIntersecting) {
          renderShimmersForBlogList(6);
          fetchAllBlogs();
        }
      },
      {
        threshold: 1,
      }
    );
    observer.observe(observerElement);
  } else {
    currentEventObserver?.remove();
  }
};

window.renderShimmersForBlogList = (count = 3) => {
  const shimmerTemplate = document.getElementById('blog-card-shimmer');
  const blogsListWrapper = document.querySelector('.blogs-card-container');

  [...Array(count)].forEach((key) => {
    const shimmer = document.importNode(shimmerTemplate.content, true);
    blogsListWrapper.appendChild(shimmer);
  });
};

window.appInitializer = () => {
  fetchAllBlogs();
};
