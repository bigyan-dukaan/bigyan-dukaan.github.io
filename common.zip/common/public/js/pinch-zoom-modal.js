window.productImageModalElement = document.getElementById('pinch-zoom-modal');
window.pinchTargetElem = null;
window.pinchZoomMainSplide = null;
window.pinchZoomThumbSplide = null;
window.splideImagesHaveLoaded = false;

// desktop image zoom on hover
window.handleImageZoom = (targetElem) => {
  const imageZoom = (e, img) => {
    const rect = targetElem.getBoundingClientRect();
    const x = e.clientX - rect.left; // x position within the element.
    const y = e.clientY - rect.top; // y position within the element.
    if (img) {
      img.style.transformOrigin = `${x}px ${y}px`;
      img.style.transform = 'scale(2)';
    }
  };
  const imageZoomOut = (e, img) => {
    img.style.transformOrigin = `center center`;
    img.style.transform = 'scale(1)';
  };

  if (targetElem && window.innerWidth > 1024) {
    const image = targetElem.querySelector('img');
    targetElem.addEventListener('mousemove', (e) => imageZoom(e, image), false);
    targetElem.addEventListener(
      'mouseleave',
      (e) => imageZoomOut(e, image),
      false
    );
  }
};

// Calculate distance between two fingers
window.distanceBtwPointers = (evt) =>
  Math.hypot(
    evt.touches[0].pageX - evt.touches[1].pageX,
    evt.touches[0].pageY - evt.touches[1].pageY
  );

window.handleProductImageModalTouchStart = (evt, imageElement, start) => {
  if (evt.touches.length === 2) {
    evt.preventDefault(); // Prevent page scroll

    // Calculate where the fingers have started on the X and Y axis
    start.x = (evt.touches[0].pageX + evt.touches[1].pageX) / 2;
    start.y = (evt.touches[0].pageY + evt.touches[1].pageY) / 2;
    start.distance = distanceBtwPointers(evt);
  }
};

window.handleProductImageModalTouchMove = (evt, imageElement, start) => {
  if (evt.touches.length === 2) {
    evt.preventDefault(); // Prevent page scroll

    let scale;
    if (evt.scale) {
      scale = evt.scale; // safari provides evt.scale for scale
    } else {
      const deltaDistance = distanceBtwPointers(evt);
      scale = deltaDistance / start.distance;
    }
    imageElementScale = Math.min(Math.max(1, scale), 4);

    // Calculate how much the fingers have moved on the X and Y axis
    const deltaX =
      ((evt.touches[0].pageX + evt.touches[1].pageX) / 2 - start.x) * 2; // x2 for accelarated movement
    const deltaY =
      ((evt.touches[0].pageY + evt.touches[1].pageY) / 2 - start.y) * 2; // x2 for accelarated movement

    // Transform the image to make it grow and move with fingers
    const transform = `translate3d(${deltaX}px, ${deltaY}px, 0) scale(${imageElementScale})`;
    imageElement.style.transform = transform;
    imageElement.style.WebkitTransform = transform;
  }
};

window.handleProductImageModalTouchEnd = (evt, imageElement) => {
  evt.preventDefault();
  imageElement.style.transform = '';
  imageElement.style.WebkitTransform = '';
};

window.pinchZoom = (imageElement) => {
  const start = {};
  const imageElementScale = 1;

  imageElement.addEventListener(
    'touchstart',
    (evt) => handleProductImageModalTouchStart(evt, imageElement, start),
    { passive: false }
  );
  imageElement.addEventListener(
    'touchmove',
    (evt) =>
      handleProductImageModalTouchMove(
        evt,
        imageElement,
        start,
        imageElementScale
      ),
    {
      passive: false,
    }
  );
  imageElement.addEventListener(
    'touchend',
    (evt) => handleProductImageModalTouchEnd(evt, imageElement),
    {
      passive: false,
    }
  );
};

window.closePinchZoomModal = () => {
  productImageModalElement.classList.add('hidden');
  handleBodyOverflow();
  // unmount the splide
  pinchZoomMainSplide = null;
  pinchZoomThumbSplide = null;

  pinchTargetElem.removeEventListener(
    'touchstart',
    handleProductImageModalTouchStart
  );
  pinchTargetElem.removeEventListener(
    'touchmove',
    handleProductImageModalTouchMove
  );
  pinchTargetElem.removeEventListener(
    'touchend',
    handleProductImageModalTouchEnd
  );
};

window.pinchZoomSlider = (imageIndex) => {
  pinchZoomMainSplide = new Splide('#pinch-zoom-modal-carousel', {
    pagination: false,
    drag: false,
    autoplay: false,
    lazyLoad: 'sequential',
    breakpoints: { 768: { drag: true } },
  });

  pinchZoomThumbSplide = new Splide('#pinch-zoom-thumbnail-carousel', {
    autoplay: false,
    arrows: false,
    pagination: false,
    rewind: true,
    isNavigation: true,
    direction: 'ttb',
    height: 'auto',
    lazyLoad: 'sequential',
    breakpoints: {
      1024: {
        direction: 'ltr',
      },
    },
  });

  pinchZoomMainSplide.sync(pinchZoomThumbSplide);
  pinchZoomMainSplide.mount();
  pinchZoomThumbSplide.mount();

  if (!window.splideImagesHaveLoaded) {
    pinchZoomMainSplide.on('lazyload:loaded', (img, slide) => {
      if (slide.index === imageIndex) {
        window.splideImagesHaveLoaded = true;
        pinchZoomThumbSplide.go(imageIndex);
        q$.select('.pzloaderContainer').addClass('hidden');
      }
    });
  } else {
    pinchZoomThumbSplide.go(imageIndex);
  }

  pinchTargetElem = productImageModalElement.querySelector(
    '.splide__slide.is-active'
  );
  pinchZoom(pinchTargetElem);
  handleImageZoom(pinchTargetElem);

  if (pinchZoomMainSplide !== null) {
    pinchZoomMainSplide.on('moved', () => {
      pinchTargetElem = productImageModalElement.querySelector(
        '.splide__slide.is-active'
      );
      pinchZoom(pinchTargetElem);
      handleImageZoom(pinchTargetElem);
    });
  }
};

window.openPinchZoomModal = (imageIndex) => {
  productImageModalElement.classList.remove('hidden');
  handleBodyOverflow();
  pinchZoomSlider(imageIndex);
};

window.initPinchZoomModal = () => {
  productImageModalElement.addEventListener('click', (evt) => {
    evt.preventDefault();
    closePinchZoomModal();
  });

  const dknMainProductImageElem = document.querySelectorAll(
    '.dkn-main-product-image'
  );
  const dknMainProductThumbnailImageElem = document.querySelectorAll(
    '.dkn-main-product-thumbnail-image'
  );

  const dknPinchZoomModalBtns = document.querySelectorAll(
    '.dkn-pinch-zoom-modal-btn'
  );

  if ([...dknPinchZoomModalBtns].length > 0) {
    [...dknPinchZoomModalBtns].forEach((dknPinchZoomModalBtn, ind) => {
      const imageIndex =
        dknMainProductImageElem[ind].getAttribute('data-index');

      dknPinchZoomModalBtn.setAttribute(
        'onclick',
        `openPinchZoomModal(${imageIndex})`
      );
    });
  } else {
    dknMainProductImageElem.forEach((elem) => {
      const imageIndex = elem.getAttribute('data-index');
      elem.setAttribute('onclick', `openPinchZoomModal(${imageIndex})`);
    });
  }

  dknMainProductThumbnailImageElem.forEach((elem, i) => {
    elem.addEventListener('click', (evt) => {
      const imageIndex = dknMainProductImageElem[i].getAttribute('data-index');

      [...dknMainProductImageElem]
        .filter((ele) => ele.dataset.index == i)
        .forEach((el) => {
          el.setAttribute('onclick', `openPinchZoomModal(${imageIndex})`);
        });
    });
  });
};

window.onload = () => {
  initPinchZoomModal();
};
