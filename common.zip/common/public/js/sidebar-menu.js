window.initSidebarMenuItems = () => {
  initMenuItems();
  initMenu();
  window.mobileMenuItems = document.querySelectorAll('.dropdown-menu');

  mobileMenuItems.forEach((element) => {
    let rotation = 0;
    element.querySelector('.icon').addEventListener('click', function () {
      rotation += 180;
      this.style.transform = `rotate(${rotation}deg)`;
      element.nextElementSibling.classList.toggle('hidden');
      element.classList.toggle('menu-accordion-active');
    });
  });
  // for second level
  const subMenuItems = document.querySelectorAll('.mobile-sub-menu-item');
  subMenuItems.forEach((element) => {
    let rotation = 0;
    element.querySelector('.icon')?.addEventListener('click', function () {
      rotation += 180;
      this.style.transform = `rotate(${rotation}deg)`;
      element.nextElementSibling.classList.toggle('hidden');
      element.classList.toggle('menu-accordion-active');
    });
  });
  // for third level

  const subSubMenuItems = document.querySelectorAll('.sub-sub-child-menu-item');

  subSubMenuItems.forEach((element) => {
    let rotation = 0;
    element.querySelector('.icon')?.addEventListener('click', function () {
      rotation += 180;
      this.style.transform = `rotate(${rotation}deg)`;
      element.nextElementSibling.classList.toggle('hidden');
      element.classList.toggle('menu-accordion-active');
    });
  });
};

window.handleMenuHamburgerClick = () => {
  document
    .querySelector('.menu-dropdown__button')
    .addEventListener('click', () => {
      document.querySelector('.mobile-menu-section').classList.add('active');
    });

  document.getElementById('closeMenu').addEventListener('click', () => {
    document.querySelector('.mobile-menu-section').classList.remove('active');
  });
};
window.initMenuItems = () => {
  const menu = { shop: '/categories', contact: '/contact', about: '/about-us' };
  const header = document.getElementsByClassName('menu-content');
  const mobileHeader = document.getElementsByClassName('mobile-menu-content');
  const btns = [
    ...(header?.[0]?.children || []),
    ...(mobileHeader?.[0]?.children || []),
  ];
  const pathname =
    window.location.pathname.split(`/${DukaanData.DUKAAN_STORE.link}`)?.[1] ||
    '';
  if (btns.length > 1) {
    const active = Object.entries(menu).find((el) => pathname.includes(el[1]));
    [...btns].forEach((el) => {
      el.classList.remove('active');
    });
    if (active) {
      const elements = [...btns].filter((el) => el.id === active[0]);
      elements.forEach((ele) => {
        ele.classList.add('active');
      });
    } else if (pathname === '') {
      [...btns].forEach((ele) => {
        if (ele.id === 'home') {
          ele.classList.add('active');
        }
      });
    }
  }
};
window.initSidebarMenu = () => {
  document.querySelector('.mobile-menu-section').classList.add('active');
};

window.initMenu = () => {
  document.querySelector('.menu-hamburger')?.addEventListener('click', () => {
    document.querySelector('.mobile-menu-section').classList.add('active');
  });

  document.getElementById('closeMenu').addEventListener('click', () => {
    document.querySelector('.mobile-menu-section').classList.remove('active');
  });
  const { isMobile } = deviceType();
  if (isMobile) {
    const vogueSlides = document.getElementsByClassName('slide');
    const g = document.getElementsByClassName('thumbImageWrapper');

    let currentSlide = 0;
    const maxSlide = vogueSlides.length - 1;

    Array.from(vogueSlides).forEach((slide, index) => {
      slide.style.transform = `translateX(${index * 100}%)`;
    });

    for (let i = 0, len = g.length; i < len; i++) {
      // eslint-disable-next-line no-loop-func
      (function (index) {
        g[i].onclick = function () {
          if (index > currentSlide) {
            if (currentSlide !== maxSlide) {
              currentSlide = index;
            }

            Array.from(vogueSlides).forEach((slide, idx) => {
              slide.style.transform = `translateX(${
                100 * (idx - currentSlide)
              }%)`;
            });
          } else {
            if (currentSlide !== 0) {
              currentSlide = index;
            }

            Array.from(vogueSlides).forEach((slide, idx) => {
              slide.style.transform = `translateX(${
                100 * (idx - currentSlide)
              }%)`;
            });
          }
        };
      })(i);
    }
  }
};

window.closeMenuItemDrawer = (e) => {
  if (e.target !== e.currentTarget) return;
  document.querySelector('.mobile-menu-section').classList.remove('active');
};
