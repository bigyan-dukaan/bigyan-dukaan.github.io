window.modal = document.getElementById('loginModal');
window.otpModal = document.getElementById('otpModal');
window.btn = document.getElementById('myBtn');
// eslint-disable-next-line prefer-destructuring
window.span = document.getElementsByClassName('close')[0];
window.MOBILE_FORM = document.getElementById('mobile-form');
window.OTP_FORM = document.getElementById('otp-form');
window.MOBILE_CTA = document.getElementById('mobile-cta');
window.OTP_CTA = document.getElementById('otp-cta');
window.OTP_MODE = 0;
window.FINAL_CALLBACK = () => {};
window.SOCIAL_LOGIN_CONTAINER = document.getElementById(
  'social-login-container'
);
window.OTP_TITLE = document.getElementById('otp-title');
window.MOBILE_VERIFY_BUTTON = document.getElementById('mobile-verify-button');
window.signInValue = null;
window.otpInputHandlers = [];

window.addEventListener('DOMContentLoaded', () => {
  const paramString = new URLSearchParams(window.location.search);
  const login = paramString.get('login');
  if (login && login === 'true') {
    initDukaanAuth(
      () => {},
      () => {
        const userDataLocalStorageKey = `v3-${DukaanData.DUKAAN_STORE.link}-user-data`;
        localStorage.removeItem(userDataLocalStorageKey);
        window.location.reload();
      }
    );
  }
});

window.isInternational = () => DukaanData.DUKAAN_STORE.country !== 77;
window.ctrlDown = false;
window.spaceDown = false;
window.spaceKey = 16;
window.ctrlKey = 17;
window.cmdKey = 91;
window.cmdKeyFFox = 224;
const OTP_OPTIONS = {
  SMS: 0,
  CALL: 1,
  WHATSAPP: 2,
};

window.triggerAuthEvent = () => {
  const { additional_meta: additionalMeta = {} } =
    DukaanData?.DUKAAN_STORE || {};
  const { ga4_tag_meta: ga4Meta, ga4_360_event_map: ga4EventMap = {} } =
    additionalMeta || {};
  const { login_signup: loginSignupEventConversionId } = ga4EventMap;

  if (ga4Meta && loginSignupEventConversionId) {
    window.gtag('event', 'conversion', {
      allow_custom_scripts: true,
      send_to: loginSignupEventConversionId,
    });
  }
};

window.initDukaanAuth = (cb, afterLogin = () => {}) => {
  const localAccessToken = localStorage.getItem('al_to');
  if (localAccessToken) {
    cb();
  } else {
    FINAL_CALLBACK = () => {
      afterLogin();
      cb(true);
      window.triggerAuthEvent();
    };
    openModal();
  }
};

window.validatePhoneNumber = () => {
  const { isMobile } = deviceType();
  const mobileInputId = isMobile ? 'm-mobile-input' : 'd-mobile-input';
  const phoneNumberInput = document.getElementById(mobileInputId);
  if (phoneNumberInput) {
    phoneNumberInput.addEventListener('keypress', (e) => {
      if (e.keyCode < 48 || e.keyCode > 57) e.preventDefault();
    });
  }
};

window.handleEnterSignIn = (e) => {
  if (e.key === 'Enter') {
    handleSubmitForm(e);
  }
};

window.openModal = () => {
  modal.classList.remove('hidden');
  signInValue = null;
  const { additional_meta: additionalMeta = {} } = DukaanData.DUKAAN_STORE;
  const { hasSocialLogin } = additionalMeta;

  const { isMobile } = deviceType();
  const emailInputId = isMobile ? 'm-email-input' : 'd-email-input';
  const mobileInputId = isMobile ? 'm-mobile-input' : 'd-mobile-input';
  validatePhoneNumber();
  resetAuthInputFields();

  if (hasSocialLogin || isInternational()) {
    try {
      firebase.initializeApp(FIREBASE_CONFIG);
    } catch {
      console.log('firebase-error');
    }
  }

  if (isInternational()) {
    document.getElementById(emailInputId).value = '';
    document.getElementById(emailInputId).focus();
    document
      .getElementById(emailInputId)
      .addEventListener('keydown', handleEnterSignIn, false);
  } else {
    document.getElementById(mobileInputId).value = '';
    document.getElementById(mobileInputId).focus();
    document
      .getElementById(mobileInputId)
      .addEventListener('keydown', handleEnterSignIn, false);
  }
};

window.closeModal = () => {
  modal.classList.add('hidden');
  resetAuthInputFields();
  hideError();
};

window.openOTPModal = () => {
  renderCountdown();
  otpModal.classList.remove('hidden');
  OTPInput();
  addEventListnerToOTP();
  showOTPForm();
  closeModal();
};

window.closeOTPModal = () => {
  otpModal.classList.add('hidden');
  resetAuthInputFields();
  inputOTPRemoveListeners();
  hideError();
};

window.onclick = function (event) {
  if (event.target == modal) {
    closeModal();
  }
};

window.validateEmail = (value) => {
  if (!value || (Boolean(value) && value.length === 0)) {
    showError(DukaanData.DUKAAN_LANGUAGE.EMAIL_IS_REQUIRED);
    return DukaanData.DUKAAN_LANGUAGE.EMAIL_IS_REQUIRED;
  }
  if (/^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/.test(value)) hideError();
  else {
    showError(DukaanData.DUKAAN_LANGUAGE.PLEASE_ENTER_A_VALID_EMAIL_ADDRESS);
    return DukaanData.DUKAAN_LANGUAGE.PLEASE_ENTER_A_VALID_EMAIL_ADDRESS;
  }
};

window.validateNumber = (event, maxlength, mobile) => {
  const value = event?.target?.value || mobile;
  let inputValue = '';
  const inputBox = document.querySelector('.input-box');

  if (!value || (Boolean(value) && value.length === 0)) {
    showError(DukaanData.DUKAAN_LANGUAGE.MOBILE_NUMBER_IS_REQUIRED);
    inputBox.classList.add('input-error');
    return DukaanData.DUKAAN_LANGUAGE.MOBILE_NUMBER_IS_REQUIRED;
  }
  inputBox.classList.remove('input-error');
  inputValue = value.replace(/[^0-9]/g, '').replace(/(\..*)\./g, '$1');
  if (event?.target) event.target.value = inputValue;

  if (!!inputValue && inputValue.length != maxlength) {
    inputBox.classList.add('input-error');
    showError(DukaanData.DUKAAN_LANGUAGE.PLEASE_ENTER_A_VALID_MOBILE_NUMBER);
    return DukaanData.DUKAAN_LANGUAGE.PLEASE_ENTER_A_VALID_MOBILE_NUMBER;
  }
  inputBox.classList.remove('input-error');
  hideError();
};

window.inputOTPKeyDownListeners = (inputs, i, event) => {
  const { which, keyCode, key } = event;
  const keyEvent = which || keyCode;
  if (keyEvent == ctrlKey || keyEvent == cmdKey || keyEvent == cmdKeyFFox) {
    ctrlDown = true;
    return;
  }
  if (keyEvent == spaceKey) {
    spaceDown = true;
    return;
  }
  if (key === 'Backspace') {
    if (inputs[i].value !== '') inputs[i].value = '';
    else if (i !== 0) inputs[i - 1].focus();
  } else {
    if (i === inputs.length - 1 && inputs[i].value !== '') {
      return true;
    }
    if (key === 'ArrowLeft' && i !== 0) {
      inputs[i - 1].focus();
    } else if (key === 'ArrowRight' && i !== inputs.length - 1) {
      inputs[i + 1].focus();
    } else if (
      ((keyEvent > 47 && keyEvent < 58) || (keyEvent > 95 && keyEvent < 106)) &&
      spaceDown === false
    ) {
      inputs[i].value = key;
      if (i !== inputs.length - 1) inputs[i + 1].focus();
      event.preventDefault();
    } else if (
      (keyEvent > 64 && keyEvent < 91 && ctrlDown === false) ||
      spaceDown
    ) {
      event.preventDefault();
    }
  }
};

window.inputOTPKeyUpListeners = (event) => {
  const { which, keyCode } = event;
  const keyEvent = which || keyCode;
  if (keyEvent == ctrlKey || keyEvent == cmdKey || keyEvent == cmdKeyFFox) {
    ctrlDown = false;
  }
  if (keyEvent == spaceKey) {
    spaceDown = false;
  }
};

window.OTPInput = () => {
  const inputs = document.querySelectorAll('input[name="otp-value"]');

  for (let i = 0; i < inputs.length; i++) {
    const wrappedFn = inputOTPKeyDownListeners.bind(this, inputs, i);
    otpInputHandlers.push(wrappedFn);
    inputs[i].addEventListener('keydown', wrappedFn, false);
    inputs[i].addEventListener('keyup', inputOTPKeyUpListeners, false);
  }

  inputs[0].focus();
};
window.inputOTPRemoveListeners = () => {
  const inputs = document.querySelectorAll('input[name="otp-value"]');
  for (let i = 0; i < inputs.length; i++) {
    inputs[i].removeEventListener('keydown', otpInputHandlers[i], false);
    inputs[i].removeEventListener('keyup', inputOTPKeyUpListeners, false);
  }
  otpInputHandlers = [];
};

window.showElement = (elem) => {
  if (Boolean(elem) && elem.classList.contains('hidden')) {
    elem.classList.remove('hidden');
  }
};

window.hideElement = (elem) => {
  if (Boolean(elem) && !elem.classList.contains('hidden')) {
    elem.classList.add('hidden');
  }
};

window.showError = (error) => {
  const errorElemList = document.querySelectorAll('.error-message');
  errorElemList.forEach((errorElem) => {
    showElement(errorElem);
    errorElem.innerHTML = '';
    errorElem.classList.add('shake');
    setTimeout(() => errorElem.classList.remove('shake'), 800);
    errorElem.innerHTML = error;
  });
};

window.hideError = () => {
  const errorElemList = document.querySelectorAll('.error-message');
  errorElemList.forEach((errorElem) => {
    if (errorElem) {
      hideElement(errorElem);
      errorElem.innerHTML = '';
    }
  });
};

window.showOTPForm = () => {
  const { isMobile } = deviceType();
  const emailInputId = isMobile ? 'm-email-input' : 'd-email-input';
  const mobileInputId = isMobile ? 'm-mobile-input' : 'd-mobile-input';

  if (isInternational()) {
    otpModal.querySelector('.dukaan-auth-modal-title').textContent =
      DukaanData.DUKAAN_LANGUAGE.VERIFY_YOUR_EMAIL;
    // ('Verify your email');
    OTP_TITLE.innerHTML =
      DukaanData.DUKAAN_LANGUAGE.VERIFICATION_CODE_SENT_TO__VALUE.injectText({
        value: `<span>${
          document.getElementById(emailInputId)?.value || signInValue
        }</span>`,
      });
    // `Verification code sent to <span>${
    //   document.getElementById(emailInputId)?.value || signInValue
    // }</span>`;
  } else {
    otpModal.querySelector('.dukaan-auth-modal-title').textContent =
      DukaanData.DUKAAN_LANGUAGE.OTP_VERIFICATION;
    // ('OTP Verification');
    OTP_TITLE.innerHTML =
      DukaanData.DUKAAN_LANGUAGE.ENTER_6DIGIT_OTP_SENT_TO__MOBILE.injectText({
        mobile: `<span>+91${
          document.getElementById(mobileInputId)?.value || signInValue
        }</span>`,
      });
    // `Enter 6-digit OTP sent to <span>+91${
    //   document.getElementById(mobileInputId)?.value || signInValue
    // }</span>`;
  }
};

window.OTP_TIMEOUT = 30000;
window.OTP_OPTIONS = {
  SMS: 0,
  CALL: 1,
  WHATSAPP: 2,
};

window.timerDate = Date.now() + OTP_TIMEOUT;

window.setTimerDate = (date) => (timerDate = date);

window.onOTPSent = () => {
  setTimerDate(Date.now() + OTP_TIMEOUT);
  enqueueSnackbar(
    DukaanData.DUKAAN_LANGUAGE.OTP_SENT_SUCCESSFULLY,
    true,
    'success'
  );
};

window.onResendOtpLink = (mode) => {
  sendOTP(mode, onOTPSent);
  closeResendOptionModal();
};

window.getTwoDigit = (timer) => (timer <= 9 ? `0${timer}` : timer);

window.renderCountdown = () => {
  const second = 1000;
  const minute = second * 60;
  const hour = minute * 60;
  setTimerDate(Date.now() + OTP_TIMEOUT);
  let distance = timerDate - Date.now();
  document.getElementById('otp-countdown-timer').classList.remove('hidden');
  document.getElementById('otp-cta').classList.add('hidden');
  document.getElementById('timer-mins-text').innerText = getTwoDigit(
    Math.floor((distance % hour) / minute)
  );
  document.getElementById('timer-secs-text').innerText = getTwoDigit(
    Math.floor((distance % minute) / second)
  );
  const countdownInterval = setInterval(() => {
    distance = timerDate - Date.now();
    document.getElementById('otp-countdown-timer').classList.remove('hidden');
    document.getElementById('otp-cta').classList.add('hidden');
    document.getElementById('timer-mins-text').innerText = getTwoDigit(
      Math.floor((distance % hour) / minute)
    );
    document.getElementById('timer-secs-text').innerText = getTwoDigit(
      Math.floor((distance % minute) / second)
    );
    if (distance < 0) {
      clearInterval(countdownInterval);
      document.getElementById('otp-countdown-timer').classList.add('hidden');
      document.getElementById('otp-cta').classList.remove('hidden');
    }
  }, 1000);
};

window.handleSubmitForm = (event) => {
  event.preventDefault();
  sendOTP(0);
};

const rs = (str = '') => str.split('').reverse().join('');

const getHashcode = () =>
  `${rs(DukaanData.DUKAAN_STORE.theme_session_uuid)}${rs(
    DukaanData.DUKAAN_STORE.store_version
  )}`;

window.sendOTPRequest = (otpData) => {
  const { mode, email, mobile, successCallback } = otpData;
  const storeId = DukaanData.DUKAAN_STORE.id;
  const hashcode = getHashcode();
  const qp = isInternational()
    ? `email=${email}&store_id=${storeId}&otp=&referred_by=`
    : `hashcode=${hashcode}&mobile=${mobile}&country_code=%2B91&mode=${mode}&store_id=${storeId}&otp=&referred_by=`;

  const baseUrl = isInternational()
    ? `${window.DukaanData.CLIENT_API_ENDPOINT}/api/account/buyer/email-otp-sign-in/`
    : `${window.DukaanData.CLIENT_API_ENDPOINT}/api/account/buyer/sign-in/`;
  const url = `${baseUrl}?${qp}`;
  const xhr = new XMLHttpRequest();
  document
    .querySelector('#loginModalForm .bounceLoader')
    ?.classList?.remove('hidden');
  xhr.open('GET', url);
  xhr.setRequestHeader(
    'x-requested-with',
    window?.DukaanData?.DUKAAN_SESSION_ID
  );
  xhr.onreadystatechange = function () {
    if (xhr.readyState === 4) {
      if (xhr.status == 200 || xhr.status == 201) {
        if (OTP_MODE === OTP_OPTIONS.WHATSAPP) {
          TrackDruidEvent('USER_WHATSAPP_OTP_REQUESTED', EVENT_TYPES.CLICK);
        } else {
          TrackDruidEvent('USER_OTP_REQUESTED', EVENT_TYPES.CLICK);
        }
        openOTPModal();
        if (typeof successCallback !== 'undefined') {
          successCallback();
          closeResendOptionModal();
        }
      } else if (xhr.status == 400) {
        const error = JSON.parse(xhr.responseText);
        if (error?.data?.error) {
          showError(error?.data?.error);
        } else {
          showError(DukaanData.DUKAAN_LANGUAGE.SOMETHING_WENT_WRONG);
        }
      } else {
        showError(
          DukaanData.DUKAAN_LANGUAGE.TOO_MANY_ATTEMPTS_TRY_AFTER_SOMETIME
        );
      }
    }
    document
      .querySelector('#loginModalForm .bounceLoader')
      ?.classList?.add('hidden');
  };
  xhr.send();
};

window.sendOTP = (mode, successCallback) => {
  let mobile = '';
  let email = '';
  let errorMsg = '';
  const { isMobile } = deviceType();
  const emailInputId = isMobile ? 'm-email-input' : 'd-email-input';
  const mobileInputId = isMobile ? 'm-mobile-input' : 'd-mobile-input';
  const mobileInput = document.getElementById(mobileInputId);
  const emailInput = document.getElementById(emailInputId);

  if (mobileInput) {
    mobile = mobileInput.value == signInValue ? signInValue : mobileInput.value;
    signInValue = mobile;
    errorMsg = validateNumber(null, 10, mobile);
    mobileInput.setAttribute('onkeyup', 'validateNumber(event, 10)');
    if (errorMsg) {
      showError(errorMsg);
      return;
    }
  }

  if (emailInput) {
    email = emailInput.value == signInValue ? signInValue : emailInput.value;
    signInValue = email;
    errorMsg = validateEmail(email);
    emailInput.setAttribute('onkeyup', `validateEmail(event.target.value)`);
    if (errorMsg) {
      showError(errorMsg);
      return;
    }
  }
  hideError();
  sendOTPRequest({
    mode,
    mobile,
    email,
    successCallback,
  });
};

window.handleOTPForm = () => {
  const otpFormData = new FormData(document.querySelector('form#otp-values'));
  const otpValues = otpFormData.getAll('otp-value');
  if (!otpValues.includes('')) submitOTP();
};

window.validateOTP = (event, otp) => {
  const otpValue = event?.target?.value || otp;
  if (!otpValue || (Boolean(otpValue) && otpValue.length === 0)) {
    showError(DukaanData.DUKAAN_LANGUAGE.OTP_IS_REQUIRED);
    return DukaanData.DUKAAN_LANGUAGE.OTP_IS_REQUIRED;
  }
  if (otpValue.length !== 6) {
    showError(DukaanData.DUKAAN_LANGUAGE.OTP_SHOULD_HAVE_SIX_DIGITS);
    return DukaanData.DUKAAN_LANGUAGE.OTP_SHOULD_HAVE_SIX_DIGITS;
  }
  hideError();
};

window.dispatchLoginEvent = (data) => {
  const DKN_STORE_LOGIN_EVENT_NAME = 'dkn_store_login';
  const DKN_STORE_USER_REGISTER_EVENT_NAME = 'dkn_store_user_register';
  const overrides = {
    _login_data: data,
  };

  const payload = window.dknGenerateEventPayload(overrides);
  const event = new Event(
    data?.is_new_buyer
      ? DKN_STORE_USER_REGISTER_EVENT_NAME
      : DKN_STORE_LOGIN_EVENT_NAME
  );
  event.payload = payload;
  document.dispatchEvent(event);
};

window.submitOTP = () => {
  // const buyerSignature = "y7pjphc9gc-ddTRud";
  const buyerSignature = localStorage.__b_sig__;
  const inputs = document.querySelectorAll('input[name="otp-value"]');
  const otpValue = document.getElementById('m-otp-input').value;
  let otp = '';
  if (!otpValue) {
    for (let i = 0; i < inputs.length; i++) {
      otp += inputs[i].value;
    }
  } else {
    document
      .getElementById('m-otp-input')
      .setAttribute('onkeyup', 'validateOTP(event)');
    otp = otpValue;
  }

  const errorMsg = validateOTP(null, otp);
  if (Boolean(errorMsg) && errorMsg.length > 0) {
    showError(errorMsg);
    return;
  }
  hideError();

  const { isMobile } = deviceType();
  const emailInputId = isMobile ? 'm-email-input' : 'd-email-input';
  const mobileInputId = isMobile ? 'm-mobile-input' : 'd-mobile-input';
  const mobile = document.getElementById(mobileInputId)?.value || signInValue;
  const email = document.getElementById(emailInputId)?.value || signInValue;
  const url = isInternational()
    ? `${window.DukaanData.CLIENT_API_ENDPOINT}/api/account/buyer/email-otp-sign-in/`
    : `${window.DukaanData.CLIENT_API_ENDPOINT}/api/account/buyer/sign-in/`;
  const xhr = new XMLHttpRequest();
  document
    .querySelector('#otp-values .bounceLoader')
    .classList.remove('hidden');
  xhr.open('POST', url);
  xhr.setRequestHeader('content-type', 'application/json');
  xhr.setRequestHeader(
    'x-requested-with',
    window?.DukaanData?.DUKAAN_SESSION_ID
  );
  xhr.onreadystatechange = function () {
    if (xhr.readyState === 4) {
      if (xhr.status == 200 || xhr.status == 201) {
        const res = JSON.parse(xhr.responseText);
        localStorage.setItem('al_to', res.data.access_token);
        const loginData = res?.data || {};
        dispatchLoginEvent({
          user_id: loginData?.user_id,
          is_new_buyer: loginData?.is_new_buyer,
          mobile: mobile || undefined,
          email: email || undefined,
        });
        if (OTP_MODE === OTP_OPTIONS.WHATSAPP) {
          TrackDruidEvent(
            'USER_WHATSAPP_OTP_SUBMITTED_SUCCESSFULLY',
            EVENT_TYPES.CLICK
          );
        } else {
          TrackDruidEvent('USER_OTP_SUBMITTED_SUCCESSFULLY', EVENT_TYPES.CLICK);
        }
        if (typeof window?.customerNotesInit === 'function') {
          customerNotesInit();
        }
        closeModal();
        closeOTPModal();
        FINAL_CALLBACK();
      } else if (xhr.status == 400) {
        const error = JSON.parse(xhr.responseText);
        if (error?.data?.error) {
          showError(error?.data?.error);
        } else {
          showError(DukaanData.DUKAAN_LANGUAGE.SOMETHING_WENT_WRONG);
        }
      } else {
        showError(DukaanData.DUKAAN_LANGUAGE.SOMETHING_WENT_WRONG);
      }
    }
    document.querySelector('#otp-values .bounceLoader').classList.add('hidden');
  };
  const data = isInternational()
    ? `{"email":"${email}","store_id":"${DukaanData.DUKAAN_STORE.id}","otp":"${otp}","signature":${buyerSignature}}`
    : `{"mobile":"${mobile}","store_id":"${DukaanData.DUKAAN_STORE.id}","country_code":"+91","otp":"${otp}","signature":${buyerSignature},"mode":${OTP_MODE}}`;
  xhr.send(data);
};

window.openResendOptionModal = () => {
  const resendOTPModal = document.getElementById('resend-options-modal');
  resendOTPModal.classList.remove('hidden');
};

window.closeResendOptionModal = () => {
  const resendOTPModal = document.getElementById('resend-options-modal');
  resendOTPModal.classList.add('hidden');
  resetAuthInputFields();
};

window.resetAuthInputFields = () => {
  const inputs = document.querySelectorAll('#otpModal input');
  inputs.forEach((inp) => (inp.value = ''));
  hideError();
};

// OAuth

window.GOOGLE_API_KEY = 'AIzaSyCc5pw8so3aXFhTrW3IGS5eplejXu9K1ak';

window.socialGoogleLogin = (params) => {
  axios
    .post(
      `${window.DukaanData.CLIENT_API_ENDPOINT}/api/account/buyer/firebase/google-sign-in-callback/`,
      params,
      {
        headers: {
          'x-requested-with': window?.DukaanData?.DUKAAN_SESSION_ID,
        },
      }
    )
    .then((res) => {
      const { data } = res;
      localStorage.setItem(
        'al_to',
        data?.access_token || data?.data?.access_token || ''
      );
      closeModal();
      FINAL_CALLBACK();
    })
    .catch((e) => console.log(e));
};

window.socialFacebookLogin = (params) => {
  axios
    .post(
      `${window.DukaanData.CLIENT_API_ENDPOINT}/api/account/buyer/firebase/facebook-sign-in-callback/`,
      params,
      {
        headers: {
          'x-requested-with': window?.DukaanData?.DUKAAN_SESSION_ID,
        },
      }
    )
    .then((res) => {
      const { data } = res;
      localStorage.setItem(
        'al_to',
        data?.access_token || data?.data?.access_token || ''
      );
      closeModal();
      FINAL_CALLBACK();
    })
    .catch((e) => console.log(e));
};

window.AUTH_CALLBACK_URL_MAP = {
  google: socialGoogleLogin,
  facebook: socialFacebookLogin,
};

window.FIREBASE_CONFIG = {
  apiKey: GOOGLE_API_KEY,
  authDomain: 'dukaan-seller-web.firebaseapp.com',
  projectId: 'dukaan-seller-web',
  storageBucket: 'dukaan-seller-web.appspot.com',
  messagingSenderId: '193655940279',
  appId: '1:193655940279:web:728f14f149c3f938479932',
  measurementId: 'G-EQXVJVLYWW',
};

window.handleAuthSuccess = (
  result,
  platform,
  successCallback,
  errorCallback
) => {
  const { user = {} } = result;
  let token;
  if (platform === 'google') {
    token = result?.credential?.idToken || result?.credential;
  } else {
    token = result?.credential?.accessToken;
  }
  const profile = user;
  const [profileData] = profile.providerData;

  if (
    platform === 'facebook' &&
    (!profileData?.email || profileData.email === '')
  ) {
    enqueueSnackbar(
      `${DukaanData.DUKAAN_LANGUAGE.CAN_NOT_LOGIN_WITH__FACEBOOK_ACCOUNT_WITHOUT_EMAIL_ADDRESS}.`.injectText(
        { facebook: 'facebook ' }
      ),
      true,
      'error'
    );
    // errorCallback();
  }

  const params = {
    token,
    mode: 'web',
  };

  AUTH_CALLBACK_URL_MAP[platform](params);
};

const oauth = (platform, successCallback, errorCallback) => {
  const auth = firebase.auth();
  auth.useDeviceLanguage();

  const AUTH_PROVIDER = {
    google: firebase.auth.GoogleAuthProvider,
    facebook: firebase.auth.FacebookAuthProvider,
  };

  const provider = new AUTH_PROVIDER[platform]();
  if (platform === 'facebook') {
    provider.addScope('email');
  } else {
    provider.addScope('https://www.googleapis.com/auth/userinfo.email');
  }
  auth
    .signInWithPopup(provider)
    .then((result) => {
      handleAuthSuccess(result, platform, successCallback, errorCallback);
    })
    .catch((e) => {
      console.log(e);
      // errorCallback();
    });
};

window.handleOAuthClick = (platform) => {
  // setSubmittingOn();

  oauth(
    platform
    // (data) => {
    //   setUser(data);
    //   setSubmittingOff();
    // },
    // () => {
    //   setSubmittingOff();
    // }
  );
};

window.handleClipboardCopy = (e) => {
  if (e.target.name === 'otp-value') {
    let data = e.clipboardData.getData('Text');
    data = data.split('');
    const elems = document.querySelectorAll("input[name='otp-value']");
    [].forEach.call(elems, (node, index) => {
      data[index] ||= '';
      node.value = data[index];
    });
    elems[elems.length - 1].focus();
  }
};

window.addEventListnerToOTP = () => (document.onpaste = handleClipboardCopy);
