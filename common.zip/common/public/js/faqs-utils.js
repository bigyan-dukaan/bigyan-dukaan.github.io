window.initProductFAQs = () => {
  window.fetchProductFAQs({
    successCallback: window.renderProductFaqSection,
    errorCallback: window.renderProductFaqSection,
  });
};

window.initCategoryFAQs = () => {
  window.fetchCategoryFAQs({
    successCallback: window.renderProductFaqSection,
    errorCallback: window.renderProductFaqSection,
  });
};

window.renderProductFaqSection = ({ faqs }) => {
  const mountElems = document.querySelectorAll('.dkn-product-faqs');
  if (!mountElems) return;

  mountElems.forEach((mountElem) => {
    if (!faqs.length) {
      mountElem?.remove();
      return;
    }
    mountElem.classList.remove('hidden');
    window.renderProductFaqList({ faqs });
  });
};

window.renderProductFaqList = ({ faqs }) => {
  const mountElems = document.querySelectorAll('.dkn-faq-list');
  if (!mountElems) return;

  mountElems.forEach((mountElem, ind) => {
    mountElem.innerHTML = '';
    if (!faqs.length) return;

    faqs.forEach((faq, index) => {
      const { question, answer } = faq;
      const faqItemTemplate = window.q$
        .selectById('dkn-faq-item-template')
        .getTemplateContent().elem;

      window.q$
        .selectAll('[data-faq-index]', faqItemTemplate)
        .addClassAll(`dkn-faq-item-parent-${ind}-child-${index}`);

      window.q$
        .selectAll('.dkn-faq-heading-wrapper', faqItemTemplate)
        .setAttributeAll(
          'onclick',
          `handleToggleContent(".dkn-faq-item-parent-${ind}-child-${index}")`
        );

      window.q$
        .selectAll('.dkn-faq-heading-text', faqItemTemplate)
        .modifyTextContentAll(question);

      window.q$
        .selectAll('.dkn-faq-content', faqItemTemplate)
        .modifyTextContentAll(answer);

      mountElem.appendChild(faqItemTemplate);
    });
  });
};

window.fetchProductFAQs = ({ successCallback, errorCallback }) => {
  const headers = {};
  if (localStorage && localStorage.al_to)
    headers.Authorization = `Bearer ${localStorage.al_to}`;
  headers['Content-Type'] = 'application/json';
  headers['x-requested-with'] = window?.DukaanData?.DUKAAN_SESSION_ID;

  fetch(
    `${window.DukaanData.CLIENT_API_ENDPOINT}/api/store/buyer/faq-plugin/${DukaanData.DUKAAN_STORE.link}/get-faqs/product/${DukaanData.DUKAAN_PRODUCT.id}/`,
    {
      method: 'GET',
      // headers,
    }
  )
    .then((res) => res.json())
    .then((res) => {
      const faqs = res?.data?.faqs_list;
      if (!faqs?.length) {
        errorCallback({ faqs: [] });
        return;
      }
      successCallback({ faqs });
    })
    .catch((err) => {
      // console.log(`fetchProductFAQs error : ${err.message}`);
      errorCallback({ faqs: [] });
    });
};

window.fetchCategoryFAQs = ({ successCallback, errorCallback }) => {
  const headers = {};
  if (localStorage && localStorage.al_to)
    headers.Authorization = `Bearer ${localStorage.al_to}`;
  headers['Content-Type'] = 'application/json';
  headers['x-requested-with'] = window?.DukaanData?.DUKAAN_SESSION_ID;

  fetch(
    `${window.DukaanData.CLIENT_API_ENDPOINT}/api/store/buyer/faq-plugin/${DukaanData.DUKAAN_STORE.link}/get-faqs/product-category/${DukaanData.DUKAAN_CATEGORY.id}/`,
    {
      method: 'GET',
      // headers,
    }
  )
    .then((res) => res.json())
    .then((res) => {
      const faqs = res?.data?.faqs_list;
      if (!faqs?.length) {
        errorCallback({ faqs: [] });
        return;
      }
      successCallback({ faqs });
    })
    .catch((err) => {
      // console.log(`fetchProductFAQs error : ${err.message}`);
      errorCallback({ faqs: [] });
    });
};
