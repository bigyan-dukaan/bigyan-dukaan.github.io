window.toggleSortbyDropdown = () => {
  document.getElementById('wow-custom-dropdown').classList.toggle('d-none');
  document.body.style.overflow =
    document.body.style.overflow === 'hidden' ? 'auto' : 'hidden';
  document
    .querySelector('.sort-by-chevron-opened-state-icon')
    .classList.toggle('open-arrow-state');
};

window.closeSortbyDropdown = () => {
  q$.selectById('wow-custom-dropdown').addClass('d-none');
  document.body.style.overflow =
    document.body.style.overflow === 'hidden' ? 'auto' : 'hidden';
  q$.select('.sort-by-chevron-opened-state-icon').elem?.classList?.toggle(
    'open-arrow-state'
  );
};

// close dropdown on clicking outside..
document.addEventListener('click', (event) => {
  const specifiedElement = document.querySelector('.custom-dropdown');
  const isClickInside = specifiedElement?.contains(event?.target);
  if (
    !isClickInside &&
    document.body.style.overflow === 'hidden' &&
    !document.querySelector('.sort-by-dropdown.hidden')
  )
    closeSortbyDropdown();
});

window.getSortTypeText = (ordering) => {
  switch (ordering) {
    case 'bestsellers':
      return 'Bestsellers';
    case 'better_discount':
      // return 'Discount';
      return DukaanData.DUKAAN_LANGUAGE.DISCOUNT;
    case 'price_low_to_high':
      // return 'Price - low to high';
      return DukaanData.DUKAAN_LANGUAGE.PRICE_LOW_TO_HIGH;
    case 'price_high_to_low':
      // return 'Price - high to low';
      return DukaanData.DUKAAN_LANGUAGE.PRICE_HIGH_TO_LOW;
    default:
      return 'Bestsellers';
  }
};

window.sortDropDownHandler = (sortBy, evt) => {
  window.q$
    .selectAll('.dkn-dropdown-sort-radio-button')
    .removeClassAll('selected');

  const selectedOption = window.q$.select(
    `.dkn-dropdown-option[value="${sortBy}"]`
  ).elem;

  window.q$
    .select('.dkn-dropdown-sort-radio-button', selectedOption)
    .addClass('selected');
  window.q$
    .select('.dkn-sort-by-selected-option-label')
    .modifyTextContent(getSortTypeText(sortBy));
};

window.sortByDropdownClickHandler = (evt, sortType, callback = () => {}) => {
  const payload = window.getPayloadDataFromFilters();
  payload[window.filterCategoryParams.SORT_BY] = sortType;
  const url = new URL(window.location);
  url.searchParams.set(window.filterCategoryParams.SORT_BY, sortType);
  url.searchParams.set(window.filterCategoryParams.PAGE_NUMBER, 1);
  window.history.replaceState({}, '', url);
  window.getProductCards(payload, 1);
  callback(sortType, evt);
  toggleSortbyDropdown();
};

window.appInitializer = () => {
  const paramString = new URLSearchParams(window.location.search);
  const defaultOrdering = paramString.get('sort_by') || 'relevance';
  window.q$
    .select('.dkn-sort-by-selected-option-label')
    .modifyTextContent(getSortTypeText(defaultOrdering));

  const selectedOption = window.q$.select(
    `.dkn-dropdown-option[value="${defaultOrdering}"]`
  ).elem;

  if (selectedOption) {
    window.q$
      .select('.dkn-dropdown-sort-radio-button', selectedOption)
      .addClass('selected');
  }
};
