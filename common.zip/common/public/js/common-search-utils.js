/* global q$ */
/* eslint-disable no-param-reassign */

window.fetchStoreCategoriesSearchDrawer = null;

window.searchDrawerElem = document.getElementById('offcanvasSearchDrawer');
if (window.searchDrawerElem) {
  window.searchDrawerElem.addEventListener('show.bs.offcanvas', () => {
    window.renderSearchContent();
  });
}

window.getDataFromLocalStorageV2 = (key) =>
  JSON.parse(localStorage.getItem(key)) || [];

window.getHistoryStoragekey = () =>
  `v3-${window.DukaanData.DUKAAN_STORE.link}-search-history`;

window.setDataFromLocalStorage = (key, value) => {
  localStorage.setItem(window.getHistoryStoragekey(), JSON.stringify(value));
};

window.setHistory = (term) => {
  const prevHistory = window.getDataFromLocalStorageV2(
    window.getHistoryStoragekey()
  );
  let newHistory;
  if (prevHistory.some((historyItem) => historyItem.term === term)) {
    newHistory = [
      { term },
      ...prevHistory.filter((historyItem) => historyItem.term !== term),
    ];
  } else {
    newHistory = [{ term }, ...prevHistory.slice(0, 3)];
  }
  window.setDataFromLocalStorage(window.getHistoryStoragekey(), newHistory);
  return newHistory;
};

window.getRecentSearches = () =>
  window.getDataFromLocalStorageV2(window.getHistoryStoragekey());

window.clearRecentSearches = () => {
  localStorage.removeItem(window.getHistoryStoragekey());
  window.renderRecentSearches();
};

window.clearInputSearch = () => {
  window.q$.selectAll('.dkn-search-input').elem.forEach((elem) => {
    elem.value = '';
  });
  window.q$.selectAll('.dkn-search-meta').removeClassAll('hidden');
  window.q$.selectAll('.dkn-search-predictions').addClassAll('hidden');
  window.q$.selectAll('.dkn-prediction-section-heading').addClassAll('hidden');
  window.q$.selectAll('.dkn-search-cancel-btn').addClassAll('hidden');
};

window.debounce = (callback, timeout = 300) => {
  let timer;
  return (...args) => {
    clearTimeout(timer);
    timer = setTimeout(() => {
      callback.apply(this, args);
    }, timeout);
  };
};

window.renderRecentSearches = () => {
  const {
    mountElemSelector = '.dkn-recent-searches-list',
    recentSearchItemTemplateId = 'dkn-recent-searches-template',
  } = window?.searchConfig?.recentSearches || {};
  const recentSearchList = window.getRecentSearches();
  if (recentSearchList.length > 0) {
    const recentSearchListElements =
      window.q$.selectAll(mountElemSelector).elem;

    recentSearchListElements.forEach((recentSearchListEl) => {
      recentSearchListEl.innerHTML = '';

      recentSearchList.forEach((search) => {
        const recentSearchItem = window.q$
          .selectById(recentSearchItemTemplateId)
          .getTemplateContent().elem;

        window.q$
          .select('.dkn-recent-search-item', recentSearchItem)
          .setAttribute('onclick', `redirectToSearchPage('${search.term}')`);
        window.q$
          .select('.dkn-recent-search-item-text', recentSearchItem)
          .modifyTextContent(search.term);

        recentSearchListEl.appendChild(recentSearchItem);
      });
    });
  } else {
    window.q$.selectAll('.dkn-recent-searches').addClassAll('hidden');
  }
};

window.renderPredictions = (predictions) => {
  const {
    mountElemSelector = '.dkn-search-predictions',
    predictionItemTemplateId = 'dkn-search-prediction-item-template',
  } = window?.searchConfig?.predictions || {};
  const searchPredictionsElements = window.q$.selectAll(mountElemSelector).elem;

  window.q$.selectAll('.dkn-search-cancel-btn').removeClassAll('hidden');
  window.q$.selectAll('.dkn-search-meta').addClassAll('hidden');

  searchPredictionsElements.forEach((searchPredictionsElement) => {
    searchPredictionsElement.innerHTML = '';
    searchPredictionsElement.classList.remove('hidden');

    if (!predictions?.length) {
      window.q$.select('.dkn-prediction-section-heading').addClass('hidden');
      searchPredictionsElement.innerHTML =
        '<p class="no-prediction text-14_20">No results found</p>';
      return;
    }
    DukaanData.PRODUCTS_MAP = {
      ...DukaanData.PRODUCTS_MAP,
      ...predictions.reduce((map, product) => {
        const serializedSKUs = window.serializeSKUs(product.skus || []);
        const attributes = window.getAllProductAttributeValues(serializedSKUs);
        map[product.uuid] = {
          ...product,
          skus: serializedSKUs,
          attributes,
        };
        return map;
      }, {}),
    };

    predictions.forEach((prediction) => {
      const predictionItem = window.q$
        .selectById(predictionItemTemplateId)
        .getTemplateContent()
        .elem.querySelector('.dkn-search-prediction-item');

      window.productDataRenderer(predictionItem, {
        key: 'search-prediction',
        product: prediction,
        additionalRenderer: window.searchProductCardAdditionalRenderer,
        getCustomCategoryNameText: window.getCustomCategoryNameText,
      });

      searchPredictionsElement.appendChild(predictionItem);
    });
  });
};

window.renderShimmerForCategoriesInSearch = (count = 4) => {
  const {
    mountElemSelector = '.dkn-search-content-wrapper',
    shimmerTemplateId = 'dkn-search-category-card-shimmer-template',
  } = window?.searchConfig?.shimmers || {};
  const categoryListElems = window.q$.selectAll(mountElemSelector).elem;
  categoryListElems?.forEach((categoryListElem) => {
    const shimmerCard = window.q$
      .selectById(shimmerTemplateId)
      .getTemplateContent().elem;
    for (let i = 1; i <= count; i += 1) {
      categoryListElem.appendChild(shimmerCard);
    }
  });
};

window.renderCategoryList = (categories, nextUrl) => {
  const shimmerElems = document.querySelectorAll(
    '.dkn-search-category-card-shimmer'
  );
  if (shimmerElems) {
    shimmerElems.forEach((shimmerElem) => shimmerElem.remove());
  }

  const categoryListElements = document.querySelectorAll(
    '.dkn-search-category-list'
  );

  categoryListElements.forEach((categoryListElement) => {
    categories.forEach((category) => {
      window.categoryCardRenderer(categoryListElement, category, {
        templateId: 'dkn-search-category-card-template',
      });
    });

    const currentEventObserver = categoryListElement.querySelector(
      '#search-categories-list-observer'
    );

    if (nextUrl) {
      if (currentEventObserver) {
        currentEventObserver?.remove();
      }

      const newObserverElement = document.createElement('div');
      newObserverElement.setAttribute('id', 'search-categories-list-observer');
      categoryListElement.appendChild(newObserverElement);

      const observerElement = categoryListElement.querySelector(
        '#search-categories-list-observer'
      );

      const observer = new IntersectionObserver(
        (entries) => {
          if (entries[0].isIntersecting) {
            window.renderShimmerForCategoriesInSearch(4);
            window.fetchStoreCategoriesSearchDrawer({
              nextUrl,
              cb: renderCategoryList,
            });
          }
        },
        {
          threshold: 1,
        }
      );
      observer.observe(observerElement);
    } else {
      currentEventObserver?.remove();
    }
  });
};

window.openDesktopSearchDropDown = () => {
  window.q$.select('.dkn-searchbar-backdrop').removeClass('hidden');
  window.q$.select('.dkn-search-dropdown-desktop').removeClass('hidden');
  window.q$.select('.dkn-search-input').elem.focus();
  document.body.style.overflow = 'hidden';
  window.renderSearchContent();
};

window.closeDesktopSearchDropDown = () => {
  window.q$.select('.dkn-searchbar-backdrop').addClass('hidden');
  window.q$.select('.dkn-search-dropdown-desktop').addClass('hidden');
  document.body.style.overflow = 'initial';
};

window.renderSearchContent = () => {
  const {
    mountElemSelector = '.dkn-search-content-wrapper',
    searchContentTemplateId = 'dkn-search-content-template',
  } = window?.searchConfig?.searchContent || {};
  const searchContentWrappers = window.q$.selectAll(mountElemSelector).elem;

  searchContentWrappers.forEach((item) => {
    const searchContent = window.q$
      .selectById(searchContentTemplateId)
      .getTemplateContent().elem;
    item.innerHTML = '';
    item.appendChild(searchContent);
  });
  window.renderRecentSearches();
  window.fetchStoreCategoriesSearchDrawer = window.fetchStoreCategories();
  window.fetchStoreCategoriesSearchDrawer({
    cb: renderCategoryList,
    loadPoint: '.dkn-search-category-list',
    firstFetch: true,
  });
};

window.handleInputChange = (event) => {
  const query = event.target.value;
  if (query?.length === 0) {
    window.q$.selectAll('.dkn-search-meta').removeClassAll('hidden');
    window.q$.selectAll('.dkn-search-predictions').addClassAll('hidden');
    window.renderRecentSearches();
  }

  if (query?.length < 3) return;
  // window.setHistory(query);

  const extraParams =
    window?.searchConfig?.extraParamsForFetchingPredictions || {};

  fetch(
    `${window.DukaanData.DUKAAN_ADVANCED_SEARCH_API_BASE_URL}/api/advanced-search/${window.DukaanData.DUKAAN_STORE.id}/`,
    {
      method: 'post',
      body: JSON.stringify({ query, page_size: 12, ...extraParams }),
      headers: {
        Accept: 'application/json',
        'Content-Type': 'application/json',
        'x-requested-with': window?.DukaanData?.DUKAAN_SESSION_ID,
      },
    }
  )
    .then((res) => res.json())
    .then((res) => {
      const predictions = res?.data?.products || [];
      window.renderPredictions(predictions);
    })
    .catch(() => {});
};

window.redirectToSearchPage = (value) => {
  value = value.trim();
  if (Boolean(value) && value.length > 0) {
    window.setHistory(value);
    window.location.href = dknGetSearchUrl(value);
  }
};

window.redirectToSearchPageOnSubmit = (e, formId) => {
  e.preventDefault();
  const formData = new FormData(document.querySelector(`form#${formId}`));
  const value = formData.get('search');
  window.redirectToSearchPage(value);
};

window.onSearchInputChange = debounce(
  (event) => window.handleInputChange(event),
  300
);

window.categoryCardRenderer = (
  mountElem,
  category,
  options = {
    templateId: 'dkn-category-card-template',
    customCardHref: false,
  }
) => {
  const { templateId, customCardHref } = options;
  const { name, image, id, uuid } = category;
  const categoryCard = q$.selectById(templateId).getTemplateContent().elem;

  q$.selectAll('[data-category-id]', categoryCard).setDataAttributeAll(
    'categoryId',
    id
  );
  q$.selectAll('[data-category-uuid]', categoryCard).setDataAttributeAll(
    'categoryUuid',
    uuid
  );

  window.q$
    .selectAll('.dkn-category-card-name', categoryCard)
    .modifyTextContentAll(name);
  window.q$
    .selectAll('.dkn-category-card-image', categoryCard)
    .setAttributeAll('src', window.getCdnUrl(image, 500));
  window.q$
    .selectAll('.dkn-category-card-image', categoryCard)
    .setAttributeAll('onerror', 'imageOnError(event)');
  if (!customCardHref) {
    window.q$
      .selectAll('.dkn-category-card-link', categoryCard)
      .setAttributeAll(
        'href',
        window.getCategoryCardLink(category, DukaanData.DUKAAN_BASE_URL)
      );
  } else {
    window.q$
      .selectAll('.dkn-category-card-link', categoryCard)
      .setAttributeAll('href', category?.slug);
  }

  if (typeof options?.additionalRenderer === 'function') {
    options.additionalRenderer({ category, categoryCard });
  }
  mountElem.appendChild(categoryCard);
};

window.productDataRenderer = (parentElement, options = {}) => {
  const { key, product, activeSKU } = options;
  const {
    id,
    uuid,
    name,
    slug,
    image,
    description,
    meta,
    unit,
    base_qty: baseQty,
    inventory,
  } = product;

  const sellingPrice = activeSKU?.selling_price || product?.selling_price;
  const originalPrice = activeSKU?.original_price || product?.original_price;
  const inStock = activeSKU?.in_stock || product?.in_stock;
  const categoryName =
    activeSKU?.categories?.[0]?.name || product?.categories?.[0]?.name;

  const discountPercent = window.getDiscountPercentValue(
    sellingPrice,
    originalPrice
  );
  const foodTypeIcon = window.getFoodTypeIcon(meta);

  // adding relevant data attributes
  q$.selectAll('[data-product-id]', parentElement).setDataAttributeAll(
    'productId',
    id
  );
  q$.selectAll('[data-product-uuid]', parentElement).setDataAttributeAll(
    'productUuid',
    uuid
  );

  parentElement.setAttribute('id', `dkn-product-data-parent-${uuid}-${key}`);

  // adding relevant data to all elements of product card
  q$.selectAll('a', parentElement).setAttributeAll(
    'href',
    window.getProductPageUrl(product)
  );

  q$.selectAll('.dkn-product-name', parentElement).modifyTextContentAll(name);

  q$.selectAll('.dkn-product-image', parentElement).setAttributeAll(
    'src',
    window.getCdnUrl(image, 700)
  );

  q$.selectAll('.dkn-category-name', parentElement).modifyTextContentAll(
    categoryName
  );

  q$.selectAll('.dkn-product-image', parentElement).setAttributeAll(
    'onerror',
    'window.imageOnError(event)'
  );

  if (description) {
    const santizedDescription = HtmlSanitizer?.SanitizeHtml(description);
    if (santizedDescription) {
      q$.selectAll(
        '.dkn-product-description',
        parentElement
      ).modifyInnerHTMLAll(santizedDescription);
    }
  } else {
    q$.selectAll('.dkn-product-description', parentElement).addClassAll(
      'hidden'
    );
  }

  if (foodTypeIcon) {
    q$.selectAll(
      '.dkn-product-food-type-icon',
      parentElement
    ).modifyInnerHTMLAll(window.getFoodTypeIcon(meta));
    q$.selectAll('.dkn-product-food-type-icon', parentElement).removeClassAll(
      'hidden'
    );
  } else {
    q$.selectAll('.dkn-product-food-type-icon', parentElement).addClassAll(
      'hidden'
    );
  }

  let unitText = '';
  if (activeSKU?.meta?.size) {
    unitText = `${activeSKU.meta.size.attributeLabel}: ${activeSKU.meta.size.value}`;
  } else if (unit) {
    unitText = `${DukaanData.DUKAAN_LANGUAGE.PER}${
      baseQty === 1 ? '' : ` ${baseQty}`
    } ${unit}`;
  }
  if (unitText) {
    q$.selectAll('.dkn-product-item-unit', parentElement).modifyTextContentAll(
      unitText
    );
  }

  // pricing related rendering
  q$.selectAll(
    '.dkn-product-selling-price',
    parentElement
  ).modifyTextContentAll(window.formatMoney(sellingPrice));
  if (discountPercent > 0) {
    q$.selectAll(
      '.dkn-product-original-price',
      parentElement
    ).modifyTextContentAll(window.formatMoney(originalPrice));

    let discountText = '';
    if (options.getCustomDiscountText) {
      discountText = options.getCustomDiscountText(discountPercent);
    } else {
      discountText = `${discountPercent}% OFF`;
    }
    q$.selectAll('.dkn-product-discount', parentElement).modifyTextContentAll(
      discountText
    );
    q$.selectAll(
      '.dkn-product-you-save-text',
      parentElement
    ).modifyTextContentAll(
      `You save ${formatMoney(originalPrice - sellingPrice)}.`
    );
    q$.selectAll('.dkn-product-you-save-text', parentElement).removeClassAll(
      'hidden'
    );
    q$.selectAll('.dkn-product-original-price', parentElement).removeClassAll(
      'hidden'
    );
    q$.selectAll('.dkn-product-discount', parentElement).removeClassAll(
      'hidden'
    );
  } else {
    q$.selectAll('.dkn-product-original-price', parentElement).addClassAll(
      'hidden'
    );
    q$.selectAll('.dkn-product-discount', parentElement).addClassAll('hidden');
  }

  const stockLeftMessage = q$.select(
    '.dkn-stock-left-message',
    parentElement
  ).elem;
  if (stockLeftMessage) {
    if (inventory <= 10 && inventory) {
      stockLeftMessage.classList.remove('hidden');
      stockLeftMessage.textContent =
        `${DukaanData.DUKAAN_LANGUAGE.ONLY__INVENTORY_LEFT_IN_STOCK_HURRY_UP}!`.injectText(
          {
            inventory,
          }
        );
    } else {
      stockLeftMessage.classList.add('hidden');
      stockLeftMessage.textContent = ``;
    }
  }
  const stockText = q$.select('.dkn-product-stock-text', parentElement).elem;
  if (stockText) {
    if (inStock) {
      stockText.textContent = DukaanData.DUKAAN_LANGUAGE.IN_STOCK;
      stockText.classList.add('text-c-green');
      stockText.classList.remove('text-c-red');
    } else {
      stockText.textContent = DukaanData.DUKAAN_LANGUAGE.OUT_OF_STOCK;
      stockText.classList.remove('text-c-green');
      stockText.classList.add('text-c-red');
    }
  }

  // brands related rendering
  if (product?.brands?.length) {
    const { logo, name: brandName } = product.brands[0];

    // brand logo
    if (logo) {
      q$.selectAll('.dkn-product-brand-image', parentElement).setAttributeAll(
        'src',
        window.getCdnUrl(logo, 100)
      );
    } else {
      q$.selectAll('.dkn-product-brand-image', parentElement).setAttributeAll(
        'onerror',
        'window.imageOnError(event)'
      );
    }

    // brand name
    if (brandName) {
      q$.selectAll(
        '.dkn-product-brand-name',
        parentElement
      ).modifyTextContentAll(brandName);
    } else {
      q$.selectAll('.dkn-product-brand-name', parentElement).addClassAll(
        'hidden'
      );
    }
  } else {
    q$.selectAll('.dkn-product-brand-details', parentElement).addClassAll(
      'hidden'
    );
  }

  // calling custom renderer if it exists
  if (options.additionalRenderer) {
    options.additionalRenderer(parentElement, product, options);
  }
};

window.renderAddToBagOnProductCard = () => {
  const showAddToBagButton =
    window.DukaanData?.DUKAAN_THEME_DATA?.meta?.advanced?.product
      ?.showAddToBagOnProductCard;

  const addToBagElement = q$.select(
    'add-to-bag-button-with-variants', // need to rename this to dkn format later
    parentElement
  ).elem;

  if (addToBagElement) {
    if (
      (typeof showAddToBagButton !== 'undefined' && showAddToBagButton) ||
      typeof showAddToBagButton === 'undefined'
    ) {
      addToBagButtonWithVariantsRenderer(addToBagElement);
    } else {
      addToBagElement.classList.add('hidden');
    }
  }
};
