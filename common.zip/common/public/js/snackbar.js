window.snackbarTimeout = undefined;

window.closeSnackbar = () => {
  const snackbarElement = document.getElementById('snackbar');
  snackbarElement.classList.add('hidden');
  clearTimeout(snackbarTimeout);
};
window.enqueueSnackbar = (
  message = '',
  showClose = false,
  type = '',
  link = `/${window.DukaanData.DUKAAN_STORE.link}/bag`
) => {
  const snackbarElement = document.getElementById('snackbar');
  snackbarElement.style.backgroundColor = '#353535';
  const snackbarAction = snackbarElement.querySelector('.snackbar-action');
  snackbarAction.classList.add('hidden');
  snackbarElement.querySelector('.snackbar-close-icon').classList.add('hidden');

  if (snackbarElement.classList.contains('hidden')) {
    snackbarElement.classList.remove('hidden');
  }

  snackbarElement.querySelector('.snackbar-text').textContent = message;

  if (showClose) {
    snackbarElement
      .querySelector('.snackbar-close-icon')
      .classList.remove('hidden');
  }

  if (type === 'go-to-bag') {
    snackbarAction.classList.remove('hidden');
    snackbarAction.textContent =
      window.GO_TO_BAG_TEXT || DukaanData.DUKAAN_LANGUAGE.GO_TO_BAG;
    snackbarAction.setAttribute('href', `${link}`);
  } else if (type === 'error') {
    snackbarElement.style.backgroundColor = 'var(--secondary-red)';
  } else if (type === 'success') {
    snackbarElement.style.backgroundColor = 'var(--secondary-green)';
  }

  clearTimeout(snackbarTimeout);
  snackbarTimeout = setTimeout(() => {
    snackbarElement.classList.add('hidden');
  }, 5000);
};
