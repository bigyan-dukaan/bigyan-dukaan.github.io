/*

+-----------------------------------------------------------------+
|   Created by Chirag Mehta - http://chir.ag/tech/download/ntc    |
|-----------------------------------------------------------------|
|               ntc js (Name that Color JavaScript)               |
+-----------------------------------------------------------------+

All the functions, code, lists etc. have been written specifically
for the Name that Color JavaScript by Chirag Mehta unless otherwise
specified.

This script is released under the: Creative Commons License:
Attribution 2.5 http://creativecommons.org/licenses/by/2.5/

Sample Usage:

  <script type="text/javascript" src="ntc.js"></script>

  <script type="text/javascript">

    var n_match  = ntc.name("#6195ED");
    n_rgb = n_match[0]; // This is the RGB value of the closest matching color
    n_name = n_match[1]; // This is the text string for the name of the match
    n_shade_rgb = n_match[2]; // This is the RGB value for the name of colors shade
    n_shade_name = n_match[3]; // This is the text string for the name of colors shade
    n_exactmatch = n_match[4]; // True if exact color match, False if close-match

    alert(n_match);

  </script>

*/

window.ntc = {
  init() {
    let color;
    let rgb;
    let hsl;
    for (let i = 0; i < ntc.names.length; i++) {
      color = `#${ntc.names[i][0]}`;
      rgb = ntc.rgb(color);
      hsl = ntc.hsl(color);
      ntc.names[i].push(rgb[0], rgb[1], rgb[2], hsl[0], hsl[1], hsl[2]);
    }
  },

  name(color) {
    color = color.toUpperCase();
    if (color.length < 3 || color.length > 7)
      return ['#000000', `Invalid Color: ${color}`, '#000000', '', false];
    if (color.length % 3 == 0) color = `#${color}`;
    if (color.length == 4)
      color = `#${color.substr(1, 1)}${color.substr(1, 1)}${color.substr(
        2,
        1
      )}${color.substr(2, 1)}${color.substr(3, 1)}${color.substr(3, 1)}`;

    const rgb = ntc.rgb(color);
    const r = rgb[0];
    const g = rgb[1];
    const b = rgb[2];
    const hsl = ntc.hsl(color);
    const h = hsl[0];
    const s = hsl[1];
    const l = hsl[2];
    let ndf1 = 0;
    ndf2 = 0;
    ndf = 0;
    let cl = -1;
    let df = -1;

    for (let i = 0; i < ntc.names.length; i++) {
      if (color == `#${ntc.names[i][0]}`)
        return [
          `#${ntc.names[i][0]}`,
          ntc.names[i][1],
          ntc.shadergb(ntc.names[i][2]),
          ntc.names[i][2],
          true,
        ];

      ndf1 =
        Math.pow(r - ntc.names[i][3], 2) +
        Math.pow(g - ntc.names[i][4], 2) +
        Math.pow(b - ntc.names[i][5], 2);
      ndf2 =
        Math.abs(Math.pow(h - ntc.names[i][6], 2)) +
        Math.pow(s - ntc.names[i][7], 2) +
        Math.abs(Math.pow(l - ntc.names[i][8], 2));
      ndf = ndf1 + ndf2 * 2;
      if (df < 0 || df > ndf) {
        df = ndf;
        cl = i;
      }
    }

    return cl < 0
      ? ['#000000', `Invalid Color: ${color}`, '#000000', '', false]
      : [
          `#${ntc.names[cl][0]}`,
          ntc.names[cl][1],
          ntc.shadergb(ntc.names[cl][2]),
          ntc.names[cl][2],
          false,
        ];
  },

  // adopted from: Farbtastic 1.2
  // http://acko.net/dev/farbtastic
  hsl(color) {
    const rgb = [
      parseInt(`0x${color.substring(1, 3)}`) / 255,
      parseInt(`0x${color.substring(3, 5)}`) / 255,
      parseInt(`0x${color.substring(5, 7)}`) / 255,
    ];
    let min;
    let max;
    let delta;
    let h;
    let s;
    let l;
    const r = rgb[0];
    const g = rgb[1];
    const b = rgb[2];

    min = Math.min(r, Math.min(g, b));
    max = Math.max(r, Math.max(g, b));
    delta = max - min;
    l = (min + max) / 2;

    s = 0;
    if (l > 0 && l < 1) s = delta / (l < 0.5 ? 2 * l : 2 - 2 * l);

    h = 0;
    if (delta > 0) {
      if (max == r && max != g) h += (g - b) / delta;
      if (max == g && max != b) h += 2 + (b - r) / delta;
      if (max == b && max != r) h += 4 + (r - g) / delta;
      h /= 6;
    }
    return [parseInt(h * 255), parseInt(s * 255), parseInt(l * 255)];
  },

  // adopted from: Farbtastic 1.2
  // http://acko.net/dev/farbtastic
  rgb(color) {
    return [
      parseInt(`0x${color.substring(1, 3)}`),
      parseInt(`0x${color.substring(3, 5)}`),
      parseInt(`0x${color.substring(5, 7)}`),
    ];
  },

  shadergb(shadename) {
    for (let i = 0; i < ntc.shades.length; i++) {
      if (shadename == ntc.shades[i][1]) return `#${ntc.shades[i][0]}`;
    }
    return '#000000';
  },

  shades: [
    ['FF0000', 'Red'],
    ['FFA500', 'Orange'],
    ['FFFF00', 'Yellow'],
    ['008000', 'Green'],
    ['0000FF', 'Blue'],
    ['EE82EE', 'Violet'],
    ['A52A2A', 'Brown'],
    ['000000', 'Black'],
    ['808080', 'Grey'],
    ['FFFFFF', 'White'],
  ],

  names: [
    ['CD5C5C', 'Indian Red', 'Indian Red'],
    ['F08080', 'Light Coral', 'Light Coral'],
    ['FA8072', 'Salmon', 'Salmon'],
    ['E9967A', 'Dark Salmon', 'Dark Salmon'],
    ['FFA07A', 'Light Salmon', 'Light Salmon'],
    ['DC143C', 'Crimson', 'Crimson'],
    ['FF0000', 'Red', 'Red'],
    ['B22222', 'Fire Brick', 'Fire Brick'],
    ['8B0000', 'Dark Red', 'Dark Red'],
    ['FFC0CB', 'Pink', 'Pink'],
    ['FFB6C1', 'Light Pink', 'Light Pink'],
    ['FF69B4', 'Hot Pink', 'Hot Pink'],
    ['FF1493', 'Deep Pink', 'Deep Pink'],
    ['C71585', 'Medium Violet Red', 'Medium Violet Red'],
    ['DB7093', 'Pale Violet Red', 'Pale Violet Red'],
    ['FFA07A', 'Light Salmon', 'Light Salmon'],
    ['FF7F50', 'Coral', 'Coral'],
    ['FF6347', 'Tomato', 'Tomato'],
    ['FF4500', 'Orange Red', 'Orange Red'],
    ['FF8C00', 'Dark Orange', 'Dark Orange'],
    ['FFA500', 'Orange', 'Orange'],
    ['FFD700', 'Gold', 'Gold'],
    ['FFFF00', 'Yellow', 'Yellow'],
    ['FFFFE0', 'Light Yellow', 'Light Yellow'],
    ['FFFACD', 'Lemon Chiffon', 'Lemon Chiffon'],
    ['FAFAD2', 'Light Goldenrod Yellow', 'Light Goldenrod Yellow'],
    ['FFEFD5', 'Papaya Whip', 'Papaya Whip'],
    ['FFE4B5', 'Moccasin', 'Moccasin'],
    ['FFDAB9', 'Peach Puff', 'Peach Puff'],
    ['EEE8AA', 'Pale Goldenrod', 'Pale Goldenrod'],
    ['F0E68C', 'Khaki', 'Khaki'],
    ['BDB76B', 'Dark Khaki', 'Dark Khaki'],
    ['E6E6FA', 'Lavender', 'Lavender'],
    ['D8BFD8', 'Thistle', 'Thistle'],
    ['DDA0DD', 'Plum', 'Plum'],
    ['EE82EE', 'Violet', 'Violet'],
    ['DA70D6', 'Orchid', 'Orchid'],
    ['FF00FF', 'Fuchsia', 'Fuchsia'],
    ['FF00FF', 'Magenta', 'Magenta'],
    ['BA55D3', 'Medium Orchid', 'Medium Orchid'],
    ['9370DB', 'Medium Purple', 'Medium Purple'],
    ['663399', 'Rebecca Purple', 'Rebecca Purple'],
    ['8A2BE2', 'Blue Violet', 'Blue Violet'],
    ['9400D3', 'Dark Violet', 'Dark Violet'],
    ['9932CC', 'Dark Orchid', 'Dark Orchid'],
    ['8B008B', 'Dark Magenta', 'Dark Magenta'],
    ['800080', 'Purple', 'Purple'],
    ['4B0082', 'Indigo', 'Indigo'],
    ['6A5ACD', 'Slate Blue', 'Slate Blue'],
    ['483D8B', 'Dark Slate Blue', 'Dark Slate Blue'],
    ['7B68EE', 'Medium Slate Blue', 'Medium Slate Blue'],
    ['ADFF2F', 'Green Yellow', 'Green Yellow'],
    ['7FFF00', 'Chartreuse', 'Chartreuse'],
    ['7CFC00', 'Lawn Green', 'Lawn Green'],
    ['00FF00', 'Lime', 'Lime'],
    ['32CD32', 'Lime Green', 'Lime Green'],
    ['98FB98', 'Pale Green', 'Pale Green'],
    ['90EE90', 'Light Green', 'Light Green'],
    ['00FA9A', 'Medium Spring Green', 'Medium Spring Green'],
    ['00FF7F', 'Spring Green', 'Spring Green'],
    ['3CB371', 'Medium Sea Green', 'Medium Sea Green'],
    ['2E8B57', 'Sea Green', 'Sea Green'],
    ['228B22', 'Forest Green', 'Forest Green'],
    ['008000', 'Green', 'Green'],
    ['006400', 'Dark Green', 'Dark Green'],
    ['9ACD32', 'Yellow Green', 'Yellow Green'],
    ['6B8E23', 'Olive Drab', 'Olive Drab'],
    ['808000', 'Olive', 'Olive'],
    ['556B2F', 'Dark Olive Green', 'Dark Olive Green'],
    ['66CDAA', 'Medium Aquamarine', 'Medium Aquamarine'],
    ['8FBC8B', 'Dark Sea Green', 'Dark Sea Green'],
    ['20B2AA', 'Light Sea Green', 'Light Sea Green'],
    ['008B8B', 'Dark Cyan', 'Dark Cyan'],
    ['008080', 'Teal', 'Teal'],
    ['00FFFF', 'Aqua', 'Aqua'],
    ['00FFFF', 'Cyan', 'Cyan'],
    ['E0FFFF', 'Light Cyan', 'Light Cyan'],
    ['AFEEEE', 'Pale Turquoise', 'Pale Turquoise'],
    ['7FFFD4', 'Aquamarine', 'Aquamarine'],
    ['40E0D0', 'Turquoise', 'Turquoise'],
    ['48D1CC', 'Medium Turquoise', 'Medium Turquoise'],
    ['00CED1', 'Dark Turquoise', 'Dark Turquoise'],
    ['5F9EA0', 'Cadet Blue', 'Cadet Blue'],
    ['4682B4', 'Steel Blue', 'Steel Blue'],
    ['B0C4DE', 'Light Steel Blue', 'Light Steel Blue'],
    ['B0E0E6', 'Powder Blue', 'Powder Blue'],
    ['ADD8E6', 'Light Blue', 'Light Blue'],
    ['87CEEB', 'Sky Blue', 'Sky Blue'],
    ['87CEFA', 'Light Sky Blue', 'Light Sky Blue'],
    ['00BFFF', 'Deep Sky Blue', 'Deep Sky Blue'],
    ['1E90FF', 'Dodger Blue', 'Dodger Blue'],
    ['6495ED', 'Cornflower Blue', 'Cornflower Blue'],
    ['7B68EE', 'Medium Slate Blue', 'Medium Slate Blue'],
    ['4169E1', 'Royal Blue', 'Royal Blue'],
    ['0000FF', 'Blue', 'Blue'],
    ['0000CD', 'Medium Blue', 'Medium Blue'],
    ['00008B', 'Dark Blue', 'Dark Blue'],
    ['000080', 'Navy', 'Navy'],
    ['191970', 'Midnight Blue', 'Midnight Blue'],
    ['FFF8DC', 'Cornsilk', 'Cornsilk'],
    ['FFEBCD', 'Blanched Almond', 'Blanched Almond'],
    ['FFE4C4', 'Bisque', 'Bisque'],
    ['FFDEAD', 'Navajo White', 'Navajo White'],
    ['F5DEB3', 'Wheat', 'Wheat'],
    ['DEB887', 'Burly Wood', 'Burly Wood'],
    ['D2B48C', 'Tan', 'Tan'],
    ['BC8F8F', 'Rosy Brown', 'Rosy Brown'],
    ['F4A460', 'Sandy Brown', 'Sandy Brown'],
    ['DAA520', 'Goldenrod', 'Goldenrod'],
    ['B8860B', 'Dark Goldenrod', 'Dark Goldenrod'],
    ['CD853F', 'Peru', 'Peru'],
    ['D2691E', 'Chocolate', 'Chocolate'],
    ['8B4513', 'Saddle Brown', 'Saddle Brown'],
    ['A0522D', 'Sienna', 'Sienna'],
    ['A52A2A', 'Brown', 'Brown'],
    ['800000', 'Maroon', 'Maroon'],
    ['FFFFFF', 'White', 'White'],
    ['FFFAFA', 'Snow', 'Snow'],
    ['F0FFF0', 'Honey Dew', 'Honey Dew'],
    ['F5FFFA', 'Mint Cream', 'Mint Cream'],
    ['F0FFFF', 'Azure', 'Azure'],
    ['F0F8FF', 'Alice Blue', 'Alice Blue'],
    ['F8F8FF', 'Ghost White', 'Ghost White'],
    ['F5F5F5', 'White Smoke', 'White Smoke'],
    ['FFF5EE', 'Sea Shell', 'Sea Shell'],
    ['F5F5DC', 'Beige', 'Beige'],
    ['FDF5E6', 'Old Lace', 'Old Lace'],
    ['FFFAF0', 'Floral White', 'Floral White'],
    ['FFFFF0', 'Ivory', 'Ivory'],
    ['FAEBD7', 'Antique White', 'Antique White'],
    ['FAF0E6', 'Linen', 'Linen'],
    ['FFF0F5', 'Lavender Blush', 'Lavender Blush'],
    ['FFE4E1', 'Misty Rose', 'Misty Rose'],
    ['DCDCDC', 'Gainsboro', 'Gainsboro'],
    ['D3D3D3', 'Light Gray', 'Light Gray'],
    ['C0C0C0', 'Silver', 'Silver'],
    ['A9A9A9', 'Dark Gray', 'Dark Gray'],
    ['808080', 'Gray', 'Gray'],
    ['696969', 'Dim Gray', 'Dim Gray'],
    ['778899', 'Light Slate Gray', 'Light Slate Gray'],
    ['708090', 'Slate Gray', 'Slate Gray'],
    ['2F4F4F', 'Dark Slate Gray', 'Dark Slate Gray'],
    ['000000', 'Black', 'Black'],
  ],
};

ntc.init();

// module.exports = ntc;
