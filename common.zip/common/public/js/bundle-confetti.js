window.toggleBundleConfetti = () => {
  const { bundleApplied, moreCount, bundleName } =
    getCurrentBundleApplicablityData();
  const bundleActive = moreCount !== -1;
  const bundleConfetti = q$.selectById('bundle-confetti').elem;

  if (!bundleConfetti) return;

  if (!bundleActive) {
    bundleConfetti.classList.add('hidden');
    document.documentElement.style.setProperty(
      '--container-bottom-sticky',
      '0'
    );
    return;
  }

  if (!bundleApplied && moreCount !== 0) {
    bundleConfetti.classList.remove('hidden');
    q$.select('.bundle-confetti-add-text-wrapper', bundleConfetti).addClass(
      'hidden'
    );
    q$.select('.bundle-confetti-text', bundleConfetti).modifyTextContent(
      `Add ${moreCount} ${pluralize(
        moreCount,
        'item'
      )} to avail ${bundleName} offer`
    );
  }

  if (bundleApplied && moreCount === 0) {
    bundleConfetti.classList.remove('hidden');
    q$.select('.bundle-confetti-add-text-wrapper', bundleConfetti)
      .removeClass('hidden')
      .setAttribute('href', `/${DukaanData.DUKAAN_STORE.link}/bag`);

    q$.select('.bundle-confetti-add-text', bundleConfetti).modifyTextContent(
      'Go to cart'
    );

    q$.select('.bundle-confetti-text', bundleConfetti).modifyTextContent(
      `Congrats you've unlocked ${bundleName} offer!`
    );
  }
};

window.getCurrentBundleApplicablityData = () => {
  let currentBundleState = {
    bundleApplied: false,
    moreCount: -1,
  };
  const bagProducts = getDataFromLocalStorage(PRODUCTS_STORAGE_KEY(), {});
  const bagProductList = Object.values(bagProducts).map(Object.values).flat();
  const bundleProduct = DukaanData.DUKAAN_PRODUCT;
  const { product_bundle_min_line_item_quantity: minQty } = bundleProduct;

  if (!bundleProduct || bundleProduct?.product_type !== 2)
    return currentBundleState;

  const bundleGroupQtyMap = {};

  bagProductList.forEach((item) => {
    item?.bundle_data?.forEach((data) => {
      bundleGroupQtyMap[data.bundle_uuid] =
        bundleGroupQtyMap?.[data.bundle_uuid] || {};
      bundleGroupQtyMap[data.bundle_uuid][data.bundle_group] =
        (bundleGroupQtyMap?.[data.bundle_uuid]?.[data.bundle_group] || 0) +
        data.bundle_qty;
    });
  });

  const currentBundleGroupsMap = bundleGroupQtyMap?.[bundleProduct.uuid];
  if (!currentBundleGroupsMap) return currentBundleState;

  const currentBundleGroups = Object.entries(currentBundleGroupsMap);
  currentBundleGroups.forEach(([key, value]) => {
    if (currentBundleState?.bundleApplied === true) return;
    if (value >= minQty) {
      currentBundleState = {
        bundleApplied: true,
        moreCount: 0,
        bundleName: bundleProduct.name,
        currentBundleGroup: key,
        bundleProduct,
      };
    } else {
      currentBundleState = {
        bundleApplied: false,
        moreCount: minQty - value,
        bundleName: bundleProduct.name,
        currentBundleGroup: key,
        bundleProduct,
      };
    }
  });

  return currentBundleState;
};
