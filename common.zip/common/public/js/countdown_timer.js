window.initCountdownTimer = async () => {
  const countDownTimer = await countDownInit();

  if(!countDownTimer) return;

  let TIMER_DATA = window.DukaanData?.DUKAAN_PRODUCT?.misc_data?.timer;
  let storeMethod = TIMER_DATA.store_method;
  let startTime = TIMER_DATA.start_time;
  let endTime = TIMER_DATA.end_time;
  let countDownDate = new Date();

  if (storeMethod === 'daily') {
    let endTimeHours = endTime.split(':');
    let startTimeHours = startTime.split(':');
    let endTimeToday = new Date().setHours(
      endTimeHours[0],
      endTimeHours[1],
      endTimeHours[2]
    );
    /** Case Handled if user selects endTime as 12:00 AM */
    if(endTime === '00:00:00') endTimeToday = new Date().setHours(23, 59, 00);
    /** Case Handled if user selects endTime as 12:00 AM */
    let startTimeToday = new Date().setHours(
      startTimeHours[0],
      startTimeHours[1],
      startTimeHours[2]
    );
    if (startTimeToday - countDownDate.getTime() < 0) {
      countDownDate = endTimeToday;
      removeLocalTimers();
      localStorage.setItem(`product_timer_method_${storeMethod}`, storeMethod);
      timerFunction(countDownDate);
    }
  } else if (storeMethod === 'onetime' || storeMethod === 'cookie') {
    const newExpiryDate =
      countDownDate.getTime() +
      TIMER_DATA.days * (1000 * 60 * 60 * 24) +
      TIMER_DATA.hours * (1000 * 60 * 60) +
      TIMER_DATA.minutes * (1000 * 60);
    const localStoreTimerMethod = localStorage.getItem(`product_timer_method_${storeMethod}`);
    const localStoraTimerValue = localStorage.getItem('product_timer_value');
    if(!localStoreTimerMethod) {
      removeLocalTimers();
    }
    if(localStoraTimerValue) {
      const valueArr = localStoraTimerValue.split('-');
      const TIMER_DATA_ARR = [TIMER_DATA.days, TIMER_DATA.hours, TIMER_DATA.minutes];
      const ArrCheck = [];
      valueArr.forEach((vA, i) => ArrCheck.push(vA === TIMER_DATA_ARR[i]));
      if(ArrCheck.includes(false)) removeLocalTimers();
    }
    let localExpiryDate = localStorage.getItem(
      `product_timer_${DukaanData.DUKAAN_PRODUCT.id}`
    );
    if (!localExpiryDate) {
      localStorage.setItem(
        `product_timer_${DukaanData.DUKAAN_PRODUCT.id}`,
        newExpiryDate
      );
      localStorage.setItem(`product_timer_value`, `${TIMER_DATA.days}-${TIMER_DATA.hours}-${TIMER_DATA.minutes}`);
      localStorage.setItem(`product_timer_method_${storeMethod}`, storeMethod);
      localExpiryDate = newExpiryDate;
    }
    countDownDate = localExpiryDate;
    timerFunction(countDownDate);
  }
};

window.removeLocalTimers = () => {
  localStorage.removeItem(`product_timer_method_daily`);
  localStorage.removeItem(`product_timer_method_cookie`);
  localStorage.removeItem(`product_timer_method_onetime`);
  localStorage.removeItem(`product_timer_${DukaanData.DUKAAN_PRODUCT.id}`);
  localStorage.removeItem(`product_timer_value`);
}

window.showTimer = () => {
  const timerContainers = document.querySelectorAll(
    '.countdown-timer-container'
  );
  document.getElementById('countdown-timer').classList.remove('hidden');
  timerContainers?.forEach((timerContainer) => {
    if (timerContainer) {
      timerContainer.classList.remove('hidden');
    }
  });
}

window.hideTimer = () => {
  const timerContainers = document.querySelectorAll(
    '.countdown-timer-container'
  );
  document.getElementById('countdown-timer').classList.add('hidden');
  timerContainers?.forEach((timerContainer) => {
    if (timerContainer) {
      timerContainer.classList.add('hidden');
    }
  });
}

window.timerFunction = (countDownDate) => {
  let x = setInterval(function () {
    now = new Date().getTime();
    let distance = countDownDate - now;
    // Time calculations for days, hours, minutes and seconds
    let days = Math.floor(distance / (1000 * 60 * 60 * 24));
    let hours = Math.floor(
      (distance % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60)
    );
    let minutes = Math.floor((distance % (1000 * 60 * 60)) / (1000 * 60));
    let seconds = Math.floor((distance % (1000 * 60)) / 1000);
    document.getElementById('countdown-timer-days').innerHTML = String(
      days
    ).padStart(2, 0);
    document.getElementById('countdown-timer-hours').innerHTML = String(
      hours
    ).padStart(2, 0);
    document.getElementById('countdown-timer-minutes').innerHTML = String(
      minutes
    ).padStart(2, 0);
    document.getElementById('countdown-timer-seconds').innerHTML = String(
      seconds
    ).padStart(2, 0);

    if (distance < 0) {
      clearInterval(x);
      hideTimer();
    } else {
      showTimer();
    }
  }, 1000);
};

window.countDownInit = async () => {
  return fetch(`https://apps.mydukaan.io/public/v2/apps/store/${DukaanData.DUKAAN_STORE.id}/`)
    .then((res) => res.json())
    .then((res) => {
      const { store_apps_list: appList } = res;
      const availablePlugins = appList?.reduce((acc, item) => {
        if (item.isActive) {
          acc[item._id] = item;
        }
        return acc;
      }, {});
      return !!(!!availablePlugins && availablePlugins[APP_IDS.COUNTDOWNTIMER]);
    })
}