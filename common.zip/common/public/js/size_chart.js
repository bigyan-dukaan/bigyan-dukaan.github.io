window.renderSizeChartModal = () => {
  const values = window.DukaanData.SIZE_CHART_LIST;
  const sizeChartModal = document.getElementById('size-chart-modal');
  document.getElementsByTagName('body')[0].style.overflow = 'hidden';
  sizeChartModal.classList.remove('hidden');
  const sizeChartTable = sizeChartModal.querySelector('.size-chart-table');
  const headingRow = sizeChartTable.querySelector('.size-chart-heading');
  const sizeTableBody = sizeChartTable.querySelector('.size-chart-body');
  sizeTableBody.innerHTML = '';
  headingRow.innerHTML = '';
  values[0].map((value) => {
    const tableColumn = document.createElement('th');
    tableColumn.textContent = value;
    headingRow.append(tableColumn);
  });

  values.slice(1).forEach((dataList) => {
    const tableRow = document.createElement('tr');
    tableRow.classList.add('size-chart-row');
    dataList.forEach((data) => {
      const columnValue = document.createElement('td');
      columnValue.textContent = data;
      tableRow.append(columnValue);
    });
    sizeTableBody.append(tableRow);
  });
};

window.renderSizeChart = () => {
  customTag('size-chart-btn', renderSizeChartButton);
};

window.renderSizeChartButton = (mountElem) => {
  mountElem.innerHTML = '';
  const sizeChartLabelTemplate = document.getElementById('size-chart-button');
  const sizeChartLabel = document.importNode(
    sizeChartLabelTemplate.content,
    true
  );
  mountElem.append(sizeChartLabel);
};

window.closeSizeChartModal = () => {
  document.getElementsByTagName('body')[0].style.overflow = 'auto';
  document.getElementById('size-chart-modal').classList.add('hidden');
};
