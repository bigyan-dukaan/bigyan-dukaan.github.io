// pagination

window.sizeValue = 30;

window.leftArrow = document.getElementById('left-arrow');
window.rightArrow = document.getElementById('right-arrow');

window.createPagination = (totalProductCount, selectedIndex) => {
  scrollToView = true;
  totalProductCount = Number(totalProductCount);

  if (totalProductCount < sizeValue) {
    return;
  }

  const paginationWrapper = document.getElementById('pagination-wrapper');
  paginationWrapper.classList.remove('hidden');

  const pageListWrapper = document.getElementById('page-numbers-list');
  pageListWrapper.innerHTML = '';

  selectedIndex = Number(selectedIndex);
  const noOfPages = Math.ceil(Number(totalProductCount / sizeValue));

  const url = new URL(window.location);
  url.searchParams.set('page', selectedIndex);
  window.history.replaceState({}, '', url);

  const firstIndex = 1;
  let lastIndex = 4;
  let secondIndex = 2;
  let lastSecondIndex = 3;
  let showDotsLeft = false;
  let showDotsRight = false;

  if (noOfPages <= 4) {
    for (let i = 1; i <= noOfPages; i++) {
      pageListWrapper.append(
        renderPageNoItem(i, i == selectedIndex, totalProductCount)
      );
    }
  } else {
    if (noOfPages > 4) {
      leftArrow.classList.remove('hidden');
      leftArrow.setAttribute(
        'onclick',
        `handleLeftArrowClick("${totalProductCount}", ${selectedIndex - 1})`
      );
      rightArrow.classList.remove('hidden');
      rightArrow.setAttribute(
        'onclick',
        `handleRightArrowClick("${totalProductCount}", ${
          selectedIndex + 1
        } , "${noOfPages}")`
      );

      if (selectedIndex == 1) {
        if (leftArrow.classList.contains('active'))
          leftArrow.classList.remove('active');
      } else leftArrow.classList.add('active');

      if (selectedIndex == noOfPages) {
        if (rightArrow.classList.contains('active'))
          rightArrow.classList.remove('active');
      } else rightArrow.classList.add('active');

      lastIndex = noOfPages;
      if (selectedIndex >= 4) {
        if (selectedIndex >= noOfPages - 2) {
          secondIndex = noOfPages - 2;
          lastSecondIndex = noOfPages - 1;
        } else {
          lastSecondIndex = noOfPages - 1;
          secondIndex = selectedIndex;
        }
      }
    }

    if (secondIndex - 1 != firstIndex) showDotsLeft = true;

    if (
      (secondIndex < lastSecondIndex && secondIndex + 1 != lastSecondIndex) ||
      (lastSecondIndex === 3 && lastIndex > 4)
    )
      showDotsRight = true;

    pageListWrapper.append(
      renderPageNoItem(
        firstIndex,
        firstIndex == selectedIndex,
        totalProductCount
      )
    );

    const leftThreeDotsTemplate = document.getElementById('three-dots');
    const leftThreeDots = document.importNode(
      leftThreeDotsTemplate.content,
      true
    );

    const rightThreeDotsTemplate = document.getElementById('three-dots');
    const rightThreeDots = document.importNode(
      rightThreeDotsTemplate.content,
      true
    );

    if (showDotsLeft) pageListWrapper.append(leftThreeDots);

    pageListWrapper.append(
      renderPageNoItem(
        secondIndex,
        secondIndex == selectedIndex,
        totalProductCount
      )
    );

    if (showDotsRight && lastSecondIndex > 4)
      pageListWrapper.append(rightThreeDots);
    pageListWrapper.append(
      renderPageNoItem(
        lastSecondIndex,
        lastSecondIndex == selectedIndex,
        totalProductCount
      )
    );

    if (showDotsRight && lastSecondIndex < 4)
      pageListWrapper.append(rightThreeDots);

    pageListWrapper.append(
      renderPageNoItem(lastIndex, lastIndex == selectedIndex, totalProductCount)
    );
  }
};

window.handleRightArrowClick = (
  totalProductCount,
  selectedIndex,
  noOfPages
) => {
  totalProductCount = Number(totalProductCount);
  selectedIndex = Number(selectedIndex);
  noOfPages = Number(noOfPages);
  if (selectedIndex > noOfPages) {
    if (rightArrow.classList.contains('active'))
      rightArrow.classList.remove('active');
  } else {
    rightArrow.classList.add('active');
    fetchPaginatedCategoryProducts(null, selectedIndex);
  }
};

window.handleLeftArrowClick = (totalProductCount, selectedIndex) => {
  totalProductCount = Number(totalProductCount);
  selectedIndex = Number(selectedIndex);
  if (selectedIndex <= 0) {
    if (leftArrow.classList.contains('active'))
      leftArrow.classList.remove('active');
  } else {
    leftArrow.classList.add('active');
    fetchPaginatedCategoryProducts(null, selectedIndex);
  }
};

window.paginationButtonClickHandler = (index) => {
  const paramString = new URLSearchParams(window.location.search);
  const url = new URL(window.location);
  url.searchParams.set('page', index);
  window.history.replaceState({}, '', url);
  fetchPaginatedCategoryProducts(paramString.get('ordering') || '', index);
};

window.renderPageNoItem = (index, isSelected, totalProductCount) => {
  const pageNoItemTemplate = document.getElementById('page-no-item');
  const pageNoItem = document.importNode(pageNoItemTemplate.content, true);
  pageNoItem.querySelector('.page-number').textContent = index;
  pageNoItem
    .querySelector('.page-no-item')
    .setAttribute('onclick', `paginationButtonClickHandler(${index})`);
  if (isSelected)
    pageNoItem.querySelector('.page-no-item').classList.add('active');
  return pageNoItem;
};

window.categoryShimmerRenderer = (customShimmer) => {
  const productListWrapper = document.getElementById('product-list-wrapper');
  productListWrapper.innerHTML = '';

  for (let i = 1; i <= 8; i++) {
    const shimmerDiv = document.createElement('div');
    shimmerDiv.className = 'product-card flex d-column';
    shimmerDiv.innerHTML = `
      <div class="product-image shimmer" style="width:100%"></div>
            <div class="price-tag shimmer" style="height: 24px; width:100%; margin-top: 8px;"></div>
            <div class="shimmer" style="height: 16px; width:100%; margin-top: 8px;"></div>`;
    productListWrapper.appendChild(shimmerDiv);
  }
};

window.categoryProductsRenderer = (products, totalCount) => {
  const productListWrapper = document.getElementById('product-list-wrapper');
  productListWrapper.innerHTML = '';
  // const heading = document.querySelector('.category-heading');
  // heading.innerHTML="";
  // heading.textContent = `${DukaanData.DUKAAN_CATEGORY.name} (${totalCount})`;

  if (totalCount == 0) {
    productListWrapper.textContent = 'No Products found';
    return;
  }
  products.map((product) =>
    productListWrapper.appendChild(categoryProductRenderer(product))
  );
};

window.categoryProductRenderer = (product) => {
  const productCardTemplate = document.getElementById('category-product-card');

  const element = document.importNode(productCardTemplate.content, true);

  element.querySelector('.product-image').src = `${getCdnUrl(
    product.image,
    500
  )}`;

  element.querySelector('.product-image').alt = product.name;

  element
    .querySelector('a')
    .setAttribute(
      'href',
      `${DukaanData.DUKAAN_BASE_URL}/products/${product.slug}`
    );

  element.querySelector('.product-name').textContent = product.name;
  element
    .querySelector('.product-name')
    .setAttribute(
      'href',
      `${DukaanData.DUKAAN_BASE_URL}/products/${product.slug}`
    );

  const sellingPrice = product.skus[0]
    ? product.skus[0].selling_price
    : product.selling_price;
  const originalPrice = product.skus[0]
    ? product.skus[0].original_price
    : product.original_price;
  element.querySelector('.product-selling-price').textContent =
    formatMoney(sellingPrice);

  if (sellingPrice < originalPrice) {
    element.querySelector('.product-original-price').textContent = formatMoney(
      Number(originalPrice)
    );
    element.querySelector(
      '.product-discount-percent'
    ).textContent = `(${Math.ceil(
      ((originalPrice - sellingPrice) / originalPrice) * 100
    )}% OFF)`;
  } else {
    element.querySelector('.product-original-price').textContent = null;
    element.querySelector('.product-discount-percent').classList.add('hidden');
    element.querySelector('.product-original-price').classList.add('hidden');
  }
  if (element.querySelector('add-to-bag-button-with-variants')) {
    element.querySelector(
      'add-to-bag-button-with-variants'
    ).dataset = `${formatMoney(product.selling_price)}`;
    const addToBagElement = element.querySelector(
      'add-to-bag-button-with-variants'
    );
    addToBagElement.dataset.productUuid = product.uuid;
    addToBagButtonWithVariantsRenderer(addToBagElement);
  }

  if (element.querySelector('.pricing-label')) {
    if (!product.in_stock) {
      element.querySelector('.pricing-label').classList.add('hidden');
      element.querySelector('.out-of-stock-label').classList.remove('hidden');
    }
  }

  const badge = element.querySelector('.bxgy-badge');

  if (
    Boolean(badge) &&
    Boolean(product.coupon_data) &&
    product.coupon_data.length > 0
  ) {
    badge.textContent = getBXGYText(product.coupon_data);
    badge.classList.remove('hidden');
  }

  if (element.querySelector('wishlist-button-load-point')) {
    element
      .querySelector('wishlist-button-load-point')
      .setAttribute('data-product-uuid', `${product.uuid}`);
  }

  return element;
};

window.scrollToView = false;

window.fetchPaginatedCategoryProducts = (
  ordering = '',
  page = 1,
  disableScroll = false
) => {
  categoryShimmerRenderer();
  fetch(
    `${window.DukaanData.CLIENT_API_ENDPOINT}/api/product/buyer/${DukaanData.DUKAAN_STORE.uuid}/product-list/v2/?category=${DukaanData.DUKAAN_CATEGORY.uuid}&ordering=${ordering}&search=&page=${page}&pop_fields=category_data,store_data`,
    {
      headers: {
        'Content-Type': 'application/json',
        // 'Content-Type': 'application/x-www-form-urlencoded',
      },
    }
  )
    .then((res) => res.json())
    .then((res) => {
      const products = res.results;
      const totalCount = res.count;
      const paginationWrapper = document.getElementById('pagination-wrapper');
      paginationWrapper.classList.add('hidden');
      leftArrow.classList.add('hidden');
      rightArrow.classList.add('hidden');
      createPagination(totalCount, page);

      if (scrollToView && !disableScroll) {
        const element = document.getElementById('category-details-page');
        const y = element.getBoundingClientRect().top + window.scrollY;
        window.scroll({
          top: y - 100,
          behavior: 'smooth',
        });
      }

      hashProductMapper(products);

      // DukaanData.PRODUCTS_MAP = {
      //   ...DukaanData.PRODUCTS_MAP,
      //   ...products.reduce((map, product) => {
      //     const serializedSKUs = serializeSKUs(product.skus || []);
      //     const attributes = getAllProductAttributeValues(serializedSKUs);
      //     map[product.uuid] = {
      //       ...product,
      //       skus: serializedSKUs,
      //       attributes,
      //     };
      //     return map;
      //   }, {}),
      // };
      categoryProductsRenderer(products, totalCount);
    })
    .catch((error) => console.log(error));
};
