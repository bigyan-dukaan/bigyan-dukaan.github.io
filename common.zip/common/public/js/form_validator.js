window.FormValidator = class FormValidator {
  constructor(form, fields, submitHandler) {
    this.form = form;
    this.fields = fields;
    this.submitHandler = submitHandler;
  }

  initialize = () => {
    this.validateOnEntry();
    this.validateOnSubmit();
    this.validatePhoneNumberInput();
  }

  validateOnSubmit = () => {
    this.form.addEventListener('submit', e => {
      e.preventDefault();
      const errorArray = [];
      this.fields.forEach(field => {
        const input = document.querySelector(`#${field}`);
        const isError = this.validateFields(input);
        errorArray.push(isError);
      });
      if(errorArray.every(eA => eA === false)) {
        this.submitHandler();
      }
    })
  }

  validateOnEntry = () => {
    this.fields.forEach(field => {
      const input = document.querySelector(`#${field}`);
      input.addEventListener('input', event => {
        this.validateFields(input);
      });
    })
  }

  validateFields = (field) => {
    // Check presence of values
    let isError = false;
    if (field.value.trim() === "") {
      this.setStatus(field, `${field.previousElementSibling.innerText.toLowerCase()} cannot be blank`, "error");
      isError = true;
    } else {
      this.setStatus(field, null, "success");
      isError = false;
    }

    // check for a valid email address
    if (field.type === "email") {
      const re = /\S+@\S+\.\S+/;
      if (re.test(field.value)) {
        this.setStatus(field, null, "success");
        isError = false;
      } else {
        this.setStatus(field, "Please enter valid email address", "error");
        isError = true;
      }
    }

    // check for a valid phone number
    if (field.type === "tel") {
      // const re = /\+?\d[\d -]{8,12}\d/;
      const re= /^(?:(?:\+|0{0,2})91(\s*[\-]\s*)?|[0]?)?[789]\d{9}$/;
      if (re.test(field.value)) {
        this.setStatus(field, null, "success");
        isError = false;
      } else {
        this.setStatus(field, "Please enter valid phone number", "error");
        isError = true;
      }
    }

    return isError;
  }

  setStatus = (field, message, status) => {
    const errorMessage = field.parentElement.querySelector('.error-message');

    if (status === "success") {
      if (errorMessage) { errorMessage.innerText = "" };
      field.classList.remove('input-error');
    }

    if (status === "error") {
      if (errorMessage) { errorMessage.innerText = message };
      field.classList.add('input-error');
    }
  }

  validatePhoneNumberInput = () => {
    var iChars = "!@#$%^&*()=_[]\\\';,./{}|\":<>?";
    const input = document.querySelector('input[name="phone"]');
    input.addEventListener('keypress', (e) => {
      if (iChars.indexOf(e.key) != -1 || (e.keyCode >= 65 && e.keyCode <= 90) || (e.keyCode >= 97 && e.keyCode <= 122)) {
        e.preventDefault();
        return false;
      }
    });
  }
}
