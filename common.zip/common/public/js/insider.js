try {
  window.InsiderQueue = window.InsiderQueue || [];
  const implementListener = (event) => {
    document.addEventListener(event.event_name_dkn, (e) => {
      const eventPayload = e.payload;
      const eventName = event.event_name_alias;
      const serializedData = event.serializer(eventPayload);

      if (event.isSystemEvent) {
        trackInsiderEvent(eventName, serializedData, eventPayload);
      } else {
        trackInsiderEvent(
          'custom_event',
          [
            {
              event_name: eventName,
              event_parameters: serializedData,
            },
          ],
          eventPayload
        );
      }
    });
  };

  const findValueInMetafields = (metafields, key) => {
    const metafield = (metafields || []).find((f) => f.key === key);
    return metafield?.value_str || metafield?.value || '';
  };

  const formatMoney = (num) => Math.round(num * 100) / 100;

  const ProductSerializer = (eventPayload) => {
    const {
      store_data,
      _product: original_products,
      items: event_products,
      productDiscount = 0,
    } = eventPayload;

    const first_product = original_products || {};
    const eventProduct = event_products?.[0] || {};
    const originalPrice =
      eventProduct?.original_price || first_product?.original_price || 0;
    const sellingPrice =
      eventProduct?.selling_price || first_product?.selling_price || 0;
    const finalPrice = sellingPrice - (productDiscount || 0);

    const rawImage =
      first_product?.image ||
      first_product?.image_url ||
      first_product?.parent_product?.image;
    const taxonomy = [
      findValueInMetafields(first_product?.metafields, 'event_category_1') ||
        first_product.categories?.[0]?.name ||
        first_product?.categories?.[0] ||
        '',
      findValueInMetafields(first_product?.metafields, 'event_category_2') ||
        '',
    ].filter((i) => !!i);
    const payload = {
      id: (
        eventProduct?.product_id ||
        first_product?.id ||
        first_product?.product_id ||
        ''
      ).toString(),
      name: first_product.name,
      taxonomy,
      unit_price: originalPrice,
      unit_sale_price: finalPrice,
      url: `${window.location.protocol}//${window.location.host}${
        eventProduct.product_url || first_product?.product_url
      }`,
      stock: first_product?.inventory_quantity || 1,
      size: eventPayload?._sku?.meta?.size?.value || '',
      product_image_url:
        typeof window.getCdnUrl === 'function'
          ? window.getCdnUrl(rawImage, 700, 700)
          : rawImage,
      custom: {},
    };

    const quantity = eventProduct.quantity || first_product.quantity;
    if (quantity) payload.quantity = quantity;
    if (eventProduct.isBundle) {
      payload.custom.bundle = eventProduct.isBundle || false;
    }

    return payload;
  };

  const CheckoutSerializer = (eventPayload, pushItems = true) => {
    const {
      store_data: storeData,
      items: products,
      total_cart_cost,
      total_cart_original_cost: total_mrp,
      coupon_discount: totalDiscount,
      coupon,
    } = eventPayload;
    const res = {
      shipping_cost: eventPayload?.delivery_cost_applied || 0,
      total: formatMoney(total_cart_cost),
    };

    const storeId = storeData?.id;
    const isUatStore = storeId === 202299439;

    const evenlyDistributedDiscountAmount = isUatStore
      ? totalDiscount / products.length
      : 0;

    if (pushItems) {
      res.items = products.map((p) =>
        ProductSerializer({
          items: [p],
          _product: p.parent_product,
          _sku: p._sku,
          productDiscount: evenlyDistributedDiscountAmount,
        })
      );
    }

    return res;
  };
  const PurchaseSerializer = (eventPayload) => {
    const {
      store_data: storeData,
      items: products,
      total_cart_cost,
      _order_details: orderDetails,
      coupon_discount: couponDiscount,
      coupon: couponCode,
    } = eventPayload;
    const first_product = products[0];
    const taxonomy = [
      findValueInMetafields(first_product?.metafields, 'event_category_1') ||
        first_product.categories?.[0]?.name ||
        first_product?.categories?.[0] ||
        '',
      findValueInMetafields(first_product?.metafields, 'event_category_2') ||
        '',
    ].filter((i) => !!i);

    const storeId = storeData?.id;
    const isUatStore = storeId === 202299439;

    const evenlyDistributedDiscountAmount = isUatStore
      ? couponDiscount / products.length
      : 0;

    const serializedProducts = products.map((product) => ({
      id: (product?.product_id || product?.parent_product?.id || '').toString(),
      name: product.name,
      taxonomy,
      unit_price: product.original_price,
      unit_sale_price: product.selling_price - evenlyDistributedDiscountAmount,
      quantity: product.quantity,
      url: `${window.location.protocol}//${window.location.host}${product.product_url}`,
      // stock: product.stock,
      size: product?._sku?.variant_size || '',
      product_image_url:
        typeof window.getCdnUrl === 'function'
          ? window.getCdnUrl(product.image_url, 700, 700)
          : product.image_url,
      custom: {
        discount_code: couponCode,
        discount_value: couponDiscount,
      },
    }));

    return {
      order_id: orderDetails?.display_order_id,
      total: formatMoney(total_cart_cost),
      items: serializedProducts,
    };
  };
  const AddressSerializer = (eventPayload, { isAnonymous = false } = {}) => {
    const { store_data, _address_object: address } = eventPayload;

    const payload = {
      address_1: `${address?.line || ''} ${address?.line_1 || ''} ${
        address?.landmark || ''
      }`,
      city: address.city,
      country: address.country,
      email: address.email,
      first_name: address.name.split(' ')[0] || '',
      last_name: address.name.split(' ')[1] || '',
      mobile_number: address?.mobile?.replace('-', ''),
      pincode: address.pin,
      state: address.state,
      total: formatMoney(eventPayload.total_cart_cost),
      cashback: eventPayload.eligible_credits || 0,
    };
    trackInsiderUser(payload);

    return {
      custom: payload,
    };
  };
  const CategorySerializer = (eventPayload) => {
    const {
      store_data,
      _category: category,
      product_count: productCount,
    } = eventPayload;
    return [category.name];
  };
  const CustomerSerializer = (eventPayload) => {
    const { _login_data: loginData } = eventPayload;
    trackInsiderUser();
    return {
      customer_id: loginData?.user_id,
      mobile_number: loginData?.mobile,
      first_time_user: loginData?.is_new_buyer,
    };
  };
  const OrderSerializer = (eventPayload) => {
    const { _order_details: orderDetails } = eventPayload;
    return {
      order_id: orderDetails?.display_order_id,
      order_date: new Date(orderDetails?.created_at_utc).toISOString(),
      first_time_user: orderDetails?.is_first_order_for_customer,
      order_tracking_url: eventPayload?.tracking_url,
      payment_mode: orderDetails?.payment_mode === 0 ? 'COD' : 'Prepaid',
      coupon_applied: orderDetails?.coupon_code,
      payment_status: 'Cancelled',
    };
  };
  const trackInsiderEvent = (eventName, eventData, originalEventPayload) => {
    window.InsiderQueue.push({
      type: eventName.toLowerCase().replace(/ /g, '_'),
      value: eventData,
    });
    window.InsiderQueue.push({
      type: 'currency',
      value:
        window?.DukaanData?.DUKAAN_STORE?.currency?.cc ||
        originalEventPayload?.store_data?.currency?.cc ||
        'INR',
    });
    window.InsiderQueue.push({
      type: 'init',
    });
  };
  const trackInsiderUser = (payload = {}) => {
    const token = localStorage.al_to;
    const userParams = {};

    if (token) {
      try {
        const user_json = JSON.parse(atob(token.split('.')[1]));
        const mobile = user_json?.username || '';
        const email = user_json?.email || '';
        const userId = user_json?.user_id || '';
        const finalMobile = mobile?.replace('-', '');

        userParams.mobile = finalMobile;
        userParams.uuid = userId.toString();
        userParams.email = email;
      } catch {
        //
      }
    }

    let location = {};
    if (localStorage.userLocation) {
      try {
        const locationJSON = JSON.parse(localStorage.userLocation);
        location = {
          country: locationJSON?.data?.country?.toLowerCase() || '',
          city: locationJSON.data.city,
        };
      } catch {
        //
      }
    }

    window.InsiderQueue.push({
      type: 'init',
    });

    window.InsiderQueue.push({
      type: 'user',
      value: {
        name: payload.first_name || '',
        surname: payload.last_name || '',
        phone_number: userParams.mobile || payload?.mobile_number || '',
        email: payload.email || userParams.email || '',
        uuid: userParams.uuid || '',
        language: navigator.language,
        email_optin: true,
        sms_optin: true,
        gdpr_optin: true,
        country: payload.country || location.country || '',
        city: payload.city || location.city || '',
      },
    });
    window.InsiderQueue.push({
      type: 'init',
    });
  };

  const dukaan_events = [
    {
      event_name_dkn: 'dkn_add_to_bag',
      event_name_alias: 'add_to_cart',
      serializer: ProductSerializer,
      isSystemEvent: true,
    },
    {
      event_name_dkn: 'dkn_initiate_checkout',
      event_name_alias: 'checkout_started',
      serializer: (params) => CheckoutSerializer(params, false),
    },
    {
      event_name_dkn: 'dkn_purchase',
      event_name_alias: 'purchase',
      serializer: PurchaseSerializer,
      isSystemEvent: true,
    },
    {
      event_name_dkn: 'dkn_add_address',
      event_name_alias: 'address_added',
      serializer: AddressSerializer,
    },
    {
      event_name_dkn: 'dkn_add_anonymous_address',
      event_name_alias: 'anonymous_address_added',
      serializer: (params) => AddressSerializer(params, { isAnonymous: true }),
    },
    {
      event_name_dkn: 'dkn_select_address',
      event_name_alias: 'address_selected',
      serializer: AddressSerializer,
    },
    {
      event_name_dkn: 'dkn_category_view_content',
      event_name_alias: 'category',
      serializer: CategorySerializer,
      isSystemEvent: true,
    },
    {
      event_name_dkn: 'dkn_store_login',
      event_name_alias: 'customer_logged_in',
      serializer: CustomerSerializer,
    },
    {
      event_name_dkn: 'dkn_store_user_register',
      event_name_alias: 'customer_registered',
      serializer: CustomerSerializer,
    },
    {
      event_name_dkn: 'dkn_product_view_content',
      event_name_alias: 'product',
      serializer: ProductSerializer,
      isSystemEvent: true,
    },
    {
      event_name_dkn: 'dkn_product_searched',
      event_name_alias: 'product_searched',
      serializer: ProductSerializer,
    },
    {
      event_name_dkn: 'dkn_remove_from_bag',
      event_name_alias: 'remove_from_cart',
      serializer: ProductSerializer,
      isSystemEvent: true,
    },
    {
      event_name_dkn: 'dkn_order_cancelled',
      event_name_alias: 'order_cancelled',
      serializer: OrderSerializer,
    },
    {
      event_name_dkn: 'dkn_payment_failed',
      event_name_alias: 'payment_failed',
      serializer: CheckoutSerializer,
    },
    {
      event_name_dkn: 'dkn_homepage_view_content',
      event_name_alias: 'home',
      serializer: () => ({}),
      isSystemEvent: true,
    },
    {
      event_name_dkn: 'dkn_add_payment_info',
      event_name_alias: 'add_payment_info',
      serializer: () => ({}),
    },
    {
      event_name_dkn: 'dkn_view_bag',
      event_name_alias: 'cart',
      serializer: CheckoutSerializer,
      isSystemEvent: true,
    },
  ];

  dukaan_events.forEach((event) => implementListener(event));
  trackInsiderUser();
} catch (error) {
  console.error('Error in Insider Web SDK integration:', error);
}
