window.toggleCouponFooter = () => {
  const { isApplied, moreCount, couponText, couponCode, productDetails } =
    getBXGYOfferData();
  const bagCouponActive = productDetails.buy_x_count;
  const couponSticky = document.getElementById('coupon-sticky');
  let isCouponPresent = null;
  const { isDesktop } = deviceType();

  if (!couponSticky) return;

  if (!bagCouponActive) {
    couponSticky.classList.add('hidden');
    document.documentElement.style.setProperty(
      '--container-bottom-sticky',
      '0'
    );
    return;
  }

  const renderFooter = () => {
    const bxgyText = couponSticky.querySelector('.bxgy-text');
    const addText = couponSticky.querySelector('.sticky-text');
    const addTextWrapper = couponSticky.querySelector('.add-text');
    const aTag = couponSticky.querySelector('a');
    if (!isApplied && moreCount !== 0) {
      couponSticky.classList.remove('hidden');
      bxgyText.textContent =
        DukaanData.DUKAAN_LANGUAGE.ADD__MORECOUNT_MORE__COUPONTEXT_ITEM_TO_UNLOCK_THE_OFFER.injectText(
          {
            moreCount,
            couponText,
          }
        );
      addTextWrapper.classList.add('hidden');
    }

    if (isApplied && moreCount === 0) {
      couponSticky.classList.remove('hidden');
      if (isDesktop) {
        addTextWrapper.classList.remove('hidden');
      }
      bxgyText.textContent =
        DukaanData.DUKAAN_LANGUAGE.CONGRATS_YOU_HAVE_UNLOCKED__COUPONCODE_OFFER.injectText(
          {
            couponCode,
          }
        );
      addText.textContent =
        window.GO_TO_BAG_TEXT || DukaanData.DUKAAN_LANGUAGE.GO_TO_BAG;
      aTag.setAttribute('href', `/${DukaanData.DUKAAN_STORE.link}/bag`);
    }
    document.documentElement.style.setProperty(
      '--container-bottom-sticky',
      '42px'
    );
  };

  if (window?.DukaanData.DUKAAN_COUPONS?.length) {
    isCouponPresent = DukaanData?.DUKAAN_COUPONS?.find(
      (coupon) => coupon.code === couponCode
    )?.code;
    if (isCouponPresent) renderFooter();
    return;
  }

  fetchCoupons({
    successCallback: () => {
      isCouponPresent = DukaanData?.DUKAAN_COUPONS?.find(
        (coupon) => coupon.code === couponCode
      )?.code;
      if (isCouponPresent) renderFooter();
    },
  });
};

window.getBXGYOfferData = () => {
  const bagProducts = getDataFromLocalStorage(PRODUCTS_STORAGE_KEY(), {});
  const bagProductList = Object.values(bagProducts).map(Object.values).flat();

  const filteredProducts = bagProductList.filter(
    (item) => item?.parent_product?.coupon_data?.length || false
  );

  const getTotalItemsCount = (products = []) =>
    products.reduce((acc, { ordered_qty: qty }) => acc + (qty || 0), 0);

  const count = getTotalItemsCount(filteredProducts);
  const [filteredProduct = {}] = filteredProducts;
  const productDetails = {
    ...filteredProduct,
    ...filteredProduct?.parent_product?.coupon_data?.[0],
  };
  const productCount = count;

  return {
    isApplied:
      productCount >= productDetails.buy_x_count + productDetails.get_y_count,
    buyXCount: productDetails.buy_x_count,
    getYCount: productDetails.get_y_count,
    couponCode: productDetails.code,
    categorySlug: `buy-${productDetails.buy_x_count}-get-${productDetails.get_y_count}`,
    couponText: `'BUY ${productDetails.buy_x_count} GET ${productDetails.get_y_count}'`,
    moreCount:
      productDetails.buy_x_count + productDetails.get_y_count - productCount > 0
        ? productDetails.buy_x_count + productDetails.get_y_count - productCount
        : 0,
    productDetails,
  };
};
