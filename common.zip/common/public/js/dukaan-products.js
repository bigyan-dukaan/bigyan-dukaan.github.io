window.roundToMultiple = (num, factor) => factor * Math.floor(num / factor);
window.isVideoImageLink = (link = '') => link.includes('https://img.youtube');
const TWTUUID = '197a3a5a-9953-4227-b4a0-7e4e1e845793';

window.renderAvailableBundlesOnPDP = () => {
  const { isMobile } = deviceType();
  const product = DukaanData.DUKAAN_PRODUCT;
  const renderBundleOptionsOnPDP = (products) => {
    q$.select('pdp-bundles-load-point').removeClass('hidden');
    const mountElem = q$.select(
      'pdp-bundles-load-point .pdp-bundles-list'
    ).elem;
    if (!mountElem) return;
    products?.forEach((item) => {
      const { name, slug } = item;
      const bundleItem = document.createElement('div');
      bundleItem.classList.add('d-flex', 'align-items-center', 'flex', 'a-c');
      bundleItem.innerHTML = `<div class="bundle-icon"><svg color="var(--secondary)" width="21" height="20" viewBox="0 0 21 20" fill="none" xmlns="http://www.w3.org/2000/svg">
      <path fill-rule="evenodd" clip-rule="evenodd" d="M10.7277 2.15222C10.4152 1.83965 9.99125 1.66406 9.54925 1.66406H3.57292C2.65244 1.66406 1.90625 2.41025 1.90625 3.33073V9.30706C1.90625 9.74906 2.08184 10.173 2.39441 10.4856L9.89442 17.9856C10.5452 18.6364 11.6006 18.6364 12.2514 17.9856L18.2277 12.0092C18.8786 11.3584 18.8786 10.3031 18.2277 9.65223L10.7277 2.15222ZM7.73958 6.2474C7.73958 6.93775 7.17994 7.4974 6.48958 7.4974C5.79922 7.4974 5.23958 6.93775 5.23958 6.2474C5.23958 5.55704 5.79922 4.9974 6.48958 4.9974C7.17994 4.9974 7.73958 5.55704 7.73958 6.2474Z" fill="currentColor"/>
      </svg>
      </div>
      <div class="bundle-text" style="display: inline-block;">
      <b>Combo Offer:</b>
      ${name}.
      <a href="${DukaanData.DUKAAN_BASE_URL}/bundles/${slug}" class="view-products-link">View products</a>
      </div>
      `;
      mountElem.appendChild(bundleItem);
    });
  };
  const renderAvailableComboOnPDP = (combo) => {
    if (!combo) return;

    const parentElement = q$
      .select('.dkn-single-combo-details-wrapper')
      .removeClass('hidden').elem;
    if (!parentElement) return;

    const { productIds } = getBundleApplicablityData(combo);
    q$.select('.dkn-single-combo-name', parentElement).modifyTextContent(
      combo.name
    );
    q$.select(
      '.dkn-single-combo-selling-price',
      parentElement
    ).modifyTextContent(formatMoney(combo.selling_price));
    q$.select(
      '.dkn-single-combo-original-price',
      parentElement
    ).modifyTextContent(formatMoney(combo.original_price));
    q$.select('.dkn-single-combo-view-btn', parentElement).setAttribute(
      'href',
      getBundlePageUrl(combo)
    );
    q$.select('add-to-bag-button.dkn-single-combo-add-button', parentElement)
      .setAttribute('data-product-uuid', combo.uuid)
      .setAttribute('data-sku-uuid', combo?.skus?.[0]?.uuid);

    const tempdiv = document.createElement('div');
    tempdiv.innerHTML = `

        <style>
        
.dkn-single-combo-products-list add-to-bag-button {
  display: none;
}

.dkn-single-combo-products-list {
  width: calc(100% + 24px);
  margin: 0px -12px;
}

.dkn-single-combo-view-btn,
.dkn-single-combo-add-button .add-to-bag-button-wrapper .btn-outline-primary {
  display: flex;
  padding: 8px 24px;
  justify-content: center;
  align-items: center;
  color: var(--primary);
  text-align: center;
  font-size: 16px;
  font-weight: 500;
  line-height: 24px;
  border-radius: var(--single-combo-br, 0px);
  width: 100%;
  border: 1px solid var(--primary);
}
.dkn-single-combo-view-btn:hover,
.dkn-single-combo-add-button .add-to-bag-button-wrapper .btn-outline-primary:hover {
  color: var(--primary);
  background-color: rgba(0,0,0,0.01);
}

.dkn-single-combo-add-button .add-to-bag-button-wrapper {
  margin-top: 0px !important;
}
.dkn-single-combo-add-button .add-to-bag-button-wrapper .btn-outline-primary {
  background-color: var(--primary);
  color: var(--white);
}

.dkn-single-combo-action-wrapper {
  width: 100%;
}

.dkn-single-combo-products-list .dkn-product-card:not(:last-child)::after {
  content: '+';
  position: absolute;
  color: var(--black-60);
  right: -16px;
  top: calc(50% - 14px);
  font-size: 14px;
}

.dkn-single-combo-products-list .dkn-product-card {
  width: calc((100% - 48px) / 2) !important;
  min-width: calc((100% - 48px) / 2) !important;
  max-width: calc((100% - 48px) / 2) !important;
  margin: 12px;
}

.dkn-single-combo-details-wrapper {
  border: 1px solid var(--black-85);
  border-radius: var(--single-combo-br, 4px);
}

.dkn-single-combo-details-wrapper .dkn-slider__arrow {
  position: absolute;
  top: calc(50% - 36px);
  width: 24px;
  height: 24px;
  background: #ffffff;
  border: 1px solid #d9d9d9;
  box-shadow: 0px 5px 5px rgba(0, 0, 0, 0.1);
  border-radius: 28px;
  z-index: 2;
  cursor: pointer;
}

.dkn-single-combo-details-wrapper svg {
  width: 14px;
  height: 14px;
}

.dkn-single-combo-details-wrapper .dkn-slider__arrow--next {
  right: -14px !important;
}

.dkn-single-combo-details-wrapper .dkn-slider__arrow--prev {
  left: -14px !important;
}

.dkn-single-combo-details-wrapper .dkn-slider__arrow svg path {
  fill: #1A181E;
}

.dkn-single-combo-details-wrapper .dkn-product-card-variant-item {
  text-align: center;
}

.dkn-single-combo-products-list::-webkit-scrollbar {
  display: none;
}

.without-cart-add-to-bag-button.out-of-stock-text {
  border: none !important;
  background: rgba(229, 11, 32, 0.1) !important;
  opacity: 0.4 !important;
  color: var(--secondary-red) !important;
  cursor: not-allowed;
  text-align: center;
  width: 100%
}

.dkn-single-combo-add-button .add-to-bag-button-wrapper .without-cart-add-to-bag-button {
  width: 100%;
  height: auto;
  border-radius: 0px;
  overflow: hidden;
  background: var(--primary);
  color: var(--white);
  border: 1px solid var(--primary);
}

@media screen and (min-width: 1024px) {
  .dkn-single-combo-products-list {
    width: calc(100% + 32px);
    margin: 0px -16px;
  }
  .dkn-single-combo-products-list .dkn-product-card {
    width: calc((100% - 96px) / 3) !important;
    min-width: calc((100% - 96px) / 3) !important;
    max-width: calc((100% - 96px) / 3) !important;
    margin: 16px;
  }

  .dkn-single-combo-view-btn {
    width: calc(50% - 8px);
    min-width: calc(50% - 8px);
    margin-right: 8px;
    margin-bottom: 0px;
  }

  .dkn-single-combo-add-button{
    width: calc(50% - 8px);
    min-width: calc(50% - 8px);
    margin-left: 8px;
    margin-bottom: 0px;
  }

  .dkn-single-combo-details-wrapper .dkn-slider__arrow {
    position: absolute;
    top: calc(50% - 40px);
    width: 40px;
    height: 40px;
    background: #ffffff;
    border: 1px solid #d9d9d9;
    box-shadow: 0px 5px 5px rgba(0, 0, 0, 0.1);
    border-radius: 20px;
    z-index: 2;
    cursor: pointer;
  }

  .dkn-single-combo-details-wrapper .dkn-slider__arrow--next {
    right: -20px !important;
  }

  .dkn-single-combo-details-wrapper .dkn-slider__arrow--prev {
    left: -20px !important;
  }

  .dkn-single-combo-details-wrapper svg {
    width: 16px;
    height: 16px;
  }

  .dkn-single-combo-products-list .dkn-product-card:not(:last-child)::after {
    right: -22px;
    font-size: 18px;
    top: calc(50% - 18px);
  }
}
.text-16-m14 {
  font-size: 14px !important;
  line-height: 20px !important;
}
@media screen and (min-width: 767px) {
  .text-16-m14 {
    font-size: 16px !important;
    line-height: 24px !important;
  }
}

@media screen and (max-width: 1023px) {
  .dkn-single-combo-view-btn {
    margin-bottom: 12px;
  }
}

        </style>
         <template id="dkn-product-card-combo-list-template">
        <div class="dkn-product-card ba-product-card flex d-column justify-content-between position-relative">
          <div class="dkn-product-card-soldout-badge hidden">Sold out</div>
          <div class="dkn-product-card-bxgy-badge"
               data-product-id
               data-product-uuid
               style="visibility: hidden; position: absolute;">
          </div>
          <div class="dkn-product-card-badge hidden"
               data-product-id
               data-product-uuid>
          </div>
<!--          <div class="dkn-product-card-discount-badge hidden">-->
<!--          </div>-->
          <div class="flex d-column justify-content-between">
            <div class="relative mb-2 m-mb6" style="border: 1px solid var(--black-90); border-radius: 4px; overflow: hidden; aspect-ratio: 1/1">
              <div class="product-image">
                <a>
                  <img class="dkn-product-card-image"
                       loading="lazy"
                       src=""
                       style="width: 100%"
                       onerror="imageOnError(event)"/>
                </a>
              </div>
            </div>
            <div class="flex d-column a-c">
              <a class="product-name dkn-product-card-name font-regular text-14_16 mb-2 lineClamp2 text-center" style="margin-top: 8px; margin-bottom: 6px">
              </a>
              <div class="dkn-product-card-description text-center hidden text-12_16 mb-2"
                   style="color: #057508">
              </div>
              <div class="dkn-product-card-review-info mb-2 hidden"
                   data-product-id>
              </div>
              <div class="dkn-product-card-variant-items hidden flex flex-wrap mb-2 j-c a-c" style="margin-bottom: 4px"></div>
              <div class="product-price-tag flex a-c j-c mb-2 flex-wrap">
  <div class="product-selling-price dkn-product-card-selling-price text-16-m14 font-semibold"> </div>
  <div
    class="product-original-price dkn-product-card-original-price text-12_16 text-lg-14_20 font-regular strikethrough"
    style="color: var(--black-50); margin-left: 4px">
  </div>
  <div
    class="dkn-product-card-discount text-12_16 text-lg-14_20 font-regular"
    style="color: var(--secondary-green); margin-left: 4px">
  </div>
</div>
            </div>
          </div>
          <add-to-bag-button data-add-event="HOME_PAGE_PRODUCT_ADDED" data-product-uuid=""
          class="w-100 h-auto">
          ADD TO CART
          </add-to-bag-button>
        </div>
      </template>`;
    q$.select('body').elem.appendChild(tempdiv);
    fetchAndRenderProductsFromAdvanceFilters(
      { product_ids: productIds },
      {
        areBundleProducts: true,
        bundleProduct: combo,
        wrapperElement: q$.select(
          '.dkn-single-combo-products-list-wrapper',
          parentElement
        ).elem,
        mountElement: q$.select(
          '.dkn-single-combo-products-list',
          parentElement
        ).elem,
        offset:
          q$.select('.dkn-single-combo-products-list-wrapper').elem
            .offsetWidth + (isMobile ? 24 : 32),
        additionalRenderer: window.bundleProductAdditionalRenderer,
        templateId: 'dkn-product-card-combo-list-template',
      }
    ).then((products) => {
      const bundleIsOutOfStock =
        products.filter(
          (item) =>
            item?.skus?.filter((sku) => sku.inventory === 0)?.length > 0 ||
            item?.in_stock === false
        )?.length > 0;
      if (
        bundleIsOutOfStock &&
        DukaanData.PRODUCTS_MAP[combo.uuid]?.skus?.[0]
      ) {
        DukaanData.PRODUCTS_MAP[combo.uuid].skus[0].inventory = 0;
        DukaanData.PRODUCTS_MAP[combo.uuid].skus[0].inventory_quantity = 0;
      }

      addToBagButtonRenderer(
        q$.select(
          'add-to-bag-button.dkn-single-combo-add-button',
          parentElement
        ).elem
      );
    });
  };

  fetch(
    `${window.DukaanData.CLIENT_API_ENDPOINT}/api/product/buyer/${DukaanData.DUKAAN_STORE.link}/retrieve-applicable-product-bundles/`,
    {
      method: 'post',
      body: JSON.stringify({
        product_ids: [product.id],
      }),
      headers: {
        'Content-Type': 'application/json',
        'x-requested-with': window?.DukaanData?.DUKAAN_SESSION_ID,
      },
    }
  )
    .then((res) => res.json())
    .then((res) => {
      const bundleProductIds = res?.data?.[product?.id] || [];
      if (!bundleProductIds?.length) {
        q$.selectAll('pdp-bundles-load-point').addClassAll('hidden');
        return;
      }
      fetch(
        `${window.DukaanData.DUKAAN_ADVANCED_SEARCH_API_BASE_URL}/api/advanced-search/${window.DukaanData.DUKAAN_STORE.id}/`,
        {
          method: 'post',
          body: JSON.stringify({
            product_ids: bundleProductIds,
            page_size: bundleProductIds.length,
            product_type: [2],
          }),
          headers: {
            Accept: 'application/json',
            'Content-Type': 'application/json',
            'x-requested-with': window?.DukaanData?.DUKAAN_SESSION_ID,
          },
        }
      )
        .then((resp) => resp.json())
        .then((resp) => {
          const products = resp?.data?.products || [];
          if (products?.length) {
            renderBundleOptionsOnPDP(products);
            const comboBundle =
              products.filter(
                (item) => item?.product_bundle_type === 'combo'
              )?.[0] || null;
            renderAvailableComboOnPDP(comboBundle);
          } else {
            q$.selectAll('pdp-bundles-load-point').addClassAll('hidden');
          }
        })
        .catch(() => {});
    })
    .catch(() => {});
};

window.renderComboProductsOnPDP = (products) => {
  if (!products?.length) {
    q$.select('combo-products-load-point').addClass('hidden');
    return;
  }
  q$.select('combo-products-load-point').removeClass('hidden');
  const mountElem = q$.select(
    'combo-products-load-point .combo-products-list'
  ).elem;

  const div = document.createElement('div');
  div.innerHTML = `<style>
  .dkn-product-card.combo-product-item {
    box-shadow: none;
    border-radius: 0px;
    padding: 16px 0px;
    background-color: transparent
  }
  .dkn-product-card.combo-product-item:not(:last-child){
    border-bottom: 1px solid var(--black-90);
  }
  .dkn-product-card-variant-item:not(:last-child){
    border-right: 1px solid var(--black-85);
  }
  .col-2 {
    width: 20%;
  }
  .col-10 {
    width: 80%;
  }
</style>
<template id="combo-product-item-template">
  <div class="combo-product-item dkn-product-card flex a-c">
    <img class="dkn-product-card-image h-100 col-2" style="aspect-ratio: 1/1; object-fit: contain;" />
    <div class="flex d-column align-items-start justify-content-start col-10" style="padding-left: 12px">
      <a class="dkn-product-card-name text-16-m14 lineClamp2"></a>
      <div class="dkn-product-card-variant-items hidden mt-1 flex flex-wrap"></div>
      <div class="dkn-product-card-price flex a-c mt-1">
        <div class="dkn-product-card-selling-price font-medium me-1 text-c-black text-16-m14"></div>
        <div class="dkn-product-card-original-price font-regular me-1 strikethrough text-c-black-50 text-16-m14"></div>
        <div class="dkn-product-card-discount text-c-secondary text-16-m14"></div>
      </div>
    </div>
  </div>
</template>`;

  q$.select('body').elem.appendChild(div);

  productListRenderer(mountElem, products, {
    templateId: `combo-product-item-template`,
    additionalRenderer: window.bundleProductAdditionalRenderer,
  });
};

window.handleImageChange = (itemNo) => {
  click = itemNo;
  removeInactiveClasses();
  pauseAllProductVideos();
  const clickedthumbnail = document.getElementById(`carousel-item-${itemNo}`);
  const thumbnails = document.querySelectorAll('.active');
  const thumbnailList = [...thumbnails];

  thumbnailList.forEach((thumbnailItem) => {
    thumbnailItem.classList.remove('active');
    thumbnailItem.classList.add('white-overlay');
  });
  const imageLink = clickedthumbnail.src;
  q$.selectAll('#main-carousel-image').setAttributeAll('src', imageLink);
  const mainImageContainer = document.getElementById('mainImgContainer');
  if (mainImageContainer) {
    mainImageContainer.setAttribute('data-index', itemNo);
    const videoLink = imageLink;
    mainImageContainer.setAttribute('data-video-image-link', imageLink);
    mainImageContainer.setAttribute('onclick', 'playProductVideo(event)');
    if (videoLink && isVideoImageLink(videoLink)) {
      q$.select('.pdp-only-image-wrapper', mainImageContainer).addClass(
        'hidden'
      );
      q$.select(
        '.splide-video-icon-image-wrapper',
        mainImageContainer
      ).removeClass('hidden');
    } else {
      q$.select(
        '.splide-video-icon-image-wrapper',
        mainImageContainer
      ).addClass('hidden');
      q$.select('.pdp-only-image-wrapper', mainImageContainer).removeClass(
        'hidden'
      );
    }
  }
  clickedthumbnail.classList.remove('white-overlay');
  clickedthumbnail.classList.add('active');
};

window.click = 0;
window.leftIcon = document.getElementById('caret-left-icon');
window.rightIcon = document.getElementById('caret-right-icon');
window.wrapperElement = document.getElementById('thumbnail-wrapper');
window.mobileWrapperElement = document.getElementById(
  'mobile-carousel-wrapper'
);
window.slides = document.querySelectorAll('.mobile-slider-item');

window.removeInactiveClasses = () => {
  if (leftIcon && leftIcon.classList.contains('inactive-icon')) {
    leftIcon.classList.remove('inactive-icon');
  }
  if (rightIcon && rightIcon.classList.contains('inactive-icon')) {
    rightIcon.classList.remove('inactive-icon');
  }
};

window.handlePrevClick = () => {
  click -= 1;
  if (click >= 0) {
    window.removeInactiveClasses();
    wrapperElement.scrollBy({ left: -130, behavior: 'smooth' });
    handleImageChange(click);
    if (click === 0) {
      click = 0;
      leftIcon.classList.add('inactive-icon');
    }
  } else {
    click = 0;
    leftIcon.classList.add('inactive-icon');
  }
};

window.handleNextClick = () => {
  click += 1;
  if (click < DukaanData.DUKAAN_PRODUCT.all_images.length) {
    removeInactiveClasses();
    wrapperElement.scrollBy({ left: +130, behavior: 'smooth' });
    handleImageChange(click);
    if (click === DukaanData.DUKAAN_PRODUCT.all_images.length - 1) {
      click = DukaanData.DUKAAN_PRODUCT.all_images.length - 1;
      rightIcon.classList.add('inactive-icon');
    }
  } else {
    click = DukaanData.DUKAAN_PRODUCT.all_images.length - 1;
    rightIcon.classList.add('inactive-icon');
  }
};

window.handleMobileImageChange = (index) => {
  removeActiveClassMobile();
  pauseAllProductVideos();
  const controlDot = document.getElementById(`control-dot-${index}`);
  slides.forEach((slide, indx) => {
    slide.style.transform = `translateX(${100 * (indx - index)}%)`;
  });
  controlDot.classList.add('control-dot-active');
};

window.handleMobileScrollRight = () => {
  click += 1;
  if (click < DukaanData.DUKAAN_PRODUCT.all_images.length) {
    handleMobileImageChange(click);
  } else click = DukaanData.DUKAAN_PRODUCT.all_images.length - 1;
};

window.handleMobileScrollLeft = () => {
  click -= 1;
  if (click >= 0) {
    handleMobileImageChange(click);
  } else click = 0;
};

window.handleMobileDotClick = (index) => handleMobileImageChange(index);

window.removeActiveClassMobile = () => {
  const controlDots = document.querySelectorAll('.control-dot-active');
  const controlDotList = [...controlDots];

  controlDotList.forEach((item) => {
    item.classList.remove('control-dot-active');
  });
};

window.handleCategoryScroll = (e) => {
  const { target } = e;

  if (target.scrollLeft === 0) leftIcon?.classList.add('inactive-icon');
  else leftIcon?.classList.remove('inactive-icon');

  if (target.scrollWidth - 30 <= target.clientWidth + target.scrollLeft)
    rightIcon?.classList.add('inactive-icon');
  else rightIcon?.classList.remove('inactive-icon');
};

window.touchstartX = 0;
window.touchendX = 0;

window.handleGesture = () => {
  if (touchendX < touchstartX) {
    handleMobileScrollRight();
  }
  if (touchendX > touchstartX) {
    handleMobileScrollLeft();
  }
};

window.handleTouchEnd = (e) => {
  touchendX = e.changedTouches[0].screenX;
  handleGesture();
};

window.handleTouchStart = (e) => {
  touchstartX = e.changedTouches[0].screenX;
};

window.fetchSimilarProducts = (productFromServer, categoryIdListFromProp) => {
  const { upsell_enabled: upsellEnabled = true } =
    DukaanData?.DUKAAN_STORE?.preferences?.upsell_cross_sell_plugin || {};
  let categoryIds = [];

  if (categoryIdListFromProp?.length) {
    categoryIds =
      categoryIdListFromProp
        ?.map((item) => Number(item))
        ?.filter((item) => !!item) || [];
  } else {
    categoryIds =
      DukaanData?.DUKAAN_PRODUCT?.categories?.map((category) => category.id) ||
      [];
  }

  if (
    !categoryIds?.length ||
    !upsellEnabled ||
    DukaanData.DUKAAN_PAGE_KEY === 'bundle'
  ) {
    const wrapper = document.querySelector('.similar-products-wrapper');
    if (wrapper) {
      wrapper.classList.add('hidden');
    }
    return;
  }

  fetch(
    `${window.DukaanData.DUKAAN_ADVANCED_SEARCH_API_BASE_URL}/api/advanced-search/${window.DukaanData.DUKAAN_STORE.id}/`,
    {
      method: 'post',
      body: JSON.stringify({
        category_ids: categoryIds || [],
        offset: 0,
        page_size: 30,
        show_out_of_stock_products: true,
        push_oos_products_to_bottom: true,
        continue_selling_when_oos: true,
      }),
      headers: {
        'Content-Type': 'application/json',
        'x-requested-with': window?.DukaanData?.DUKAAN_SESSION_ID,
        // 'Content-Type': 'application/x-www-form-urlencoded',
      },
    }
  )
    .then((res) => res.json())
    .then((res) => {
      let { products: rawProducts = [] } = res?.data || {};
      const { productIds } = getBundleApplicablityData(
        DukaanData.DUKAAN_PRODUCT
      );
      rawProducts = rawProducts.filter(
        (product) =>
          product.id !== DukaanData.DUKAAN_PRODUCT.id &&
          !productIds?.includes(product.id)
      );
      const { isMobile } = deviceType();
      const defaultProductLimit = isMobile ? 6 : 12;
      let productLimit = defaultProductLimit;
      if (typeof SIMILAR_PRODUCT_LIMIT !== 'undefined') {
        productLimit = SIMILAR_PRODUCT_LIMIT;
      }

      const products = window.languageSerializer(
        rawProducts.slice(0, productLimit)
      );
      const viewAllButtons = document.querySelectorAll(
        '.view-all-button-wrapper'
      );

      if (typeof viewAllButtons !== 'undefined') {
        viewAllButtons.forEach((button) => {
          if (products.length > productLimit) button.classList.remove('hidden');
        });
      }

      hashProductMapper(products);

      if (products?.length === 0) {
        const wrapper = document.querySelector('.similar-products-wrapper');
        if (wrapper) {
          wrapper.classList.add('hidden');
        }
      }

      renderSimilarProducts(products);

      if (typeof renderMinimalProductList !== 'undefined') {
        renderMinimalProductList(products.slice(0, 4));
      }

      if (typeof initProductSplide !== 'undefined') initProductSplide();
      // rendering similar products list splide if exist
      if (typeof renderProductsListSplide !== 'undefined') {
        renderProductsListSplide(products);
      }
    })
    .catch(() => {});
};

window.fetchSimilarProductsOld = () => {
  const { upsell_enabled: upsellEnabled = true } =
    DukaanData?.DUKAAN_STORE?.preferences?.upsell_cross_sell_plugin || {};
  const categoryIds = DukaanData?.DUKAAN_PRODUCT?.categories?.map(
    (category) => category.id
  );
  if (
    !categoryIds?.length ||
    !upsellEnabled ||
    DukaanData.DUKAAN_PAGE_KEY === 'bundle'
  ) {
    const wrapper = document.querySelector('.similar-products-wrapper');
    if (wrapper) {
      wrapper.classList.add('hidden');
    }
    return;
  }
  fetch(
    `${window.DukaanData.DUKAAN_ADVANCED_SEARCH_API_BASE_URL}/api/advanced-search/${window.DukaanData.DUKAAN_STORE.id}/`,
    {
      method: 'post',
      body: JSON.stringify({
        category_ids: categoryIds || [],
        offset: 0,
        page_size: 30,
        product_attrs: {},
        sku_attrs: {},
        sort_by: '',
      }),
      headers: {
        'Content-Type': 'application/json',
        'x-requested-with': window?.DukaanData?.DUKAAN_SESSION_ID,
        // 'Content-Type': 'application/x-www-form-urlencoded',
      },
    }
  )
    .then((res) => res.json())
    .then((res) => {
      let { products: rawProducts = [] } = res?.data || {};
      rawProducts = rawProducts.filter(
        (product) => product.id !== DukaanData.DUKAAN_PRODUCT.id
      );
      const products = rawProducts.slice(
        0,
        roundToMultiple(rawProducts.length, 4)
      );
      renderSimilarProductsOld(products);

      if (typeof initProductSplide !== 'undefined') initProductSplide();

      const { isMobile } = deviceType();
      const defaultProductLimit = isMobile ? 6 : 12;
      let productLimit = defaultProductLimit;

      if (typeof SIMILAR_PRODUCT_LIMIT !== 'undefined') {
        productLimit = SIMILAR_PRODUCT_LIMIT;
      }

      const viewAllButtons = document.querySelectorAll(
        '.view-all-button-wrapper'
      );

      if (typeof viewAllButtons !== 'undefined') {
        viewAllButtons.forEach((button) => {
          if (products.length > productLimit) button.classList.remove('hidden');
        });
      }

      hashProductMapper(products);

      // DukaanData.PRODUCTS_MAP = {
      //   ...DukaanData.PRODUCTS_MAP,
      //   ...products.reduce((map, product) => {
      //     const serializedSKUs = serializeSKUs(product.skus || []);
      //     const attributes = getAllProductAttributeValues(serializedSKUs);
      //     map[product.uuid] = { ...product, skus: serializedSKUs, attributes };
      //     return map;
      //   }, {}),
      // };

      // rendering similar products list splide if exist
      if (typeof renderProductsListSplide !== 'undefined') {
        renderProductsListSplide(products);
      }
    })
    .catch(() => {});
};

window.renderSimilarProducts = (products, customParentSelector) => {
  customTag(
    `${
      customParentSelector ? `${customParentSelector} ` : ''
    }similar-products-list`,
    (element) => {
      similarProductsRenderer(element, products, {
        addToBagEventName: 'PDP_SUGGESTIONS_PRODUCT_ADDED',
      });
    },
    { isQuerySelector: true }
  );
};

window.renderSimilarProductsOld = (products, customParentSelector = '') => {
  customTag(
    `${
      customParentSelector ? `${customParentSelector} ` : ''
    }similar-products-list`,
    (element) => {
      similarProductsRendererOld(element, products);
    },
    { isQuerySelector: true }
  );
};

window.similarProductsRenderer = (mountElement, products, options = {}) => {
  if (!products.length) {
    const wrapper = document.querySelector('.similar-products-wrapper');
    if (wrapper) {
      wrapper.classList.add('hidden');
    }
    return;
  }

  window.productListRenderer(mountElement, products, {
    ...options,
    templateId: window.productCardTemplateId || 'similar-product-card',
    getCustomDiscountText: window.getCustomDiscountText,
    additionalRenderer: window.productCardAdditionalRenderer,
    productCardClasses: window.similarProductCardClasses,
    reviewInfoTemplateId: window?.productCardReviewTemplateId,
  });
};

window.similarProductsRendererOld = (mountElement, products) => {
  mountElement.innerHTML = '';
  const similarProductCardTemplate = document.getElementById(
    'similar-product-card'
  );
  if (!products.length) {
    const wrapper = document.querySelector('.similar-products-wrapper');
    if (wrapper) {
      wrapper.classList.add('hidden');
    }
    return;
  }

  // window.productListRenderer(mountElement, products, {
  //   templateId: 'similar-product-card',
  //   getCustomDiscountText: window.getCustomDiscountText,
  //   additionalRenderer: window.productCardAdditionalRenderer,
  // });

  products.forEach((product) => {
    const similarProductCard = document.importNode(
      similarProductCardTemplate.content,
      true
    );
    similarProductCard.querySelectorAll('a').forEach((el) => {
      el.setAttribute(
        'href',
        `${DukaanData.DUKAAN_BASE_URL}/products/${product.slug}`
      );
      el.setAttribute('data-product-uuid', product.uuid);
    });
    if (similarProductCard.querySelector('.product-name')) {
      similarProductCard.querySelector('.product-name').textContent =
        product.name;
    }

    const originalPrice = product.original_price;
    const sellingPrice = product.selling_price;

    if (
      (((originalPrice - sellingPrice) / originalPrice) * 100).toFixed(0) > 0
    ) {
      if (similarProductCard.querySelector('.product-discount-badge')) {
        const discount = (
          ((originalPrice - sellingPrice) / originalPrice) *
          100
        ).toFixed(0);
        similarProductCard.querySelector(
          '.product-discount-badge'
        ).textContent =
          typeof discountBadgeFormatter !== 'undefined'
            ? discountBadgeFormatter(discount)
            : `(${discount}% OFF)`;
      }
    } else {
      similarProductCard
        .querySelector('.product-discount-badge')
        ?.classList.add('hidden');
    }

    // renders product slideshow with splide if exist.
    const productSplideTemplate = document.querySelector(
      '#product-splide-container'
    );
    if (productSplideTemplate) {
      if (typeof productSplideRenderer !== 'undefined') {
        productSplideRenderer(
          productSplideTemplate,
          product,
          similarProductCard
        );
        const splideProgressBar = similarProductCard.querySelector(
          '.splide-progress-bar'
        );
        if (splideProgressBar) {
          splideProgressBar.style['-webkit-animation-duration'] = `${
            1500 * product.all_images.length
          }ms`;
        }
      }
    }

    if (similarProductCard.querySelector('.product-image')) {
      similarProductCard
        .querySelector('.product-image')
        .setAttribute(
          'src',
          `${getCdnUrl(
            product.image,
            window?.DukaanData?.PRODUCT_IMAGE_CDN_SIZE || 700
          )}`
        );
    }

    const productBadges = (bxgyData, onSaleBool, inStock) => {
      if (inStock) {
        if (bxgyData?.length > 0) {
          const bxgyBadge = similarProductCard.querySelector('.bxgy-badge'); // BXGY class for product page
          if (bxgyBadge) {
            bxgyBadge.classList.remove('hidden');
            bxgyBadge.textContent = getBXGYText(product.coupon_data);
          }
        } else if (onSaleBool) {
          const onSaleBadge =
            similarProductCard.querySelector('.on-sale-badge');
          if (onSaleBadge) {
            onSaleBadge.classList.remove('hidden');
          }
        }
      } else {
        const soldOutBadge =
          similarProductCard.querySelector('.sold-out-badge');
        if (soldOutBadge) {
          soldOutBadge.classList.remove('hidden');
        }
      }
    };

    if (similarProductCard.querySelector('.pricing-label')) {
      if (!product.in_stock) {
        similarProductCard
          .querySelector('.pricing-label')
          .classList.add('hidden');
        similarProductCard
          .querySelector('.out-of-stock-label')
          .classList.remove('hidden');
      }
    }

    if (similarProductCard.querySelector('.product-unit') !== null) {
      similarProductCard.querySelector('.product-unit').textContent = `${
        DukaanData.DUKAAN_LANGUAGE.PER
      }${product.base_qty === 1 ? '' : ` ${product.base_qty}`} ${product.unit}`;
    }
    if (similarProductCard.querySelector('.product-selling-price') !== null) {
      similarProductCard.querySelector('.product-selling-price').textContent =
        formatMoney(sellingPrice);
    }
    if (similarProductCard.querySelector('.product-original-price') !== null) {
      if (originalPrice === sellingPrice) {
        similarProductCard
          .querySelector('.product-original-price')
          .classList.add('hidden');
      } else {
        similarProductCard
          .querySelector('.product-original-price')
          .classList.remove('hidden');
        similarProductCard.querySelector(
          '.product-original-price'
        ).textContent = formatMoney(originalPrice);
      }
    }

    if (similarProductCard.querySelector('add-to-bag-button-with-variants')) {
      similarProductCard.querySelector(
        'add-to-bag-button-with-variants'
      ).dataset = `${formatMoney(sellingPrice)}`;
      const addToBagElement = similarProductCard.querySelector(
        'add-to-bag-button-with-variants'
      );
      addToBagElement.dataset.productUuid = product.uuid;
      addToBagButtonWithVariantsRenderer(addToBagElement);
    }

    if (similarProductCard.querySelector('.product-discount') !== null) {
      if (originalPrice === sellingPrice) {
        similarProductCard
          .querySelector('.product-discount')
          .classList.add('hidden');
      } else {
        similarProductCard
          .querySelector('.product-discount')
          .classList.remove('hidden');
        similarProductCard.querySelector(
          '.product-discount'
        ).textContent = `(${Math.ceil(
          ((originalPrice - sellingPrice) / originalPrice) * 100
        )}% off)`;
      }
    }
    productBadges(
      product.coupon_data,
      originalPrice > sellingPrice,
      product.in_stock
    );
    if (typeof handleProductCardChange !== 'undefined') {
      handleProductCardChange(similarProductCard, product);
    }

    const wishlistButtonLoadPoint = similarProductCard.querySelector(
      'wishlist-button-load-point'
    );
    if (wishlistButtonLoadPoint) {
      wishlistButtonLoadPoint.setAttribute('data-product-uuid', product.uuid);
    }

    mountElement.appendChild(similarProductCard);
  });

  if (typeof dknRenderWishlistButtons !== 'undefined') {
    window.dknRenderWishlistButtons(mountElement);
  }

  if (typeof dknRenderNotifyMeButtons !== 'undefined') {
    window.dknRenderNotifyMeButtons(mountElement);
  }
};

window.scrollCarouselToSKUImage = (activeSKU) => {
  if (typeof splide !== 'undefined' && !!splide) {
    const primaryImage = activeSKU.primary_image;
    const allImages = DukaanData.DUKAAN_PRODUCT.all_images;
    if (allImages.length > 0) {
      const index = allImages.indexOf(primaryImage);
      if (index >= 0) window?.splide?.go(index);
    }
  }
};

window.toTitleCase = (str) =>
  str.replace(
    /\w\S*/g,
    (txt) => txt.charAt(0).toUpperCase() + txt.substr(1).toLowerCase()
  );

window.setActiveSkuIdInParams = (activeSKU) => {
  const paramString = new URLSearchParams(window.location.search);
  paramString.set('sku_id', activeSKU.id);
  window.history.replaceState(
    {},
    '',
    `${window.location.origin}${
      window.location.pathname
    }?${paramString.toString()}`
  );
};

window.reRenderProductDetails = (element, activeSKU, productDetails) => {
  setActiveSkuIdInParams(activeSKU);
  const productDiscount = (
    ((activeSKU.original_price - activeSKU.selling_price) /
      activeSKU.original_price) *
    100
  ).toFixed(0);
  const discountAttribute = productDetails.metafields.find((attribute) => {
    return attribute.key === 'Discounting Type';
  });
  if (typeof scrollToSKUImage !== 'undefined') {
    scrollToSKUImage(activeSKU);
  } else {
    scrollCarouselToSKUImage(activeSKU);
  }
  if (typeof pdpCouponsRenderder !== 'undefined')
    pdpCouponsRenderder(activeSKU?.selling_price);

  if (element.querySelector('.product-unit')) {
    element.querySelector('.product-unit').textContent = `${
      DukaanData.DUKAAN_LANGUAGE.PER
    }${
      !!productDetails.base_qty && productDetails.base_qty === 1
        ? ''
        : ` ${productDetails.base_qty}`
    } ${activeSKU.unit || productDetails.unit}`;
  }
  q$.select('.product-selling-price', element).modifyTextContent(
    formatMoney(activeSKU.selling_price)
  );
  if (activeSKU.original_price === activeSKU.selling_price) {
    element.querySelector('.product-original-price')?.classList?.add('hidden');
    element.querySelector('.product-savings-text')?.classList?.add('hidden');
  } else {
    element
      .querySelector('.product-original-price')
      ?.classList?.remove('hidden');
    element.querySelector('.product-savings-text')?.classList?.remove('hidden');
    element.querySelector('.product-original-price').textContent = formatMoney(
      activeSKU.original_price
    );
    if (element.querySelector('.product-savings')) {
      element.querySelector('.product-savings').textContent = formatMoney(
        activeSKU.original_price - activeSKU.selling_price
      );
    }
  }
  if (element.querySelector('.stock-left-message')) {
    if (activeSKU.inventory <= 10 && !!activeSKU.inventory) {
      element.querySelector('.stock-left-message').classList.remove('hidden');
      element.querySelector('.stock-left-message').textContent =
        `${DukaanData.DUKAAN_LANGUAGE.ONLY__INVENTORY_LEFT_IN_STOCK_HURRY_UP}!`.injectText(
          {
            inventory: activeSKU.inventory,
          }
        );
    } else {
      element.querySelector('.stock-left-message').classList.add('hidden');
      element.querySelector('.stock-left-message').textContent = ``;
    }
  }
  if (productDiscount > 0 && element.querySelector('.product-discount-badge')) {
    element.querySelector('.product-discount-badge').classList.remove('hidden');
    element.querySelector('.product-discount-badge').textContent =
      typeof discountBadgeFormatter !== 'undefined'
        ? discountBadgeFormatter(Math.round(productDiscount))
        : `(${Math.round(productDiscount)}% OFF)`;
  } else {
    element.querySelector('.product-discount-badge')?.classList.add('hidden');
  }
  const discountBadge = element.querySelector('.product-discount-badge');

  if (
    discountAttribute &&
    discountAttribute?.value === 'Absolute value' &&
    discountBadge
  ) {
    discountBadge.textContent = `(${formatMoney(
      activeSKU.original_price - activeSKU.selling_price
    )} OFF)`;
    discountBadge.classList.remove('hidden');
  } else if (productDiscount > 0 && discountBadge) {
    const discount = Math.round(productDiscount);
    discountBadge.textContent =
      typeof discountBadgeFormatter !== 'undefined'
        ? discountBadgeFormatter(discount)
        : `(${discount}% OFF)`;
    discountBadge?.classList.remove('hidden');
  } else {
    discountBadge?.classList.add('hidden');
  }

  const stockText = element.querySelector('.dkn-product-stock-text');
  if (stockText) {
    if (activeSKU.in_stock) {
      stockText.textContent = DukaanData.DUKAAN_LANGUAGE.IN_STOCK;
      stockText.classList.add('text-c-green', 'text-success');
      stockText.classList.remove('text-c-red', 'text-danger');
    } else {
      stockText.textContent = DukaanData.DUKAAN_LANGUAGE.OUT_OF_STOCK;
      stockText.classList.remove('text-c-green', 'text-success');
      stockText.classList.add('text-c-red', 'text-danger');
    }
  }

  if (activeSKU?.sku_code) {
    q$.selectAll('.dkn-product-sku-code', element).modifyTextContentAll(
      activeSKU.sku_code
    );
    q$.selectAll('.dkn-product-sku-code-wrapper', element).removeClassAll(
      'hidden'
    );
  } else {
    q$.selectAll('.dkn-product-sku-code-wrapper', element).addClassAll(
      'hidden'
    );
  }
  const inventory = activeSKU.inventory_quantity;
  if (inventory !== null && inventory > 0) {
    q$.selectAll(
      '.dkn-product-active-sku-inventory',
      element
    ).modifyTextContentAll(inventory);
    q$.selectAll(
      '.dkn-product-active-sku-inventory-wrapper',
      element
    ).removeClassAll('hidden');
  } else {
    q$.selectAll(
      '.dkn-product-active-sku-inventory-wrapper',
      element
    ).addClassAll('hidden');
  }
  if (inventory !== null && inventory > 0 && inventory < 100) {
    q$.select('.pdp-last-units-text', element)
      .removeClass('hidden')
      .modifyTextContent(
        `Last ${inventory} ${pluralize(inventory, 'unit')} left`
      );
    q$.select('.pdp-units-separator', element).removeClass('hidden');
  } else {
    q$.select('.pdp-last-units-text', element)
      .addClass('hidden')
      .modifyTextContent(``);
    q$.select('.pdp-units-separator', element).addClass('hidden');
  }
  const whatsAppLink = `https://wa.me/?text=${encodeURIComponent(`
    Product Name: ${productDetails?.name}\n Price: ${formatMoney(
    activeSKU?.selling_price
  )} \n SKU Code: ${activeSKU?.sku_code}\n Product Link: ${
    DukaanData?.CURRENT_URL
  }`)}`;

  q$.select('.dkn-whatsapp-button-link').setAttribute('href', whatsAppLink);

  if (activeSKU?.attributes?.[0]?.value && productDetails?.skus?.length > 0) {
    q$.select('.product-page__product-name-with-variants').modifyTextContent(
      `${productDetails?.name} - ${activeSKU?.attributes?.[0]?.value}`
    );
  }
  // for bioayurveda
  if (typeof renderBestBeforeAttribute === 'function') {
    renderBestBeforeAttribute(element, activeSKU);
  }

  if (typeof customProductDetailsRenderer === 'function') {
    customProductDetailsRenderer(activeSKU);
  }
};

window.getTodayPlusXDays = (days) => {
  const today = new Date();
  const resultDate = new Date(today);
  resultDate.setDate(today.getDate() + Number(days));
  return resultDate;
};
window.formatEstimatedDeliveryDate = (estimatedDate) => {
  const months = [
    'January',
    'February',
    'March',
    'April',
    'May',
    'June',
    'July',
    'August',
    'September',
    'October',
    'November',
    'December',
  ];
  const days = [
    'Sunday', // Adjusted to start with Sunday to align with getDay() indexing
    'Monday',
    'Tuesday',
    'Wednesday',
    'Thursday',
    'Friday',
    'Saturday',
  ];
  const dayIndex = estimatedDate.getDay();
  const monthIndex = estimatedDate.getMonth();
  const date = estimatedDate.getDate();

  return `${days[dayIndex]}, ${date} ${months[monthIndex]}`; // Adjusted format to include day name at the start
};

window.handlePincodeChange = (e, customElm = null, customCondition = null) => {
  const value = e?.target?.value;
  let element = document;
  let condition = value.length < 6;

  if (customElm) element = document.querySelector(`#${customElm}`);
  if (customCondition) condition = customCondition;

  if (condition) {
    const wrapper = element.querySelector('.pin-check-messages-section');
    wrapper.querySelector('.success-message')?.classList.add('hidden');
    wrapper.querySelector('.error-message')?.classList.add('hidden');
    element.querySelector('.check-button')?.classList.add('disabled');
  } else {
    element.querySelector('.check-button')?.classList.remove('disabled');
  }
};

window.renderPinSuccessMessage = (data, customElm) => {
  let element = document;
  if (customElm) element = document.querySelector(`#${customElm}`);

  const wrapper = element.querySelector('.pin-check-messages-section');
  wrapper.querySelector('.success-message').classList.remove('hidden');
  wrapper.querySelector('.error-message').classList.add('hidden');
  const deliveryInNDays =
    Number(data.fastest_delivery_days) || Number(data.slowest_delivery_days);
  const estimatedDeliveryDate = getTodayPlusXDays(deliveryInNDays);
  const message = formatEstimatedDeliveryDate(estimatedDeliveryDate);
  wrapper.querySelector(
    '.success-message .formatted-date'
  ).innerHTML = `${message}`;
};

// offduty pincode success msg
window.renderPincodeSuccessMessage = (data) => {
  const wrapper = document.querySelector('.pin-check-messages-section');
  wrapper.querySelector('.success-message').classList.remove('hidden');
  wrapper.querySelector('.error-message').classList.add('hidden');
  const fastestDeliveryDays = +data.delivery_time.slice(0, 1);
  const slowestDeliveryDays = +data.delivery_time.slice(2, 3);
  const estimatedDeliveryDate = getTodayPlusXDays(
    fastestDeliveryDays || slowestDeliveryDays
  );
  const message = formatEstimatedDeliveryDate(estimatedDeliveryDate);
  wrapper.querySelector(
    '.success-message .formatted-date'
  ).innerHTML = `${message}`;

  const isCOD = data.cod_serviceable;
  if (isCOD === true) {
    document.querySelector('.cod-text').innerHTML = `
        <div class="d-flex a-c" style="padding-top: 6px">
          <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path fill-rule="evenodd" clip-rule="evenodd"
              d="M0.351562 4.99961C0.351562 4.08834 1.09029 3.34961 2.00156 3.34961H19.0016C19.9128 3.34961 20.6516 4.08834 20.6516 4.99961V6.34961H22.0016C22.9128 6.34961 23.6516 7.08834 23.6516 7.99961V18.9996C23.6516 19.9109 22.9128 20.6496 22.0016 20.6496H5.00156C4.09029 20.6496 3.35156 19.9109 3.35156 18.9996V17.6496H2.00156C1.09029 17.6496 0.351562 16.9109 0.351562 15.9996V4.99961ZM20.6516 15.9996V7.64961H22.0016C22.1949 7.64961 22.3516 7.80631 22.3516 7.99961V18.9996C22.3516 19.1929 22.1949 19.3496 22.0016 19.3496H5.00156C4.80826 19.3496 4.65156 19.1929 4.65156 18.9996V17.6496H19.0016C19.9128 17.6496 20.6516 16.9109 20.6516 15.9996ZM2.00156 4.64961C1.80826 4.64961 1.65156 4.80631 1.65156 4.99961V15.9996C1.65156 16.1929 1.80826 16.3496 2.00156 16.3496H19.0016C19.1949 16.3496 19.3516 16.1929 19.3516 15.9996V4.99961C19.3516 4.80631 19.1949 4.64961 19.0016 4.64961H2.00156ZM7.7063 5.99963H13.3821C13.7154 5.99963 13.9868 6.24207 13.9868 6.5399C13.9868 6.83773 13.7154 7.08017 13.3821 7.08017L11.7583 7.07966L11.7718 7.09506C12.0204 7.39428 12.2007 7.74072 12.2949 8.1074L12.3051 8.15592L13.3821 8.15635C13.6877 8.15635 13.9412 8.36006 13.9813 8.62342L13.9868 8.69661C13.9868 8.99445 13.7154 9.23688 13.3821 9.23688L12.3076 9.2367L12.2695 9.3895C11.9386 10.5165 10.8206 11.3511 9.49001 11.4138L9.3291 11.4176L9.22355 11.417L12.1846 13.9187C12.3987 14.1051 12.429 14.3968 12.2659 14.6142L12.2044 14.6837C11.9747 14.8997 11.5927 14.9097 11.351 14.7046L7.28596 11.2696C7.17216 11.1679 7.10424 11.0297 7.1043 10.8898C7.09829 10.5894 7.36726 10.3424 7.70898 10.337L9.33095 10.337C10.1156 10.3353 10.7962 9.88973 11.0522 9.25299L11.0575 9.2367L7.7063 9.23688C7.40071 9.23688 7.14722 9.03317 7.10709 8.76981L7.10156 8.69661C7.10156 8.39878 7.37293 8.15635 7.7063 8.15635L11.055 8.15592C10.812 7.5631 10.1938 7.13328 9.46889 7.08475L9.33178 7.08017H7.7063C7.37293 7.08017 7.10156 6.83773 7.10156 6.5399C7.10156 6.24207 7.37293 5.99963 7.7063 5.99963Z"
              fill="#808080" />
          </svg>
          <p class="ms12">${DukaanData.DUKAAN_LANGUAGE.CASH_ON_DELIVERY_AVAIBALE}</p>
        </div>
        `;
  } else {
    document.querySelector('.cod-text').innerHTML = `
        <div class="d-flex a-c" style="padding-top: 6px">
          <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path fill-rule="evenodd" clip-rule="evenodd"
              d="M0.351562 4.99961C0.351562 4.08834 1.09029 3.34961 2.00156 3.34961H19.0016C19.9128 3.34961 20.6516 4.08834 20.6516 4.99961V6.34961H22.0016C22.9128 6.34961 23.6516 7.08834 23.6516 7.99961V18.9996C23.6516 19.9109 22.9128 20.6496 22.0016 20.6496H5.00156C4.09029 20.6496 3.35156 19.9109 3.35156 18.9996V17.6496H2.00156C1.09029 17.6496 0.351562 16.9109 0.351562 15.9996V4.99961ZM20.6516 15.9996V7.64961H22.0016C22.1949 7.64961 22.3516 7.80631 22.3516 7.99961V18.9996C22.3516 19.1929 22.1949 19.3496 22.0016 19.3496H5.00156C4.80826 19.3496 4.65156 19.1929 4.65156 18.9996V17.6496H19.0016C19.9128 17.6496 20.6516 16.9109 20.6516 15.9996ZM2.00156 4.64961C1.80826 4.64961 1.65156 4.80631 1.65156 4.99961V15.9996C1.65156 16.1929 1.80826 16.3496 2.00156 16.3496H19.0016C19.1949 16.3496 19.3516 16.1929 19.3516 15.9996V4.99961C19.3516 4.80631 19.1949 4.64961 19.0016 4.64961H2.00156ZM7.7063 5.99963H13.3821C13.7154 5.99963 13.9868 6.24207 13.9868 6.5399C13.9868 6.83773 13.7154 7.08017 13.3821 7.08017L11.7583 7.07966L11.7718 7.09506C12.0204 7.39428 12.2007 7.74072 12.2949 8.1074L12.3051 8.15592L13.3821 8.15635C13.6877 8.15635 13.9412 8.36006 13.9813 8.62342L13.9868 8.69661C13.9868 8.99445 13.7154 9.23688 13.3821 9.23688L12.3076 9.2367L12.2695 9.3895C11.9386 10.5165 10.8206 11.3511 9.49001 11.4138L9.3291 11.4176L9.22355 11.417L12.1846 13.9187C12.3987 14.1051 12.429 14.3968 12.2659 14.6142L12.2044 14.6837C11.9747 14.8997 11.5927 14.9097 11.351 14.7046L7.28596 11.2696C7.17216 11.1679 7.10424 11.0297 7.1043 10.8898C7.09829 10.5894 7.36726 10.3424 7.70898 10.337L9.33095 10.337C10.1156 10.3353 10.7962 9.88973 11.0522 9.25299L11.0575 9.2367L7.7063 9.23688C7.40071 9.23688 7.14722 9.03317 7.10709 8.76981L7.10156 8.69661C7.10156 8.39878 7.37293 8.15635 7.7063 8.15635L11.055 8.15592C10.812 7.5631 10.1938 7.13328 9.46889 7.08475L9.33178 7.08017H7.7063C7.37293 7.08017 7.10156 6.83773 7.10156 6.5399C7.10156 6.24207 7.37293 5.99963 7.7063 5.99963Z"
              fill="#808080" />
          </svg>
          <p class="ms12">${DukaanData.DUKAAN_LANGUAGE.PREPAID_ONLY}</p>
        </div>
      `;
  }
};

window.renderPinErrorMessage = (customElm) => {
  let element = document;
  if (customElm) element = document.querySelector(`#${customElm}`);

  const wrapper = element.querySelector('.pin-check-messages-section');
  wrapper.querySelector('.success-message').classList.add('hidden');
  wrapper.querySelector('.error-message').classList.remove('hidden');
};

window.handlePinSubmit = (customElm) => {
  let element = document;
  if (customElm) element = document.querySelector(`#${customElm}`);

  element.querySelector('.check-button')?.classList.remove('disabled');
  const formData = new FormData(element.querySelector('.pin-check-form'));
  const data = [...formData.entries()].reduce((acc, [key, value]) => {
    acc[key] = value;
    return acc;
  }, {});
  const { pin } = data;

  if (!pin) {
    renderPinErrorMessage(customElm);
    element.querySelector(
      '.pin-check-messages-section .error-message'
    ).textContent = DukaanData.DUKAAN_LANGUAGE.ENTER_A_VALID_PINCODE;
    return;
  }

  let url = `${window.DukaanData.CLIENT_API_ENDPOINT}/api/order/buyer/store/${window.DukaanData.DUKAAN_STORE.uuid}/estimated-delivery-time/?drop_pincode=${pin}`;
  if (data.twt) {
    url = `${url}&twt=true`;
  }
  fetch(url, {
    method: 'get',
    headers: {
      'Content-Type': 'application/json',
      'x-requested-with': window?.DukaanData?.DUKAAN_SESSION_ID,
      // 'Content-Type': 'application/x-www-form-urlencoded',
    },
  })
    .then((res) => res.json())
    .then((res) => {
      if (res.status_code === 200) {
        renderPinSuccessMessage(res.data, customElm);
        if (DukaanData.DUKAAN_STORE.uuid === TWTUUID) {
          localStorage.setItem('twtBuyerPin', pin);
        }
      } else {
        renderPinErrorMessage(customElm);
      }
    })
    .catch(() => {
      renderPinErrorMessage(customElm);
    });
};

// offduty pincode submit
window.handlePincodeSubmit = () => {
  document.querySelector('.check-button')?.classList.remove('disabled');
  const formData = new FormData(document.querySelector('.pin-check-form'));
  const data = [...formData.entries()].reduce((acc, [key, value]) => {
    acc[key] = value;
    return acc;
  }, {});
  const { pin } = data;

  if (!pin) {
    renderPinErrorMessage();
    document.querySelector(
      '.pin-check-messages-section .error-message'
    ).textContent = DukaanData.DUKAAN_LANGUAGE.ENTER_A_VALID_PINCODE;
    return;
  }

  fetch(
    `${window.DukaanData.CLIENT_API_ENDPOINT}/api/store/buyer/pincode-checker-plugin/${window.DukaanData.DUKAAN_STORE.link}/get-data/${pin}/`,
    {
      method: 'get',
      headers: {
        'Content-Type': 'application/json',
        'x-requested-with': window?.DukaanData?.DUKAAN_SESSION_ID,
        // 'Content-Type': 'application/x-www-form-urlencoded',
      },
    }
  )
    .then((res) => res.json())
    .then((res) => {
      if (res.status_code === 200) {
        renderPincodeSuccessMessage(res.data);
      } else {
        renderPinErrorMessage();
      }
    })
    .catch(() => {
      renderPinErrorMessage();
    });
};

window.getFirstSKUKeyWhichIsInStock = (skus) => {
  let key = 0;
  for (let i = 0; i < skus.length; i += 1) {
    if (skus[i].in_stock) {
      key = i;
      break;
    }
  }

  const selectedSKUIndexFromParams = skus.findIndex(
    (sku) => sku.id === DukaanData.DUKAAN_SKU_ID_FROM_PARAMS
  );

  if (selectedSKUIndexFromParams !== -1) {
    key = selectedSKUIndexFromParams;
  }

  return key;
};

window.fetchPDPSizeChartData = () => {
  fetch(
    `${window.DukaanData.CLIENT_API2_ENDPOINT}/api/product/buyer/${DukaanData.DUKAAN_PRODUCT.id}/product-details/`,
    {
      method: 'get',
      headers: {
        'Content-Type': 'application/json',
        'x-requested-with': window?.DukaanData?.DUKAAN_SESSION_ID,
      },
    }
  )
    .then((res) => res.json())
    .then((res) => {
      const sizeChart = res?.data?.size_chart || [];

      if (Boolean(sizeChart) && sizeChart.values.length > 0) {
        window.DukaanData.SIZE_CHART_LIST = sizeChart.values;
        if (typeof renderSizeChart !== 'undefined') renderSizeChart();
      }
    })
    .catch((e) => console.log(e));
};

window.getFlattenedBundleProducts = (products, bundleProduct) => {
  const { productSkus } = getBundleApplicablityData(bundleProduct);

  const productsInBundle = products
    ?.map((item) => {
      const skus =
        productSkus?.find((data) => Number(data.productId) === item.id)
          ?.skuIds || [];

      if (skus?.length) {
        item.skus = item.skus.filter((sku) => skus.includes(sku.id));
      }
      return item;
    })
    .map((item) => item?.skus?.map((sku) => ({ ...item, skus: [sku] })))
    .flat();

  return productsInBundle;
};

window.fetchComboProductsOnPDP = (productFromServer) => {
  // combo-products-load-point
  if (
    !(
      productFromServer?.product_type === 2 &&
      productFromServer?.product_bundle_type === 'combo'
    )
  )
    return;

  // hide bxgy badge and wishlist button for combo product page
  q$.selectAll(
    '.dkn-pdp-wishlist-button-wrapper, .dkn-pdp-info-bxgy-badge'
  ).setStylePropertyAll('display', 'none');

  const { productIds, productSkus } =
    getBundleApplicablityData(productFromServer);
  if (productIds?.length > 0) {
    q$.select('.pdp-button-wrapper').addClass('disabled');
    fetch(
      `${window.DukaanData.DUKAAN_ADVANCED_SEARCH_API_BASE_URL}/api/advanced-search/${window.DukaanData.DUKAAN_STORE.id}/`,
      {
        method: 'post',
        body: JSON.stringify({
          product_ids: productIds,
          page_size: productIds.length,
          continue_selling_when_oos: true,
          show_out_of_stock_products: true,
          push_oos_products_to_bottom: true,
        }),
        headers: {
          Accept: 'application/json',
          'Content-Type': 'application/json',
          'x-requested-with': window?.DukaanData?.DUKAAN_SESSION_ID,
        },
      }
    )
      .then((res) => res.json())
      .then((res) => {
        let products = res?.data?.products || {};
        let bundleIsOutOfStock = false;

        products = products?.map((item) => {
          const skus =
            productSkus?.find((data) => Number(data.productId) === item.id)
              ?.skuIds || [];

          if (skus?.length) {
            item.skus = item.skus.filter((sku) => skus.includes(sku.id));
          }
          return item;
        });
        dknAddProductsToProductsMap(products);
        products = getFlattenedBundleProducts(
          products,
          DukaanData.DUKAAN_PRODUCT
        );
        DukaanData.PRODUCTS_MAP[productFromServer.uuid].applicableProducts =
          products;
        renderComboProductsOnPDP(products);

        bundleIsOutOfStock =
          products.filter(
            (item) =>
              item?.skus?.filter((sku) => sku.inventory === 0)?.length > 0 ||
              item?.in_stock === false
          )?.length > 0;

        if (
          bundleIsOutOfStock &&
          DukaanData.PRODUCTS_MAP[productFromServer.uuid]?.skus?.[0]
        ) {
          DukaanData.PRODUCTS_MAP[productFromServer.uuid].skus[0].inventory = 0;
          const actionButtonsElements = q$.selectAll(
            '.pdp-button-wrapper'
          ).elem;

          actionButtonsElements?.forEach((actionButtonsElement) => {
            actionButtonsElement.innerHTML = '';
            actionButtonsElement.appendChild(
              q$.selectById('pdp-button-wrapper').getTemplateContent().elem
            );
            dknRenderActionButtons(
              {
                key: 'productPage',
                productUUID: productFromServer?.uuid,
                skuUUID: productFromServer?.skus?.[0]?.uuid,
              },
              actionButtonsElement
            );
          });
        }
      })
      .catch((e) => {
        console.error(e);
      })
      .finally(() => {
        q$.select('.pdp-button-wrapper').removeClass('disabled');
      });
  }
};

window.productPageCommonFnCalls = (productFromServer) => {
  druidProductPageView();
  checkCouponSticky();
  checkStoreClosedSticky();
  setFooterBottomMarginEqualToHeightOfPDPButtonWrapperClassElement();
  retrieveSKUs(productFromServer, () => {
    if (typeof addSKUToBagFromQueryParams === 'function') {
      addSKUToBagFromQueryParams();
    }
  });
  fetchCouponsAndOffersOnPDP();
  fetchSimilarProducts(productFromServer);
  if (typeof initCountdownTimer !== 'undefined') initCountdownTimer();
  if (typeof fetchPDPSizeChartData === 'function') {
    fetchPDPSizeChartData();
  }

  // chunk for bundles starts
  const aboveAtbBundleElements = `<pdp-bundles-load-point class="hidden">
  <div class="pdp-bundles-list"></div>
  </pdp-bundles-load-point>
  <combo-products-load-point class="hidden flex d-column" style="max-width: 448px; padding-top: 24px;">
  <div class="text-16_24 font-semibold">Items in this combo</div>
  <div class="combo-products-list"></div>
  </combo-products-load-point>`;

  const belowAtbBundleElements = `<div class="dkn-single-combo-details-wrapper p-3 my-3 mt-4_5 mb-lg-4_5  hidden">
  <div class="dkn-single-combo-name font-semibold text-16_24 text-lg-20_28"></div>
  <div class="dkn-single-combo-products-list-wrapper position-relative pb-3" style="width: 100%;"> 
    <div class="dkn-slider__arrow dkn-slider__arrow--prev hidden flex a-c j-c position-absolute"
      style="left: 8px">
      <svg width="18" height="18" viewBox="0 0 18 18" fill="none" xmlns="http://www.w3.org/2000/svg">
        <path fill-rule="evenodd" clip-rule="evenodd"
          d="M12.1553 3.21967C12.4482 3.51256 12.4482 3.98744 12.1553 4.28033L7.43566 9L12.1553 13.7197C12.4482 14.0126 12.4482 14.4874 12.1553 14.7803C11.8624 15.0732 11.3876 15.0732 11.0947 14.7803L5.84467 9.53033C5.55178 9.23744 5.55178 8.76256 5.84467 8.46967L11.0947 3.21967C11.3876 2.92678 11.8624 2.92678 12.1553 3.21967Z"
          fill="#1A181E" />
      </svg>
    </div>
    <div class="dkn-single-combo-products-list flex overflow-auto"></div>
    <div class="dkn-slider__arrow dkn-slider__arrow--next hidden flex a-c j-c v"
      style="right: 8px">
      <svg width="18" height="18" viewBox="0 0 18 18" fill="none" xmlns="http://www.w3.org/2000/svg">
        <path fill-rule="evenodd" clip-rule="evenodd"
          d="M5.84467 14.7803C5.55178 14.4874 5.55178 14.0126 5.84467 13.7197L10.5643 9L5.84467 4.28033C5.55178 3.98744 5.55178 3.51256 5.84467 3.21967C6.13756 2.92678 6.61244 2.92678 6.90533 3.21967L12.1553 8.46967C12.4482 8.76256 12.4482 9.23744 12.1553 9.53033L6.90533 14.7803C6.61244 15.0732 6.13756 15.0732 5.84467 14.7803Z"
          fill="#1A181E" />
      </svg>
    </div>
  </div>
  <div class="dkn-single-combo-actions-wrapper flex d-column a-c" style="border-top: 1px solid var(--black-90); padding-top: 16px;">
    <div class="dkn-single-combo-price text-16_24 text-lg-18_26 font-medium" style="margin-bottom: 16px;">
      Total:&nbsp; <span class="dkn-single-combo-selling-price"></span><span class="dkn-single-combo-original-price text-16-m14 font-regular strikethrough" style="margin-left: 4px;"></span>
    </div>
    <div class="dkn-single-combo-action-wrapper flex d-column flex-lg-row">
      <a href="" class="dkn-single-combo-view-btn">View Combo</a>
      <add-to-bag-button data-add-event="PRODUCT_PAGE_PRODUCT_ADDED" class="dkn-single-combo-add-button product-add-to-bag-button"></add-to-bag-button>
    </div>
  </div>
 </div>`;

  q$.select('pdp-bundle-elements-above-atb').modifyInnerHTML(
    aboveAtbBundleElements
  );
  q$.select('pdp-bundle-elements-below-atb').modifyInnerHTML(
    belowAtbBundleElements
  );
  fetchComboProductsOnPDP(productFromServer); // combo bundle's product list
  renderAvailableBundlesOnPDP(); // bundles list
  // chunk for bundles end
};

window.retrieveSKUs = (productFromServer, callback = () => {}) => {
  fetch(
    `${window.DukaanData.CLIENT_API2_ENDPOINT}/api/product/buyer/${DukaanData.DUKAAN_PRODUCT.id}/product-details/`,
    {
      method: 'get',
      headers: {
        'Content-Type': 'application/json',
        'x-requested-with': window?.DukaanData?.DUKAAN_SESSION_ID,
      },
    }
  )
    .then((res) => res.json())
    .then((res) => {
      const skus = res?.data.skus || [];
      const rawProduct = {
        ...productFromServer,
        skus,
        skusApi: true,
        metafields: DukaanData?.DUKAAN_PRODUCT_ATTRIBUTE || [],
      };
      dknAddProductsToProductsMap([rawProduct]);
      const product = DukaanData.PRODUCTS_MAP[productFromServer.uuid];
      const parentElement = q$.select('.dkn-product-page-information').elem;
      const activeSKU = dknGetFirstAvailableSKU(product.skus);
      const key = 'productPage';
      const productUUID = product.uuid;
      const productContext = {
        key,
        productUUID,
        skuUUID: activeSKU.uuid,
      };

      const hasSizeAttribute =
        product?.skus?.[0]?.new_meta?.size ||
        product?.skus?.[0]?.new_meta?.Size;

      let productVariantConfig = {
        renderActiveSKUStateByDefault:
          !hasSizeAttribute || product.skus.length === 1,
      };
      if (typeof window.getProductVariantsConfig === 'function') {
        productVariantConfig = {
          ...productVariantConfig,
          ...getProductVariantsConfig(),
        };
      }
      const renderAddons = DukaanData.DUKAAN_STORE.store_category === 6;
      setActiveSkuIdInParams(activeSKU);
      const variantFormElement = q$.select(
        '.dkn-variant-selection-form-wrapper',
        parentElement
      ).elem;

      const singleQuantityToAddSku = 'c60e8f16-d159-4c4e-8c64-54935952174e';

      const hideProductQuantitySelector =
        singleQuantityToAddSku === productContext.skuUUID;

      const externalQuantityFieldElement = q$.select(
        '.dkn-product-external-quantity-field',
        parentElement
      ).elem;

      if (externalQuantityFieldElement) {
        if (hideProductQuantitySelector) {
          externalQuantityFieldElement.style.display = 'none';
        } else {
          externalQuantityFieldElement.style.display = '';
          externalQuantityFieldElement.innerHTML = '';
          const quantityField = q$
            .selectById('dkn-product-qty-field-template')
            .getTemplateContent().elem;
          externalQuantityFieldElement.appendChild(quantityField);
          dknRenderProductQuantityInputField(
            productContext,
            externalQuantityFieldElement
          );
        }
      }

      const actionButtonsElements = q$.selectAll('.pdp-button-wrapper').elem;

      if (variantFormElement) {
        variantFormElement.innerHTML = '';
        dknRenderProductVariantForm(productContext, variantFormElement, {
          renderAddons,
          renderActiveSKUStateByDefault:
            productVariantConfig.renderActiveSKUStateByDefault,
        });
      }
      if (parentElement) {
        reRenderProductDetails(parentElement, activeSKU, product);
      }

      actionButtonsElements?.forEach((actionButtonsElement) => {
        actionButtonsElement.innerHTML = '';
        actionButtonsElement.appendChild(
          q$.selectById('pdp-button-wrapper').getTemplateContent().elem
        );
        dknRenderActionButtons(productContext, actionButtonsElement, {
          renderActiveSKUStateByDefault:
            productVariantConfig.renderActiveSKUStateByDefault,
        });
      });

      if (typeof dknRenderWishlistButtons !== 'undefined') {
        window.dknRenderWishlistButtons();
      }

      if (typeof dknRenderNotifyMeButtons !== 'undefined') {
        window.dknRenderNotifyMeButtons();
      }

      const addToWishlistElements = q$.selectAll(
        '.dkn-pdp-wishlist-button-wrapper'
      ).elem;

      addToWishlistElements?.forEach((addToWishlistElement) => {
        addToWishlistElement.setAttribute(
          'id',
          `dkn-product-wishlist-button-${productUUID}-${key}`
        );
        addToWishlistElement.dataset.productUuid = productUUID;
        addToWishlistElement.dataset.skuUuid = activeSKU.uuid;
        addToWishlistElement.dataset.key = key;
        addToWishlistButtonRenderer(addToWishlistElement);
      });

      if (typeof renderPDPPageAdditionalButtons === 'function') {
        renderPDPPageAdditionalButtons(product);
      }
      if (typeof customPdpVariantFormAdditionalRenderer !== 'undefined') {
        window.customPdpVariantFormAdditionalRenderer(product, activeSKU);
      }
      // dknFireViewContentEventOnSKUClick(activeSKU, product);
      dknViewContentEvent(activeSKU, product);
      callback();
    })
    .catch((e) => console.log(e));
};

window.pauseAllProductVideos = () => {
  document.querySelectorAll('.product-image-ytplayer').forEach((ele) => {
    ele?.contentWindow?.postMessage(
      '{"event":"command","func":"stopVideo","args":""}',
      '*'
    );
  });
};

window.playProductVideo = (e) => {
  pauseAllProductVideos();
  const element = e.slide || e.currentTarget;
  if (!element) return;

  const videoImageLink = element.dataset.videoImageLink || '';

  if (!videoImageLink) return;

  const videoId = videoImageLink
    .split('https://img.youtube.com/vi/')?.[1]
    ?.replace('/maxresdefault.jpg', '');
  if (!videoId) return;

  const wrapper = element.querySelector('.splide-video-icon-image-wrapper');
  const rect = wrapper.getBoundingClientRect();
  const elementHeight = rect.height;
  const elementWidth = rect.width;

  const iframeString = `<iframe class="product-image-ytplayer" type="text/html" width="${elementWidth}" height="${elementHeight}"
  src="https://www.youtube.com/embed/${videoId}?autoplay=1&mute=1&enablejsapi=1&showinfo=0&modestbranding=1" allowfullscreen allowscriptaccess="always"
  frameborder="0"></iframe>`;

  wrapper.innerHTML = iframeString;
};

window.setFooterBottomMarginEqualToHeightOfPDPButtonWrapperClassElement =
  () => {
    if (DukaanData?.DUKAAN_THEME_DATA?.meta?.advanced?.showStickyBuyNowMobile) {
      const buttonWrapperElements = document.querySelectorAll(
        '.product-details-section .pdp-button-wrapper'
      );
      const { isMobile } = window.deviceType();
      buttonWrapperElements?.forEach((buttonWrapperElem) => {
        if (buttonWrapperElem && isMobile) {
          const buttonWrapperHeight =
            buttonWrapperElem.getBoundingClientRect().height;
          if (document.querySelector('footer')) {
            document.querySelector(
              'footer'
            ).style.marginBottom = `${buttonWrapperHeight}px`;
          }
          buttonWrapperElem.classList.add('pdp-button-wrapper-fixed');
        }
      });
    }
  };

window.addSKUToBagFromQueryParams = () => {
  const paramString = new URLSearchParams(window.location.search);
  const RAW_DUKAAN_SKU_ID_FROM_PARAMS = paramString.get('sku_id');
  const DUKAAN_SKU_ID_FROM_PARAMS = RAW_DUKAAN_SKU_ID_FROM_PARAMS
    ? Number(RAW_DUKAAN_SKU_ID_FROM_PARAMS)
    : undefined;
  const DUKAAN_SKU_ADD_TO_BAG = paramString.get('add_to_bag');
  const DUKAAN_QUERY_COUPON = paramString.get('coupon');
  if (DUKAAN_SKU_ID_FROM_PARAMS && DUKAAN_SKU_ADD_TO_BAG) {
    const selectedSKU = DukaanData.DUKAAN_PRODUCT.skus.find(
      (sku) => sku.id === DUKAAN_SKU_ID_FROM_PARAMS
    );
    const productUUID = DukaanData.DUKAAN_PRODUCT.uuid;
    const skuUUID = selectedSKU?.uuid;

    if (skuUUID && productUUID) {
      window.addToBag(null, skuUUID, productUUID, {
        qtyToAdd: 1,
      });

      let couponQueryParam = '';
      if (DUKAAN_QUERY_COUPON) {
        couponQueryParam = `?coupon=${DUKAAN_QUERY_COUPON}`;
      }
      window.location.href = `/${DukaanData.DUKAAN_STORE.link}/bag${couponQueryParam}`;
    }
  }
};

window.fetchAndRenderProductsFromAdvanceFilters = (
  payload,
  {
    wrapperElement,
    mountElement,
    additionalRenderer,
    offset = 350,
    areBundleProducts = false,
    bundleProduct = null,
    templateId = 'dkn-product-card-template',
    getCustomDiscountText = window.getCustomDiscountText,
    sliceCount = 10,
  }
) =>
  fetch(
    `${window.DukaanData.DUKAAN_ADVANCED_SEARCH_API_BASE_URL}/api/advanced-search/${window.DukaanData.DUKAAN_STORE.id}/`,
    {
      method: 'post',
      body: JSON.stringify({
        ...payload,
        continue_selling_when_oos: true,
        show_out_of_stock_products: true,
        push_oos_products_to_bottom: true,
      }),
      headers: {
        'Content-Type': 'application/json',
        'x-requested-with': window?.DukaanData?.DUKAAN_SESSION_ID,
        // 'Content-Type': 'application/x-www-form-urlencoded',
      },
    }
  )
    .then((res) => res.json())
    .then((res) => {
      if (res) {
        let { products = [] } = res?.data || {};

        if (!products?.length) {
          wrapperElement.classList.add('hidden');
          return [];
        }
        wrapperElement.classList.remove('hidden');
        DukaanData.PRODUCTS_MAP = {
          ...DukaanData.PRODUCTS_MAP,
          ...products.reduce((map, product) => {
            if (DukaanData?.PRODUCTS_MAP?.[product.uuid]?.skusApi) return map;
            const serializedSKUs = serializeSKUs(product.skus || []);
            const attributes = getAllProductAttributeValues(serializedSKUs);
            const serializedProduct = {
              ...product,
              skus: serializedSKUs,
              attributes,
            };
            if (typeof window?.getBundleSerializedProduct === 'function') {
              map[product.uuid] = getBundleSerializedProduct(
                serializedProduct,
                bundleProduct
              );
            } else map[product.uuid] = serializedProduct;
            return map;
          }, {}),
        };
        if (areBundleProducts && bundleProduct) {
          products = getFlattenedBundleProducts(products, bundleProduct);
          dknAddProductsToProductsMap([
            { ...bundleProduct, applicableProducts: products },
          ]);
        } else {
          products = products.slice(0, sliceCount);
        }

        productListRenderer(mountElement, products, {
          templateId,
          getCustomDiscountText,
          additionalRenderer: (productCard, product) => {
            if (typeof additionalRenderer === 'function')
              additionalRenderer(productCard, product);
            window.productCardAdditionalRenderer(productCard, product);
          },
        });

        dknInitSlider({
          sliderOverflowContainer: mountElement,
          sliderOuterContainer: wrapperElement,
          offsetValue: offset,
          hideDisabledButtons: areBundleProducts,
        });
        return products;
      }
      return [];
    })
    .catch(() => {});
