/* eslint-disable no-param-reassign */
// ---------------------------------------------------------------------------------------------------------------------
// Keys
// ---------------------------------------------------------------------------------------------------------------------

window.PRODUCTS_STORAGE_KEY = () =>
  `v3-${DukaanData.DUKAAN_STORE.link}-advanced-bag-products`;
window.LOCAL_STORAGE_UPDATED_EVENT_NAME = 'localStorageUpdated';
window.SESSION_STORAGE_UPDATED_EVENT_NAME = 'sessionStorageUpdated';

window.DKN_PRODUCT_ADD_TO_BAG_EVENT_NAME = 'dkn_add_to_bag';
window.DKN_PRODUCT_REMOVE_FROM_BAG_EVENT_NAME = 'dkn_remove_from_bag';
window.DKN_PRODUCT_SEARCHED_EVENT_NAME = 'dkn_product_searched';
window.DKN_PRODUCT_VIEW_CONTENT_EVENT_NAME = 'dkn_product_view_content';
window.DKN_CATEGORY_VIEW_CONTENT_EVENT_NAME = 'dkn_category_view_content';
window.DKN_HOMEPAGE_VIEW_CONTENT_EVENT_NAME = 'dkn_homepage_view_content';
window.DKN_HOMEPAGE_BANNER_CLICK_EVENT_NAME = 'dkn_homepage_banner_click';

window.BAG_COUPON_STORAGE_KEY = () =>
  `v3-${DukaanData.DUKAAN_STORE.link}-bag-coupon`;

window.SESSION_LANDING_PAGE_STORAGE_KEY = () =>
  `v3-${DukaanData.DUKAAN_STORE.link}-session-landing-page`;
window.IP_INFO_STORAGE_KEY = '__ip_info__';

// ---------------------------------------------------------------------------------------------------------------------
// Dukaan Analytics
// ---------------------------------------------------------------------------------------------------------------------
// Druid

window.DRUID_ENTITY_TYPES = {
  PRODUCT: 'PRODUCT',
  SEARCH: 'SEARCH',
  STORE: 'STORE',
  CATEGORY: 'CATEGORY',
  BANNER: 'BANNER',
  COUPON: 'COUPON',
  BAG: 'BAG',
  ORDER: 'ORDER',
  SOCIAL: 'SOCIAL',
};

window.EVENT_TYPES = {
  VIEW: 'VIEW',
  CLICK: 'CLICK',
  EVENT: 'EVENT',
};

// Helpers

window.isLoggedIn = () => !!localStorage.al_to;

window.druidProductAddClick = (product, eventName) => {
  const options = {
    entityCost: product?.selling_price,
    entityID: product?.id,
    entityName: product?.name,
    entityParentID: product?.categories?.[0]?.id,
    entityParentName: product?.categories?.[0]?.name,
    entityType: DRUID_ENTITY_TYPES.PRODUCT,
    additionalData: product,
  };
  TrackDruidEvent(eventName, EVENT_TYPES.CLICK, options);
};

window.druidStorePageView = () => {
  const options = {
    entityID: DukaanData?.DUKAAN_STORE?.id,
    entityName: DukaanData?.DUKAAN_STORE?.name,
    entityType: DRUID_ENTITY_TYPES.STORE,
    entityParentID: '',
    entityParentName: '',
    entityCost: 0,
    additionalData: [],
  };
  TrackDruidEvent('STORE_VIEW_BUSINESS', EVENT_TYPES.VIEW, options);
};

window.druidProductPageView = () => {
  const options = {
    entityID: DukaanData?.DUKAAN_PRODUCT?.id,
    entityName: DukaanData?.DUKAAN_PRODUCT?.name,
    entityType: DRUID_ENTITY_TYPES.PRODUCT,
    entityParentID: DukaanData?.DUKAAN_PRODUCT?.categories?.[0]?.id,
    entityParentName: DukaanData?.DUKAAN_PRODUCT?.categories?.[0]?.name,
    entityCost: DukaanData?.DUKAAN_PRODUCT?.selling_price,
    additionalData: [],
  };
  TrackDruidEvent('PRODUCT_VIEW_BUSINESS', EVENT_TYPES.VIEW, options);
};

// Google ECommerce

window.fireGoogleEcommerceProductClickEvent = (event) => {
  const productUUID = event?.currentTarget?.dataset?.productUuid || '';
  if (!productUUID) return;

  const product = window.DukaanData?.PRODUCTS_MAP?.[productUUID];
  if (!product) return;

  const payload = {
    click: {
      products: [
        {
          name: product.name, // Name or ID is required.
          id: product.id,
          price: product.selling_price,
          variant: product?.skus?.[0]?.id || undefined,
          position: product.position,
        },
      ],
    },
  };

  window.dataLayer = window.dataLayer || [];
  window.dataLayer.push({ ecommerce: null });
  window.dataLayer.push({
    event: 'productClick',
    ecommerce: payload,
  });
};

window.fireGoogleEcommerceProductPageViewEvent = (productUUID) => {
  if (!productUUID) return;

  const product = window.DukaanData?.PRODUCTS_MAP?.[productUUID];
  if (!product) return;

  const payload = {
    detail: {
      products: [
        {
          name: product.name,
          id: product.id,
          price: product.selling_price,
          variant: product?.skus?.[0]?.id || undefined,
        },
      ],
    },
  };

  window.dataLayer = window.dataLayer || [];
  window.dataLayer.push({ ecommerce: null });
  window.dataLayer.push({ ecommerce: payload });
};

window.fireGoogleEcommerceProductAddToBagEvent = (currentSKU, product) => {
  if (!product || !currentSKU) return;

  const payload = {
    currencyCode: DukaanData?.DUKAAN_STORE?.currency?.cc,
    add: {
      products: [
        {
          name: product.name,
          id: product.id,
          price: currentSKU.selling_price,
          variant: currentSKU.id,
          quantity: 1,
        },
      ],
    },
  };

  window.dataLayer = window.dataLayer || [];
  window.dataLayer.push({ ecommerce: null });
  window.dataLayer.push({
    event: 'addToCart',
    ecommerce: payload,
  });
};

window.fireGoogleEcommerceProductRemoveFromBagEvent = (currentSKU, product) => {
  if (!product || !currentSKU) return;

  const payload = {
    currencyCode: DukaanData?.DUKAAN_STORE?.currency?.cc,
    remove: {
      products: [
        {
          name: product.name,
          id: product.id,
          price: currentSKU.selling_price,
          variant: currentSKU.id,
          quantity: 1,
        },
      ],
    },
  };

  window.dataLayer = window.dataLayer || [];
  window.dataLayer.push({ ecommerce: null });
  window.dataLayer.push({
    event: 'removeFromCart',
    ecommerce: payload,
  });
};

window.getDeviceBrand = () => {
  if (window) {
    return navigator.platform;
  }
  return 'NODE';
};

window.getDeviceModel = () => {
  if (window) {
    return window.navigator.userAgent;
  }
  return 'AWS';
};

window.getDeviceFingerprint = () => {
  if (window) {
    return window.navigator.productSub;
  }
  return 'NODE';
};

window.getOS = () => {
  if (window) {
    let Name = 'Unknown OS';
    if (window.navigator.userAgent.indexOf('Win') !== -1) Name = 'Windows OS';
    if (window.navigator.userAgent.indexOf('Mac') !== -1) Name = 'Macintosh';
    if (window.navigator.userAgent.indexOf('Linux') !== -1) Name = 'Linux OS';
    if (window.navigator.userAgent.indexOf('Android') !== -1)
      Name = 'Android OS';
    if (window.navigator.userAgent.indexOf('like Mac') !== -1) Name = 'iOS';
    return Name;
  }
  return 'SSR';
};

window.FireDruidEvent = (params) => {
  const data = JSON.stringify(params);
  const xhr = new XMLHttpRequest();
  xhr.addEventListener('readystatechange', function () {
    if (this.readyState === 4) {
      // console.log(this.responseText);
    }
  });
  xhr.open('POST', 'https://api4.mydukaan.io/v1/post/events');
  xhr.setRequestHeader('Content-Type', 'application/json');
  xhr.setRequestHeader(
    'x-requested-with',
    window?.DukaanData?.DUKAAN_SESSION_ID
  );
  xhr.send(data);

  if (window && window?.DukaanData) {
    const { additional_meta: additionalMeta = {} } = DukaanData.DUKAAN_STORE;
    const { additional_druid_event_webhook: additionalDruidEventWebhook } =
      additionalMeta;

    if (additionalDruidEventWebhook) {
      const additionalXhr = new XMLHttpRequest();
      additionalXhr.addEventListener('readystatechange', function () {
        if (this.readyState === 4) {
          // console.log(this.responseText);
        }
      });
      additionalXhr.open('POST', 'https://api4.mydukaan.io/v1/post/events');
      additionalXhr.setRequestHeader('Content-Type', 'application/json');
      additionalXhr.send(data);
    }
  }
};

window.TrackDruidEvent = (eventName, eventType, options = []) => {
  let businessDetails = {};
  if (!(window && window.DukaanData)) {
    const dataString = document.getElementById('__DUKAAN_DATA__').innerHTML;
    const data = JSON.parse(dataString);

    businessDetails = data.DUKAAN_STORE;
  } else {
    businessDetails = DukaanData.DUKAAN_STORE;
  }

  // console.log(window.DukaanData);

  const storeLink = window?.DukaanData?.DUKAAN_STORE?.link;

  // TODO
  const signature = getDataFromLocalStorage('__b_sig__', '');
  const ipInfo = getDataFromLocalStorage(IP_INFO_STORAGE_KEY, {});
  const ver = businessDetails?.ver;
  const deviceBrandIPHash = ipInfo.device_brand_ip_hash;
  const clientIp = ipInfo.ip;

  const campaign = getDataFromLocalStorage(`${storeLink}_utm_campaign`, '');
  const medium = getDataFromLocalStorage(`${storeLink}_utm_medium`, '');
  const source = getDataFromLocalStorage(`${storeLink}_utm_source`, '');
  const term = getDataFromLocalStorage(`${storeLink}_utm_term`, '');
  const content = getDataFromLocalStorage(`${storeLink}_utm_content`, '');
  const query = getDataFromLocalStorage(`${storeLink}_utm_query`, '');
  const vcRefId = getDataFromLocalStorage(`${storeLink}_vcRefId`, '');

  const ipInfoData = getDataFromLocalStorage(window.IP_INFO_STORAGE_KEY, {});
  const landingPageData =
    getDataFromLocalStorage(window.SESSION_LANDING_PAGE_STORAGE_KEY(), '') ||
    DukaanData?.DUKAAN_LANDING_PAGE;

  const config = {
    timestamp: new Date(),
    u_lat: 0.0,
    u_lon: 0.0,
    u_userID: signature,
    u_storeID: businessDetails?.id,
    u_storeLink: storeLink,
    u_storePhone: atob(businessDetails?.account_hash || ''),
    d_platform: 'REACT',
    d_source: 'BUYER-WEB',
    d_OSVersion: getOS(),
    d_appVersion: '1.0.0',
    d_deviceBrand: getDeviceBrand(),
    d_deviceModel: getDeviceModel(),
    d_deviceFingerprint: getDeviceFingerprint(),
    d_IPAddress: clientIp,
    eventName: eventName?.toUpperCase(),
    eventType: eventType?.toUpperCase(),
    u_storeType: 0,
    u_storePlan: 0,
    u_storeCategory: businessDetails?.store_category,
    u_storeCountry: businessDetails?.country,
    u_isPremium: ver,
    u_utmSource: source,
    u_utmMedium: medium,
    u_utmCampaign: campaign,
    u_utmTerm: term,
    u_utmContent: content,
    u_utmQuery: query,
    u_adClid: vcRefId ? `moj-${vcRefId}` : deviceBrandIPHash,
    u_extraJson: JSON.stringify(options.additionalData || {}),
    u_sessionID: window.DukaanData.DUKAAN_SESSION_ID,
    u_landingPage: landingPageData,
    u_pageURL: window.location.href,
    u_pageBaseURL: window.location.href.split('?')?.[0],
    u_httpReferer: document.referrer || undefined,
    d_ipCity: ipInfoData?.city,
    d_ipRegion: ipInfoData?.region,
    d_ipCountry: ipInfoData?.country,
    d_ipPostal: ipInfoData?.postal,
    d_ipLoc: ipInfoData?.loc,
    entityID: options.entityID || '',
    entityName: options.entityName || '',
    entityType: options.entityType || '',
    entityParentID: options.entityParentID || '',
    entityParentName: options.entityParentName || '',
    entityCost: options.entityCost || '',
  };
  FireDruidEvent(config);
};

// GTAG and FB

window.dataLayer = window.dataLayer || [];

window.initGTM = (propertyId) =>
  // (function (w, d, s, l, i) {
  //   w[l] = w[l] || [];
  //   w[l].push({ 'gtm.start': new Date().getTime(), event: 'gtm.js' });
  //   const f = d.getElementsByTagName(s)[0];
  //   const j = d.createElement(s);
  //   // eslint-disable-next-line eqeqeq
  //   const dl = l != 'dataLayer' ? `&l=${l}` : '';
  //   // j.async = true;
  //   j.defer = true;
  //   j.src = `https://www.googletagmanager.com/gtm.js?id=${i}${dl}`;
  //   f.parentNode.insertBefore(j, f);
  // })(window, document, 'script', 'dataLayer', propertyId);
  // window.gtag('js', new Date());
  // window.gtag('config', propertyId);
  true;

window.initGTag = (propertyId) =>
  // (function (w, d, s, l, i) {
  //   w[l] = w[l] || [];
  //   w[l].push({ 'gtm.start': new Date().getTime(), event: 'gtm.js' });
  //   const f = d.getElementsByTagName(s)[0];
  //   const j = d.createElement(s);
  //   // eslint-disable-next-line eqeqeq
  //   const dl = l != 'dataLayer' ? `&l=${l}` : '';
  //   // j.async = true;
  //   j.defer = true;
  //   j.src = `https://www.googletagmanager.com/gtag/js?id=${i}${dl}`;
  //   f.parentNode.insertBefore(j, f);
  // })(window, document, 'script', 'dataLayer', propertyId);
  // window.gtag('js', new Date());
  // window.gtag('config', propertyId);
  true;

window.ALL_STORE_CATEGORIES = [
  {
    id: 6,
    title: 'Restaurants',
  },
  {
    id: 1,
    title: 'Grocery & Essentials',
  },
  {
    id: 2,
    title: 'Fashion & Apparels',
  },
  {
    id: 3,
    title: 'Home Decor & Appliances',
  },
  {
    id: 4,
    title: 'Mobiles & Computers',
  },
  {
    id: 5,
    title: 'Fruits & Vegetables',
  },
  {
    id: 7,
    title: 'Medicines & Healthcare',
  },
  {
    id: 11,
    title: 'Hardware & Tools',
  },
  {
    id: 10,
    title: 'Sea Food & Meat',
  },
  {
    id: 9,
    title: 'Books',
  },
  {
    id: 8,
    title: 'Paan Shop',
  },
];

window.dknGenerateEventPayload = (overrides = {}) => {
  const ipInfo = getDataFromLocalStorage(IP_INFO_STORAGE_KEY, {});
  const clientIp = ipInfo.ip;
  const { currency, link: storeLink } = DukaanData.DUKAAN_STORE;

  const getCookieValue = (name) =>
    document.cookie.match(`(^|;)\\s*${name}\\s*=\\s*([^;]+)`)?.pop() || '';

  const campaign = getDataFromLocalStorage(`${storeLink}_utm_campaign`, '');
  const medium = getDataFromLocalStorage(`${storeLink}_utm_medium`, '');
  const source = getDataFromLocalStorage(`${storeLink}_utm_source`, '');
  const term = getDataFromLocalStorage(`${storeLink}_utm_term`, '');
  const content = getDataFromLocalStorage(`${storeLink}_utm_content`, '');
  const query = getDataFromLocalStorage(`${storeLink}_utm_query`, '');
  const vcRefId = getDataFromLocalStorage(`${storeLink}_vcRefId`, '');
  const fbclid = getDataFromLocalStorage(`${storeLink}_fbclid`, '');
  const gclid = getDataFromLocalStorage(`${storeLink}_gclid`, '');

  const utmData = {
    utm_campaign: campaign || undefined,
    utm_medium: medium || undefined,
    utm_source: source || undefined,
    utm_term: term || undefined,
    utm_content: content || undefined,
    utm_query: query || undefined,
    vcRefId: vcRefId || undefined,
    fbclid: fbclid || undefined,
    gclid: gclid || undefined,
  };

  const customData = {
    page_title: document.title,
    page_referrer: document.referrer || '',
    store_id: window?.DukaanData?.DUKAAN_STORE?.id || '',
    DUKAAN_SESSION_ID: window?.DukaanData?.DUKAAN_SESSION_ID,
  };

  const cookieData = {
    fbc: getCookieValue('_fbc') ? getCookieValue('_fbc') : undefined,
    fbp: getCookieValue('_fbp') ? getCookieValue('_fbp') : undefined,
  };

  const userData = {
    client_ip_address: clientIp,
    client_user_agent: navigator.userAgent,
    ph: [null],
  };

  return {
    event_id: `dukaan_${generateRandomString(10)}`,
    event_time: Math.floor(new Date().getTime() / 1000),
    currency: currency?.cc,
    content_category: overrides?.items?.[0].categories?.[0],
    user_data: userData,
    cookie_data: cookieData,
    utm_data: utmData,
    custom_data: customData,
    ...overrides,
  };
};

window.dknAddToBagEvent = (sku, product, { qty, isBundle }) => {
  const overrides = {
    _product: product,
    _sku: sku,
    items: [
      {
        sku_id: sku.id,
        product_id: product.id,
        image_url: product?.image || product?.all_images[0],
        name: product.name,
        attributes: sku?.attributes?.map((a) => a.value) || [],
        brands: product?.brands?.map((b) => b.name) || [],
        categories: product?.categories?.map((c) => c.name) || [],
        quantity: qty || 1,
        selling_price: sku.selling_price,
        original_price: sku.original_price,
        product_url: window.getProductLink(product, sku.id),
        isBundle,
      },
    ],
  };

  const payload = window.dknGenerateEventPayload(overrides);
  const event = new Event(window.DKN_PRODUCT_ADD_TO_BAG_EVENT_NAME);
  event.payload = payload;
  document.dispatchEvent(event);
};

window.dknRemoveFromBagEvent = (sku, product, { qty, isBundle }) => {
  const overrides = {
    _product: product,
    _sku: sku,
    items: [
      {
        sku_id: sku.id,
        product_id: product.id,
        image_url: product?.image || product?.all_images[0],
        name: product.name,
        attributes: sku?.attributes?.map((a) => a.value) || [],
        brands: product?.brands?.map((b) => b.name) || [],
        categories: product?.categories?.map((c) => c.name) || [],
        quantity: qty || 1,
        selling_price: sku.selling_price,
        original_price: sku.original_price,
        product_url: window.getProductLink(product, sku.id),
        isBundle,
      },
    ],
  };

  const payload = window.dknGenerateEventPayload(overrides);
  const event = new Event(window.DKN_PRODUCT_REMOVE_FROM_BAG_EVENT_NAME);
  event.payload = payload;
  document.dispatchEvent(event);
};

window.dknProductSearchedEvent = (searchQuery) => {
  const overrides = {
    search_query: searchQuery,
  };

  const payload = window.dknGenerateEventPayload(overrides);
  const event = new Event(window.DKN_PRODUCT_SEARCHED_EVENT_NAME);
  event.payload = payload;
  document.dispatchEvent(event);
};

window.dknViewContentEvent = (sku, product, { isBundle = false } = {}) => {
  const overrides = {
    _product: product,
    _sku: sku,
    items: [
      {
        sku_id: sku.id,
        product_id: isBundle ? `vsku_${product.id}` : product.id,
        in_stock: product?.in_stock,
        image_url: product?.image || product?.all_images[0],
        name: product.name,
        attributes: sku?.attributes?.map((a) => a.value) || [],
        brands: product?.brands?.map((b) => b.name) || [],
        categories: product?.categories?.map((c) => c.name) || [],
        selling_price: sku.selling_price,
        original_price: sku.original_price,
        product_url: window.getProductLink(product, sku.id),
        isBundle,
      },
    ],
  };

  const payload = window.dknGenerateEventPayload(overrides);
  const event = new Event(window.DKN_PRODUCT_VIEW_CONTENT_EVENT_NAME);
  event.payload = payload;

  setTimeout(() => {
    document.dispatchEvent(event);
  }, 2000);
};

window.dknCategoryViewContentEvent = (category) => {
  const overrides = {
    category_id: category?.id,
    _category: category,
  };

  const payload = window.dknGenerateEventPayload(overrides);
  const event = new Event(window.DKN_CATEGORY_VIEW_CONTENT_EVENT_NAME);
  event.payload = payload;

  setTimeout(() => {
    document.dispatchEvent(event);
  }, 2000);
};

window.dknHomepageViewContentEvent = () => {
  const overrides = {};

  const payload = window.dknGenerateEventPayload(overrides);
  const event = new Event(window.DKN_HOMEPAGE_VIEW_CONTENT_EVENT_NAME);
  event.payload = payload;

  setTimeout(() => {
    document.dispatchEvent(event);
  }, 2000);
};

window.dknBannerClickedEvent = (e) => {
  e.preventDefault();
  const element = e.currentTarget;

  const bannerLink = element?.href;
  const bannerImage = element?.querySelector('img')?.src;

  const overrides = {
    _banner: {
      banner_image: bannerImage,
      banner_link: bannerLink,
    },
  };

  const payload = window.dknGenerateEventPayload(overrides);
  const event = new Event(window.DKN_HOMEPAGE_BANNER_CLICK_EVENT_NAME);
  event.payload = payload;
  document.dispatchEvent(event);

  if (bannerLink) {
    window.location = bannerLink;
  }
};

window.sendConversionApiEvent = (payload, callback = () => {}) => {
  fetch(`${window.DukaanData.CLIENT_API_ENDPOINT}/api/conversion-api/`, {
    method: 'post',
    body: JSON.stringify(payload),
    headers: {
      'Content-Type': 'application/json',
      'x-requested-with': window?.DukaanData?.DUKAAN_SESSION_ID,
      // 'Content-Type': 'application/x-www-form-urlencoded',
    },
  })
    .then((res) => res.json())
    .then((res) => {
      callback(res);
    })
    .catch(() => {});
};

window.sendServerSideEventCallback = (
  payload,
  options = {},
  callback = () => {}
) => {
  const {
    additional_meta: additionalMeta = {},
    store_category: storeCategory,
    currency,
    link: storeLink,
  } = DukaanData.DUKAAN_STORE;
  const { facebook_pixel_id_meta: facebookPixelIDMeta } = additionalMeta;

  const getCookieValue = (name) =>
    document.cookie.match(`(^|;)\\s*${name}\\s*=\\s*([^;]+)`)?.pop() || '';

  const generatePayload = (overrides = {}) => {
    // const ipInfo = getDataFromLocalStorage(IP_INFO_STORAGE_KEY, {});
    // const clientIp = ipInfo.ip;

    const storeCategoryName =
      ALL_STORE_CATEGORIES.find((c) => storeCategory === c.id)?.title ||
      'UNCATEGORIZED';

    const campaign = getDataFromLocalStorage(`${storeLink}_utm_campaign`, '');
    const medium = getDataFromLocalStorage(`${storeLink}_utm_medium`, '');
    const source = getDataFromLocalStorage(`${storeLink}_utm_source`, '');
    const term = getDataFromLocalStorage(`${storeLink}_utm_term`, '');
    const content = getDataFromLocalStorage(`${storeLink}_utm_content`, '');
    const query = getDataFromLocalStorage(`${storeLink}_utm_query`, '');
    const vcRefId = getDataFromLocalStorage(`${storeLink}_vcRefId`, '');
    const fbclid = getDataFromLocalStorage(`${storeLink}_fbclid`, '');
    const gclid = getDataFromLocalStorage(`${storeLink}_gclid`, '');

    const utmData = {
      page_title: document.title,
      page_referrer: document.referrer,
      store_id: DukaanData?.DUKAAN_STORE?.id || '',
      utm_campaign: campaign || undefined,
      utm_medium: medium || undefined,
      utm_source: source || undefined,
      utm_term: term || undefined,
      utm_content: content || undefined,
      utm_query: query || undefined,
      vcRefId: vcRefId || undefined,
      fbclid: fbclid || undefined,
      gclid: gclid || undefined,
    };

    return [
      {
        event_name: overrides.event_name,
        event_id: `dukaan_${generateRandomString(10)}`,
        event_time: Math.floor(new Date().getTime() / 1000),
        user_data: {
          client_ip_address: null,
          client_user_agent: navigator.userAgent,
          ph: [null],
        },
        contents: overrides.contents,
        custom_data: {
          ...utmData,
          currency: currency?.cc,
          content_category: storeCategoryName, // store_category_name
          ...overrides.custom_data,
        },
        event_source_url: window.location.href,
        action_source: 'website',
        fbc: getCookieValue('_fbc') ? getCookieValue('_fbc') : undefined,
        fbp: getCookieValue('_fbp') ? getCookieValue('_fbp') : undefined,
      },
    ];
  };

  const finalData = generatePayload(payload);
  const clientEventData = finalData[0] || {};

  if (window.fbq) {
    window?.fbq?.(
      'track',
      finalData[0].event_name,
      {
        ...clientEventData,
        ...clientEventData.custom_data,
        ...clientEventData.user_data,
      },
      {
        eventId: finalData[0].event_id,
      }
    );
  } else {
    window.dknCustomClientViewContentEvent = () => {
      if (!window.fbq) return;

      window?.fbq?.(
        'track',
        finalData[0].event_name,
        {
          ...clientEventData,
          ...clientEventData.custom_data,
          ...clientEventData.user_data,
        },
        {
          eventId: finalData[0].event_id,
        }
      );
    };
  }

  if (!facebookPixelIDMeta && !options.overrideFacebookPixelCheck) return;

  fetch(`${window.DukaanData.CLIENT_API_ENDPOINT}/api/conversion-api/`, {
    method: 'post',
    body: JSON.stringify(finalData),
    headers: {
      'Content-Type': 'application/json',
      'x-requested-with': window?.DukaanData?.DUKAAN_SESSION_ID,
      // 'Content-Type': 'application/x-www-form-urlencoded',
    },
  })
    .then((res) => res.json())
    .then((res) => {
      callback(res);
    })
    .catch(() => {});
};

window.sendServerSideEvent = (...args) => {
  try {
    sendServerSideEventCallback(...args);
    // eslint-disable-next-line no-empty
  } catch (e) {}
};

const getBuyerIdFromToken = () => {
  const token = localStorage.al_to;

  if (!token) return '';

  try {
    const mainToken = token.split('.')[1];
    const decodedToken = JSON.parse(atob(mainToken));

    return decodedToken?.buyer_id || '';
  } catch (e) {
    return '';
  }
};

window.initAnalytics = () => {
  const { meta: { misc_data: miscData = {} } = {} } = DukaanData.DUKAAN_STORE;
  const {
    google_adwords_conversion_id: rawAdwordsConversionID = '',
    google_analytics_property_id: googleAnalyticsPropId,
  } = miscData || {};
  const adwordsConversionID =
    !rawAdwordsConversionID || rawAdwordsConversionID.startsWith('AW-')
      ? rawAdwordsConversionID
      : `AW-${rawAdwordsConversionID}`;

  const tags = [googleAnalyticsPropId, adwordsConversionID].filter((n) => !!n);
  window.gtag = function () {
    // eslint-disable-next-line prefer-rest-params
    window.dataLayer.push(arguments);
  };
  window.dataLayer = window.dataLayer || [];
  if (tags.length) {
    (function (w, d, s, l, i) {
      w[l] = w[l] || [];
      w[l].push({ 'gtm.start': new Date().getTime(), event: 'gtm.js' });
      const f = d.getElementsByTagName(s)[0];
      const j = d.createElement(s);
      // eslint-disable-next-line eqeqeq
      const dl = l != 'dataLayer' ? `&l=${l}` : '';
      // j.async = true;
      j.defer = true;
      j.src = `https://www.googletagmanager.com/gtag/js?id=${i}${dl}`;
      f.parentNode.insertBefore(j, f);
    })(window, document, 'script', 'dataLayer', tags[0]);
    window.gtag('js', new Date());
  }

  tags.forEach((t) => {
    window.gtag('config', t, {
      user_id: getBuyerIdFromToken() || '',
    });
  });
};

window.GAPage = () => {
  window.dataLayer = window.dataLayer || [];
  window.dataLayer.push({
    event: 'page-view',
    page: window.location.pathname,
    buyer_id: getBuyerIdFromToken() || '',
  });

  const { additional_meta: additionalMeta = {} } =
    DukaanData?.DUKAAN_STORE || {};
  const { ga4_tag_meta: ga4Meta, ga4_360_event_map: ga4EventMap = {} } =
    additionalMeta || {};
  const { page_view: pageViewEventConversionId } = ga4EventMap;

  window.gtag ||= function () {
    // eslint-disable-next-line prefer-rest-params
    window.dataLayer.push(arguments);
  };
  if (ga4Meta && pageViewEventConversionId) {
    window.gtag('event', 'conversion', {
      allow_custom_scripts: true,
      send_to: pageViewEventConversionId,
    });
  }
};

window.initializeAPM = () => {
  if (typeof elasticApm !== 'undefined') {
    elasticApm.init({
      serviceName: 'sceptre-storefronts',
      serverUrl:
        'https://56a9f6c953e2427386e2517a3463f96c.apm.ap-south-1.aws.elastic-cloud.com:443',
      serviceVersion: '',
      environment: 'production',
    });
  }
};

// window.dknFireViewContentEventOnSKUClick = (sku, product) => {
//   const businessDetails = DukaanData.DUKAAN_STORE;
//   // const { additional_meta: additionalMeta = {} } = businessDetails;
//   // const { facebook_pixel_id_meta: facebookPixelIdMeta } = additionalMeta;
//
//   const { id: skuId, selling_price: sellingPrice } = sku;
//
//   sendServerSideEvent(
//     {
//       event_name: 'ViewContent',
//       contents: [
//         {
//           id: skuId,
//           item_price: sellingPrice,
//           delivery_category: 'home_delivery',
//         },
//       ],
//       custom_data: {
//         content_ids: [skuId],
//         content_category:
//           ALL_STORE_CATEGORIES.find(
//             (c) => businessDetails.store_category === c.id
//           )?.title || 'UNCATEGORIZED',
//         currency: businessDetails?.currency?.cc,
//         content_name: product.name,
//       },
//     },
//     {
//       overrideFacebookPixelCheck: true,
//     }
//   );
// };

// ---------------------------------------------------------------------------------------------------------------------
// Storage utils
// ---------------------------------------------------------------------------------------------------------------------

// Local storage
window.setLocalStorageItem = (key, value) => {
  window?.localStorage?.setItem(key, value);
};

window.setDataToLocalStorage = (storageKey, storageHash) => {
  setLocalStorageItem(storageKey, JSON.stringify(storageHash));
};

window.getLocalStorageItem = (key) =>
  window?.localStorage?.getItem(key) || null;

window.getDataFromLocalStorage = (storageKey, defaultData = {}) => {
  try {
    return JSON.parse(getLocalStorageItem(storageKey)) || defaultData;
  } catch (e) {
    return defaultData;
  }
};

window.initLocalStorageBagLangugeSerializer = () => {
  const allBagProducts = getDataFromLocalStorage(PRODUCTS_STORAGE_KEY(), {});
  let newBagProducts = {};

  // eslint-disable-next-line no-restricted-syntax, guard-for-in
  for (const productUUID in allBagProducts) {
    if (Object.values(allBagProducts[productUUID]).length > 0) {
      newBagProducts = {
        ...newBagProducts,
        [productUUID]: allBagProducts[productUUID],
      };
      // eslint-disable-next-line no-restricted-syntax, guard-for-in
      for (const skuUUID in allBagProducts[productUUID]) {
        newBagProducts[productUUID][skuUUID] = {
          ...newBagProducts[productUUID][skuUUID],
          parent_product: window.languageSerializer(
            newBagProducts[productUUID][skuUUID].parent_product,
            true
          ),
        };
      }
    } else {
      newBagProducts = {
        ...newBagProducts,
        [productUUID]: allBagProducts[productUUID],
      };
    }
  }
  setDataToLocalStorage(PRODUCTS_STORAGE_KEY(), newBagProducts);
};

window.initLocalstorage = () => {
  const originalSetItem = localStorage.setItem;

  localStorage.setItem = function (key, value) {
    const event = new Event(LOCAL_STORAGE_UPDATED_EVENT_NAME);
    event.key = key;
    try {
      event.value = JSON.parse(value);
    } catch (e) {
      event.value = value;
    }

    // eslint-disable-next-line prefer-rest-params
    originalSetItem.apply(this, arguments);
    document.dispatchEvent(event);
  };
};

// Session storage
window.setSessionItem = (key, value) =>
  window?.sessionStorage?.setItem(key, value);

window.setDataToSessionStorage = (storageKey, storageHash) => {
  setSessionItem(storageKey, JSON.stringify(storageHash));
};

window.getSessionItem = (key) => window?.sessionStorage?.getItem(key) || null;

window.getDataFromSessionStorage = (storageKey, defaultData = {}) => {
  try {
    return JSON.parse(getSessionItem(storageKey)) || defaultData;
  } catch (e) {
    return defaultData;
  }
};

window.initSessionStorage = () => {
  const originalSetItem = Storage.prototype.setItem;

  Storage.prototype.setItem = function (key, value) {
    const event = new Event(SESSION_STORAGE_UPDATED_EVENT_NAME);
    event.key = key;
    try {
      event.value = JSON.parse(value);
    } catch (e) {
      event.value = value;
    }

    document.dispatchEvent(event);
    // eslint-disable-next-line prefer-rest-params
    originalSetItem.apply(this, arguments);
  };
};

// JavaScript HTML Sanitizer v2.0.2, (c) Alexander Yumashev, Jitbit Software.

// homepage https://github.com/jitbit/HtmlSanitizer

// License: MIT https://github.com/jitbit/HtmlSanitizer/blob/master/LICENSE

window.HtmlSanitizer = new (function () {
  const _tagWhitelist = {
    A: true,
    ABBR: true,
    B: true,
    BLOCKQUOTE: true,
    BODY: true,
    BR: true,
    CENTER: true,
    CODE: true,
    DD: true,
    DIV: true,
    DL: true,
    DT: true,
    EM: true,
    FONT: true,
    H1: true,
    H2: true,
    H3: true,
    H4: true,
    H5: true,
    H6: true,
    HR: true,
    I: true,
    IMG: true,
    LABEL: true,
    LI: true,
    OL: true,
    P: true,
    PRE: true,
    SMALL: true,
    SOURCE: true,
    SPAN: true,
    STRONG: true,
    SUB: true,
    SUP: true,
    TABLE: true,
    TBODY: true,
    TR: true,
    TD: true,
    TH: true,
    THEAD: true,
    UL: true,
    U: true,
    VIDEO: true,
  };

  // const _tagWhitelist = {
  //   B: true,
  //   I: true,
  //   U: true,
  //   LI: true,
  //   OL: true,
  //   UL: true,
  //   P: true,
  //   BR: true,
  //   HR: true,
  //   STRIKE: true,
  //   BLOCKQUOTE: true,
  //   FIGURE: true,
  //   PRE: true,
  //   H1: true,
  //   H2: true,
  //   H3: true,
  //   H4: true,
  //   H5: true,
  //   H6: true,
  //   SUP: true,
  //   SUB: true,
  //   STRONG: true,
  //   EM: true,
  //   INS: true,
  //   DEL: true,
  //   TABLE: true,
  //   TR: true,
  //   TH: true,
  //   TD: true,
  //   A: true,
  //   IMG: true,
  // };

  const _contentTagWhiteList = {
    FORM: true,
    'GOOGLE-SHEETS-HTML-ORIGIN': true,
  }; // tags that will be converted to DIVs

  const _attributeWhitelist = {
    align: true,
    color: true,
    controls: true,
    height: true,
    href: true,
    id: true,
    src: true,
    style: true,
    target: true,
    title: true,
    type: true,
    width: true,
  };

  // const _attributeWhitelist = {
  //   align: true,
  //   color: true,
  //   controls: true,
  //   height: true,
  //   href: true,
  //   id: true,
  //   src: true,
  //   srcset: true,
  //   style: true,
  //   target: true,
  //   title: true,
  //   type: true,
  //   width: true,
  //   class: true,
  //   alt: true,
  //   loading: true,
  //   name: true,
  // };

  const _cssWhitelist = {
    'background-color': true,
    color: true,
    'font-size': true,
    'font-weight': true,
    'text-align': true,
    'text-decoration': true,
    width: true,
  };

  const _schemaWhiteList = [
    'http:',
    'https:',
    'data:',
    'm-files:',
    'file:',
    'ftp:',
    'mailto:',
    'pw:',
  ]; // which "protocols" are allowed in "href", "src" etc

  const _uriAttributes = { href: true, action: true };

  const _parser = new DOMParser();

  this.SanitizeHtml = function (input, extraSelector) {
    input = input.trim();
    if (input == '') return ''; // to save performance

    // firefox "bogus node" workaround for wysiwyg's
    if (input == '<br>') return '';

    if (input.indexOf('<body') == -1) input = `<body>${input}</body>`; // add "body" otherwise some tags are skipped, like <style>

    const doc = _parser.parseFromString(input, 'text/html');

    // DOM clobbering check (damn you firefox)
    if (doc.body.tagName !== 'BODY') doc.body.remove();
    if (typeof doc.createElement !== 'function') doc.createElement.remove();

    function makeSanitizedCopy(node) {
      let newNode;
      if (node.nodeType == Node.TEXT_NODE) {
        newNode = node.cloneNode(true);
      } else if (
        node.nodeType == Node.ELEMENT_NODE &&
        (_tagWhitelist[node.tagName] ||
          _contentTagWhiteList[node.tagName] ||
          (extraSelector && node.matches(extraSelector)))
      ) {
        // is tag allowed?

        if (_contentTagWhiteList[node.tagName])
          newNode = doc.createElement('DIV'); // convert to DIV
        else newNode = doc.createElement(node.tagName);

        for (let i = 0; i < node.attributes.length; i++) {
          const attr = node.attributes[i];
          if (_attributeWhitelist[attr.name]) {
            if (attr.name == 'style') {
              for (let s = 0; s < node.style.length; s++) {
                const styleName = node.style[s];
                if (_cssWhitelist[styleName])
                  newNode.style.setProperty(
                    styleName,
                    node.style.getPropertyValue(styleName)
                  );
              }
            } else {
              if (_uriAttributes[attr.name]) {
                // if this is a "uri" attribute, that can have "javascript:" or something
                if (
                  attr.value.indexOf(':') > -1 &&
                  !startsWithAny(attr.value, _schemaWhiteList)
                )
                  continue;
              }
              newNode.setAttribute(attr.name, attr.value);
            }
          }
        }
        for (let i = 0; i < node.childNodes.length; i++) {
          const subCopy = makeSanitizedCopy(node.childNodes[i]);
          newNode.appendChild(subCopy, false);
        }

        // remove useless empty spans (lots of those when pasting from MS Outlook)
        if (
          (newNode.tagName == 'SPAN' ||
            newNode.tagName == 'B' ||
            newNode.tagName == 'I' ||
            newNode.tagName == 'U') &&
          newNode.innerHTML.trim() == ''
        ) {
          return doc.createDocumentFragment();
        }
      } else {
        newNode = doc.createDocumentFragment();
      }
      return newNode;
    }

    const resultElement = makeSanitizedCopy(doc.body);

    return resultElement.innerHTML
      .replace(/<br[^>]*>(\S)/g, '<br>\n$1')
      .replace(/div><div/g, 'div>\n<div'); // replace is just for cleaner code
  };

  function startsWithAny(str, substrings) {
    for (let i = 0; i < substrings.length; i++) {
      if (str.indexOf(substrings[i]) == 0) {
        return true;
      }
    }
    return false;
  }

  this.AllowedTags = _tagWhitelist;
  this.AllowedAttributes = _attributeWhitelist;
  this.AllowedCssStyles = _cssWhitelist;
  this.AllowedSchemas = _schemaWhiteList;
})();

// ---------------------------------------------------------------------------------------------------------------------
// General utils
// ---------------------------------------------------------------------------------------------------------------------

function flat() {
  return this.reduce((a, b) => a.concat(Array.isArray(b) ? b.flat() : b), []);
}
if (!Array.prototype.flat) {
  // eslint-disable-next-line no-extend-native
  Array.prototype.flat = flat;
}

// ---------------------------------------------------------------------------------------------------------------------
// Cart utils
// ---------------------------------------------------------------------------------------------------------------------

window.clearBag = () => {
  setDataToLocalStorage(PRODUCTS_STORAGE_KEY(), {});
  dispatchProductUpdateEvent({});
  renderCartProductList();
  handleLightSpeedSideCart(0);
};

window.applyProductCoupon = (product) => {
  const code = product?.coupon_data?.[0]?.code;
  if (code) applyCoupon(code);
};

window.applyCoupon = (coupon) => {
  setDataToLocalStorage(BAG_COUPON_STORAGE_KEY(), { appliedCoupon: coupon });
};

window.getActiveSKUKey = (skuUUID, addonString) => {
  if (addonString === 'undefined') return skuUUID;
  const addOnUUIDs = addonString.split(',');
  const productKey = [skuUUID, addOnUUIDs.sort().join('__')]
    .filter((element) => !!element)
    .join('::');
  return productKey;
};

window.hashProduct = (product) => {
  // HASH SINGLE PRODUCT
  const serializedSKUs = serializeSKUs(product.skus || []);
  const attributes = getAllProductAttributeValues(serializedSKUs);
  DukaanData.PRODUCTS_MAP[product.uuid] = {
    ...product,
    ...window.languageSerializer(product),
    skus: serializedSKUs,
    attributes,
  };
};

window.hashProductMapper = (results = []) => {
  const PRODUCTS_MAP = results.reduce((map, product) => {
    const serializedSKUs = serializeSKUs(product.skus || []);
    const attributes = getAllProductAttributeValues(serializedSKUs);
    productReducerMapper(map, product, serializedSKUs, attributes);
    return map;
  }, {});

  window.DukaanData.PRODUCTS_MAP = {
    ...(DukaanData.PRODUCTS_MAP || []),
    ...(PRODUCTS_MAP || []),
  };
};

window.hashCategory = (results = []) => {
  window.DukaanData.DUKAAN_CATALOG = [
    ...window.DukaanData.DUKAAN_CATALOG,
    ...results,
  ];
};

// eslint-disable-next-line no-return-assign
window.productReducerMapper = (map, product, serializedSKUs, attributes) => {
  if (DukaanData.PRODUCTS_MAP?.[product.uuid]?.skusApi) return;
  map[product.uuid] = {
    ...product,
    ...window.languageSerializer(product),
    skus: serializedSKUs,
    attributes,
  };
};

window.hashProductMap = (results = []) => {
  let productMap = {};
  results?.forEach((category) => {
    productMap = {
      ...productMap,
      ...category?.products?.reduce((map, product) => {
        if (!product?.categories?.length) {
          product.categories = [{ ...category, products: [] }];
        }
        const serializedSKUs = serializeSKUs(product.skus || []);
        const attributes = getAllProductAttributeValues(serializedSKUs);
        productReducerMapper(map, product, serializedSKUs, attributes);
        return map;
      }, {}),
    };
  });

  window.DukaanData.PRODUCTS_MAP = {
    ...(DukaanData.PRODUCTS_MAP || []),
    ...(productMap || []),
  };
};

window.retrieveProductSku = async (productUUID, target = null) => {
  addToBagLoader(target, true);
  let product = window.DukaanData.PRODUCTS_MAP[productUUID];
  const previousSkus = product?.skus || [];
  const isBundleProduct = product?.bundle_data?.length > 0;
  const response = await fetch(
    `${window.DukaanData.CLIENT_API2_ENDPOINT}/api/product/buyer/${product.id}/product-details/`,
    {
      method: 'get',
      headers: {
        'Content-Type': 'application/json',
        'x-requested-with': window?.DukaanData?.DUKAAN_SESSION_ID,
      },
    }
  );

  const res = await response.json();
  const { skus, ...addons } = res?.data || [];
  let serializedSKUs = serializeSKUs(skus || []);
  if (typeof getFormattedSKUS !== 'undefined')
    serializedSKUs = getFormattedSKUS(serializedSKUs);

  const attributes = getAllProductAttributeValues(serializedSKUs);
  const { addOnsList, addOns } = getSerializedAddons(addons);
  product.skus = [];
  product = {
    ...product,
    ...addons,
    skus: serializedSKUs,
    attributes,
    addOnsList,
    addOns,
    skusApi: true,
  };

  if (isBundleProduct) {
    product.skus =
      product?.skus?.filter(
        (sku) => previousSkus?.filter((item) => item.id === sku.id)?.length
      ) || [];
  }

  window.DukaanData.PRODUCTS_MAP = {
    ...(DukaanData.PRODUCTS_MAP || []),
    [product.uuid]: product,
  };

  addToBagLoader(target, false);
  return product;
};

window.addToBagLoader = (target, addLoader) => {
  if (target !== null) {
    if (addLoader) {
      const loader = document
        .querySelector('.loaderContainer')
        ?.cloneNode(true);
      if (loader) {
        loader.classList.remove('hidden');
        target.classList.add('disabled');
        target.appendChild(loader);
      }
    } else {
      target.classList.remove('disabled');
      target.querySelector('.loaderContainer')?.remove();
    }
  }
};

window.abandonCartCall = () => {
  const constructBagData = () => {
    const { link, id: storeId } = DukaanData.DUKAAN_STORE;
    const CART_COUNT_KEY = 'cart-count';
    const CART_VARIANTS = 'cart-last-variants';
    const CART_QTY = 'cart-product-qty';
    const BAG_PRODUCTS_KEY = 'advanced-bag-products';
    const getStorageKey = (store, key) => `v3-${store}-${key}`;

    const getUserDataFromToken = () => {
      let userJSON = '';
      try {
        userJSON = JSON.parse(atob(localStorage.al_to.split('.')[1]));
      } catch {
        return {};
      }

      const { username } = userJSON;
      if (!username) return {};

      if (username.startsWith('+')) {
        return {
          mobile: username,
        };
      }
      return {
        email: username,
      };
    };

    const cartCount = getDataFromLocalStorage(
      getStorageKey(link, CART_COUNT_KEY)
    );
    const cartVariants = getDataFromLocalStorage(
      getStorageKey(link, CART_VARIANTS)
    );
    const cartQty = getDataFromLocalStorage(getStorageKey(link, CART_QTY));
    const bagProducts = getDataFromLocalStorage(
      getStorageKey(link, BAG_PRODUCTS_KEY)
    );
    const bagProductList = getBagProductListFromLocalStorage();

    const bagItems = bagProductList.map(
      ({ ordered_qty: orderedQty, parent_product: { name } = {} }) => ({
        name,
        quantity: orderedQty,
      })
    );

    const userData = getUserDataFromToken();

    return {
      name: '-',
      mobile: userData.mobile,
      email: userData.email,
      line: '-',
      line_1: null,
      city: '-',
      pin: '-',
      state: '-',
      landmark: '-',
      area: '-',
      country: 'in',
      store: storeId,
      meta: {
        cart_data: {
          products: [...bagItems],
          local_storage_data: {
            [CART_COUNT_KEY]: cartCount,
            [CART_VARIANTS]: cartVariants,
            [CART_QTY]: cartQty,
            [BAG_PRODUCTS_KEY]: bagProducts,
          },
        },
      },
    };
  };

  const setLocalStorageWithExpiration = (key, value, expirationMinutes) => {
    const now = new Date();
    const item = {
      value,
      expiration: now.getTime() + expirationMinutes * 60 * 1000, // Calculate expiration timestamp
    };
    localStorage.setItem(key, JSON.stringify(item));
  };

  const getLocalStorageWithExpiration = (key) => {
    try {
      const item = JSON.parse(localStorage.getItem(key));
      if (!item) return null;

      const now = new Date();
      if (now.getTime() > item.expiration) {
        // Item has expired, remove it from local storage and return null
        localStorage.removeItem(key);
        return null;
      }

      return item.value;
    } catch {
      return null;
    }
  };

  const CART_LEAD_LS_KEY = `v3-${DukaanData.DUKAAN_STORE.link}-session-cart-lead-data`;
  const sessionCartLead = getLocalStorageWithExpiration(CART_LEAD_LS_KEY);
  let url;
  if (sessionCartLead) {
    url = `${window.DukaanData.CLIENT_API_ENDPOINT}/api/order/buyer/cart-lead/?replace_abandoned_order_uuid=${sessionCartLead}`;
  } else {
    url = `${window.DukaanData.CLIENT_API_ENDPOINT}/api/order/buyer/cart-lead/`;
  }
  const payload = constructBagData();

  if (isLoggedIn()) {
    axios
      .patch(url, payload, {
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${localStorage.al_to}`,
        },
      })
      .then((res) => {
        const cartLeadUUID = res?.data?.data?.cart_lead_abandoned_order_uuid;

        if (cartLeadUUID) {
          setLocalStorageWithExpiration(CART_LEAD_LS_KEY, cartLeadUUID, 90);
        }
      });
  }
};

window.dknGenerateUUID = () => {
  // Public Domain/MIT
  let d = new Date().getTime(); // Timestamp
  let d2 =
    (typeof performance !== 'undefined' &&
      performance.now &&
      performance.now() * 1000) ||
    0; // Time in microseconds since page-load or 0 if unsupported
  return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, (c) => {
    let r = Math.random() * 16; // random number between 0 and 16
    if (d > 0) {
      // Use timestamp until depleted
      r = (d + r) % 16 | 0;
      d = Math.floor(d / 16);
    } else {
      // Use microseconds since page-load if supported
      r = (d2 + r) % 16 | 0;
      d2 = Math.floor(d2 / 16);
    }
    return (c === 'x' ? r : (r & 0x3) | 0x8).toString(16);
  });
};

window.PRODUCT_BUNDLES_TYPES = {
  COMBO: 'combo',
  MIX_MATCH: 'mix_and_match',
  X_FOR_Y: 'x_items_for_y_each',
};

window.PRODUCT_TYPES = {
  OLD_PRODUCT: 0,
  PRODUCT: 1,
  BUNDLE: 2,
};

window.BUNDLE_ITEM_TYPES = {
  PRODUCT: 'product',
  SKU: 'productsku',
  CATEGORY: 'productcategory',
};

window.bundleProductAdditionalRenderer = (productCard, product) => {
  const sku = product?.skus?.[0];
  if (!sku) return;
  const {
    original_price: originalPrice,
    selling_price: sellingPrice,
    primary_image: image,
    attributes,
  } = sku;

  const discountPercent = window.getDiscountPercentValue(
    sellingPrice,
    originalPrice
  );

  window.q$
    .selectAll('.dkn-product-card-selling-price', productCard)
    .modifyTextContentAll(window.formatMoney(sellingPrice));

  if (discountPercent > 0) {
    window.q$
      .selectAll('.dkn-product-card-original-price', productCard)
      .modifyTextContentAll(window.formatMoney(originalPrice));

    let discountText = '';
    if (window.getCustomDiscountText) {
      discountText = window.getCustomDiscountText(discountPercent);
    } else {
      discountText = `${discountPercent}% OFF`;
    }
    window.q$
      .selectAll('.dkn-product-card-discount', productCard)
      .modifyTextContentAll(discountText);
  } else {
    window.q$
      .selectAll('.dkn-product-card-original-price', productCard)
      .addClassAll('hidden');
    window.q$
      .selectAll('.dkn-product-card-discount', productCard)
      .addClassAll('hidden');
  }

  if (!image?.includes('category-def')) {
    q$.select('.dkn-product-card-image', productCard).setAttribute(
      'src',
      getCdnUrl(image, 500)
    );
  }

  if (
    attributes?.length &&
    (window?.advanceFiltersConfig?.showSkusOnBundlesPage ||
      DukaanData?.DUKAAN_PRODUCT?.product_bundle_type === 'combo' ||
      DukaanData?.DUKAAN_PRODUCT?.product_type === 1)
  ) {
    let variantsElem = q$
      .select('.dkn-product-card-variant-items', productCard)
      .addClass('flex')
      .addClass('w-100')
      .removeClass('hidden').elem;

    if (!variantsElem) {
      const div = document.createElement('div');
      div.classList.add(
        ...[
          'dkn-product-card-variant-items',
          'hidden',
          'mt-1',
          'flex',
          'flex-wrap',
          'w-100',
        ]
      );
      q$.select('.dkn-product-card-name', productCard).elem.appendChild(div);
      variantsElem = q$
        .select('.dkn-product-card-variant-items', productCard)
        .removeClass('hidden').elem;
    }

    attributes.forEach((attr) => {
      const isColor = dknCheckIfValueIsHexCode(attr.value);
      const div = document.createElement('div');
      if (isColor) {
        div.innerHTML = `Color: <span class="attr-item-bg" style="background-color: ${attr.value}; height: 16px; width: 16px; margin-left: 2px; border: 1px solid var(--black-90); border-radius: 3px"></span>`;
      } else {
        div.innerHTML = `${attr.master_attribute}: ${attr.value}`;
      }
      div.classList.add(
        'dkn-product-card-variant-item',
        'text-13_16',
        'text-c-black-30',
        'd-flex',
        'me-1',
        'pe-1',
        'flex'
      );
      div.style.setProperty('width', 'max-content');
      variantsElem.appendChild(div);
    });
  } else {
    q$.select('.dkn-product-card-variant-items', productCard).addClass(
      'hidden'
    );
  }
};

window.getBundleApplicablityData = (bundleProduct = {}) => {
  const { product_bundle_applicability: bundleApplicablityData = [] } =
    bundleProduct;

  let productIds = bundleApplicablityData
    ?.filter((item) => item.content_type === BUNDLE_ITEM_TYPES.PRODUCT)
    ?.map((item) => item.object_id);

  let productSkus = bundleApplicablityData
    ?.filter((item) => item?.content_type === BUNDLE_ITEM_TYPES.SKU)
    ?.map((item) => ({
      productId: item?.product_id,
      skuId: item.object_id,
      quantity_in_bundle: item?.quantity || 1,
    }))
    ?.filter((item) => item.productId);

  // prod id 1
  // sku id 1,2,3
  // sku seletced 1 2
  // [sku, sku]
  // [{pd: 1, skuid: 1}, {pd:1, skuid:2}]

  const productIdAndSKUIdMap = {};
  productSkus.forEach((item) => {
    productIdAndSKUIdMap[item.productId] = [
      ...(productIdAndSKUIdMap?.[item?.productId] || []),
      item.skuId,
    ];
  });

  // {1: [1,2]}
  productIds = [
    ...productIds, // [56,467,88] product type
    ...(productSkus?.map((item) => item.productId) || []), // [1,1] type sku ka prod id
  ];

  productIds = uniq(productIds);
  productSkus = Object.entries(productIdAndSKUIdMap).map(([key, value]) => ({
    productId: Number(key),
    skuIds: value,
  }));

  // [{pdid: 1, skuids:[1,2]}]

  const categoryIds = bundleApplicablityData
    ?.filter((item) => item.content_type === BUNDLE_ITEM_TYPES.CATEGORY)
    ?.map((item) => item.object_id);

  return { productIds, categoryIds, productSkus };
};

window.getColorName = () => {};

window.getBundleSerializedProduct = (product) => {
  const crossCategoryBundleProduct =
    DukaanData.CROSS_CATEGORY_BUNDLE_PRODUCT?.[0];

  const bundleProduct = DukaanData.DUKAAN_PRODUCT || crossCategoryBundleProduct;

  const url = new URL(window.location);
  const queryFromParams = url.searchParams.get('query');

  if (
    (DukaanData.DUKAAN_PAGE_KEY !== 'bundle' ||
      !bundleProduct ||
      queryFromParams?.length > 0 ||
      product?.uuid === bundleProduct?.uuid) &&
    !crossCategoryBundleProduct
  )
    return product;

  // which skus are applicable for the product
  const { productSkus } = getBundleApplicablityData(bundleProduct);
  const skuIds = productSkus?.find(
    (sku) => sku.productId === product.id
  )?.skuIds;

  // filter out skus if only some of them are applicable
  if (skuIds?.length) {
    product.skus =
      product?.skus?.filter((sku) => skuIds.includes(sku.id)) || [];
  }

  const {
    uuid,
    id,
    name,
    slug,
    product_bundle_applicability,
    product_bundle_discount_type,
    product_bundle_discount_value,
    product_bundle_each_line_item_price,
    product_bundle_max_line_item_quantity,
    product_bundle_min_line_item_quantity,
    product_bundle_type,
    product_type,
    max_bundle_qty_in_cart,
    all_images,
    skus,
    coupon_data,
    image,
  } = bundleProduct;

  product.bundle_data = [
    {
      id,
      name,
      image,
      all_images,
      skus,
      slug,
      coupon_data,
      product_bundle_applicability,
      product_bundle_discount_type,
      product_bundle_discount_value,
      product_bundle_each_line_item_price,
      product_bundle_max_line_item_quantity,
      product_bundle_min_line_item_quantity,
      max_bundle_qty_in_cart,
      product_bundle_type,
      product_type,
      bundle_qty: 0,
      bundle_group: null,
      bundle_uuid: uuid,
    },
  ];

  return product;
};

window.getValidBundleInstanceCountInCart = (bundleUUID) => {
  const bagProductList = window.getBagProductListFromLocalStorage();

  const { bundleGroups, allBundles, bundleIdBundleGroupIdMap } =
    bagProductList.reduce(
      (acc, bagProduct) => {
        const productBundleGroups = bagProduct.bundle_data || [];
        if (!productBundleGroups.length) return acc;

        productBundleGroups.forEach((productBundleGroup) => {
          acc.bundleGroups[productBundleGroup.bundle_group] ||= [];
          acc.bundleGroups[productBundleGroup.bundle_group].push(bagProduct);
          acc.allBundles[productBundleGroup.bundle_group] = productBundleGroup;

          acc.bundleIdBundleGroupIdMap[productBundleGroup.bundle_uuid] ||= [];
          if (
            !acc.bundleIdBundleGroupIdMap[
              productBundleGroup.bundle_uuid
            ].includes(productBundleGroup.bundle_group)
          ) {
            acc.bundleIdBundleGroupIdMap[productBundleGroup.bundle_uuid].push(
              productBundleGroup.bundle_group
            );
          }
        });

        return acc;
      },
      {
        allBundles: {},
        bundleGroups: {},
        bundleIdBundleGroupIdMap: {},
      }
    );

  const validBundleGroupUUID =
    bundleIdBundleGroupIdMap?.[bundleUUID]?.filter((key) => {
      const groupData = bundleGroups[key] || [];
      const total = groupData.reduce(
        (acc, item) =>
          acc +
          (item?.bundle_data?.find((b) => b.bundle_group === key)?.bundle_qty ||
            0),
        0
      );

      return total === allBundles[key].product_bundle_max_line_item_quantity;
    }) || [];

  return validBundleGroupUUID.length;
};

const singleQuantityToAddSku = 'c60e8f16-d159-4c4e-8c64-54935952174e';

window.addToBag = async (
  event, // browser event
  skuUUID,
  productUUID,
  {
    // quantityInputId,
    qtyToAdd = 1, // qty to increase of the SKU: qty = qty + qtyToAdd
    qtyToUpdate = 0, // update the quantity of an SKU in the cart: qty = qtyToUpdate
    addEventName = '', // analytics event - fb/google/internal analytics
    addonString = '',
    isBuyNow = false,
    skipSKUsCall = false, // bundles
    bundleGroupId = null, // bundles
  }
) => {
  if (typeof window.validateAddToBag === 'function') {
    const isValid = window.validateAddToBag(productUUID, skuUUID);
    if (!isValid) return;
  }
  const allBagProducts = getDataFromLocalStorage(PRODUCTS_STORAGE_KEY(), {});
  const skus = allBagProducts[productUUID] || {};

  // Skip adding if the SKU already has an ordered quantity and the quantity to add is non-negative
  if (skus[singleQuantityToAddSku]?.ordered_qty >= 1 && qtyToAdd >= 0) {
    return;
  }

  const type = qtyToAdd < 0 ? 'remove' : 'add';
  let product =
    window.DukaanData.PRODUCTS_MAP[productUUID] ||
    skus?.[skuUUID]?.parent_product;

  // handle size variant not selected feature
  const hasSizeAttribute =
    product?.skus?.[0]?.new_meta?.size || product?.skus?.[0]?.new_meta?.Size;

  const formId = `dkn-variant-form-${productUUID}-productPage`;
  if (
    document.querySelector(`form#${formId}`) &&
    hasSizeAttribute &&
    !bundleGroupId
  ) {
    const variantFormData = new FormData(
      document.querySelector(`form#${formId}`)
    );
    if (
      !(
        variantFormData?.getAll('size')?.length ||
        variantFormData?.getAll('Size')?.length
      )
    ) {
      if (!q$.select('.variant-form-error-text').elem) {
        const sizeDiv = q$.select(`form#${formId}`).elem;
        const div = document.createElement('div');
        div.classList.add('variant-form-error-text');
        sizeDiv.insertBefore(div, sizeDiv.firstChild);
      }
      q$.select('.variant-form-error-text')
        .removeClass('hidden')
        .addClass('shake')
        .modifyTextContent('Please select size')
        .elem.scrollIntoView({ behavior: 'smooth', block: 'center' });
      setTimeout(
        () => q$.select('.variant-form-error-text').removeClass('shake'),
        800
      );
      return;
    }
    q$.select('.variant-form-error-text').addClass('hidden');
  }

  vibrate(10);

  // fetch the latest sku data of the given product
  if (!product.skusApi && event && !skipSKUsCall) {
    const target = event.currentTarget;
    product = await retrieveProductSku(productUUID, target);
  }
  let sku = product?.skus?.[0];
  const { additional_meta: additionalMeta = {} } = DukaanData.DUKAAN_STORE;
  const {
    a2c_conversion_tag_meta: a2cConversionTagMeta,
    ga4_tag_meta: ga4Meta,
    ga4_360_event_map: ga4EventMap = {},
    hasATCAbandonFlow = false,
  } = additionalMeta || {};
  const {
    add_to_cart: addToCartEventConversionId,
    buy_now: buyNowEventConversionId,
  } = ga4EventMap;

  if (!skuUUID || skuUUID === 'null' || skuUUID === 'undefined') {
    if (
      (product.skus.length > 1 && product.skus[0]?.attributes?.length > 0) ||
      product?.addOnsList?.length > 0
    ) {
      const currentActiveProduct = getDataFromSessionStorage(
        'active-product',
        ''
      );
      if (!currentActiveProduct) {
        setDataToSessionStorage('active-add-event-name', addEventName);
        setDataToSessionStorage('active-product', productUUID);
      }
      return;
    }
  } else {
    sku = product.skus.find((s) => s.uuid === skuUUID);
    if (!sku) return;
  }

  let addOnUUIDs = [];
  if (
    Boolean(addonString) &&
    addonString !== 'undefined' &&
    addonString.length > 0
  )
    addOnUUIDs = addonString.split(',');

  const mandatoryAddOnGroups = product?.addOns?.filter(
    (addOnGroup) => addOnGroup.mandatory === true
  );

  let addOnError = false;
  mandatoryAddOnGroups?.forEach((addOnGroup) => {
    if (!addOnGroup.add_ons.find((item) => addOnUUIDs.includes(item.uuid))) {
      enqueueSnackbar(
        DukaanData.DUKAAN_LANGUAGE.PLEASE_SELECT_ONE__ADDONNAME.injectText({
          addonName: addOnGroup.name,
        }),
        true,
        'error'
      );
      //  Please select one ${addOnGroup.name}`, true, 'error');
      addOnError = true;
      return;
    }
    const selectedItems = addOnGroup.add_ons.filter((item) =>
      addOnUUIDs.includes(item.uuid)
    );
    if (selectedItems.length > 1 && addOnGroup.onlyOneSelection) {
      enqueueSnackbar(
        DukaanData.DUKAAN_LANGUAGE.PLEASE_SELECT_ONLY_ONE__ADDONNAME.injectText(
          {
            addonName: addOnGroup.name,
          }
        ),
        // `Please select only one ${addOnGroup.name}`,
        true,
        'error'
      );
      addOnError = true;
    }
  });

  if (addOnError) {
    return;
  }

  const productKey = getActiveSKUKey(skuUUID, addonString);
  const finalSkuUUID = productKey || sku?.uuid;

  let currentSKU = sku;
  let orderedQty = qtyToAdd;
  let newSKUs;

  if (skus[finalSkuUUID]) {
    currentSKU = skus[finalSkuUUID];
    orderedQty = currentSKU.ordered_qty + qtyToAdd;
  }

  if (qtyToUpdate) {
    orderedQty = Number.isNaN(qtyToUpdate) ? 1 : Number(qtyToUpdate);
  }

  // api data for max units to add in bag
  const allowedAddToBagQty = window?.DukaanData?.allowedAddToBagQty;
  const defaultInventoryValue = allowedAddToBagQty || 99;

  // if sku level inv 5 stop here instead of defaultinv 99
  const inventory = Math.min(
    currentSKU.inventory_quantity || 99,
    defaultInventoryValue
  );

  if (orderedQty > inventory) {
    if (typeof enqueueSnackbar !== 'undefined') {
      let oosMessage =
        DukaanData.DUKAAN_LANGUAGE.THE_SELLER_HAS_ONLY__INVENTORYQTY_OF_THESE_AVAILABLE.injectText(
          {
            inventoryQty: inventory,
          }
        );
      if (typeof window.getNoInventoryErrorMessage === 'function') {
        oosMessage = window.getNoInventoryErrorMessage({ inventory });
      }

      enqueueSnackbar(oosMessage, true);
    }
    return;
  }

  const pageKey = DukaanData.DUKAAN_PAGE_KEY;
  const { isMobile } = deviceType();
  if (orderedQty !== 0 && typeof enqueueSnackbar !== 'undefined') {
    const message = !currentSKU.ordered_qty
      ? DukaanData.DUKAAN_LANGUAGE.PRODUCT_ADDED_TO_BAG
      : DukaanData.DUKAAN_LANGUAGE.PRODUCT_QUANTITY_UPDATED_TO__ORDEREDQTY.injectText(
          {
            orderedQty,
          }
        );
    if (
      !(
        (pageKey === 'product' && isMobile) ||
        (window?.storeConfig?.hideAddToBagSnackbarOnMobile === true && isMobile)
      )
    ) {
      enqueueSnackbar(message, true, 'go-to-bag');
    }
  }

  if (!orderedQty && typeof closeSnackbar !== 'undefined') {
    closeSnackbar();
  }

  if (type === 'add') {
    closeSnackbar();
  }

  if (orderedQty <= 0) {
    newSKUs = { ...skus };
    if (newSKUs[finalSkuUUID]) {
      delete newSKUs[finalSkuUUID];
    } else {
      Object.keys(skus).forEach((cartSkuUUID) => {
        if (cartSkuUUID === currentSKU.uuid) {
          delete newSKUs[cartSkuUUID];
        }
      });
    }
    // removeProductLastVariant(parentProductUUID);
  } else {
    // bundle processing

    // product is product data from products_map
    const { bundle_data: currentBundleData = [] } = product || {};
    let bundleProduct = currentBundleData?.[0];

    // bundle data present in the cart or localstorage
    const finalBundleData = currentSKU?.bundle_data || [];

    // when bundle data is not present on window, cart ka bundle data is used
    if (!bundleProduct && finalBundleData?.length > 0) {
      bundleProduct = { ...finalBundleData[0] };
    }

    const canAddBundle =
      !bundleProduct?.max_bundle_qty_in_cart ||
      window.getValidBundleInstanceCountInCart(bundleProduct.bundle_uuid) <
        bundleProduct?.max_bundle_qty_in_cart;

    if (bundleProduct && !canAddBundle) {
      window.enqueueSnackbar(
        `You can only add ${bundleProduct.max_bundle_qty_in_cart} of this combo`,
        true
      );
      return;
    }

    if (bundleProduct) {
      const bagProductList = getBagProductListFromLocalStorage();
      const bundleGroupIdAndQtyPair = {};
      bagProductList
        ?.filter(
          (bagProduct) =>
            !!bagProduct?.bundle_data?.find(
              (bundle) => bundle.bundle_uuid === bundleProduct.bundle_uuid
            )
        )
        ?.forEach((bagProduct) => {
          bagProduct?.bundle_data?.forEach((bundle) => {
            if (bundle.bundle_uuid === bundleProduct.bundle_uuid) {
              bundleGroupIdAndQtyPair[bundle.bundle_group] =
                (bundleGroupIdAndQtyPair?.[bundle.bundle_group] || 0) +
                bundle.bundle_qty;
            }
          });
        });

      const maxQty = bundleProduct?.product_bundle_max_line_item_quantity;
      const existingGroupIds = Object.keys(bundleGroupIdAndQtyPair) || [];
      let currentBundleGroupId = null;
      if (type === 'add') {
        if (bundleGroupId) {
          finalBundleData.push({
            ...bundleProduct,
            bundle_qty: qtyToAdd,
            bundle_group: bundleGroupId,
          });
        } else if (bundleProduct?.product_bundle_type === 'combo') {
          finalBundleData.push({
            ...bundleProduct,
            bundle_qty: 1,
            bundle_group: dknGenerateUUID(),
          });
        } else {
          let qtyToAddInBundle = qtyToAdd;
          if (!finalBundleData?.length) {
            qtyToAddInBundle += currentSKU.ordered_qty || 0;
          }
          let noOfItemsToBeAdded = qtyToAddInBundle;
          existingGroupIds.forEach((key) => {
            if (bundleGroupIdAndQtyPair[key] < maxQty) {
              const existingBundleItem = finalBundleData?.find(
                (bundle) =>
                  bundle.bundle_uuid === bundleProduct.bundle_uuid &&
                  bundle.bundle_group === key
              );

              if (existingBundleItem) {
                const difference = maxQty - bundleGroupIdAndQtyPair[key];
                if (difference > noOfItemsToBeAdded) {
                  existingBundleItem.bundle_qty += noOfItemsToBeAdded;
                  noOfItemsToBeAdded = 0;
                } else {
                  existingBundleItem.bundle_qty += difference;
                  noOfItemsToBeAdded -= difference;
                }
              } else {
                currentBundleGroupId = key;
              }
            }
          });

          if (noOfItemsToBeAdded > 0) {
            if (currentBundleGroupId) {
              const qtyPresent = bundleGroupIdAndQtyPair[currentBundleGroupId];
              const difference = maxQty - qtyPresent;
              if (difference >= noOfItemsToBeAdded) {
                finalBundleData.push({
                  ...bundleProduct,
                  bundle_qty: noOfItemsToBeAdded,
                  bundle_group: currentBundleGroupId,
                });
                noOfItemsToBeAdded = 0;
              } else {
                finalBundleData.push({
                  ...bundleProduct,
                  bundle_qty: difference,
                  bundle_group: currentBundleGroupId,
                });
                noOfItemsToBeAdded -= difference;
              }
            }

            for (let i = 1; i <= noOfItemsToBeAdded / maxQty; i += 1) {
              finalBundleData.push({
                ...bundleProduct,
                bundle_qty: maxQty,
                bundle_group: dknGenerateUUID(),
              });
            }

            if (noOfItemsToBeAdded % maxQty !== 0) {
              finalBundleData.push({
                ...bundleProduct,
                bundle_qty: noOfItemsToBeAdded % maxQty,
                bundle_group: dknGenerateUUID(),
              });
            }
          }
        }
      } else {
        const currentBundleGroups = finalBundleData?.filter(
          (bundle) => bundle.bundle_uuid === bundleProduct.bundle_uuid
        );
        const otherBundleGroups = finalBundleData?.filter(
          (bundle) => !bundle.bundle_uuid === bundleProduct.bundle_uuid
        );

        let index = -1;

        if (currentBundleGroups?.length) {
          const leastQauntityItem = currentBundleGroups.sort(
            (a, b) => a.bundle_qty - b.bundle_qty
          )?.[0];
          index = finalBundleData.findIndex(
            (bundle) =>
              bundle.bundle_uuid === leastQauntityItem.bundle_uuid &&
              bundle.bundle_group === leastQauntityItem.bundle_group
          );
        } else if (otherBundleGroups?.length) {
          const leastQauntityItem = otherBundleGroups.sort(
            (a, b) => a.bundle_qty - b.bundle_qty
          )?.[0];
          index = finalBundleData.findIndex(
            (bundle) =>
              bundle.bundle_uuid === leastQauntityItem.bundle_uuid &&
              bundle.bundle_group === leastQauntityItem.bundle_group
          );
        }

        if (index !== -1) {
          finalBundleData[index].bundle_qty += qtyToAdd;
          if (finalBundleData[index].bundle_qty === 0) {
            finalBundleData.splice(index, 1);
          }
        }
      }
    }

    newSKUs = {
      ...skus,
      [finalSkuUUID]: {
        ...currentSKU,
        product_key: finalSkuUUID,
        uuid: sku.uuid,
        parent_product: product,
        ordered_qty: orderedQty,
        selected_addons: addOnUUIDs,
        add_ons: product.addOnsList,
        bundle_data: finalBundleData || [],
      },
    };
  }

  const newBagProducts = {
    ...allBagProducts,
    [productUUID]: newSKUs,
  };

  if (type === 'add') {
    GAPage();
    if (typeof window.customAddToBagEventHandler !== 'undefined') {
      window.customAddToBagEventHandler(currentSKU, product);
    }
    if (addEventName) {
      // internal analytics
      druidProductAddClick(product, addEventName);
    }
    if (window.scq) {
      // sharechat analytics
      window.scq('Add to cart', 'pre_defined');
    }

    if (window.gtag && a2cConversionTagMeta) {
      window.gtag('event', 'conversion', {
        send_to: a2cConversionTagMeta,
        value: sku.selling_price,
        currency: DukaanData?.DUKAAN_STORE?.currency?.cc,
      });
    }

    if (
      window.gtag &&
      ga4Meta &&
      (addToCartEventConversionId || buyNowEventConversionId)
    ) {
      window.gtag('event', 'conversion', {
        allow_custom_scripts: true,
        send_to: isBuyNow
          ? buyNowEventConversionId
          : addToCartEventConversionId,
      });
    }

    // if (window.fbq) {
    //   sendServerSideEvent({
    //     event_name: 'AddToCart',
    //     contents: [
    //       {
    //         id: sku.id,
    //         quantity: 1,
    //         item_price: sku.selling_price,
    //         delivery_category: 'home_delivery',
    //       },
    //     ],
    //     custom_data: {
    //       value: sku.selling_price,
    //       content_name: product.name,
    //       content_type: 'product',
    //       content_ids: [sku.id],
    //     },
    //   });
    // }
  } else if (typeof window.customRemoveFromBagEventHandler !== 'undefined') {
    window.fireGoogleEcommerceProductRemoveFromBagEvent(currentSKU, product);
  }

  // if (type !== 'remove' && !window?.storeConfig?.skipAutomaticBXGYCouponApply) {
  //   applyProductCoupon(product);
  // }

  // setDataToLocalStorage(BAG_PRODUCTS_STORAGE_KEY, newBagProducts);
  // if (qtyToAdd > 0) appendProductLastVariant(parentProductUUID, skuUUID);
  // setBagProducts(newBagProducts);

  setDataToLocalStorage(PRODUCTS_STORAGE_KEY(), newBagProducts);
  dispatchProductUpdateEvent(newBagProducts);
  // const event = new Event(LOCAL_STORAGE_UPDATED_EVENT_NAME);
  // event.key = PRODUCTS_STORAGE_KEY();
  // event.value = newBagProducts;
  // document.dispatchEvent(event);
  checkCouponSticky(); // BXGY ka congratulations message strip
  if (typeof renderSubtotal !== 'undefined') renderSubtotal(); // lightspeed ka cart

  // moengage ya internal events
  if (type === 'remove') {
    window.dknRemoveFromBagEvent(sku, product, {
      qty: qtyToUpdate || qtyToAdd,
    });
  } else if (bundleGroupId) {
    window.dknAddToBagEvent(product?.skus?.[0], product, {
      qty: qtyToAdd,
      isBundle: true,
    });
  } else {
    window.dknAddToBagEvent(sku, product, {
      qty: qtyToUpdate || qtyToAdd,
    });
  }

  // quickcheckout
  let skuPrimaryImage = sku?.primary_image;
  if (
    [
      'https://api-enterprise.mydukaan.io/static/images/category-def.jpg',
      'https://api.mydukaan.io/static/images/category-def.jpg',
    ].includes(skuPrimaryImage)
  ) {
    skuPrimaryImage = '';
  }
  showAddToBagSnackbar({
    name: product.name,
    image:
      skuPrimaryImage ||
      product?.all_images?.[0] ||
      'https://api-enterprise.mydukaan.io/static/images/category-def.jpg',
  });

  if (DukaanData?.DUKAAN_STORE?.additional_meta?.hasQuickCheckout) {
    renderQuickCheckoutPopup();
  }

  if (type === 'add' && typeof afterAddToBagCall !== 'undefined') {
    afterAddToBagCall(productUUID, skuUUID, { qty: qtyToUpdate || qtyToAdd });
  }

  if (hasATCAbandonFlow) {
    abandonCartCall();
  }

  if (isBuyNow) {
    window.redirectToBagPage();
  }

  return true;
};

window.checkCouponSticky = () => {
  if (document.querySelector('.coupon-sticky')) {
    const elem = document.querySelector('.coupon-sticky');
    if (elem.classList.contains('hidden')) {
      document.documentElement.style.setProperty(
        '--container-bottom-sticky',
        '0'
      );
    } else {
      document.documentElement.style.setProperty(
        '--container-bottom-sticky',
        '42px'
      );
    }
  }
};

window.checkStoreClosedSticky = () => {
  if (document.querySelector('.storeClosed')) {
    document.documentElement.style.setProperty(
      '--container-bottom-sticky',
      '42px'
    );
  } else {
    document.documentElement.style.setProperty(
      '--container-bottom-sticky',
      '0px'
    );
  }
};

window.dispatchProductUpdateEvent = (newBagProducts) => {
  const event = new Event(LOCAL_STORAGE_UPDATED_EVENT_NAME);
  event.key = PRODUCTS_STORAGE_KEY();
  event.value = newBagProducts;
  document.dispatchEvent(event);
};

window.getProductCosts = (bagProducts) => {
  if (bagProducts?.length > 0) {
    return bagProducts.reduce(
      (total, product) => {
        const {
          parent_product: parentProduct,
          ordered_qty: orderedQty,
          selling_price: variantSellingPrice,
          original_price: variantOriginalPrice,
        } = product;
        const addOnPrice = getAddOnTotal(product);

        const sellingPrice =
          Number(orderedQty) *
          ((Number(variantSellingPrice) ||
            Number(parentProduct.selling_price)) +
            Number(addOnPrice));

        const originalPrice =
          Number(orderedQty) *
          ((Number(variantOriginalPrice) ||
            Number(parentProduct.original_price)) +
            Number(addOnPrice));

        total.sellingPrice += sellingPrice;
        total.originalPrice += originalPrice;
        return total;
      },
      { sellingPrice: 0, originalPrice: 0 }
    );
  }
  return { sellingPrice: 0, originalPrice: 0 };
};

window.getBagProductListFromLocalStorage = () => {
  const bagProducts = getDataFromLocalStorage(PRODUCTS_STORAGE_KEY(), {});
  const bagProductList = Object.values(bagProducts).map(Object.values).flat();
  return bagProductList;
};

window.totalBagCost = () => {
  const bagProductList = getBagProductListFromLocalStorage();

  const {
    sellingPrice: totalProductCost,
    originalPrice: totalProductSellingCost,
  } = getProductCosts(bagProductList);

  return { totalProductCost, totalProductSellingCost };
};

window.fetchCoupons = ({ successCallback = () => {} }) => {
  const headers = {};
  if (localStorage && localStorage.al_to) {
    headers.Authorization = `Bearer ${localStorage.al_to}`;
  }
  headers['Content-Type'] = 'application/json';
  headers['x-requested-with'] = window?.DukaanData?.DUKAAN_SESSION_ID;

  let couponUrl = `${window.DukaanData.CLIENT_API_ENDPOINT}/api/coupon/buyer/${DukaanData.DUKAAN_STORE.link}/coupon/v2/`;
  if (DukaanData?.DUKAAN_PRODUCT?.id)
    couponUrl += `?product_id=${DukaanData?.DUKAAN_PRODUCT?.id}`;

  const urls = [couponUrl];
  const requests = urls.map((url) =>
    axios.get(url, {
      headers,
    })
  );

  Promise.all(requests)
    .then(([couponsDataRes]) => {
      const couponsData = couponsDataRes?.data.results || [];

      const background =
        window.DukaanData?.DUKAAN_THEME_DATA?.meta?.background?.mode || 'light';

      window.DukaanData.DUKAAN_COUPONS =
        couponsData.length > 0
          ? getCouponSerializedData(couponsData, background)
          : [];

      successCallback();
    })
    .catch((error) => {
      console.log(error);
    });
};

window.getAddOnTotal = (product) => {
  if (!product.add_ons || !product.selected_addons) return 0;

  const allAddOns = [
    ...product.add_ons,
    ...(product?.add_on_groups?.map((group) => group.add_ons).flat() || []),
  ];

  return product.selected_addons.reduce((total, addOnUuid) => {
    const inputAddOn = allAddOns.find((addOn) => addOn.uuid === addOnUuid);

    if (inputAddOn) return total + inputAddOn.price;
    return total;
  }, 0);
};

// ---------------------------------------------------------------------------------------------------------------------
// Handlers
// ---------------------------------------------------------------------------------------------------------------------

window.handleLightSpeedSideCart = (count) => {
  if (count > 0 && window.DukaanData.DUKAAN_STORE.meta.is_online) {
    if (typeof renderSubtotal !== 'undefined') renderSubtotal();

    if (document.querySelector('.subtotal-element')) {
      document.querySelector('.subtotal-element').classList.remove('hidden');
    }

    if (document.querySelector('.clear-bag-button')) {
      document.querySelector('.clear-bag-button').classList.remove('hidden');
    }
    if (document.querySelector('.proceed-checkout-button')) {
      document
        .querySelector('.proceed-checkout-button')
        .classList.remove('hidden');
    }
    if (document.querySelector('.cart-sidebar-header .divider')) {
      document
        .querySelector('.cart-sidebar-header .divider')
        .classList.remove('hidden');
    }
    if (document.querySelector('.subTotaldivider')) {
      document.querySelector('.subTotaldivider').classList.remove('hidden');
    }
  } else {
    if (document.querySelector('.subtotal-element')) {
      document.querySelector('.subtotal-element').classList.add('hidden');
    }

    if (document.querySelector('.clear-bag-button')) {
      document.querySelector('.clear-bag-button').classList.add('hidden');
    }
    if (document.querySelector('.proceed-checkout-button')) {
      document
        .querySelector('.proceed-checkout-button')
        .classList.add('hidden');
    }
    if (document.querySelector('.cart-sidebar-header .divider')) {
      document
        .querySelector('.cart-sidebar-header .divider')
        .classList.add('hidden');
    }
    if (document.querySelector('.subTotaldivider')) {
      document.querySelector('.subTotaldivider').classList.add('hidden');
    }
  }
};

window.handleBagCountChange = (element, event) => {
  const products = event.value;
  const count = Object.values(products)
    .map(Object.values)
    .flat()
    .reduce((total, product) => product.ordered_qty + total, 0);
  if (count > 0) {
    element.classList.remove('hidden');
    element.innerHTML = `${count}`;
  } else {
    element.classList.add('hidden');
  }

  /** Conditional rendering for lightspeed  */
  if (document.querySelector('#lightspeed-cart-sidebar')) {
    handleLightSpeedSideCart(count);
  }

  // conditional renderering for whole truth
  if (document.querySelector('.dkn-whole-truth-bag-count')) {
    if (count >= 0) {
      element.classList.remove('hidden');
      element.innerHTML = `${count}`;
    } else {
      element.classList.add('hidden');
    }
  }

  q$.selectAll('.bagWithIframeCart-header .items-text').modifyTextContentAll(
    pluralize(count, 'item')
  );
};

window.handleProductCountChange = (element, event) => {
  const products = event.value;
  const { uuid } = element.dataset;
  const allProducts = window.DukaanData.PRODUCTS_MAP;
  const productBySKU = Object.values(allProducts).find((product) =>
    product.skus.map((sku) => sku.uuid).includes(uuid)
  );

  if (!products[productBySKU.uuid]) return;

  const count = products[productBySKU.uuid][uuid].ordered_qty;
  element.innerHTML = `${count}`;
};

window.handleProductTotalCountChange = (element, event) => {
  const products = event.value;
  const { uuid } = element.dataset;
  const product = window.DukaanData.PRODUCTS_MAP[uuid];

  if (!product || !products[product.uuid]) return;

  const count = Object.values(products[product.uuid] || {}).reduce(
    (total, sku) => sku.ordered_qty + total,
    0
  );
  element.innerHTML = `${count}`;
};

window.renderCartProductList = () => {
  customTag('cart-product-list', cartProductListRenderer);
};

window.addEventListener('message', (event) => {
  if (event?.data?.fromDukaanCheckout && event?.data?.redirectLink) {
    window.location = event.data.redirectLink;
  }

  if (event?.data?.fromDukaanCheckout && event?.data?.bagProductStateUpdated) {
    initialProductUpdate();
  }
});

window.showAddToBagSnackbar = ({ name, image }) => {
  if (DukaanData?.DUKAAN_STORE?.additional_meta?.dontShowAddToBarSnackbar)
    return;

  closeQuickCheckoutPopup();

  const snackBarHTML = `
    <style>
      .dkn-quick-checkout-snackbar {
        cursor: pointer;
        background-color: #ffffff;
        color: #1A181E;
        position:fixed;
        bottom:16px;
        right:16px;
        width:auto;
        z-index: 10000;
        display: flex;
        align-items: center;
        box-shadow: 0 4px 16px 0 rgb(26 24 30 / 24%) !important;
        border-radius: 6px;
        overflow: hidden;
        padding: 10px;
      }
      .dkn-quick-checkout-product-info-wrapper {
        display: flex;
        flex-direction: column;
      }
      .dkn-quick-checkout-product-image {
        height: 88px;
        width: 88px;
        border-radius: 4px;
        border: 1px solid #ddd;
        margin-right: 10px;
        object-fit: cover;
      }
      .dkn-quick-checkout-product-name {
        font-size: 16px;
        line-height: 24px;
        max-width: 200px;
        width: 200px;
        margin-bottom: 8px;
        font-weight: 500;      
        overflow: hidden;
        text-overflow: ellipsis;
        display: -webkit-box;
        word-break: break-word;
        -webkit-box-orient: vertical;
        -webkit-line-clamp: 2;
      }
      .dkn-quick-checkout-label {
        font-size: 14px;
        font-weight: 500;
        line-height: 20px;
        width: fit-content;
        padding: 4px 12px;
        background-color: #1A181E;
        color: white;
        border-radius: 4px;
      }
    </style>
    <div onclick="renderQuickCheckoutPopup()" class="dkn-quick-checkout-snackbar">
      <img class="dkn-quick-checkout-product-image" alt="${name}" src="${getCdnUrl(
    image,
    200,
    200
  )}" 
      />
      <div class="dkn-quick-checkout-product-info-wrapper">
        <div class="dkn-quick-checkout-product-name">${name}</div>
        <div class="dkn-quick-checkout-label">Checkout</div>
      </div>
    </div>
  `;

  const prevSnackbar = document.querySelector('#dkn-quick-checkout-snackbar');
  if (prevSnackbar) {
    prevSnackbar.remove();
  }

  const snackbar = document.createElement('div');
  snackbar.setAttribute('id', 'dkn-quick-checkout-snackbar');
  snackbar.innerHTML = snackBarHTML;
  document.querySelector('body').appendChild(snackbar);

  setTimeout(() => {
    snackbar.remove();
  }, 5000);
};

window.closeQuickCheckoutPopup = () => {
  const { isMobile } = deviceType();
  if (isMobile) {
    q$.select('body').setStyleProperty('overflow', 'auto');
  }
  q$.selectById('bagWithIframeCart').addClass('hidden');
  q$.selectById('bagWithIframeCart').elem?.remove();
};

window.renderQuickCheckoutPopup = () => {
  // if (!DukaanData?.DUKAAN_STORE?.additional_meta?.hasQuickCheckout) return;

  closeSnackbar();
  const { isMobile } = deviceType();
  const products = getBagProductListFromLocalStorage();
  const bagCount = products.reduce(
    (total, product) => product.ordered_qty + total,
    0
  );
  if (!q$.selectById('bagWithIframeCart').elem) {
    const modalHTML = `
  <style>
    .bagWithIframeCart-content-wrapper {
      position: fixed;
      right: 0;
      top: 0;
      width: 100%;
      min-width: 100%;
      height: 100%;
      min-height: 100%;
      z-index: 10000;
      background-color: white;
      -webkit-animation: run 0.25s ease-in;
      animation: run 0.25s ease-in;
      box-shadow: 5px 5px 9px 5px rgba(0,0,0,0.2);
    }
  
    .bagWithIframeCart-content {
      height: calc(100% - 56px)
    }
  
    @media screen and (min-width: 1024px) {
      .bagWithIframeCart-content-wrapper {
        width: 446px;
        min-width: 446px;
      }
    }
    @-webkit-keyframes run {
      0% {
        right: -100%;
      }
      100% {
        right: 0;    
      }
    }
  </style>
  <div class="${isMobile ? 'modal' : ''} hidden" id="bagWithIframeCart" ${
      isMobile ? 'onclick="closeQuickCheckoutPopup()' : ''
    }">
    <div class="bagWithIframeCart-content-wrapper" onclick="event.stopPropagation()">
      <div class="bagWithIframeCart-header flex a-c j-sb" style="padding: 16px;">
        <div class="cart-items-text text-16_24" style="font-weight: 500; color: #121212 !important">Your items (<span class="cart-items-count dkn-whole-truth-bag-count" data-subscribe="products"
            data-entity-type="bag-count">${bagCount}</span>&nbsp;<span class="items-text">${pluralize(
      bagCount,
      'item'
    )}</span>)</div>
        <div class="bagWithIframeCart-close-button" onclick="closeQuickCheckoutPopup()" style="cursor: pointer">
          <svg width="24" height="24" viewBox="0 0 32 32" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path fill-rule="evenodd" clip-rule="evenodd"
              d="M24.9441 8.94264C25.4648 8.42195 25.4648 7.57773 24.9441 7.05703C24.4234 6.53633 23.5792 6.53633 23.0585 7.05703L16.0013 14.1142L8.94411 7.05703C8.42341 6.53633 7.57919 6.53633 7.05849 7.05703C6.53779 7.57773 6.53779 8.42195 7.05849 8.94264L14.1157 15.9998L7.05849 23.057C6.53779 23.5777 6.53779 24.4219 7.05849 24.9426C7.57919 25.4633 8.42341 25.4633 8.94411 24.9426L16.0013 17.8854L23.0585 24.9426C23.5792 25.4633 24.4234 25.4633 24.9441 24.9426C25.4648 24.4219 25.4648 23.5777 24.9441 23.057L17.8869 15.9998L24.9441 8.94264Z"
              fill="#4D4D4D" />
          </svg>
        </div>
      </div>
      <div class="bagWithIframeCart-content"></div>
    </div>
  </div>`;

    const body = q$.select('body').elem;
    const tempDiv = document.createElement('div');
    tempDiv.innerHTML = modalHTML;
    body.appendChild(tempDiv);
  }

  if (isMobile) {
    q$.select('body').setStyleProperty('overflow', 'hidden');
  }

  q$.selectById('bagWithIframeCart').removeClass('hidden');
  q$.select('#bagWithIframeCart .bagWithIframeCart-content').modifyInnerHTML(
    `<iframe src="/${DukaanData.DUKAAN_STORE.link}/bag?quickCheckout=true" style="height: 100%; width: 100%;" ></iframe>`
  );
  q$.select('#bagWithIframeCart .dkn-whole-truth-bag-count').modifyTextContent(
    bagCount
  );
};

window.handleProductUpdates = (event) => {
  document
    .querySelectorAll('[data-subscribe="products"]')
    .forEach((element) => {
      const { entityType } = element.dataset;
      if (entityType === 'bag-count') {
        handleBagCountChange(element, event);
      } else if (entityType === 'product-count') {
        //  (element, event);
      } else if (entityType === 'product-total-count') {
        handleProductTotalCountChange(element, event);
      } else if (entityType === 'cart-product-list') {
        // handleCartSidebarChange(element, event);
      } else if (entityType === 'bxgy-footer') {
        toggleCouponFooter();
      } else if (entityType === 'go-to-checkout-sticky') {
        if (typeof renderStickyGoToCheckout !== 'undefined') {
          renderStickyGoToCheckout();
        }
      }
    });
  renderCartProductList();
  renderAllAddToBagButton();
  renderAllBuyNowButton();
};

window.initialProductUpdate = () => {
  const data = getDataFromLocalStorage(PRODUCTS_STORAGE_KEY(), {});
  const event = new Event(LOCAL_STORAGE_UPDATED_EVENT_NAME);
  event.value = data;
  event.key = PRODUCTS_STORAGE_KEY();

  handleProductUpdates(event);
};

window.findActiveSKUByAttributes = (skus, { size, color }) => {
  const currentSKU = skus.find(
    (sku) =>
      (!size || sku.meta.size.value === size) &&
      (!color || sku.meta.color.value === color)
  );
  if (currentSKU) return currentSKU;

  return skus.find((sku) => !size || sku.meta.size.value === size);
};

window.renderVariantSelectionForm = (
  selectionFormTemplateId,
  productUUID,
  variantSelectionFormAdditionalRenderer,
  buttonTemplateId,
  mountElem
) => {
  const activeProduct = window.DukaanData.PRODUCTS_MAP[productUUID];
  const activeSKU = getFirstSKUWhichIsInStock(activeProduct?.skus);
  const productCardTemplate = document.getElementById(selectionFormTemplateId);
  const sizeItemTemplate = document.getElementById('size-variant-item');
  const colorItemTemplate = document.getElementById('color-variant-item');

  const variantSelectionForm = document.importNode(
    productCardTemplate.content,
    true
  );
  const sizeListNode = variantSelectionForm.querySelector('.size-selection');
  const sizeListHeadingNode = variantSelectionForm.querySelector(
    '.size-selection-heading'
  );
  const colorListNode = variantSelectionForm.querySelector('.color-selection');
  const colorListHeadingNode = variantSelectionForm.querySelector(
    '.color-selection-heading'
  );
  const sizeSelectionWrapper = variantSelectionForm.querySelector(
    '.size-selection-wrapper'
  );
  const colorSelectionWrapper = variantSelectionForm.querySelector(
    '.color-selection-wrapper'
  );
  const addonSelectionWrapper = variantSelectionForm.querySelector(
    '.addon-selection-wrapper'
  );

  const sizeVariantSectionWrapper = q$.select(
    '.dkn-size-variant-section-wrapper',
    variantSelectionForm
  ).elem;
  const colorVariantSectionWrapper = q$.select(
    '.dkn-color-variant-section-wrapper',
    variantSelectionForm
  ).elem;

  const productInformation = variantSelectionForm.querySelector(
    '.product-information'
  );
  // const productDescription = variantSelectionForm.querySelector('.product-description')

  const isResto = DukaanData.DUKAAN_STORE.store_category === 6;

  if (productInformation) {
    productInformation.querySelector('.product-name').textContent =
      activeProduct?.name;
    // const cdnSize =
    //   productInformation.querySelector('.product-image').dataset
    //     .productImageCdnSize;
    productInformation
      .querySelector('.product-image')
      .setAttribute(
        'src',
        `${getCdnUrl(
          activeProduct?.image,
          window?.DukaanData?.PRODUCT_IMAGE_CDN_SIZE || 700
        )}`
      );

    const foodIcon = productInformation.querySelector('.food-icon');
    if (foodIcon && activeProduct?.meta?.length > 0) {
      foodIcon.innerHTML = getFoodTypeIcon(activeProduct?.meta);
      foodIcon.classList.remove('hidden');
    }
  }

  // if (productDescription && isResto) {
  //     productDescription.classList.remove('hidden');
  //     productDescription.innerHTML =  activeProduct?.description;
  // }

  if (!activeProduct?.attributes?.size?.length) {
    if (sizeListHeadingNode) {
      sizeListHeadingNode.classList.add('hidden');
    }
  }

  if (!activeProduct?.attributes?.color?.length) {
    if (colorListHeadingNode) {
      colorListHeadingNode.classList.add('hidden');
    }
  }

  // let defaultSKU = 0;
  if (activeProduct?.attributes?.size) {
    let sizeAttr = [...(activeProduct?.attributes?.size || [])];
    if (typeof sortSkuBySizes !== 'undefined' && Boolean(sizeAttr?.length)) {
      sizeAttr = sortSkuBySizes(sizeAttr);
      // if (getDefaultSelectedSku !== 'undefined')
      //   defaultSKU = getDefaultSelectedSku(activeProduct);
    }
    const sizeListHeadingLabel = sizeListHeadingNode?.querySelector(
      '.size-selection-label'
    );
    if (sizeListHeadingLabel) {
      if (isResto) {
        sizeListHeadingLabel.innerHTML = DukaanData.DUKAAN_LANGUAGE.VARIANTS;
      } else if (activeSKU.meta.size.attributeLabel) {
        sizeListHeadingLabel.innerHTML =
          DukaanData.DUKAAN_LANGUAGE.SELECT__ATTRIBUTE.injectText({
            attribute: activeSKU.meta.size.attributeLabel,
          });
        // `${DukaanData.DUKAAN_LANGUAGE.SELECT__ATTRIBUTE} ${activeSKU.meta.size.attributeLabel}`;
      } else {
        sizeListHeadingLabel.innerHTML =
          DukaanData.DUKAAN_LANGUAGE.SELECT__ATTRIBUTE.injectText({
            attribute: DukaanData.DUKAAN_LANGUAGE.SIZE,
          });
        // `${DukaanData.DUKAAN_LANGUAGE.SELECT} ${DukaanData.DUKAAN_LANGUAGE.SIZE}`;
      }
    }

    const sizeListHeadingText = sizeSelectionWrapper?.querySelector('span');
    if (sizeListHeadingText) {
      if (isResto) {
        sizeListHeadingText.innerHTML = `${DukaanData.DUKAAN_LANGUAGE.VARIANTS}<sup class="c-red">*</span>`;
      } else if (activeSKU.meta.size.attributeLabel) {
        sizeListHeadingText.innerHTML = `${DukaanData.DUKAAN_LANGUAGE.SELECT__ATTRIBUTE.injectText(
          {
            attribute: activeSKU.meta.size.attributeLabel,
          }
        )} <sup class="c-red">*</span>`;
      } else {
        sizeListHeadingText.innerHTML = `${DukaanData.DUKAAN_LANGUAGE.SELECT__ATTRIBUTE.injectText(
          {
            attribute: DukaanData.DUKAAN_LANGUAGE.SIZE,
          }
        )} <sup class="c-red">*</span>`;
      }
    }

    if (sizeListNode && sizeAttr.length > 0) {
      sizeListNode?.classList?.remove('hidden');
      sizeAttr?.forEach((size, index) => {
        const currentSKU = findActiveSKUByAttributes(activeProduct.skus, {
          size,
        });
        const sizeItem = document.importNode(sizeItemTemplate.content, true);
        const sizeItemInput = sizeItem.querySelector('input');

        if (size === activeSKU.meta.size.value)
          sizeItemInput.setAttribute('checked', 'true');
        sizeItemInput.setAttribute('id', `m-size-${size}`);
        sizeItemInput.setAttribute('value', size);
        if (!buttonTemplateId) {
          sizeItemInput.setAttribute(
            'onclick',
            `handleVariantChange('${productUUID}', {mountElem : '${mountElem}'})`
          );
        } else {
          sizeItemInput.setAttribute(
            'onclick',
            `handleVariantChange('${productUUID}', { buttonTemplateId: '${buttonTemplateId}' })`
          );
        }
        sizeItem.querySelector('label').setAttribute('for', `m-size-${size}`);
        sizeItem.querySelector('.size-value').textContent = `${size}`;
        if (sizeItem.querySelector('.size-original-price')) {
          if (currentSKU.original_price > currentSKU.selling_price) {
            sizeItem.querySelector(
              '.size-original-price'
            ).textContent = `${formatMoney(currentSKU.original_price)}`;
          }
        }
        if (sizeItem.querySelector('.size-discount')) {
          if (currentSKU.original_price > currentSKU.selling_price) {
            const discountValue = getDiscountPercentValue(
              currentSKU.selling_price,
              currentSKU.original_price
            );
            sizeItem.querySelector('.size-discount').textContent =
              typeof customDiscountFormatterForModal === 'function'
                ? customDiscountFormatterForModal(discountValue)
                : `(${discountValue}% OFF)`;
            sizeItem.querySelector('.size-discount').classList.remove('hidden');
          } else {
            sizeItem.querySelector('.size-discount').classList.add('hidden');
          }
        }
        if (sizeItem.querySelector('.size-selling-price')) {
          sizeItem.querySelector(
            '.size-selling-price'
          ).textContent = `${formatMoney(currentSKU.selling_price)}`;
        }

        if (sizeSelectionWrapper) {
          sizeSelectionWrapper.classList.remove('hidden');
        }

        sizeListNode.appendChild(sizeItem);
      });
    }
  } else {
    sizeVariantSectionWrapper?.classList?.add('hidden');
  }

  if (activeProduct?.attributes?.color) {
    const colorListHeadingLabel = colorListHeadingNode?.querySelector(
      '.color-selection-label'
    );
    if (colorListHeadingLabel) {
      if (activeSKU.meta.color.attributeLabel) {
        colorListHeadingLabel.innerHTML = `${DukaanData.DUKAAN_LANGUAGE.SELECT} ${activeSKU.meta.color.attributeLabel}`;
      } else {
        colorListHeadingLabel.innerHTML = `${DukaanData.DUKAAN_LANGUAGE.SELECT} ${DukaanData.DUKAAN_LANGUAGE.COLOR}`;
      }
    }
    const colorListHeadingText = colorSelectionWrapper?.querySelector('span');
    if (colorListHeadingText) {
      if (activeSKU.meta.color.attributeLabel) {
        colorListHeadingText.innerHTML = `${DukaanData.DUKAAN_LANGUAGE.SELECT} ${activeSKU.meta.color.attributeLabel} <sup class="c-red">*</span>`;
      } else {
        colorListHeadingText.innerHTML = `${DukaanData.DUKAAN_LANGUAGE.SELECT} ${DukaanData.DUKAAN_LANGUAGE.COLOR} <sup class="c-red">*</span>`;
      }
    }
    if (colorListNode && activeProduct?.attributes?.color?.length > 0) {
      colorListNode?.classList?.remove('hidden');
      activeProduct?.attributes?.color?.forEach((color, index) => {
        const colorItem = document.importNode(colorItemTemplate.content, true);
        const colorItemInput = colorItem.querySelector('input');
        const colorSVG = colorItem.querySelector('svg');
        const colorSVGPath = colorItem.querySelector('svg path');

        if (color === activeSKU.meta.color.value) {
          colorItemInput.setAttribute('checked', 'true');
          getTickColor(color);
        }

        const { isLight } = colorLightOrDark(color);
        colorSVG?.setAttribute('color', isLight ? '#1a181e' : '#ffffff');
        if (colorSVGPath) {
          colorSVGPath.style.setProperty(
            'color',
            `${isLight ? '#1a181e' : '#ffffff'}`
          );
        }
        colorItemInput.setAttribute('id', `color-${color}`);
        colorItemInput.setAttribute('value', color);
        if (!buttonTemplateId) {
          colorItemInput.setAttribute(
            'onclick',
            `handleVariantChange('${productUUID}', {mountElem : '${mountElem}'})`
          );
        } else {
          colorItemInput.setAttribute(
            'onclick',
            `handleVariantChange('${productUUID}', { buttonTemplateId: '${buttonTemplateId}' })`
          );
        }
        colorItem.querySelector('label').setAttribute('for', `color-${color}`);

        if (
          colorItem.querySelector('.color-value').hasAttribute('data-text-item')
        ) {
          colorItem.querySelector('.color-value').textContent = `${color}`;
        } else {
          colorItem.querySelector('.color-value').style.background = `${color}`;
        }

        if (colorSelectionWrapper) {
          colorSelectionWrapper.classList.remove('hidden');
        }
        colorListNode.appendChild(colorItem);
      });
    }
  } else {
    colorVariantSectionWrapper?.classList?.add('hidden');
  }

  if (isResto && !!addonSelectionWrapper && activeProduct?.addOns?.length > 0) {
    const addOnSectionTemplate = document.getElementById('addons-list');
    const addOnTemplate = document.getElementById('resto-addon-item');
    const addOnsGroups = activeProduct.addOns;
    addonSelectionWrapper.classList.remove('hidden');
    addOnsGroups.forEach((addOnGroup) => {
      if (addOnGroup.add_ons.length > 0) {
        const addOnSection = document.importNode(
          addOnSectionTemplate.content,
          true
        );
        const addonsList = addOnSection.querySelector('.addon-selection');
        addOnSection
          .querySelector('.addon-selection-div')
          .classList.remove('hidden');
        addOnSection.querySelector('.addons-label').textContent =
          addOnGroup.name;
        addOnGroup.add_ons?.forEach((addon) => {
          const addonItem = document.importNode(addOnTemplate.content, true);
          addonItem.querySelector('.addon-name').textContent = `${addon.name}`;
          addonItem.querySelector('.addon-price').textContent = `${formatMoney(
            addon.price
          )}`;
          const addonInput = addonItem.querySelector('input');
          addonInput.setAttribute('data-addon-uuid', `${addon.uuid}`);
          addonInput.setAttribute('value', `${addon.uuid}`);
          if (!buttonTemplateId) {
            addonInput.setAttribute(
              'onclick',
              `handleVariantChange('${productUUID}', {mountElem : '${mountElem}'})`
            );
          } else {
            addonInput.setAttribute(
              'onclick',
              `handleVariantChange('${productUUID}', { buttonTemplateId: '${buttonTemplateId}' })`
            );
          }
          addonsList.appendChild(addonItem);
        });
        addonSelectionWrapper.appendChild(addOnSection);
      }
    });
  }

  variantSelectionFormAdditionalRenderer(variantSelectionForm);
  return variantSelectionForm;
};

window.getFirstSKUWhichIsInStock = (skus) => {
  let key = 0;
  for (let i = 0; i < skus.length; i += 1) {
    if (skus[i].in_stock) {
      key = i;
      break;
    }
  }

  const selectedSKUIndexFromParams = skus.findIndex(
    (sku) => sku.id === DukaanData.DUKAAN_SKU_ID_FROM_PARAMS
  );

  if (selectedSKUIndexFromParams !== -1) {
    key = selectedSKUIndexFromParams;
  }

  return skus[key];
};

window.handleVariantModalChange = (
  mountElement,
  event, // session storage ka event hai - jismei value stored joh hai wo milta hai
  {
    // variantSelectionFormTemplateId = 'variant-selection-form',
    // variantSelectionFormAdditionalRenderer,
    actionButtonTemplateId = 'dkn-action-button-wrapper-template',
  } = {}
) => {
  mountElement.innerHTML = '';
  const productUUID = event.value;
  dknAddProductsToProductsMap([DukaanData.PRODUCTS_MAP[productUUID]]);
  const activeProduct = DukaanData.PRODUCTS_MAP[productUUID];
  const modalTemplate = document.getElementById(
    'product-variant-selection-modal'
  );
  const wrapperElement = document.importNode(modalTemplate.content, true);
  const element = wrapperElement.querySelector('.modal');
  const variantFormMountNode =
    element.querySelector('.variant-selection-form-wrapper') ||
    element.querySelector('.modal-content');

  if (!productUUID) {
    element.classList.add('hidden');
    variantFormMountNode.innerHTML = '';
    /**
     * Splide Slider added in window to be accessible from all files
     * Need to set SplideSlider to undefined on modal close
     */
    if (typeof window.splideSlider === 'object')
      window.splideSlider = undefined;
  } else {
    variantFormMountNode.innerHTML = '';
    element.classList.remove('hidden');

    // const defaultVariantSelectionFormAdditionalRenderer = (
    //   variantSelectionForm
    // ) => {
    //   const addToBagElement =
    //     variantSelectionForm.querySelector('add-to-bag-button');
    //   if (addToBagElement) {
    //     addToBagElement.dataset.productUuid = activeProduct.uuid;
    //     addToBagElement.dataset.skuUuid = activeProduct.skus[defaultSKU].uuid;
    //     addToBagButtonRenderer(addToBagElement);
    //   }

    //   const buyNowElement = variantSelectionForm.querySelector(
    //     'buy-now-button-load-point'
    //   );
    //   if (buyNowElement) {
    //     buyNowElement.dataset.productUuid = activeProduct.uuid;
    //     buyNowElement.dataset.skuUuid = activeProduct.skus[defaultSKU].uuid;
    //     buyNowButtonRenderer(buyNowElement);
    //   }
    // };

    // render reviews data in add to bag modal
    window.q$
      .select('.dkn-product-card-review-info', element)
      .modifyInnerHTML('');

    window.q$
      .select('.dkn-product-card-review-info', element)
      .setAttribute('data-product-id', activeProduct.id);

    window.fetchRatingsDataFromProductIds([activeProduct.id], element, {
      reviewInfoTemplateId: 'dkn-product-review-with-count-template',
      getCustomReviewsCountText: window.getCustomReviewsCountText,
      starHeight: window.modalStarHeight,
      starWidth: window.modalStarWidth,
    });

    // const variantSelectionForm = renderVariantSelectionForm(
    //   variantSelectionFormTemplateId,
    //   productUUID,
    //   variantSelectionFormAdditionalRenderer ||
    //     defaultVariantSelectionFormAdditionalRenderer,
    //   buttonTemplateId
    // );

    // variantFormMountNode.appendChild(variantSelectionForm);
    const activeSKU = dknGetFirstAvailableSKU(activeProduct.skus);
    const renderAddons = DukaanData.DUKAAN_STORE.store_category === 6;
    const addToBagEventName = getDataFromSessionStorage(
      'active-add-event-name',
      ''
    );
    const productContext = {
      key: 'variantModal',
      productUUID,
      skuUUID: activeSKU.uuid,
    };
    const variantFormElement = q$.select(
      '.variant-selection-form-wrapper',
      element
    ).elem;
    const actionButtonsElement = q$.select(
      '.dkn-action-button-wrapper',
      element
    ).elem;
    actionButtonsElement.appendChild(
      q$.selectById(actionButtonTemplateId).getTemplateContent().elem
    );

    const externalQuantityFieldElement = q$.select(
      '.dkn-product-external-quantity-field',
      element
    ).elem;

    if (externalQuantityFieldElement) {
      externalQuantityFieldElement.innerHTML = '';
      const quantityField = q$
        .selectById('dkn-product-qty-field-template')
        .getTemplateContent().elem;
      externalQuantityFieldElement.appendChild(quantityField);
      dknRenderProductQuantityInputField(
        productContext,
        externalQuantityFieldElement
      );
    }

    dknRenderProductVariantForm(productContext, variantFormElement, {
      renderAddons,
    });
    dknRenderActionButtons(productContext, actionButtonsElement, {
      addToBagEventName,
    });

    mountElement.appendChild(element);

    if (typeof handleModalChanges === 'function') {
      handleModalChanges(activeProduct, activeSKU);
    }
  }
};

window.titleCase = (str = '') => {
  const newStr = str.toLowerCase().split(' ');
  newStr.forEach((letter, i) => {
    newStr[i] = newStr[i].charAt(0).toUpperCase() + newStr[i].slice(1);
  });
  return newStr.join(' ');
};

window.renderMenuCurtainCategories = (categorySlug, categories) => {
  const mountElement = document.querySelector('.menu-curtain-wrapper');
  const categoryListItemTemplate = document.getElementById(
    'menu-curtain-category-item'
  );
  mountElement.querySelector(
    '.content-section-list.categories-list'
  ).innerHTML = '';

  categories.forEach((category) => {
    const categoryItem = document.importNode(
      categoryListItemTemplate.content,
      true
    );
    categoryItem
      .querySelector('a')
      .setAttribute(
        'href',
        `${DukaanData.DUKAAN_BASE_URL}/categories/${categorySlug}?category_ids=${category.id}`
      );
    categoryItem.querySelector('a').textContent = `${titleCase(category.name)}`;

    mountElement
      .querySelector('.content-section-list.categories-list')
      .appendChild(categoryItem);
  });
};

window.renderMenuCurtainSizes = (categorySlug, sizes) => {
  const mountElement = document.querySelector('.menu-curtain-wrapper');
  const ageGroupListItemTemplate = document.getElementById(
    'menu-curtain-age-item'
  );
  mountElement.querySelector('.content-section-list.age-group-list').innerHTML =
    '';

  let finalSizes = sizes;
  if (typeof getFormattedAgeGroups !== 'undefined') {
    finalSizes = getFormattedAgeGroups(sizes);
  }

  finalSizes.forEach((size) => {
    const sizeItem = document.importNode(
      ageGroupListItemTemplate.content,
      true
    );
    sizeItem
      .querySelector('a')
      .setAttribute(
        'href',
        `${DukaanData.DUKAAN_BASE_URL}/categories/${categorySlug}?size=${size.key}`
      );
    sizeItem.querySelector('a').textContent = `${size.key}`;
    mountElement
      .querySelector('.content-section-list.age-group-list')
      .appendChild(sizeItem);
  });
};

window.renderCollectionCurtain = () => {
  const mountElement = document.getElementById(
    'menu-curtain-wrapper-collections'
  );
  mountElement.classList.remove('hidden');
};

window.stringSortFunction = (a, b) => {
  const firstSize = a.split('-')[0];
  const secondSize = b.split('-')[0];
  return Number(firstSize) - Number(secondSize);
};

window.fetchMenuSizes = (categoryId, callback) => {
  fetch(
    `${window.DukaanData.DUKAAN_ADVANCED_SEARCH_API_BASE_URL}/api/advanced-search-filters/${DukaanData.DUKAAN_STORE.id}/`,
    {
      method: 'post',
      body: JSON.stringify({ category_ids: [categoryId] }),
      headers: {
        'Content-Type': 'application/json',
        'x-requested-with': window?.DukaanData?.DUKAAN_SESSION_ID,
        // 'Content-Type': 'application/x-www-form-urlencoded',
      },
    }
  )
    .then((res) => res.json())
    .then((res) => {
      const sizes = res?.data?.sku_attrs?.size;
      setDataToSessionStorage(`sizes-data-${categoryId}`, sizes || []);
      callback(sizes);
    })
    .catch(() => {});
};

window.handleMenuCurtainChange = (element, event) => {
  const { category_id: categoryId, category_slug: categorySlug } =
    event.value || {};

  if (categoryId === 'collections') {
    element.classList.add('hidden');
    renderCollectionCurtain();
    return;
  }

  const prevCategories = getDataFromSessionStorage(
    `category-data-${categoryId}`,
    []
  );
  const prevSizes = getDataFromSessionStorage(`sizes-data-${categoryId}`, []);

  if (!categorySlug) {
    element.classList.add('hidden');
    document
      .getElementById('menu-curtain-wrapper-collections')
      .classList.add('hidden');
    return;
  }

  document
    .getElementById('menu-curtain-wrapper-collections')
    .classList.add('hidden');
  element.classList.remove('hidden');

  if (prevSizes.length || !categoryId) {
    renderMenuCurtainSizes(categorySlug, prevSizes);
  } else {
    fetchMenuSizes(categoryId, (sizes) =>
      renderMenuCurtainSizes(categorySlug, sizes)
    );
  }

  if (prevCategories.length || !categoryId) {
    renderMenuCurtainCategories(categorySlug, prevCategories);
  } else {
    let loading = false;
    const offsetCount = 10;
    let offset = 0;
    let categoriesList = [];
    const fetchMenuItems = async () => {
      const fetchUrl = `${window.DukaanData.CLIENT_API2_ENDPOINT}/api/product/buyer/${DukaanData.DUKAAN_STORE.link}/product-category-list/?parent_id=${categoryId}&offset=${offset}`;
      if (loading) return;
      loading = true;
      const response = await fetch(fetchUrl, {
        method: 'get',
        headers: {
          'Content-Type': 'application/json',
          'x-requested-with': window?.DukaanData?.DUKAAN_SESSION_ID,
          // 'Content-Type': 'application/x-www-form-urlencoded',
        },
      });
      const res = await response.json();
      const { results: categories } = res;
      const count = categories?.length;
      categoriesList = [...categoriesList, ...categories];
      if (count === offsetCount) {
        offset += offsetCount;
        loading = false;
        fetchMenuItems();
      } else {
        loading = false;
        setDataToSessionStorage(
          `category-data-${categoryId}`,
          categoriesList || []
        );
        renderMenuCurtainCategories(categorySlug, categoriesList);
      }
    };
    fetchMenuItems();
  }
};

window.handleActiveProductVariantSelectionModal = (event) => {
  if (event?.value === '') {
    document.querySelectorAll('body')[0].style.overflow = 'auto';
  } else {
    document.querySelectorAll('body')[0].style.overflow = 'hidden';
  }

  document
    .querySelectorAll('product-variant-selection-modal')
    .forEach((element) => {
      handleVariantModalChange(element, event);
    });
};

window.handleMenuItemHoverChange = (event) => {
  document.querySelectorAll('.menu-curtain-wrapper').forEach((element) => {
    handleMenuCurtainChange(element, event);
  });
};

window.uniq = (values) => values.filter((v, i, a) => a.indexOf(v) === i);

window.getUniqueAttributeValuesFromSKUs = (skus, attrKey) => {
  const rawValues = skus.map((sku) => sku?.meta[attrKey]?.value);

  return uniq(rawValues);
};

window.getAttributesFromSKU = (sku) => {
  const MASTER_ATTRIBUTE_MAP = {
    SIZE: 'size',
    COLOR: 'color',
  };

  return sku.attributes.reduce((acc, attribute) => {
    const masterAttribute = attribute.master_attribute;
    const key =
      masterAttribute.toLowerCase() === 'color picker' ||
      masterAttribute.toLowerCase() === 'color'
        ? MASTER_ATTRIBUTE_MAP.COLOR
        : MASTER_ATTRIBUTE_MAP.SIZE;

    acc[key] = { ...attribute, attributeLabel: masterAttribute };
    return acc;
  }, {});
};

window.serializeSKUs = (skus) =>
  skus.map((sku) => ({
    ...sku,
    meta: getAttributesFromSKU(sku),
    new_meta: dknGetAttributesFromSKU(sku),
    inventory_quantity: sku.inventory,
    in_stock: sku.inventory === null || sku.inventory > 0,
  }));

window.getAllProductAttributeValues = (skus = []) => {
  if (!skus || !skus.length) return {};
  const allSKUAttributes = Object.keys(skus[0]?.meta);

  return allSKUAttributes.reduce((acc, attribute) => {
    acc[attribute] = getUniqueAttributeValuesFromSKUs(skus, attribute);
    return acc;
  }, {});
};

const processAddOnGroup = (addOnGroup) => {
  const {
    min_selection: minSelection,
    max_selection: maxSelection,
    mandatory: defaultAddOnMandatory,
  } = addOnGroup;
  const mandatory =
    defaultAddOnMandatory || (!!minSelection && minSelection > 1);
  const onlyOneSelection = maxSelection === 1 && minSelection === 1;
  return {
    ...addOnGroup,
    mandatory,
    onlyOneSelection,
  };
};

window.getSerializedAddons = (product = {}) => {
  const { add_ons: addOnsNonGroup, add_on_groups: addOnGroups = [] } = product;
  const addOnsMandatory = addOnsNonGroup?.length
    ? (addOnsNonGroup || []).reduce(
        (acc, addon) => acc && addon.price === 0,
        true
      )
    : false;

  const rawAddOns = addOnsNonGroup?.length
    ? [
        {
          name: 'Add-Ons',
          add_ons: addOnsNonGroup,
          mandatory: addOnsMandatory,
        },
        ...addOnGroups,
      ]
    : [...addOnGroups];

  const addOns = rawAddOns.map((addOnGroup) => processAddOnGroup(addOnGroup));
  const addOnsList = addOns.map((group) => group.add_ons).flat();
  // const activeAddOnPrice = addOnsList.reduce(
  //   (total, addOn) =>
  //     total + (activeAddOns.includes(addOn.uuid) ? addOn.price : 0),
  //   0
  // );

  return { addOnsList, addOns };
};

// ---------------------------------------------------------------------------------------------------------------------
// Web components, sort of
// ---------------------------------------------------------------------------------------------------------------------

window.customTag = (tagName, fn, options = {}) => {
  // document.createElement(tagName);
  const tagInstances = options.isQuerySelector
    ? document.querySelectorAll(tagName)
    : document.getElementsByTagName(tagName);
  [...tagInstances].forEach((instance) => {
    fn(instance);
  });
};

window.customTemplateElem = (tagElems, fn) => {
  /** Send Element direction to this function instead of tagName */
  const tagElements = tagElems.length > 0 ? tagElems : [tagElems];
  [...tagElements].forEach((instance) => {
    fn(instance);
  });
};

window.getBagProducts = () => getDataFromLocalStorage(PRODUCTS_STORAGE_KEY());

window.getBagProductBySkuAndProductUuid = (productUUID, skuUUID) => {
  const products = getBagProducts();
  return products?.[productUUID]?.[skuUUID];
};

window.getProductDetailsBySkuAndProductUuid = (productUUID, skuUUID) => {
  const product = DukaanData.PRODUCTS_MAP[productUUID];
  return product?.skus?.find((sku) => sku.uuid === skuUUID);
};

window.getBagCountByProductUUID = (productUUID) => {
  const products = getDataFromLocalStorage(PRODUCTS_STORAGE_KEY());
  const skus = Object.values(products[productUUID] || {});
  return skus.reduce((total, sku) => total + sku.ordered_qty, 0);
};

window.getBagProductSKUsList = () => {
  const products = getDataFromLocalStorage(PRODUCTS_STORAGE_KEY());
  return Object.values(products).map(Object.values).flat();
};

window.addToBagButtonRenderer = (mountElement) => {
  mountElement.innerHTML = '';
  const addonString = mountElement.dataset.addOns || '';
  const productUUID = mountElement.dataset.productUuid;
  const skuUUID = mountElement.dataset.skuUuid;
  const addToBagTemplateId =
    mountElement.dataset.addToBagTemplateId ||
    'add-to-bag-button-without-variant';
  const { btnSize } = mountElement.dataset;
  const addEventName = mountElement.dataset.addEvent || '';
  const productKey = getActiveSKUKey(skuUUID, addonString) || skuUUID;
  const product = getBagProductBySkuAndProductUuid(productUUID, productKey);
  const skuDetails = getProductDetailsBySkuAndProductUuid(productUUID, skuUUID);

  const addToBagButtonTemplate = document.getElementById(addToBagTemplateId);

  const element = document.importNode(addToBagButtonTemplate.content, true);

  const withoutCartButton = element.querySelector(
    '.without-cart-add-to-bag-button'
  );

  const hasLink = DukaanData.PRODUCTS_MAP[productUUID]?.metafields?.find(
    (metafield) => metafield.key === 'pdp_amazon_link'
  );

  const withCartButton = element.querySelector('.with-cart-add-to-bag-button');

  let isOutOfStock =
    skuDetails?.inventory !== null && skuDetails?.inventory === 0;

  if (typeof window?.soldOutStateHandler === 'function') {
    isOutOfStock = soldOutStateHandler(productUUID, skuUUID);
  }

  if (isOutOfStock) {
    const outStockTemplateID = mountElement.dataset.outStockTemplateId
      ? mountElement.dataset.outStockTemplateId
      : 'out-of-stock-button';
    const OutOfStockTemplate = document.getElementById(outStockTemplateID);

    if (OutOfStockTemplate !== null) {
      const button = document.importNode(OutOfStockTemplate.content, true);
      mountElement.appendChild(button);
    } else {
      withoutCartButton.classList.add('hidden');
      withCartButton.classList.add('hidden');
      mountElement.innerHTML = `<div class='out-of-stock-text fB a-c j-c c-red'>${DukaanData.DUKAAN_LANGUAGE.OUT_OF_STOCK}</div>`;
    }
    mountElement.classList.add('min-w-full');
    const buyNowButtonTemplate = mountElement.querySelector(
      'buy-now-button-load-point'
    );
    if (buyNowButtonTemplate) {
      buyNowButtonTemplate.classList.add('hidden');
    }
    return;
  }
  mountElement.classList.remove('min-w-full');
  const buyNowButtonTemplate = mountElement.querySelector(
    'buy-now-button-load-point'
  );
  if (buyNowButtonTemplate) {
    buyNowButtonTemplate.classList.remove('hidden');
  }

  if (product?.ordered_qty > 0) {
    withoutCartButton.classList.add('hidden');
    withCartButton.classList.remove('hidden');

    withCartButton
      .querySelector('.remove-button')
      .setAttribute(
        'onclick',
        `addToBag(event, '${skuUUID}', '${productUUID}', {qtyToAdd: -1, addonString: '${addonString}' })`
      );
    withCartButton
      .querySelector('.add-button')
      .setAttribute(
        'onclick',
        `addToBag(event, '${skuUUID}', '${productUUID}', {qtyToAdd: 1, addEventName: '${addEventName}', addonString: '${addonString}'})`
      );
    withCartButton.querySelector(
      '.product-qty'
    ).textContent = `${product?.ordered_qty}`;
  } else {
    withCartButton.classList.add('hidden');
    withoutCartButton.classList.remove('hidden');
    const tempProduct = DukaanData.PRODUCTS_MAP[productUUID];
    if (hasLink) {
      withoutCartButton.addEventListener('click', () =>
        window.open(`${hasLink.value.val[0]}`, '_blank')
      );
      withoutCartButton.textContent = '';
      withoutCartButton.innerHTML = `<p style="display: flex; justify-content: center; align-items: center">SHOP ON <span>
        <svg style="margin-top: 9px;" width="55" height="15" viewBox="0 0 65 20" fill="none" xmlns="http://www.w3.org/2000/svg">
          <path d="M13.8106 2.20559C14.3473 1.08693 15.1786 0.476915 16.4522 0.482955C17.7425 0.488994 18.4798 1.20687 19.0139 2.30999C19.1213 2.12535 19.2042 1.97004 19.2991 1.82206C19.8526 0.960961 20.6408 0.523076 21.6667 0.49072C22.2711 0.471738 22.8306 0.587357 23.3556 0.897111C24.0761 1.32205 24.4579 1.96357 24.5925 2.76686C24.6374 3.0339 24.6663 3.30699 24.6667 3.57748C24.6723 6.06415 24.6702 8.55082 24.6697 11.0375C24.6697 11.1238 24.6758 11.2105 24.6667 11.2959C24.6352 11.5996 24.5015 11.7446 24.2021 11.7497C23.5696 11.7601 22.9363 11.7605 22.3039 11.7493C22.0165 11.7441 21.8897 11.6117 21.8552 11.3283C21.8414 11.2148 21.8504 11.0987 21.8504 10.9836C21.8504 8.85626 21.8509 6.72896 21.8491 4.60123C21.8491 4.41486 21.8479 4.2259 21.8185 4.04255C21.6934 3.26687 21.0191 2.88075 20.2745 3.15082C19.7348 3.34625 19.4427 3.74962 19.3517 4.29837C19.3004 4.60813 19.2676 4.92479 19.2663 5.23799C19.2585 7.14959 19.2624 9.06161 19.2624 10.9732C19.2624 11.0884 19.2689 11.2036 19.2594 11.3179C19.2352 11.6126 19.123 11.742 18.8297 11.748C18.1826 11.7605 17.5354 11.7601 16.8883 11.7472C16.6282 11.742 16.5061 11.6035 16.4763 11.3395C16.4634 11.226 16.472 11.1095 16.472 10.9948C16.472 8.93909 16.475 6.88384 16.4681 4.82815C16.4673 4.55809 16.4362 4.28457 16.3849 4.01882C16.2813 3.48343 15.9073 3.12105 15.4517 3.08093C14.7697 3.02096 14.3706 3.23235 14.123 3.79362C13.9215 4.24919 13.8861 4.7354 13.8853 5.22419C13.8822 7.15045 13.884 9.07628 13.884 11.0025C13.884 11.1031 13.8896 11.2044 13.8818 11.3041C13.8585 11.5931 13.7381 11.7398 13.4573 11.7459C12.8106 11.7601 12.1631 11.7597 11.5159 11.7459C11.2403 11.7398 11.1337 11.6281 11.0837 11.3554C11.0604 11.2299 11.0655 11.0983 11.0655 10.9693C11.0647 7.80706 11.0647 4.6448 11.0651 1.48254C11.0651 1.42516 11.0634 1.36735 11.0655 1.30997C11.0841 0.818163 11.1881 0.717212 11.6915 0.714624C12.2092 0.712035 12.7269 0.709447 13.2446 0.715918C13.6299 0.720663 13.7287 0.819457 13.7381 1.20083C13.7459 1.51662 13.7399 1.83285 13.7399 2.14864C13.7636 2.16719 13.7873 2.18574 13.8106 2.20429V2.20559Z" fill="var(--pc-primary)"/>
          <path d="M6.36022 10.4727C6.17169 10.6353 5.99999 10.7837 5.82872 10.9317C5.29679 11.3907 4.70187 11.7221 3.99608 11.8217C3.35198 11.9128 2.70529 11.9434 2.07284 11.7665C1.23848 11.5335 0.6056 11.034 0.296708 10.2117C-0.20028 8.88725 -0.0967404 7.62149 0.78852 6.47479C1.28033 5.83759 1.95981 5.47175 2.71651 5.24569C3.58667 4.98555 4.48746 4.90056 5.38609 4.80565C5.55564 4.78796 5.72432 4.76639 5.91371 4.74396C5.97411 4.26639 5.97324 3.8134 5.84813 3.36991C5.69671 2.83323 5.12983 2.49845 4.48918 2.53599C3.67467 2.58387 3.12117 3.05325 2.98053 3.71202C2.90374 4.07096 2.76741 4.12618 2.38043 4.08649C1.88172 4.03558 1.38214 3.99028 0.883862 3.9329C0.375657 3.87466 0.285492 3.71763 0.411896 3.20985C0.714317 1.99456 1.49043 1.19127 2.63281 0.765034C4.03706 0.241298 5.46979 0.20204 6.8831 0.752523C7.96206 1.17272 8.60745 1.95617 8.73213 3.12659C8.76837 3.46741 8.78822 3.81124 8.78994 4.15379C8.79685 5.37512 8.80763 6.59688 8.78649 7.81778C8.77484 8.49639 8.96596 9.08786 9.3827 9.61462C9.44483 9.69357 9.50954 9.77208 9.56045 9.85793C9.70713 10.1038 9.70238 10.2238 9.48193 10.4235C9.00436 10.8575 8.51858 11.2829 8.02548 11.6992C7.80589 11.8843 7.6247 11.8864 7.41071 11.6841C7.13159 11.4197 6.88137 11.1237 6.62554 10.8355C6.53193 10.7298 6.45729 10.6077 6.35979 10.4731L6.36022 10.4727ZM5.92579 6.44632C5.36668 6.35141 4.84855 6.44157 4.34207 6.59257C3.14145 6.94978 2.81746 7.87041 3.0556 8.936C3.2053 9.60556 3.73809 9.91833 4.41584 9.80962C4.9055 9.7311 5.24933 9.43903 5.50128 9.03782C6.00129 8.241 5.96677 7.35574 5.92579 6.44675V6.44632Z" fill="var(--pc-primary)"/>
          <path d="M32.685 10.509C32.4655 10.6924 32.2368 10.8848 32.0064 11.0755C31.3494 11.6199 30.5879 11.8835 29.7402 11.8736C29.3123 11.8684 28.8709 11.8654 28.4602 11.764C27.5348 11.5358 26.8787 10.9603 26.5896 10.0366C26.2402 8.91968 26.2859 7.82389 26.9089 6.80273C27.4132 5.97615 28.1828 5.4701 29.1026 5.25267C29.9646 5.04861 30.8511 4.94981 31.7277 4.80788C31.896 4.7807 32.0668 4.76991 32.2756 4.74748C32.2756 4.39027 32.2972 4.05032 32.2713 3.71338C32.2079 2.88162 31.6341 2.527 30.8981 2.53907C30.1949 2.55072 29.5586 2.86695 29.3446 3.70993C29.2575 4.05377 29.1255 4.12926 28.7872 4.09561C28.2738 4.04471 27.76 3.9938 27.2471 3.93513C26.7475 3.87775 26.6427 3.70993 26.7682 3.21337C27.0698 2.02052 27.8265 1.21377 28.9494 0.780203C30.2592 0.275017 31.61 0.212462 32.9573 0.646464C34.4094 1.11412 35.1303 2.11241 35.1389 3.64004C35.1471 5.03394 35.1484 6.42827 35.1372 7.8226C35.132 8.48136 35.3188 9.06507 35.7205 9.58319C35.7731 9.65136 35.8279 9.71866 35.8753 9.79027C36.0699 10.0849 36.0656 10.2277 35.8059 10.4628C35.3482 10.8761 34.8831 11.2817 34.4103 11.6777C34.1579 11.8891 33.9827 11.8904 33.7321 11.6441C33.3766 11.2946 33.0535 10.9119 32.685 10.509ZM32.2778 6.4123C32.0353 6.4123 31.8481 6.39548 31.6648 6.41619C31.3813 6.44854 31.094 6.48262 30.8196 6.55769C29.7079 6.86313 29.2294 7.55469 29.367 8.73719C29.4771 9.68285 30.3891 10.119 31.2247 9.65481C31.6035 9.44428 31.8459 9.11899 32.025 8.73201C32.3636 7.99991 32.2959 7.23113 32.2778 6.4123Z" fill="var(--pc-primary)"/>
          <path d="M59.3602 2.36904C59.698 1.92339 59.9793 1.48939 60.3244 1.11363C60.72 0.683077 61.2597 0.521297 61.8378 0.493686C62.4336 0.465213 63.016 0.509217 63.5514 0.807755C64.3232 1.23787 64.7339 1.92037 64.8771 2.76723C64.9487 3.18916 64.991 3.62143 64.9931 4.04896C65.0039 6.40621 64.9988 8.76302 64.9979 11.1203C64.9979 11.6651 64.9159 11.7506 64.3827 11.7536C63.8508 11.7566 63.3184 11.7596 62.7865 11.7523C62.3365 11.7462 62.2373 11.6405 62.2373 11.1854C62.236 9.21643 62.242 7.24746 62.2321 5.27849C62.2299 4.879 62.1937 4.47563 62.1303 4.08089C62.0332 3.48079 61.726 3.16155 61.2213 3.06922C60.7027 2.97431 60.2567 3.17449 59.9486 3.67018C59.6199 4.19866 59.5353 4.79445 59.5345 5.40317C59.531 7.25739 59.5332 9.11117 59.5332 10.9654C59.5332 11.0806 59.5418 11.1966 59.5293 11.3101C59.4987 11.5875 59.3675 11.7393 59.0914 11.7458C58.4447 11.7613 57.7972 11.7596 57.1505 11.748C56.8869 11.7432 56.7622 11.6129 56.7217 11.3537C56.7061 11.2553 56.7143 11.153 56.7143 11.0525C56.7143 7.83289 56.7143 4.61368 56.7143 1.39405C56.7143 1.29353 56.7066 1.19128 56.7208 1.09249C56.7544 0.856936 56.8808 0.723629 57.1168 0.719747C57.735 0.708961 58.3537 0.707236 58.9719 0.72061C59.2648 0.727081 59.3515 0.828031 59.358 1.12355C59.3671 1.53641 59.3602 1.94971 59.3602 2.36818V2.36904Z" fill="var(--pc-primary)"/>
          <path d="M55.2515 6.26936C55.2609 7.69475 54.9361 9.01402 54.1134 10.1814C52.7143 12.1659 49.9239 12.5732 48.0236 11.0701C47.3057 10.5024 46.8264 9.75001 46.5429 8.89149C45.9053 6.95876 45.8976 5.02172 46.7008 3.13515C47.3001 1.72831 48.3355 0.778766 49.895 0.543214C51.8342 0.250284 53.4822 0.98455 54.443 2.75593C55.0388 3.85474 55.2536 5.04329 55.2515 6.26936ZM52.2268 6.95143C52.2268 6.43848 52.2324 5.9251 52.2255 5.41215C52.2165 4.75079 52.1289 4.09979 51.9084 3.47381C51.7044 2.89528 51.2734 2.60623 50.6621 2.61357C50.0697 2.6209 49.6396 2.94446 49.4114 3.55232C49.1923 4.13602 49.1284 4.74518 49.1068 5.36253C49.0732 6.3371 49.0689 7.31209 49.2906 8.26724C49.37 8.60978 49.496 8.95966 49.681 9.25647C50.1021 9.93293 50.9714 10.0192 51.5249 9.44974C51.7083 9.26122 51.8519 9.01229 51.9481 8.76552C52.1738 8.1857 52.2423 7.5731 52.2272 6.95186L52.2268 6.95143Z" fill="var(--pc-primary)"/>
          <path d="M26.3098 20.0001C22.632 19.9548 19.1026 19.2318 15.7509 17.7067C13.4092 16.6411 11.2879 15.2322 9.37075 13.5169C9.34918 13.4979 9.32761 13.4789 9.30862 13.4573C9.19301 13.324 9.08256 13.1825 9.17575 12.9957C9.25081 12.8451 9.44366 12.8136 9.66972 12.9284C10.1046 13.1493 10.5312 13.3857 10.9622 13.6139C14.2401 15.3473 17.7251 16.4561 21.3791 17.0419C22.9948 17.3008 24.6216 17.4272 26.261 17.4548C28.9729 17.5005 31.6407 17.1977 34.278 16.5846C36.0273 16.1782 37.7284 15.6209 39.3885 14.9379C39.5606 14.8672 39.7358 14.8003 39.9152 14.7537C40.1668 14.6886 40.4338 14.7986 40.5542 14.9949C40.6935 15.2218 40.5882 15.4181 40.4506 15.5842C40.3436 15.7136 40.1961 15.8137 40.055 15.9103C37.7539 17.4837 35.2206 18.5294 32.5251 19.1986C30.7805 19.6317 29.0126 19.9078 27.2114 19.9497C26.9107 19.9566 26.61 19.9824 26.3098 19.9997V20.0001Z" fill="var(--pc-primary)"/>
          <path d="M41.385 2.90904C40.6641 2.90904 40.0355 2.90904 39.4065 2.90904C38.9609 2.90904 38.5152 2.91336 38.0696 2.90732C37.727 2.90257 37.5769 2.78264 37.5635 2.46037C37.545 2.01558 37.5454 1.56907 37.5635 1.12428C37.5765 0.79943 37.727 0.668711 38.0627 0.66828C40.2051 0.664829 42.347 0.664397 44.4894 0.66828C44.8247 0.668711 44.958 0.794684 44.9726 1.13593C44.989 1.50867 45.005 1.88616 44.9627 2.25502C44.9381 2.47116 44.832 2.69679 44.7069 2.8797C43.9377 4.0044 43.1521 5.11788 42.3721 6.23524C41.9778 6.80039 41.5826 7.36468 41.1896 7.93069C41.1602 7.97297 41.1412 8.02302 41.0852 8.1326C41.3462 8.1326 41.5576 8.12655 41.7681 8.13346C42.7854 8.16711 43.7552 8.38842 44.6685 8.85133C45.0007 9.01958 45.1655 9.25643 45.1543 9.63391C45.1404 10.0934 45.1586 10.5537 45.1482 11.0131C45.1392 11.4264 44.9286 11.5632 44.5641 11.3846C43.5554 10.8902 42.4847 10.6257 41.3708 10.5947C40.1809 10.5615 39.0316 10.7979 37.9518 11.3203C37.3987 11.5882 37.1891 11.4661 37.1843 10.8509C37.1804 10.363 37.1929 9.87464 37.2024 9.38628C37.2093 9.0459 37.3297 8.74606 37.5247 8.46737C38.6024 6.92723 39.6757 5.38406 40.7495 3.84133C40.945 3.56004 41.1352 3.27531 41.3841 2.90904H41.385Z" fill="var(--pc-primary)"/>
          <path d="M40.1264 13.5241C39.3848 13.5901 38.6432 13.6553 37.9016 13.7221C37.7588 13.7351 37.6156 13.773 37.4745 13.764C37.3852 13.7584 37.2428 13.7036 37.226 13.6428C37.2014 13.5535 37.2377 13.4107 37.3024 13.3416C37.418 13.2183 37.5668 13.1208 37.7144 13.0345C38.3529 12.66 39.0479 12.4352 39.7739 12.314C40.6985 12.1596 41.6269 12.1268 42.5535 12.3062C42.7356 12.3416 42.9185 12.3813 43.095 12.4387C43.5328 12.5811 43.6368 12.7338 43.6562 13.1855C43.6825 13.8089 43.5656 14.4124 43.4026 15.0078C43.1079 16.0841 42.651 17.082 41.9112 17.9301C41.7244 18.1446 41.503 18.3339 41.2761 18.5057C41.208 18.557 41.0475 18.544 40.9646 18.4975C40.912 18.4677 40.8926 18.3137 40.9146 18.23C40.9642 18.0371 41.047 17.8525 41.1187 17.6648C41.4664 16.7541 41.8275 15.8464 41.9772 14.8766C42.1234 13.9288 41.9439 13.6855 41.0332 13.5988C40.7338 13.5703 40.4318 13.5668 40.1311 13.5522C40.1299 13.5427 40.1281 13.5328 40.1268 13.5233L40.1264 13.5241Z" fill="var(--pc-primary)"/>
          </svg>
          </span></p>`;
    } else if (
      tempProduct?.product_type === 2 &&
      tempProduct?.product_bundle_type === 'combo'
    ) {
      withoutCartButton.setAttribute(
        'onclick',
        `addBundleProductToBag(event, '${skuUUID}', '${productUUID}', {qtyToAdd: 1, addEventName: '${addEventName}', addonString: '${addonString}'})`
      );
    } else {
      withoutCartButton.setAttribute(
        'onclick',
        `addToBag(event, '${skuUUID}', '${productUUID}', {qtyToAdd: 1, addEventName: '${addEventName}', addonString: '${addonString}'})`
      );
    }
  }

  if (btnSize) {
    withCartButton.classList.add(`btn-${btnSize}`);
    withoutCartButton.classList.add(`btn-${btnSize}`);
  }

  mountElement.appendChild(element);
};

// add combo bundle to bag
window.addBundleProductToBag = (
  event,
  skuUUID,
  productUUID,
  { qtyToAdd, addEventName, isBuyNow }
) => {
  const quantity = qtyToAdd || 1;
  const bundleProduct = DukaanData.PRODUCTS_MAP[productUUID];
  const applicabilityData = bundleProduct?.product_bundle_applicability;
  for (let i = 1; i <= quantity; i += 1) {
    const bundleGroupId = window.dknGenerateUUID();
    const products = bundleProduct?.applicableProducts || [];
    let flag = false;
    products?.forEach((product) => {
      product?.skus?.forEach((sku) => {
        const qtyInBag =
          window.getBagProducts()?.[product.uuid]?.[sku?.uuid]?.ordered_qty ||
          0;

        const quantityApplicableForBundle =
          applicabilityData?.find(
            (item) =>
              item?.content_type === window.BUNDLE_ITEM_TYPES.SKU &&
              item.object_id === sku.id
          )?.quantity || 1;

        const finalQuantity = qtyInBag + quantityApplicableForBundle;
        const inventory = sku?.inventory_quantity || sku?.inventory;
        if (inventory !== null && inventory < finalQuantity) {
          let oosMessage = `Seller has only ${inventory} of them available`;
          if (typeof window.getNoInventoryErrorMessage === 'function') {
            oosMessage = window.getNoInventoryErrorMessage({ inventory });
          }
          window.enqueueSnackbar(oosMessage, true);
          flag = true;
        }
      });
    });

    if (flag) return;

    let areProductsAdded = true;
    products?.forEach((product) => {
      product?.skus?.forEach((sku) => {
        const quantityApplicableForBundle =
          applicabilityData?.find(
            (item) =>
              item?.content_type === window.BUNDLE_ITEM_TYPES.SKU &&
              item.object_id === sku.id
          )?.quantity || 1;

        const res = window.addToBag(event, sku?.uuid, product.uuid, {
          qtyToAdd: quantityApplicableForBundle,
          skipSKUsCall: true,
          addEventName,
          bundleGroupId,
        });

        areProductsAdded = areProductsAdded && res;
      });
    });

    window.dknAddToBagEvent(
      {
        selling_price: bundleProduct.product_bundle_min_original_price,
        original_price: bundleProduct.product_bundle_min_original_price,
      },
      { ...bundleProduct, id: `vsku_${bundleProduct.id}` },
      { qty: 1 }
    );
  }
  if (areProductsAdded) {
    enqueueSnackbar('Products added to bag', true, 'go-to-bag');
  }
  if (isBuyNow) {
    window.redirectToBagPage();
  }
};

// external quantity input renderer
window.addToBagButtonWithExternalQuantityInputRenderer = (
  mountElement,
  customQuantityElm
) => {
  mountElement.innerHTML = '';
  const addonString = mountElement.dataset.addOns || '';
  const productUUID = mountElement.dataset.productUuid;
  const skuUUID = mountElement.dataset.skuUuid;
  const qtyInputId = mountElement.dataset.quantityInputId;
  const hasAppendQty = !!mountElement.dataset.appendQty;
  const addToBagTemplateId =
    mountElement.dataset.addToBagTemplateId ||
    'add-to-bag-button-with-external-quantity-input';
  const { btnSize } = mountElement.dataset;
  const addEventName = mountElement.dataset.addEvent || '';
  const productKey = getActiveSKUKey(skuUUID, addonString) || skuUUID;
  const product = getBagProductBySkuAndProductUuid(productUUID, productKey);
  const skuDetails = getProductDetailsBySkuAndProductUuid(productUUID, skuUUID);

  const addToBagButtonTemplate = document.getElementById(addToBagTemplateId);

  const element = document.importNode(addToBagButtonTemplate.content, true);

  const withoutCartButton = element.querySelector(
    '.without-cart-add-to-bag-button'
  );
  const withCartButton = element.querySelector('.with-cart-add-to-bag-button');

  // quantity button
  const { quantityButtonId } = mountElement.dataset;
  const quantityButton = document.querySelector(`#${quantityButtonId}`);
  quantityButton?.classList.remove('hidden');

  if (skuDetails?.inventory !== null && skuDetails?.inventory === 0) {
    const outStockTemplateID = mountElement.dataset.outStockTemplateId
      ? mountElement.dataset.outStockTemplateId
      : 'out-of-stock-button';
    const OutOfStockTemplate = document.getElementById(outStockTemplateID);

    if (OutOfStockTemplate !== null) {
      const button = document.importNode(OutOfStockTemplate.content, true);
      mountElement.appendChild(button);
      if (quantityButton) {
        quantityButton.classList.add('hidden');
      }
    } else {
      withoutCartButton?.classList.add('hidden');
      withCartButton?.classList.add('hidden');
      mountElement.innerHTML = `<div class='out-of-stock-text fB a-c j-c c-red'>${DukaanData.DUKAAN_LANGUAGE.OUT_OF_STOCK}</div>`;

      if (quantityButton) {
        quantityButton.classList.add('hidden');
      }
    }
    const buyNowButtonTemplate = mountElement.querySelector(
      'buy-now-button-load-point'
    );
    if (buyNowButtonTemplate) {
      buyNowButtonTemplate.classList.add('hidden');
    }
    return;
  }
  const addToBagButtons = mountElement.querySelectorAll(
    `add-to-bag-button[data-product-uuid='${productUUID}'][data-sku-uuid='${skuUUID}']`
  );
  addToBagButtons.forEach((btn) => {
    btn.classList.remove('min-w-full');
  });
  const buyNowButtonTemplate = mountElement.querySelector(
    'buy-now-button-load-point'
  );
  if (buyNowButtonTemplate) {
    buyNowButtonTemplate.classList.remove('hidden');
  }

  if (qtyInputId) {
    const quantityInputButton =
      customQuantityElm || document.querySelector(`#${qtyInputId}`);

    if (
      quantityInputButton &&
      product?.ordered_qty === +quantityInputButton.value
    ) {
      element.querySelector('button').textContent =
        window.GO_TO_BAG_TEXT || DukaanData.DUKAAN_LANGUAGE.GO_TO_BAG;
      element
        .querySelector('button')
        .setAttribute('onclick', 'redirectToBagPage()');
      // element
      //   .querySelector('button')
      //   .setAttribute(
      //     'onclick',
      //     `addToBag(event, '${skuUUID}', '${productUUID}', {quantityInputId: '${qtyInputId}', addEventName: '${addEventName}', addonString: '${addonString}'})`
      //   );
    } else {
      element.querySelector('button').textContent =
        DukaanData.DUKAAN_LANGUAGE.ADD_TO_BAG;
      element
        .querySelector('button')
        .setAttribute(
          'onclick',
          `addToBag(event, '${skuUUID}', '${productUUID}', {quantityInputId: '${qtyInputId}', addEventName: '${addEventName}', addonString: '${addonString}', hasAppendQty: ${hasAppendQty})`
        );
    }
  }

  if (btnSize) {
    withCartButton?.classList.add(`btn-${btnSize}`);
    withoutCartButton?.classList.add(`btn-${btnSize}`);
  }

  mountElement.appendChild(element);
};

window.redirectToBagPage = (paramString) => {
  const queryString = paramString ? `?${paramString}` : '';
  window.location.href = `/${window.DukaanData.DUKAAN_STORE.link}/bag${queryString}`;
};

window.handleBuyNowButton = (
  // eslint-disable-next-line default-param-last
  isBag = false,
  addEventName,
  skuUUID,
  productUUID,
  addonString = ''
) => {
  if (isBag) {
    window.redirectToBagPage();
  } else {
    addToBag(null, skuUUID, productUUID, {
      qtyToAdd: 1,
      addonString,
      addEventName,
      isBuyNow: true,
    });
  }
};

window.buyNowButtonRenderer = (mountElement) => {
  mountElement.innerHTML = '';
  const productUUID = mountElement.dataset.productUuid;
  const skuUUID = mountElement.dataset.skuUuid;
  const { btnSize, redirectUrl } = mountElement.dataset;
  const buyNowButtonTemplateId =
    mountElement.dataset.buyNowButtonTemplateId || 'buy-now-button-template';
  const addEventName = mountElement.dataset.addEvent || '';
  const addonString = mountElement.dataset.addOns || '';
  const productKey = getActiveSKUKey(skuUUID, addonString);
  const product = getBagProductBySkuAndProductUuid(
    productUUID,
    productKey || skuUUID
  );
  const productDetails = DukaanData.PRODUCTS_MAP[productUUID];
  const currentSKU = productDetails?.skus?.find((sku) => sku.uuid === skuUUID);

  if (currentSKU?.inventory !== null && currentSKU?.inventory <= 0) {
    mountElement.classList.add('hidden');
    return;
  }

  const buyNowButtonTemplate = document.getElementById(buyNowButtonTemplateId);
  const element = document.importNode(buyNowButtonTemplate.content, true);

  mountElement.classList.remove('hidden');
  if (product?.ordered_qty > 0) {
    element.querySelector('button').textContent =
      window.GO_TO_BAG_TEXT || DukaanData.DUKAAN_LANGUAGE.GO_TO_BAG;

    if (redirectUrl) {
      element
        .querySelector('button')
        .setAttribute('onclick', `window.location = '${redirectUrl}'`);
    } else {
      element
        .querySelector('button')
        .setAttribute('onclick', `handleBuyNowButton(true, '${addEventName}')`);
    }
  } else {
    element.querySelector('button').textContent =
      window.BUY_NOW_TEXT || DukaanData.DUKAAN_LANGUAGE.BUY_NOW;
    const tempProduct = DukaanData.PRODUCTS_MAP[productUUID];
    if (redirectUrl) {
      element
        .querySelector('button')
        .setAttribute('onclick', `window.location = '${redirectUrl}'`);
    } else if (
      tempProduct?.product_type === 2 &&
      tempProduct?.product_bundle_type === 'combo'
    ) {
      element
        .querySelector('button')
        .setAttribute(
          'onclick',
          `addBundleProductToBag(event, '${skuUUID}', '${productUUID}', {qtyToAdd: 1, addEventName: '${addEventName}', addonString: '${addonString}', isBuyNow: true})`
        );
    } else {
      element
        .querySelector('button')
        .setAttribute(
          'onclick',
          `handleBuyNowButton(false, '${addEventName}', '${skuUUID}', '${productUUID}', '${addonString}')`
        );
    }
  }

  if (btnSize) {
    element.querySelector('button').classList.add(`btn-${btnSize}`);
  }

  mountElement.appendChild(element);
};

window.addToBagButtonWithVariantsRenderer = (mountElement) => {
  mountElement.innerHTML = '';
  const productUUID = mountElement.dataset.productUuid;
  const addEventName = mountElement.dataset.addEvent || '';
  const addonString = mountElement.dataset.addOns || '';
  const addToBagTemplateId =
    mountElement.dataset.addToBagTemplateId || 'add-to-bag-button-with-variant';
  const productBagCount = getBagCountByProductUUID(productUUID);
  const productDetails = DukaanData.PRODUCTS_MAP[productUUID];
  const addToBagButtonTemplate = document.getElementById(addToBagTemplateId);
  const element = document.importNode(addToBagButtonTemplate.content, true);
  element.dataset ||= {};

  const withoutCartButton = element.querySelector(
    '.without-cart-add-to-bag-button'
  );
  const withCartButton = element.querySelector('.with-cart-add-to-bag-button');

  if (productDetails && !productDetails.in_stock) {
    const outStockTemplateID = mountElement.dataset.outStockTemplateId
      ? mountElement.dataset.outStockTemplateId
      : 'out-of-stock-button';
    const OutOfStockTemplate = document.getElementById(outStockTemplateID);

    if (OutOfStockTemplate !== null) {
      const button = document.importNode(OutOfStockTemplate.content, true);

      // add class of min width 100% to add to bag button template if out of stock button exists
      const addToBagButtons = document.querySelectorAll(
        `add-to-bag-button[data-product-uuid='${productUUID}']`
      );
      addToBagButtons.forEach((btn) => {
        btn.classList.add('min-w-full');
      });

      mountElement.appendChild(button);
    } else {
      withoutCartButton.classList.add('hidden');
      withCartButton.classList.add('hidden');
      mountElement.innerHTML = `<div class='out-of-stock-text fB a-c j-c c-red t-16_24 mt-14_20'>${DukaanData.DUKAAN_LANGUAGE.OUT_OF_STOCK}</div>`;
    }
    /** Feature Product if quantity is zero or out of stock and hiden Add to cart load point */
    if (
      DukaanData.DUKAAN_THEME_DATA?.meta?.sections?.featureProduct?.isActive
    ) {
      if (
        DukaanData.DUKAAN_THEME_DATA?.meta?.sections?.featureProduct
          ?.products[0]?.id === productDetails?.id
      ) {
        if (mountElement.classList.contains('featureProductAddToBag'))
          mountElement.classList.add('visibilityHidden');
      }
    }
    return;
  }

  if (productBagCount > 0) {
    withoutCartButton.classList.add('hidden');
    withCartButton.classList.remove('hidden');

    withCartButton
      .querySelector('.remove-button')
      .setAttribute(
        'onclick',
        `addToBag(event, '', '${productUUID}', {qtyToAdd: -1, addonString: '${addonString}'})`
      );
    withCartButton
      .querySelector('.add-button')
      .setAttribute(
        'onclick',
        `addToBag(event, '', '${productUUID}', {qtyToAdd: 1, addEventName: '${addEventName}', addonString: '${addonString}'})`
      );
    withCartButton.querySelector(
      '.product-qty'
    ).textContent = `${productBagCount}`;
    element.dataset.uuid = productUUID;
  } else {
    withCartButton.classList.add('hidden');
    withoutCartButton.classList.remove('hidden');
    withoutCartButton.onclick = () =>
      addToBag(null, '', productUUID, { qtyToAdd: 1 });
    withoutCartButton.setAttribute(
      'onclick',
      `addToBag(event, '', '${productUUID}', {qtyToAdd: 1, addEventName: '${addEventName}', addonString: '${addonString}'})`
    );
    element.dataset.uuid = productUUID;
  }

  mountElement.appendChild(element);
};

window.cartProductListRenderer = (mountElement) => {
  mountElement.innerHTML = '';

  const skus = getBagProductSKUsList();

  if (skus.length === 0) {
    const noProductCardTemplate = document.getElementById('empty-bag');
    const emptyBagElem = document.importNode(
      noProductCardTemplate.content,
      true
    );
    mountElement.appendChild(emptyBagElem);
    return;
  }

  const productCardTemplate = document.getElementById('product-card');

  skus
    .filter((sku) => !!sku.ordered_qty)
    .forEach((sku) => {
      const productCard = document.importNode(
        productCardTemplate.content,
        true
      );
      const parentProduct = sku.parent_product;
      const addonsUUID = sku.selected_addons || [];
      const addonString = addonsUUID.join(',');

      productCard.querySelector('.product-name').textContent =
        parentProduct.name || 'Product name';
      if (productCard.querySelector('.product-selling-price') !== null) {
        productCard.querySelector('.product-selling-price').textContent =
          formatMoney(sku.selling_price);
      }
      if (productCard.querySelector('.product-original-price') !== null) {
        if (sku.original_price === sku.selling_price) {
          productCard
            .querySelector('.product-original-price')
            .classList.add('hidden');
        } else {
          productCard
            .querySelector('.product-original-price')
            .classList.remove('hidden');
          productCard.querySelector('.product-original-price').textContent =
            formatMoney(sku.original_price);
        }
      }
      const attributeKeys = Object.keys(sku?.new_meta);
      if (sku?.attributes?.length > 0) {
        if (productCard.querySelector('.product-variants')) {
          productCard
            .querySelector('.product-variants')
            .classList.remove('hidden');
        }
        attributeKeys.forEach((key, index) => {
          const attribute = sku.new_meta[key];
          if (attribute.type === 'size') {
            productCard
              .querySelector('.variant-size')
              .classList.remove('hidden');
            const sizeDiv = document.createElement('span');
            sizeDiv.textContent = `${attribute?.attributeLabel} ${
              attribute?.value
            } ${index < sku.attributes.length - 1 ? '|' : ''} `;
            productCard.querySelector('.variant-size').appendChild(sizeDiv);
          } else {
            if (index < sku.attributes.length - 1) {
              productCard
                .querySelector('.variant-gap')
                .classList.remove('hidden');
            }
            productCard
              .querySelector('.variant-color-container')
              .classList.remove('hidden');
            productCard.querySelector('.variant-color').style.backgroundColor =
              attribute?.value;
          }
        });
      }

      if (addonsUUID?.length > 0) {
        const addonListWrapper = productCard.querySelector(
          '.variant-addon-list'
        );
        addonListWrapper.classList.remove('hidden');
        addonsUUID.forEach((uuid) => {
          const addonDiv = document.createElement('div');
          const { name, price } = parentProduct.addOnsList.find(
            (item) => item.uuid === uuid
          );
          addonDiv.textContent = `${
            DukaanData.DUKAAN_LANGUAGE.ADD_ON
          }: ${name} (${formatMoney(price)})`;
          addonListWrapper.appendChild(addonDiv);
        });
      }

      const addToBagMountNode = productCard.querySelector('add-to-bag-button');
      addToBagMountNode.dataset.productUuid = parentProduct.uuid;
      addToBagMountNode.dataset.skuUuid = sku.uuid;
      addToBagMountNode.dataset.addOns = addonString;
      mountElement.appendChild(productCard);
    });
};

window.removeCategoryProductListObserver = () => {
  const currentEventObserver = document.getElementById(
    'category-products-observer'
  );
  currentEventObserver?.remove();
};

window.productSplideRenderer = (
  productSplideTemplate,
  product,
  productCard
) => {
  const productSplideList = productCard.querySelector('.splide__list');
  if (productSplideList) {
    if (product.all_images?.length > 1) {
      // eslint-disable-next-line no-restricted-syntax
      for (const image of product.all_images) {
        const productSplide = document.importNode(
          productSplideTemplate.content,
          true
        );
        productSplide
          .querySelector('.product-splide-image')
          .setAttribute(
            'src',
            `${getCdnUrl(
              image,
              window?.DukaanData?.PRODUCT_IMAGE_CDN_SIZE || 700
            )}`
          );
        productSplideList.appendChild(productSplide);
      }
    } else {
      const productSplide = document.importNode(
        productSplideTemplate.content,
        true
      );
      productSplide
        .querySelector('.product-splide-image')
        .setAttribute(
          'src',
          `${getCdnUrl(
            product.image,
            window?.DukaanData?.PRODUCT_IMAGE_CDN_SIZE || 700
          )}`
        );
      productSplideList.appendChild(productSplide);
    }
  }
};

window.categoryProductsRenderer = (
  mountElement,
  products,
  templateId,
  options
) => {
  const { skipBXGYCall = false } = options || {};
  // const categoryProductTemplate = document.getElementById(
  //   'product-card-template'
  // );
  products = window.languageSerializer(products);
  products.forEach((product) => {
    window.productCardRenderer(mountElement, product, {
      templateId: templateId || 'product-card-template',
      getCustomDiscountText: window.getCustomDiscountText,
      additionalRenderer: window.productCardAdditionalRenderer,
    });
  });

  const productIds = products.map((product) => product.id);
  if (!skipBXGYCall) {
    window.fetchProductCoupons(productIds);
  }
  window.fetchRatingsDataFromProductIds(productIds, mountElement, {
    reviewInfoTemplateId: 'dkn-product-review-with-count-template',
    getCustomReviewsCountText: window.getCustomReviewsCountText,
    starHeight: window.productCardStarHeight,
    starWidth: window.productCardStarWidth,
  });

  if (typeof dknRenderWishlistButtons !== 'undefined') {
    window.dknRenderWishlistButtons(mountElement);
  }
  if (typeof dknRenderNotifyMeButtons !== 'undefined') {
    window.dknRenderNotifyMeButtons(mountElement);
  }

  const observerId = 'category-products-obeserver';
  const currentEventObserver = document.getElementById(observerId);
  let newPage = 1;
  if (currentEventObserver) {
    newPage = Number(currentEventObserver.dataset.page || 1) + 1;
    currentEventObserver?.remove();
  } else {
    newPage += 1;
  }

  const newObserverElement = document.createElement('li');
  newObserverElement.setAttribute('id', observerId);
  newObserverElement.classList.add('observer-element');
  newObserverElement.dataset.page = `${newPage}`;
  mountElement.appendChild(newObserverElement);
  const observerElement = document.getElementById(observerId);
  if (observerElement) {
    const observer = new IntersectionObserver((entries) => {
      if (entries[0].isIntersecting) {
        if (typeof fetchCouponProducts !== 'undefined') {
          fetchCouponProducts({ page: newPage });
        } else if (typeof fetchCategoryProducts !== 'undefined') {
          fetchCategoryProducts({ page: newPage });
        }
      }
    });
    observer.observe(observerElement);
  }
  // products.forEach((product) => {
  //   const categoryProductCard = document.importNode(
  //     categoryProductTemplate.content,
  //     true
  //   );
  //   categoryProductCard
  //     .querySelectorAll('[data-product-card-slug]')
  //     .forEach((el) =>
  //       el.setAttribute(
  //         'href',
  //         `${DukaanData.DUKAAN_BASE_URL}/products/${product.slug}`
  //       )
  //     );

  //   // renders product slideshow with splide if exist.
  //   const productSplideTemplate = document.querySelector(
  //     '#product-splide-container'
  //   );
  //   if (productSplideTemplate && product.all_images.length > 1) {
  //     productSplideRenderer(
  //       productSplideTemplate,
  //       product,
  //       categoryProductCard
  //     );
  //     categoryProductCard
  //       .querySelector('[data-product-card-image]')
  //       .classList.add('hidden');
  //   } else if (categoryProductCard.querySelector('[data-product-card-image]')) {
  //     categoryProductCard
  //       .querySelector('.product-card-image-container .splide')
  //       ?.classList.add('hidden');
  //     categoryProductCard
  //       .querySelector('[data-product-card-image]')
  //       .setAttribute(
  //         'src',
  //         `https://cdn3.mydukaan.io/app/image/700x700/?url=${product.image}`
  //       );
  //   }

  //   if (categoryProductCard.querySelector('[data-product-card-qty]')) {
  //     categoryProductCard.querySelector(
  //       '[data-product-card-qty]'
  //     ).textContent = `per${
  //       product.base_qty === 1 ? '' : ` ${product.base_qty}`
  //     } ${product.unit}`;
  //   }

  //   if (categoryProductCard.querySelector('[data-product-bxgy-id]')) {
  //     categoryProductCard
  //       .querySelectorAll('[data-product-bxgy-id]')
  //       .forEach((el) => el.setAttribute('data-product-bxgy-id', product.id));
  //     categoryProductCard
  //       .querySelectorAll('[data-product-bxgy-uuid]')
  //       .forEach((el) =>
  //         el.setAttribute('data-product-bxgy-uuid', product.uuid)
  //       );
  //   }

  //   if (categoryProductCard.querySelector('[data-product-onsale-id]')) {
  //     categoryProductCard
  //       .querySelectorAll('[data-product-onsale-id]')
  //       .forEach((el) => el.setAttribute('data-product-onsale-id', product.id));
  //   }

  //   if (categoryProductCard.querySelector('[data-product-soldout-id]')) {
  //     categoryProductCard
  //       .querySelectorAll('[data-product-soldout-id]')
  //       .forEach((el) =>
  //         el.setAttribute('data-product-soldout-id', product.id)
  //       );
  //   }

  //   if (categoryProductCard.querySelector('[data-product-card-name]')) {
  //     categoryProductCard.querySelector(
  //       '[data-product-card-name]'
  //     ).textContent = product.name;
  //   }

  //   if (categoryProductCard.querySelector('wishlist-button-load-point')) {
  //     categoryProductCard
  //       .querySelector('wishlist-button-load-point')
  //       .setAttribute('data-product-uuid', product.uuid);
  //   }

  //   if (typeof customDiscountBadgeFormatter !== 'undefined') {
  //     customDiscountBadgeFormatter(product, categoryProductCard);
  //   }

  //   if (categoryProductCard.querySelector('[data-product-price-label]')) {
  //     if (!product.in_stock) {
  //       // categoryProductCard
  //       //   .querySelector('[data-product-price-label]')
  //       //   ?.classList.add('hidden');
  //       categoryProductCard
  //         .querySelector('[data-product-card-sold-out]')
  //         ?.classList.remove('hidden');
  //     }
  //   }

  //   const originalPrice = product.original_price;
  //   const sellingPrice = product.selling_price;

  //   if (
  //     categoryProductCard.querySelector('[data-product-card-selling-price]') !==
  //     null
  //   ) {
  //     categoryProductCard.querySelector(
  //       '[data-product-card-selling-price]'
  //     ).textContent = formatMoney(sellingPrice);
  //   }

  //   if (
  //     categoryProductCard.querySelector(
  //       '[data-product-card-original-price]'
  //     ) !== null
  //   ) {
  //     if (
  //       (((originalPrice - sellingPrice) / originalPrice) * 100).toFixed(0) > 0
  //     ) {
  //       categoryProductCard
  //         .querySelector('[data-product-card-original-price]')
  //         .classList.remove('hidden');
  //       categoryProductCard.querySelector(
  //         '[data-product-card-original-price]'
  //       ).textContent = formatMoney(originalPrice);
  //     } else {
  //       categoryProductCard
  //         .querySelector('[data-product-card-original-price]')
  //         .classList.add('hidden');
  //     }
  //   }

  //   if (
  //     (((originalPrice - sellingPrice) / originalPrice) * 100).toFixed(0) > 0
  //   ) {
  //     const discount = (
  //       ((originalPrice - sellingPrice) / originalPrice) *
  //       100
  //     ).toFixed(0);
  //     const discountBadgeFormat =
  //       typeof discountBadgeFormatter !== 'undefined'
  //         ? discountBadgeFormatter(discount)
  //         : `(${discount}% OFF)`;
  //     if (categoryProductCard.querySelector('[data-product-card-discount]')) {
  //       categoryProductCard.querySelector(
  //         '[data-product-card-discount]'
  //       ).textContent = discountBadgeFormat;
  //       categoryProductCard
  //         .querySelector('[data-product-card-discount]')
  //         ?.classList.remove('hidden');
  //     }
  //   } else {
  //     categoryProductCard
  //       .querySelector('[data-product-card-discount]')
  //       ?.classList.add('hidden');
  //   }

  //   const renderAddToBagWithVariantFn = () => {
  //     if (
  //       categoryProductCard.querySelector('add-to-bag-button-with-variants')
  //     ) {
  //       categoryProductCard.querySelector(
  //         'add-to-bag-button-with-variants'
  //       ).dataset = `${formatMoney(product.selling_price)}`;
  //       const addToBagElement = categoryProductCard.querySelector(
  //         'add-to-bag-button-with-variants'
  //       );
  //       addToBagElement.dataset.productUuid = product.uuid;
  //       addToBagButtonWithVariantsRenderer(addToBagElement);
  //     }
  //   };

  //   const showAddTOBagButtonProductCard =
  //     DukaanData.DUKAAN_THEME_DATA?.meta?.advanced?.product
  //       ?.showAddToBagOnProductCard;
  //   /**
  //    * Added isTHemelightspeed condition temporary to bypass advance product setting show add to cart button during render
  //    */
  //   const isThemeLightSpeed =
  //     DukaanData.DUKAAN_THEME_DATA.theme.key === 'lightspeed';

  //   /** Check if showAddToBagButtonProdutCard is undefined
  //    * check if add-to-bag-button-with-variant load point is avaialble and render button
  //    * else if is not undefined ie. it has a value either true or false so accordintly hide or render button
  //    */
  //   if (
  //     typeof showAddTOBagButtonProductCard !== 'undefined' &&
  //     !isThemeLightSpeed
  //   ) {
  //     if (showAddTOBagButtonProductCard) {
  //       renderAddToBagWithVariantFn();
  //     } else {
  //       categoryProductCard
  //         .querySelector('add-to-bag-button-with-variants')
  //         .classList.add('hidden');
  //     }
  //   } else renderAddToBagWithVariantFn();

  //   const isRestuarant = DukaanData.DUKAAN_STORE.store_category === 6;

  //   if (isRestuarant) {
  //     if (product?.meta?.length > 0) {
  //       const icon = getFoodTypeIcon(product.meta);
  //       const iconDiv = categoryProductCard.querySelector(
  //         '[data-product-card-food-icon]'
  //       );
  //       if (iconDiv) {
  //         iconDiv.innerHTML = icon;
  //         iconDiv.classList.remove('hidden');
  //       }
  //     }
  //     categoryProductCard
  //       .querySelectorAll('[data-product-card-slug]')
  //       .forEach((el) => {
  //         el.setAttribute('href', '');
  //         el.style.pointerEvents = 'none';
  //         el.classList.add('noUnderline');
  //       });
  //     // categoryProductCard
  //     //   .querySelectorAll('a')
  //     //   .forEach((el) => el.classList.add('noUnderline'));

  //     // if (categoryProductCard.querySelector('.product-description')) {
  //     //   categoryProductCard.querySelector('.product-description').innerHTML =
  //     //     product.description;
  //     //   categoryProductCard.querySelector('.product-description').classList.remove('hidden')
  //     // }
  //     if (product.description) {
  //       if (categoryProductCard.querySelector('[data-product-card-qty]')) {
  //         categoryProductCard.querySelector(
  //           '[data-product-card-qty]'
  //         ).textContent = product.description;
  //         categoryProductCard
  //           .querySelector('[data-product-card-qty]')
  //           .classList.add('hidden');
  //       }
  //     }
  //   }

  //   const productBadges = (onSaleBool, inStock) => {
  //     if (inStock) {
  //       if (onSaleBool) {
  //         const onSaleBadge = categoryProductCard.querySelector(
  //           `[data-product-onsale-id='${product.id}']`
  //         );
  //         if (onSaleBadge) {
  //           onSaleBadge.classList.remove('hidden');
  //         }
  //       }
  //     } else {
  //       const soldOutBadge = categoryProductCard.querySelector(
  //         `[data-product-soldout-id='${product.id}']`
  //       );
  //       if (soldOutBadge) {
  //         soldOutBadge.classList.remove('hidden');
  //       }
  //     }
  //   };

  //   productBadges(
  //     product.original_price > product.selling_price,
  //     product.in_stock
  //   );

  //   mountElement.appendChild(categoryProductCard);
  // });
};

window.getCategoryHasProducts = (category) => {
  if (
    // (category?.subcategories_count == 0 ||
    //   category?.sub_categories?.length == 0) &&
    category?.product_count > 0 ||
    category?.products?.length > 0
  ) {
    return true;
  }
  return false;
};

window.getSubCategoryParentData = (parentID) =>
  window.DukaanData.DUKAAN_CATALOG.filter(
    (category) => parentID === category.id
  )[0];

window.bestSellerCategoriesRenderer = (
  mountElement,
  categories,
  spliceCount = 10
) => {
  // mountElement.innerHTML = '';

  categories.forEach((category) => {
    renderSingleBestSellerCategory(category, mountElement, spliceCount);
  });

  // initProductSplide();
};

window.renderSingleBestSellerCategory = (
  category,
  mountElement,
  spliceCount
) => {
  const bestSellerCategoriesTemplate = document.getElementById(
    'bestseller-category-template'
  );
  if (getCategoryHasProducts(category)) {
    const bestSellerCategoriesCard = document.importNode(
      bestSellerCategoriesTemplate.content,
      true
    );
    bestSellerCategoriesCard
      .querySelector('[data-category-id]')
      ?.setAttribute('id', category.id);
    bestSellerCategoriesCard
      .querySelector('[data-category-uuid]')
      ?.setAttribute('id', category.uuid);
    bestSellerCategoriesCard.querySelector(
      '[data-bestseller-category-title]'
    ).textContent = category.name;
    if (
      bestSellerCategoriesCard.querySelector('[data-bestseller-category-count]')
    )
      bestSellerCategoriesCard.querySelector(
        '[data-bestseller-category-count]'
      ).textContent = category.product_count;
    // if (category.parent_id) {
    //   if (
    //     bestSellerCategoriesCard.querySelector(
    //       '[data-bestseller-category-subtitle]'
    //     ) !== null
    //   ) {
    //     const parentCategory = getSubCategoryParentData(category.parent_id);
    //     if (parentCategory) {
    //       bestSellerCategoriesCard.querySelector(
    //         '[data-bestseller-category-subtitle]'
    //       ).textContent = `(${parentCategory.name})`;
    //       bestSellerCategoriesCard
    //         .querySelector('[data-bestseller-category-subtitle]')
    //         .setAttribute(
    //           'href',
    //           getCategoryCardLink(parentCategory, DukaanData.DUKAAN_BASE_URL)
    //         );
    //       bestSellerCategoriesCard
    //         .querySelector('[data-bestseller-category-subtitle]')
    //         .setAttribute('title', parentCategory.name);
    //     }
    //   }
    // }
    if (
      bestSellerCategoriesCard.querySelector(
        '[data-bestseller-category-product-count]'
      ) !== null
    ) {
      bestSellerCategoriesCard.querySelector(
        '[data-bestseller-category-product-count]'
      ).textContent = category.product_count;
    }
    if (category.product_count > spliceCount) {
      bestSellerCategoriesCard
        .querySelector('[data-bestseller-category-view-all]')
        ?.classList.remove('hidden');
      bestSellerCategoriesCard
        .querySelectorAll('[data-bestseller-category-btn-view-all]')
        .forEach((el) =>
          el.setAttribute(
            'href',
            `${DukaanData.DUKAAN_BASE_URL}/categories/${category.slug}`
          )
        );
    }
    renderCategoryProducts(
      bestSellerCategoriesCard.querySelector('product-card-load-point'),
      category.products.slice(0, spliceCount)
    );
    mountElement.appendChild(bestSellerCategoriesCard);
  }
};

window.initProductSplide = () => {
  const splideContainer = document.querySelectorAll(
    '.product-card-image-container'
  );

  if (!splideContainer) return;

  const handleStartProductSplide = (card, productCardSplide) => {
    const splideProgressBar = card.querySelector('.splide-progress-bar');
    const slideLength = productCardSplide.Components.Slides.getLength();
    splideProgressBar.style['-webkit-animation-duration'] = `${
      1500 * slideLength
    }ms`;

    card.querySelector('.splide-progress-bar').classList.remove('hidden');
    card
      .querySelector('.splide-progress-bar')
      .classList.add('splide-progress-bar-animation');
    productCardSplide.Components.Autoplay.play();
  };

  const handleRemoveProductSplice = (card, productCardSplide) => {
    const splideProgressBar = card.querySelector('.splide-progress-bar');
    splideProgressBar.style['-webkit-animation-duration'] = '0';

    card.querySelector('.splide-progress-bar').classList.add('hidden');
    card
      .querySelector('.splide-progress-bar')
      .classList.remove('splide-progress-bar-animation');
    productCardSplide.go(0);
    productCardSplide.Components.Autoplay.pause();
  };

  // eslint-disable-next-line no-restricted-syntax
  for (const card of splideContainer) {
    const productCardSplideImages = card.querySelector(
      '#splide-product-card-images'
    );
    if (
      card.querySelectorAll('.splide__list .splide__slide').length > 0 &&
      productCardSplideImages
    ) {
      const productCardSplide = new Splide(productCardSplideImages, {
        type: 'slide',
        autoplay: false,
        interval: 1500,
        arrows: false,
        pauseOnHover: false,
        pagination: false,
        rewind: true,
      }).mount();

      card.addEventListener('mouseenter', () => {
        handleStartProductSplide(card, productCardSplide);
      });
      card.addEventListener('mouseleave', () => {
        handleRemoveProductSplice(card, productCardSplide);
      });
    }
  }
};

window.categoryProductListRenderer = (
  mountElement,
  products,
  templateId = 'category-product-card',
  observerId = 'category-products-observer',
  fetchFn
) => {
  const categoryProductCardTemplate = document.getElementById(templateId);
  const currentEventObserver = document.getElementById(observerId);

  const shimmerElements = mountElement.querySelectorAll('.shimmerCard');

  if (shimmerElements) {
    shimmerElements.forEach((shimmerElement) =>
      shimmerElement.classList.add('hidden')
    );
  }

  if (!products.length) {
    currentEventObserver?.remove();
    return;
  }

  products.forEach((product) => {
    const categoryProductCard = document.importNode(
      categoryProductCardTemplate.content,
      true
    );
    categoryProductCard.querySelector('.product-name').textContent =
      product.name;

    // renders product slideshow with splide if exist.
    const productSplideTemplate = document.querySelector(
      '#product-splide-container'
    );
    if (productSplideTemplate) {
      productSplideRenderer(
        productSplideTemplate,
        product,
        categoryProductCard
      );
      const splideProgressBar = categoryProductCard.querySelector(
        '.splide-progress-bar'
      );
      if (splideProgressBar) {
        splideProgressBar.style['-webkit-animation-duration'] = `${
          1500 * Number(product.all_images?.length || 1)
        }ms`;
      }
    }

    const isRestuarant = DukaanData.DUKAAN_STORE.store_category === 6;

    if (isRestuarant) {
      if (product?.meta?.length > 0) {
        const icon = getFoodTypeIcon(product.meta);
        const iconDiv = categoryProductCard.querySelector('.food-type-icon');
        if (iconDiv) {
          iconDiv.innerHTML = icon;
          iconDiv.classList.remove('hidden');
        }
      }
      categoryProductCard
        .querySelectorAll('a')
        .forEach((el) => el.setAttribute('href', '#'));
      categoryProductCard
        .querySelectorAll('a')
        .forEach((el) => el.classList.add('noUnderline'));

      if (categoryProductCard.querySelector('.product-description')) {
        categoryProductCard.querySelector('.product-description').innerHTML =
          product.description;
        categoryProductCard
          .querySelector('.product-description')
          .classList.remove('hidden');
      }
      if (categoryProductCard.querySelector('.product-unit')) {
        categoryProductCard
          .querySelector('.product-unit')
          .classList.add('hidden');
      }
    } else {
      categoryProductCard.querySelectorAll('a').forEach((el) => {
        el.setAttribute(
          'href',
          `${DukaanData.DUKAAN_BASE_URL}/products/${product.slug}`
        );
        el.setAttribute('data-product-uuid', product.uuid);
      });

      if (categoryProductCard.querySelector('.product-unit')) {
        categoryProductCard.querySelector('.product-unit').textContent = `${
          DukaanData.DUKAAN_LANGUAGE.PER
        }${product.base_qty === 1 ? '' : ` ${product.base_qty}`} ${
          product.unit
        }`;
      }
    }

    categoryProductCard
      .querySelector('.product-image')
      .setAttribute(
        'src',
        `${getCdnUrl(
          product.image,
          window?.DukaanData?.PRODUCT_IMAGE_CDN_SIZE || 700
        )}`
      );

    const productBadges = (bxgyData, onSaleBool, inStock) => {
      if (inStock) {
        if (bxgyData?.length > 0) {
          const bxgyBadge = categoryProductCard.querySelector('.bxgy-badge');
          if (bxgyBadge) {
            bxgyBadge.classList.remove('hidden');
            bxgyBadge.textContent = getBXGYText(product.coupon_data);
          }
        } else if (onSaleBool) {
          const onSaleBadge =
            categoryProductCard.querySelector('.on-sale-badge');
          if (onSaleBadge) {
            onSaleBadge.classList.remove('hidden');
          }
        }
      } else {
        const soldOutBadge =
          categoryProductCard.querySelector('.sold-out-badge');
        if (soldOutBadge) {
          soldOutBadge.classList.remove('hidden');
        }
      }
    };

    if (categoryProductCard.querySelector('.product-selling-price')) {
      categoryProductCard.querySelector(
        '.product-selling-price'
      ).textContent = `${formatMoney(product.selling_price)}`;
    }
    if (product.original_price !== product.selling_price) {
      if (categoryProductCard.querySelector('.product-original-price')) {
        categoryProductCard.querySelector(
          '.product-original-price'
        ).textContent = `${formatMoney(product.original_price)}`;
      }
    } else {
      categoryProductCard
        .querySelector('.product-original-price')
        .classList.add('hidden');
    }

    if (
      (
        ((product.original_price - product.selling_price) /
          product.original_price) *
        100
      ).toFixed(0) > 0
    ) {
      if (categoryProductCard.querySelector('.product-discount-percent')) {
        const discount = (
          ((product.original_price - product.selling_price) /
            product.original_price) *
          100
        ).toFixed(0);

        categoryProductCard.querySelector(
          '.product-discount-percent'
        ).textContent =
          typeof discountBadgeFormatter !== 'undefined'
            ? discountBadgeFormatter(discount)
            : `(${discount}% OFF)`;
      }
    } else {
      categoryProductCard
        .querySelector('.product-discount-percent')
        ?.classList.add('hidden');
    }

    if (categoryProductCard.querySelector('add-to-bag-button-with-variants')) {
      categoryProductCard.querySelector(
        'add-to-bag-button-with-variants'
      ).dataset = `${formatMoney(product.selling_price)}`;
      const addToBagElement = categoryProductCard.querySelector(
        'add-to-bag-button-with-variants'
      );
      addToBagElement.dataset.productUuid = product.uuid;
      addToBagButtonWithVariantsRenderer(addToBagElement);
    }
    if (categoryProductCard.querySelector('.out-of-stock')) {
      if (product.in_stock) {
        categoryProductCard
          .querySelector('.out-of-stock')
          .classList.add('display-none');
      } else {
        categoryProductCard
          .querySelector('add-to-bag-button-with-variants')
          .classList.add('display-none');
      }
    }
    if (typeof additionalCategoryProductCardChanges !== 'undefined') {
      additionalCategoryProductCardChanges(categoryProductCard, product);
    }
    productBadges(
      product.coupon_data,
      product.original_price > product.selling_price,
      product.in_stock
    );
    if (typeof handleProductCardChange !== 'undefined') {
      handleProductCardChange(categoryProductCard, product);
    }
    if (categoryProductCard.querySelector('wishlist-button-load-point')) {
      categoryProductCard
        .querySelector('wishlist-button-load-point')
        .setAttribute('data-product-uuid', product.uuid);
    }
    if (categoryProductCard.querySelector('notify-me-button-load-point')) {
      categoryProductCard
        .querySelector('notify-me-button-load-point')
        .setAttribute('data-product-uuid', product.uuid);
    }
    mountElement.appendChild(categoryProductCard);
  });

  let newPage = 1;
  if (currentEventObserver) {
    newPage = Number(currentEventObserver.dataset.page || 1) + 1;
    currentEventObserver?.remove();
  } else {
    newPage += 1;
  }

  const newObserverElement = document.createElement('li');
  newObserverElement.setAttribute('id', observerId);
  newObserverElement.classList.add('observer-element');
  newObserverElement.dataset.page = `${newPage}`;
  mountElement.appendChild(newObserverElement);
  const observerElement = document.getElementById(observerId);
  const observer = new IntersectionObserver((entries) => {
    if (entries[0].isIntersecting) {
      if (typeof fetchFn !== 'undefined') {
        fetchFn({ page: newPage });
      } else if (typeof fetchCouponProducts !== 'undefined') {
        fetchCouponProducts({ page: newPage });
      } else if (typeof fetchCategoryProducts !== 'undefined') {
        fetchCategoryProducts({ page: newPage });
      }
    }
  });
  observer.observe(observerElement);
};

window.scrollerEvent = [];
window.listnerParams = {
  capture: true,
  passive: true,
};

window.removeScroller = ({ observeThis }) => {
  const elem = document.querySelector(`.${observeThis}`);
  if (elem !== null && elem !== undefined) {
    document.removeEventListener('scroll', scrollerEvent[0], listnerParams);
    elem.remove();
  }
};

window.applyScroller = ({ observeThis, loading, hasMore, cb, loadPoint }) => {
  // let lastKnownScrollPosition = 0;
  let ticking = false;

  const handleEventListner = () => {
    // lastKnownScrollPosition = window.scrollY;
    if (!ticking) {
      window.requestAnimationFrame(async () => {
        const elem = document.querySelector(`.${observeThis}`);
        if (elem !== null && elem !== undefined && hasMore && !loading) {
          const elemTop = elem.getBoundingClientRect().top;
          const documentHeight = window.innerHeight;
          if (elemTop <= documentHeight + 500) {
            document
              .querySelector(`.${observeThis}`)
              ?.classList.remove('hidden');
            await cb();
            document.querySelector(`.${observeThis}`)?.classList.add('hidden');
          }
        }
        ticking = false;
      });

      ticking = true;
    }
  };

  const checkIfObserverAlreadyInViewPort = async () => {
    const elem = document.querySelector(`.${observeThis}`);
    let firstHit = false;
    if (
      !firstHit &&
      elem !== null &&
      elem !== undefined &&
      hasMore &&
      !loading
    ) {
      const elemTop = elem.getBoundingClientRect().top;
      const documentHeight = window.innerHeight;
      if (elemTop <= documentHeight + 300) {
        await cb();
        firstHit = true;
      }
    }
  };

  let listnerEvent = null;
  if (listnerEvent !== null) {
    document.removeEventListener('scroll', scrollerEvent[0], listnerParams);
    listnerEvent = null;
  }
  const observeElem = document.createElement('div');
  const observeElemInner = document
    .querySelector('.bounceLoader')
    .cloneNode(true);
  observeElemInner.classList.remove('hidden');
  observeElem.appendChild(observeElemInner);
  observeElem.className = `${observeThis} relative`;
  loadPoint?.parentElement.appendChild(observeElem);
  const eventFn = handleEventListner.bind(this);
  scrollerEvent.push(eventFn);
  document.addEventListener('scroll', eventFn, listnerParams);
  checkIfObserverAlreadyInViewPort();
};

// window.fetchProductCoupons = async (categories = []) => {
//   // const categories = [...window.DukaanData.DUKAAN_CATALOG, ...rawCategories];
//   if (!(!!categories.length > 0)) return;
//   const productIds = categories
//     .map((category) => category?.products)
//     .flat()
//     .reduce((prevValue, currentValue) => [...prevValue, currentValue?.id], []);

//   fetch(
//     `${window.DukaanData.CLIENT_API2_ENDPOINT}/api/product/buyer/${window.DukaanData.DUKAAN_STORE.id}/bxgy-coupon-details/`,
//     {
//       method: 'post',
//       body: JSON.stringify({
//         product_ids: productIds,
//       }),
//       headers: {
//         'Content-Type': 'application/json',
//         'x-requested-with': window?.DukaanData?.DUKAAN_SESSION_ID,
//       },
//     }
//   )
//     .then((res) => res.json())
//     .then((res) => {
//       const { data } = res;
//       const {
//         bxgy_allowed_product_ids: bxgyAllowedProductIds,
//         coupon_data: couponData,
//       } = data;
//       const bxgyHash = bxgyAllowedProductIds?.reduce((previous, current) => {
//         const obj = {
//           [current]: {
//             ...couponData,
//             name: couponData.name.toUpperCase(),
//           },
//         };
//         return [...previous, obj];
//       }, []);

//       bxgyHash?.forEach((bH) => {
//         const [productID] = Object.keys(bH);
//         const bxgyBadge = document.querySelectorAll(
//           `[data-product-bxgy-id='${productID}']`
//         );
//         if (bxgyBadge) {
//           const productUUID = bxgyBadge[0]?.dataset?.productBxgyUuid;
//           let product = DukaanData.PRODUCTS_MAP[productUUID];
//           if (!!product && product.in_stock) {
//             if (bxgyBadge?.length > 0) {
//               bxgyBadge.forEach((bB) => {
//                 bB.classList.remove('hidden');
//                 bB.textContent = bH[productID].name;
//               });
//             }
//             product = {
//               ...product,
//               coupon_data: [bH[productID]],
//             };

//             DukaanData.PRODUCTS_MAP = {
//               ...DukaanData.PRODUCTS_MAP,
//               [productUUID]: product,
//             };
//           }
//         }
//       });
//     })
//     .catch((err) => {
//       console.log(err);
//     });
// };

window.fetchStoreCategories = () => {
  // Common function
  let offset = 0;
  let initialized = true;
  const offsetCount = 10;

  // overriding the default browser scroll behavior
  document
    .querySelectorAll('.modal-overflow-container')
    ?.forEach((el) => el?.scrollTo(0, 0));

  // eslint-disable-next-line no-undef, no-return-assign
  return (fetchFn = ({
    nextUrl = false,
    cb,
    loadPoint = null,
    firstFetch = false,
    ...rest
  } = {}) => {
    // let fetchUrl = `${window.DukaanData.CLIENT_API2_ENDPOINT}/api/product/buyer/${window.DukaanData.DUKAAN_STORE.link}/product-category-list/`;
    const fetchUrl = `${window.DukaanData.CLIENT_API2_ENDPOINT}/api/product/buyer/${window.DukaanData.DUKAAN_STORE.link}/product-category-list/?offset=${offset}`;

    if (nextUrl) {
      offset += offsetCount;
      initialized = false;
    }

    if (initialized) offset += offsetCount;

    fetch(fetchUrl, {
      method: 'get',
      headers: {
        'Content-Type': 'application/json',
        'x-requested-with': window?.DukaanData?.DUKAAN_SESSION_ID,
        // 'Content-Type': 'application/x-www-form-urlencoded',
      },
    })
      .then((res) => res.json())
      .then((res) => {
        let categories = res?.results || [];
        const next = !(categories.length < offsetCount);
        categories =
          categories?.filter((category) => isParentCategory(category)) || [];
        DukaanData.DUKAAN_CLIENT_CATEGORY_LIST = {
          ...DukaanData?.DUKAAN_CLIENT_CATEGORY_LIST,
          ...categories?.reduce((map, category) => {
            map[category.uuid] = { ...category };
            return map;
          }, {}),
        };
        if (initialized && loadPoint !== null) {
          document
            .querySelectorAll(loadPoint)
            // eslint-disable-next-line no-return-assign
            ?.forEach((el) => (el.innerHTML = ''));
          // document.querySelectorAll(".category-sidebar-list")?.forEach(el => el.innerHTML = "");
          // document.querySelectorAll(".category-list")?.forEach(el => el.innerHTML = "");
        }
        cb(categories, next, firstFetch, loadPoint, rest);
      })
      .catch((err) => {
        console.log('fetchStoreCategories error : ', err);
        cb([], false);
      });
  });
};

window.fetchStoreSubCategories = () => {
  // Common function
  let offset = 0;
  let initialized = true;
  const offsetCount = 10;

  // eslint-disable-next-line no-undef, no-return-assign
  return (fetchFn = ({
    nextUrl = false,
    cb,
    loadPoint = null,
    firstFetch = false,
    ...rest
  } = {}) => {
    const fetchUrl = `${window.DukaanData.CLIENT_API2_ENDPOINT}/api/product/buyer/${window.DukaanData.DUKAAN_STORE.link}/product-category-list/?parent_slug=${window.DukaanData.DUKAAN_CATEGORY.slug}&offset=${offset}`;

    if (nextUrl) {
      offset += offsetCount;
      initialized = false;
      firstFetch = false;
    }

    if (initialized) offset += offsetCount;

    fetch(fetchUrl, {
      method: 'get',
      headers: {
        'Content-Type': 'application/json',
        'x-requested-with': window?.DukaanData?.DUKAAN_SESSION_ID,
        // 'Content-Type': 'application/x-www-form-urlencoded',
      },
    })
      .then((res) => res.json())
      .then((res) => {
        const categories = res?.results || [];
        const next = !(categories.length < offsetCount);
        DukaanData.DUKAAN_CLIENT_CATEGORY_LIST = {
          ...DukaanData?.DUKAAN_CLIENT_CATEGORY_LIST,
          ...categories?.reduce((map, category) => {
            map[category.uuid] = { ...category };
            return map;
          }, {}),
        };
        if (firstFetch) {
          document
            .querySelectorAll('.category-list-load-point')
            // eslint-disable-next-line no-return-assign
            .forEach((el) => (el.innerHTML = ''));
        }
        cb(categories, next, firstFetch, loadPoint, rest);
      })
      .catch(() => {
        console.log('fetchStoreSubCategories error : ', err);
        cb([], null);
      });
  });
};

window.fetchSingleCategoryDataUsingUUID = (
  uuid,
  cb,
  filterProductId,
  limit
) => {
  if (!uuid) {
    cb([]);
    return;
  }
  const url = `${window.DukaanData.CLIENT_API_ENDPOINT}/api/product/buyer/${DukaanData.DUKAAN_STORE.uuid}/product-list/v2/?category=${uuid}&ordering=&search=&page=1&pop_fields=category_data,store_data`;
  fetch(url, {
    method: 'GET',
    headers: {
      'Content-Type': 'application/json',
      'x-requested-with': window?.DukaanData?.DUKAAN_SESSION_ID,
    },
  })
    .then((res) => res.json())
    .then((resp) => {
      let products = resp?.results;

      if (filterProductId) {
        products = products.filter((product) => product.id !== filterProductId);
      }

      if (limit) {
        products = products.slice(0, limit);
      }

      DukaanData.PRODUCTS_MAP = {
        ...DukaanData.PRODUCTS_MAP,
        ...products?.reduce((map, product) => {
          const serializedSKUs = serializeSKUs(product.skus || []);
          const attributes = getAllProductAttributeValues(serializedSKUs);

          const previousSKUS = map[product.uuid]?.skus;
          let finalSKUS = [...serializedSKUs];
          if (previousSKUS?.length > 0) {
            finalSKUS = [...finalSKUS, ...previousSKUS];
          }
          map[product.uuid] = {
            ...product,
            skus: finalSKUS,
            attributes,
          };
          return map;
        }, {}),
      };
      cb(products);
    })
    .catch((err) => {
      // console.log(err);
      cb([]);
    });
};

window.shimmertListRenderer = (mountElement, mountShimmerElement, count) => {
  // mountElement.innerHTML="";
  const shimmerTemplate = document.getElementById(mountShimmerElement);
  [...Array(count).keys()].forEach(() => {
    const shimmerCard = document.importNode(shimmerTemplate?.content, true);
    mountElement.appendChild(shimmerCard);
  });
};

window.renderAllAddToBagButton = () => {
  customTag('add-to-bag-button', addToBagButtonRenderer);
  customTag(
    'add-to-bag-button-with-variants',
    addToBagButtonWithVariantsRenderer
  );
  customTag(
    'add-to-bag-button-with-external-quantity-input',
    dknAddToBagButtonWithExternalQtyFieldRenderer
  );
};

window.renderAllBuyNowButton = () => {
  customTag('buy-now-button-load-point', buyNowButtonRenderer);
};

window.renderCategoryProductList = (products) => {
  customTag('category-products-list', (element) =>
    categoryProductListRenderer(element, products)
  );
};

window.renderBestSellers = (categories, spliceCount) => {
  customTag('best-seller-load-point', (element) =>
    bestSellerCategoriesRenderer(element, categories, spliceCount)
  );
};

window.renderBestSellersWithSplide = (categories, spliceCount) => {
  customTag('best-seller-with-splide-load-point', (element) => {
    bestSellerCategoriesRenderer(element, categories, spliceCount);
  });
};

window.renderCategoryProducts = (elements, products, templateId, options) => {
  customTemplateElem(elements, (mountElem) => {
    categoryProductsRenderer(mountElem, products, templateId, options);
  });
};

window.renderShimmer = (tag, shimmerTag, count) => {
  customTag(tag, (element) => shimmertListRenderer(element, shimmerTag, count));
};

// ---------------------------------------------------------------------------------------------------------------------
// Money utils
// ---------------------------------------------------------------------------------------------------------------------

window.getStoreCountry = () =>
  DukaanData.STORE_COUNTRY || DukaanData.DEFAULT_COUNTRY;

window.formatMoney = (number) => {
  let customConfig = {};
  if (typeof getCustomCurrencyOptions === 'function') {
    customConfig = getCustomCurrencyOptions();
  }
  const currencyConversionFactor = Number(
    customConfig?.currencyConversionFactor || 1
  );
  number *= currencyConversionFactor;
  const country = getStoreCountry();
  const isInt = number % 1 === 0;
  const additionalOptions = window.additionalMoneyFormatOptions || {};
  const options = {
    style: 'currency',
    currency: customConfig?.currency_code || country?.currency_code,
    numberingSystem: country?.numberingSystem || undefined,
    ...additionalOptions,
  };
  if (isInt) {
    options.maximumFractionDigits = 0;
    options.minimumFractionDigits = 0;
  }
  const currencyString = new Intl.NumberFormat(country.locale, options).format(
    number
  );
  return currencyString?.replace(/\s/g, '') || '';
};

window.getBXGYText = (couponData) => {
  const { buy_x_count: buyXCount, get_y_count: getYCount } = couponData[0];
  const text =
    DukaanData.DUKAAN_LANGUAGE.BUY__BUYXCOUNT_GET__GETYCOUNT.injectText({
      buyxcount: buyXCount,
      getycount: getYCount,
    });

  // `BUY ${buyXCount} GET ${getYCount}`;
  return text;
};

window.dateFormatter = (date) => {
  if (typeof window.customDateFormatter !== 'undefined') {
    return window.customDateFormatter(date);
  }
  return new Date(date).toLocaleDateString('en-IN', {
    year: 'numeric',
    month: 'short',
    day: '2-digit',
  });
};

const FOOD_TYPES = [
  {
    alt: 'Veg',
    iconSvg: `<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 16 16">
  <g fill="none" fill-rule="evenodd">
      <g fill="#17B31B" fill-rule="nonzero">
          <g>
              <path d="M109.455 247c-.804 0-1.455.65-1.455 1.455v13.09c0 .804.65 1.455 1.455 1.455h13.09c.804 0 1.455-.65 1.455-1.455v-13.09c0-.804-.65-1.455-1.455-1.455h-13.09zm0 1.455h13.09v13.09h-13.09v-13.09zm6.545 2.181c-2.41 0-4.364 1.954-4.364 4.364s1.954 4.364 4.364 4.364 4.364-1.954 4.364-4.364-1.954-4.364-4.364-4.364z" transform="translate(-124 -671) translate(16 424)"/>
          </g>
      </g>
  </g>
</svg>`,
  },
  {
    alt: 'Non-veg',
    iconSvg: `<svg width="16" height="17" viewBox="0 0 16 17" fill="none" xmlns="http://www.w3.org/2000/svg">
  <path d="M0.75 2.5C0.75 1.80964 1.30964 1.25 2 1.25H14C14.6904 1.25 15.25 1.80964 15.25 2.5V14.5C15.25 15.1904 14.6904 15.75 14 15.75H2C1.30964 15.75 0.75 15.1904 0.75 14.5V2.5Z" stroke="#E50B20" stroke-width="1.5"/>
  <path d="M7.57711 4.7429C7.76143 4.41904 8.23857 4.41903 8.42289 4.7429L12.4384 11.7984C12.6176 12.1132 12.3844 12.5 12.0155 12.5H3.98447C3.6156 12.5 3.38244 12.1132 3.56157 11.7984L7.57711 4.7429Z" fill="#E50B20"/>
  </svg>
  `,
  },
  {
    alt: 'Egg',
    iconSvg: `<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 16 16">
<g fill="none" fill-rule="evenodd">
      <g fill="#FAB73B" fill-rule="nonzero">
          <g>
              <g>
                  <g>
                      <path d="M1.455 1C.65 1 0 1.65 0 2.455v13.09C0 16.35.65 17 1.455 17h13.09C15.35 17 16 16.35 16 15.545V2.455C16 1.65 15.35 1 14.545 1H1.455zm0 1.455h13.09v13.09H1.455V2.455zM8 4.636C5.59 4.636 3.636 6.59 3.636 9S5.59 13.364 8 13.364 12.364 11.41 12.364 9 10.41 4.636 8 4.636z" transform="translate(-124 -803) translate(16 424) translate(0 377) translate(108 1)"/>
                  </g>
              </g>
          </g>
      </g>
  </g>
</svg>
`,
  },
  {
    alt: 'Other',
    iconSvg: `<svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" fill="none" viewBox="0 0 20 20">
  <g clip-path="url(#clip0)">
      <g filter="url(#filter0_d)">
          <path fill="#000" d="M383.75 13.75h-450v90h450v-90z"/>
      </g>
      <path fill="#fff" d="M383.75 13.75h-450v90h450v-90z"/>
      <path fill="#000" d="M383.75-840h-450V162.5h450V-840z" opacity=".6"/>
      <path fill="#fff" fill-rule="evenodd" d="M-46.25-103.75h410c11.046 0 20 8.954 20 20v187.5h-450v-187.5c0-11.046 8.954-20 20-20z" clip-rule="evenodd"/>
      <path stroke="#D9D9D9" d="M73.75-11.25H-10c-2.761 0-5 2.239-5 5v32.5c0 2.761 2.239 5 5 5h83.75c2.761 0 5-2.239 5-5v-32.5c0-2.761-2.239-5-5-5z"/>
      <path fill="#989898" d="M1.818 0C.814 0 0 .814 0 1.818v16.364C0 19.186.814 20 1.818 20h16.364C19.186 20 20 19.186 20 18.182V1.818C20 .814 19.186 0 18.182 0H1.818zm0 1.818h16.364v16.364H1.818V1.818zM10 4.545c-3.012 0-5.455 2.443-5.455 5.455S6.988 15.454 10 15.454s5.454-2.442 5.454-5.454c0-3.012-2.442-5.455-5.454-5.455z"/>
  </g>
  <defs>
      <clipPath id="clip0">
          <path fill="#fff" d="M0 0H20V20H0z"/>
      </clipPath>
      <filter id="filter0_d" width="458" height="98" x="-70.25" y="8.75" color-interpolation-filters="sRGB" filterUnits="userSpaceOnUse">
          <feFlood flood-opacity="0" result="BackgroundImageFix"/>
          <feColorMatrix in="SourceAlpha" values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0"/>
          <feOffset dy="-1"/>
          <feGaussianBlur stdDeviation="2"/>
          <feColorMatrix values="0 0 0 0 0.85098 0 0 0 0 0.85098 0 0 0 0 0.85098 0 0 0 1 0"/>
          <feBlend in2="BackgroundImageFix" result="effect1_dropShadow"/>
          <feBlend in="SourceGraphic" in2="effect1_dropShadow" result="shape"/>
      </filter>
  </defs>
</svg>
`,
  },
];

window.getFoodTypeIcon = (meta) => {
  const foodType = meta?.filter((item) => item.key === 0)[0];
  return FOOD_TYPES[foodType?.value]?.iconSvg;
};

window.serializeUrlForCdn = (urlString) => {
  if (!urlString) return '';

  try {
    const url = new URL(urlString);
    const { pathname, origin } = url;
    const path = pathname
      .split('/')
      .map((item) => item.replaceAll('+', '%20'))
      .join('/');
    return `${origin}${path}`;
  } catch {
    return urlString;
  }
};

window.getCdnUrl = (imagePath, width, height) => {
  if (!height) {
    height = width;
  }

  let image = imagePath || '';
  if (typeof image !== 'string') return null;
  if (!image) return null;
  if (image.includes('mydukaan-prod.')) {
    image = imagePath.replace('mydukaan-prod.', 'mydukaan-prod-new.');
  }

  if (image.endsWith('.blob') || image.endsWith('.gif')) {
    return image;
  }

  if (image.startsWith('https://dms.mydukaan.io/original/')) {
    if (image.startsWith('https://dms.mydukaan.io/original/jpeg')) {
      return image.replace(
        'https://dms.mydukaan.io/original/jpeg',
        `https://dukaan.b-cdn.net/${width}x${height}/webp`
      );
    }

    return image.replace(
      'https://dms.mydukaan.io/original',
      `https://dukaan.b-cdn.net/${width}x${height}`
    );
  }

  try {
    const imageComponents = image.split('url=');
    image = imageComponents[imageComponents.length - 1] || imageComponents[0];
  } catch {
    //
  }

  image = serializeUrlForCdn(image);
  const oldDomains = [
    'https://storage.googleapis.com/dukaan-export',
    'https://storage.cloud.google.com',
    'https://dukaan-us.s3.amazonaws.com',
    'https://dukaan-core-file-service.s3.ap-southeast-1.amazonaws.com',
    'https://dukaan-core-file-service.s3.amazonaws.com',
    'https://mydukaan-prod-new.s3.amazonaws.com',
    'https://projecteagle.s3.ap-south-1.amazonaws.com',
    'https://dukaan-us.s3.us-west-2.amazonaws.com',
    'https://mydukaan.s3.amazonaws.com',
    'https://s3.ap-southeast-1.wasabisys.com/dukaan-export',
    'https://s3.ap-southeast-1.wasabisys.com/dukaan-media-v3',
    'https://s3.ap-southeast-1.wasabisys.com',
  ];

  const domain = oldDomains.find((item) => image && image.startsWith(item));

  if (domain) {
    const imgPath = image.replace(`${domain}/`, '');

    if (domain === 'https://projecteagle.s3.ap-south-1.amazonaws.com') {
      return `https://dukaan.b-cdn.net/${width}x${height}/webp/projecteagle/${imgPath}`;
    }

    if (image.includes('.gif')) {
      return `https://dukaan.b-cdn.net/original/gif/${imgPath}`;
    }

    if (image.includes('.svg')) {
      return `https://dukaan.b-cdn.net/original/svg/${imgPath}`;
    }

    return `https://dukaan.b-cdn.net/${width}x${height}/webp/${imgPath}`;
  }

  return image;
};

window.handleSnackbarError = () => {
  window.enqueueSnackbar(
    'Sorry, there was some issue with share, try after sometime',
    true,
    'error'
  );
};

window.handleShareButtonClick = async () => {
  const productLink = window.location.href;
  try {
    if (window?.navigator?.share) {
      navigator.share({
        url: window?.location?.href,
      });
    } else if (productLink) {
      window.copyTextToClipboard(productLink, 'Product link copied!');
    } else {
      window.handleSnackbarError();
    }
  } catch (err) {
    window.handleSnackbarError();
  }
};

// ---------------------------------------------------------------------------------------------------------------------
// Coupons & Offers
// ---------------------------------------------------------------------------------------------------------------------

window.fetchCouponsAndOffersOnIndex = (successCallback) => {
  const headers = {};
  if (localStorage && localStorage.al_to) {
    headers.Authorization = `Bearer ${localStorage.al_to}`;
  }
  headers['Content-Type'] = 'application/json';
  headers['x-requested-with'] = window?.DukaanData?.DUKAAN_SESSION_ID;

  const urls = [
    `${window.DukaanData.CLIENT_API_ENDPOINT}/api/coupon/buyer/${DukaanData.DUKAAN_STORE.link}/coupon/v2/`,
    `${window.DukaanData.CLIENT_API_ENDPOINT}/api/store/buyer/${DukaanData.DUKAAN_STORE.link}/payment-discount-provider/`,
  ];

  const requests = urls.map((url) =>
    axios.get(url, {
      headers,
    })
  );

  Promise.all(requests)
    .then(([couponsDataRes, offersDataRes]) => {
      const couponsData = couponsDataRes?.data.results || [];
      const discountProviders = offersDataRes?.data.data || {};
      const background =
        window.DukaanData.DUKAAN_THEME_DATA.meta?.background?.mode ||
        window.DukaanData.DUKAAN_THEME_MODE ||
        'light';
      if (couponsData.length > 0) {
        window.DukaanData.DUKAAN_COUPONS = getCouponSerializedData(
          couponsData,
          background
        );
        customTag('mobile-coupons', mobileCouponsRenderer);
      }
      const offersData = getDiscountsArray(
        discountProviders,
        false,
        background
      );
      if (offersData.length > 0) {
        window.DukaanData.DUKAAN_PAYMENT_OFFERS = offersData;
      }
      const totalCount = couponsData.length + offersData.length;
      if (totalCount > 0)
        document.getElementById('offers-label')?.classList.remove('hidden');
      if (successCallback) {
        successCallback();
      }
    })
    .catch((error) => {
      console.log(error);
    });
};

window.fetchCouponsAndOffersOnPDP = ({ sku: rawSKU } = {}) => {
  const sku =
    rawSKU || dknGetFirstAvailableSKU(DukaanData.DUKAAN_PRODUCT?.skus);
  const headers = {};
  if (localStorage && localStorage?.al_to) {
    headers.Authorization = `Bearer ${localStorage.al_to}`;
  }
  headers['Content-Type'] = 'application/json';
  headers['x-requested-with'] = window?.DukaanData?.DUKAAN_SESSION_ID;

  const couponParams = sku?.id
    ? `product_sku_id=${sku.id}`
    : `product_id=${DukaanData.DUKAAN_PRODUCT.id}`;

  const urls = [
    `${window.DukaanData.CLIENT_API_ENDPOINT}/api/coupon/buyer/${DukaanData.DUKAAN_STORE.link}/coupon/v2/?${couponParams}`,
    `${window.DukaanData.CLIENT_API_ENDPOINT}/api/store/buyer/${DukaanData.DUKAAN_STORE.link}/payment-discount-provider/`,
  ];

  const requests = urls.map((url) =>
    axios
      .get(url, {
        headers,
      })
      .catch(() => {})
  );

  Promise.all(requests)
    .then(([couponsDataRes, offersDataRes]) => {
      const couponsData = couponsDataRes?.data?.results || [];
      const discountProviders = offersDataRes?.data?.data || {};
      const background =
        window.DukaanData.DUKAAN_THEME_DATA.meta?.background?.mode ||
        window.DukaanData.DUKAAN_THEME_MODE ||
        'light';
      window.DukaanData.DUKAAN_COUPONS = getCouponSerializedData(
        couponsData,
        background
      );
      const product =
        DukaanData.PRODUCTS_MAP[window?.DukaanData?.PRODUCTS_DETAILS?.uuid];
      const firstAvailableSKU = dknGetFirstAvailableSKU(product?.skus);
      pdpCouponsRenderder(
        sku?.selling_price || firstAvailableSKU?.selling_price
      );
      const offersData = getDiscountsArray(
        discountProviders,
        false,
        background
      );
      if (offersData.length > 0) {
        window.DukaanData.DUKAAN_PAYMENT_OFFERS = offersData;
        customTag('desktop-payment-offers', desktopOffersRenderer);
        customTag('mobile-payment-offers', mobileOffersRenderer);
      } else {
        window.DukaanData.DUKAAN_PAYMENT_OFFERS = [];
      }
    })
    .catch((error) => {
      console.log(error);
    });
};

// sub category utils

window.isParentCategory = (category) => {
  if (category?.parent_id === null) {
    return true;
  }
  return false;
};

window.getHasSubCategories = (category) => {
  if (category?.parent_id === null && category?.subcategories_count > 0) {
    return true;
  }
  return false;
};

window.getCategoryCardLink = (category, baseUrl = DukaanData.DUKAAN_BASE_URL) =>
  `${baseUrl}/categories/${category.slug}`;

window.getProductLink = (
  product,
  skuId,
  baseUrl = DukaanData.DUKAAN_BASE_URL
) => {
  const { slug, metafields = [] } = product;
  const permalink = metafields?.find(
    (field) => field.key === 'product_permalink'
  )?.value_str;
  const skuParam = skuId ? `?sku_id=${skuId}` : '';
  if (permalink && window?.storeConfig?.hasPermalinkBasedProductPageRoutes) {
    if (permalink?.includes('http') || permalink?.includes('https'))
      return permalink;
    return `${DukaanData.DUKAAN_BASE_URL}${permalink}${skuParam}`;
  }
  return `${baseUrl}/products/${slug}${skuParam}`;
};

// ---------------------------------------------------------------------------------------------------------------------
// Filters
// ---------------------------------------------------------------------------------------------------------------------

window.DEVICES = {
  MOBILE: 'mobile',
  DESKTOP: 'desktop',
};

window.deviceType = () => {
  let device = '';
  let isMobile = false;
  let isDesktop = false;
  if (window.innerWidth > 1024) {
    device = window.DEVICES.DESKTOP;
    isDesktop = true;
  } else {
    device = window.DEVICES.MOBILE;
    isMobile = true;
  }

  return { device, isDesktop, isMobile };
};

window.toggleShowHide = (e, key) => {
  const upArrow = e.currentTarget.firstElementChild;
  const downArrow = e.currentTarget.lastElementChild;

  const filter = e.currentTarget.parentNode.parentElement.querySelector(
    `#filter-items-${key}`
  );

  if (upArrow) {
    if (upArrow.classList.contains('hidden')) {
      upArrow.classList.remove('hidden');
      downArrow.classList.add('hidden');
      filter.classList.remove('hidden');
    } else {
      upArrow.classList.add('hidden');
      downArrow.classList.remove('hidden');
      filter.classList.add('hidden');
    }
  }
};

window.setAttributesOfIcons = (element, key) => {
  const upArrow = element.querySelector('.up-arrow');
  upArrow.setAttribute('id', `up-arrow-${key}`);
  const downArrow = element.querySelector('.down-arrow');
  downArrow.setAttribute('id', `down-arrow-${key}`);
  const iconBox = element.querySelector('.icon-box');
  iconBox.setAttribute('onclick', `toggleShowHide(event,"${key}")`);
};

window.filtersRenderer = (id, filters) => {
  if (!filters) return;
  const filtersWrapper = document.getElementById(id);
  filtersWrapper.innerHTML = '';

  const { isMobile } = deviceType();

  const DUKAAN_SUBCATEGORIES_MAP = window.DukaanData.DUKAAN_SUB_CATEGORIES_MAP;

  if (DUKAAN_SUBCATEGORIES_MAP?.length > 0) {
    const filterSection = document.getElementById('filter-box-id');
    const element = document.importNode(filterSection.content, true);
    const label = 'category_ids';
    setAttributesOfIcons(element, label);
    element.querySelector('.filter-name').textContent = 'category';
    const box = element.querySelector('.filter-items');
    box.setAttribute('id', `filter-items-${label}`);

    DUKAAN_SUBCATEGORIES_MAP.map((dataItem) =>
      box.appendChild(categoryFilterRenderer(dataItem, label))
    );
    filtersWrapper.appendChild(element);
  }

  if (filters.sku_attrs) {
    const keys = Object.keys(filters?.sku_attrs);

    keys.forEach((key) => {
      if (filters.sku_attrs[key].length > 0) {
        const data = filters.sku_attrs[key];
        const filterSection = document.getElementById('filter-box-id');
        const element = document.importNode(filterSection.content, true);

        setAttributesOfIcons(element, key);
        element.querySelector('.filter-name').textContent = key;
        const box = element.querySelector('.filter-items');
        box.setAttribute('id', `filter-items-${key}`);

        if (key === 'color') {
          if (isMobile) {
            box.setAttribute('class', 'filter-items flex d-row');
            box.setAttribute('style', 'flex-wrap:wrap');
          }
          data.map((dataItem) =>
            box.appendChild(colorFilterRenderer(dataItem, key))
          );
        } else {
          let formattedData = data;
          if (typeof getFormattedAgeGroups !== 'undefined') {
            formattedData = getFormattedAgeGroups(data);
          }
          formattedData.map((dataItem) =>
            box.appendChild(filterRenderer(dataItem, key))
          );
        }
        filtersWrapper.appendChild(element);
      }
    });
  }
  if (filters.product_attrs) {
    const keys = Object.keys(filters.product_attrs);
    window.DukaanData.DUKAAN_PRODUCT_ATTRS = keys;
    keys.forEach((key) => {
      if (filters.product_attrs[key].length > 0) {
        const data = filters.product_attrs[key];
        const filterSection = document.getElementById('filter-box-id');
        const element = document.importNode(filterSection.content, true);
        setAttributesOfIcons(element, key);
        element.querySelector('.filter-name').textContent = key;
        const box = element.querySelector('.filter-items');
        box.setAttribute('id', `filter-items-${key}`);
        data.map((dataItem) => box.appendChild(filterRenderer(dataItem, key)));
        filtersWrapper.appendChild(element);
      }
    });
  }
  if (
    filters.min_selling_price !== filters.max_selling_price &&
    filters.max_selling_price
  ) {
    const minSP = Number(
      filters.min_selling_price ? filters.min_selling_price : 1
    );
    const maxSP = Number(filters.max_selling_price);
    const difference = Number(((maxSP - minSP) / 5).toFixed(0));
    const priceRanges = [];
    let lowerRange = minSP;
    // eslint-disable-next-line no-unused-vars
    [1, 2, 3, 4, 5].forEach((key) => {
      priceRanges.push({
        key: `${formatMoney(lowerRange)} - ${formatMoney(
          lowerRange + difference
        )}`,
        lowerRange,
        upperRange: lowerRange + difference,
      });
      lowerRange += difference;
    });

    const filterSection = document.getElementById('filter-box-id');
    const element = document.importNode(filterSection.content, true);
    const label = 'price_ranges';
    setAttributesOfIcons(element, label);

    element.querySelector('.filter-name').textContent =
      DukaanData.DUKAAN_LANGUAGE.PRICE;
    const box = element.querySelector('.filter-items');
    box.setAttribute('id', `filter-items-${label}`);
    priceRanges.map((dataItem) =>
      box.appendChild(priceFilterRenderer(dataItem, label))
    );
    filtersWrapper.appendChild(element);
  }

  if (filters.min_discount !== filters.max_discount && filters.max_discount) {
    const minDiscount = filters?.min_discount || 0;
    const maxDiscount = filters?.max_discount;
    const discountRanges = [];
    if (minDiscount.toFixed(0) > 0 && minDiscount.toFixed(0) < 10)
      discountRanges.push({
        key: '10% and below',
        val: Math.round(minDiscount),
      });

    [10, 20, 30, 40, 50, 60, 70, 80, 90, 100].map((value) => {
      if (value <= maxDiscount)
        discountRanges.push({ key: `${value}% and above`, val: value });
    });
    const filterSection = document.getElementById('filter-box-id');
    const element = document.importNode(filterSection.content, true);
    const label = 'minimum_discount_percent';
    setAttributesOfIcons(element, label);
    element.querySelector('.filter-name').textContent =
      DukaanData.DUKAAN_LANGUAGE.DISCOUNT;
    const box = element.querySelector('.filter-items');
    box.setAttribute('id', `filter-items-${label}`);
    discountRanges.map((dataItem) =>
      box.appendChild(filterRadioRenderer(dataItem, label))
    );
    filtersWrapper.appendChild(element);
  }

  // return filtersWrapper;
};

window.categoryFilterRenderer = (filter, label) => {
  const filterItemTemplate = document.getElementById('check-box-id');
  const element = document.importNode(filterItemTemplate.content, true);
  element.querySelector('.check-box-label').innerHTML = `${filter.name}
  <input name=${label} class="input-check-box ${label}-${filter.id}" value=${filter.id} type="checkbox">
          <span class="checkmark"></span>
  `;

  element
    .querySelector('.input-check-box')
    .setAttribute('onclick', `handleFilterChange(event)`);
  return element;
};

window.filterRenderer = (filter, label) => {
  const filterItemTemplate = document.getElementById('check-box-id');
  const element = document.importNode(filterItemTemplate.content, true);
  element.querySelector('.check-box-label').innerHTML = `${filter?.key}
  <input name=${label} class="input-check-box ${label}-${removeWhiteSpace(
    filter.key
  )}" value="${filter.key}" type="checkbox">
          <span class="checkmark"></span>
  `;

  element
    .querySelector('.input-check-box')
    .setAttribute('onclick', `handleFilterChange()`);
  return element;
};

window.priceFilterRenderer = (filter, label) => {
  const filterItemTemplate = document.getElementById('check-box-id');
  const element = document.importNode(filterItemTemplate.content, true);
  element.querySelector('.check-box-label').innerHTML = `${filter?.key}
  <input name=${label} class="input-check-box ${label}-${filter.lowerRange}-${filter.upperRange}" value=${filter.lowerRange}-${filter.upperRange} type="checkbox">
          <span class="checkmark"></span>
  `;

  element
    .querySelector('.input-check-box')
    .setAttribute('onclick', `handleFilterChange()`);
  return element;
};

window.getColorName = (color) => {
  if (color === undefined) return {};
  let backgroundHEX = color;
  let backgroundColor = '';
  if (backgroundHEX?.length > 7) {
    backgroundHEX = backgroundHEX.toUpperCase().replace('#FF', '#');
  }
  backgroundColor = ntc.name(backgroundHEX);
  return { color: backgroundColor[1], colorHEX: backgroundHEX };
};

window.colorFilterRenderer = (filter, label) => {
  const filterItemTemplate = document.getElementById('check-box-id');
  const element = document.importNode(filterItemTemplate.content, true);

  const mobileFilterItemTemplate =
    document.getElementById('color-check-box-id');
  const mobileElement = document.importNode(
    mobileFilterItemTemplate.content,
    true
  );
  const { color, colorHEX } = getColorName(filter.key);

  const { isDesktop } = deviceType();

  if (isDesktop) {
    element.querySelector(
      '.check-box-label'
    ).innerHTML = `<div class="flex d-row a-center j-start">
  <div style="height: 18px; width: 18px; margin-right:8px; border-radius:50%; border: 1px solid rgba(178, 178, 178, 1); background-color: ${colorHEX}" ></div>
  <div>${color}<div>
  </div>
  <input name=${label} class="input-check-box color-${filter.key.replace(
      '#',
      ''
    )}" value="${filter.key}" type="checkbox">
          <span class="checkmark"></span>
  `;
    element
      .querySelector('.input-check-box')
      .setAttribute('onclick', `handleFilterChange()`);
    return element;
  }
  mobileElement.querySelector(
    '.color-check-box-label'
  ).innerHTML = `<input name=${label}  class="color-input-check-box color-${filter.key.replace(
    '#',
    ''
  )}" value="${filter.key}" type="checkbox">
    <div class="outer-color-box"> <span class="color-checkmark" style="background:${colorHEX}"></span></div>
  `;
  mobileElement
    .querySelector('.color-input-check-box')
    .setAttribute('onclick', `handleFilterChange()`);
  return mobileElement;
};

window.filterRadioRenderer = (filter, label) => {
  const filterItemTemplate = document.getElementById('radio-select-id');
  const element = document.importNode(filterItemTemplate.content, true);
  element.querySelector('.radio-select-label').innerHTML = `${filter?.key}
  <input name=${label} class="input-radio-select ${label}-${filter.val}" value=${filter.val}  type="radio">
          <span class="radio"></span>
  `;
  element
    .querySelector('.input-radio-select')
    .setAttribute('onclick', `handleFilterChange()`);
  return element;
};

// ---------------------------------------------------------------------------------------------------------------------
// lottie utils
// ---------------------------------------------------------------------------------------------------------------------

window.injectScript = (scriptSrc, options = {}) => {
  const customScript = document.createElement('script');
  customScript.src = scriptSrc;
  if (options && options.defer === true) {
    customScript.defer = options.defer;
  }
  document.body.appendChild(customScript);
};

window.renderNoDataFoundLottie = (
  mainWrapperId = 'main-content-container',
  lottieWrapperId = 'no-data-found-lottie'
) => {
  injectScript(
    'https://cdnjs.cloudflare.com/ajax/libs/lottie-player/1.7.1/lottie-player.js'
  );
  document.getElementById(mainWrapperId).classList.add('hidden');
  document.getElementById(lottieWrapperId).classList.remove('hidden');
};

// ---------------------------------------------------------------------------------------------------------------------
// General utils
// ---------------------------------------------------------------------------------------------------------------------

window.injectScriptAtEnd = (scriptSrc, options = {}) => {
  window.addEventListener('load', () => {
    const customScript = document.createElement('script');
    customScript.src = scriptSrc;
    if (options && options.defer === true) {
      customScript.defer = options.defer;
    }
    document.body.appendChild(customScript);
  });
};

window.getAllUrlParams = () => {
  const searchParams = new URLSearchParams(window.location.search);
  const params = {};
  for (const [key, value] of searchParams) {
    params[key] = value;
  }
  return params;
};

window.setStoreUTMCampaigns = () => {
  const paramString = new URLSearchParams(window.location.search);
  const allParamsObject = getAllUrlParams();
  const allParams = Object.keys(allParamsObject);
  const utmParams = allParams.filter((param) => param.includes('utm_'));

  const { link } = DukaanData.DUKAAN_STORE;
  const source = paramString.get('utm_source');
  const medium = paramString.get('utm_medium');
  const campaign = paramString.get('utm_campaign');
  const utmTerm = paramString.get('utm_term');
  const utmContent = paramString.get('utm_content');
  const utmQuery = paramString.get('utm_query');
  const vcRefId = paramString.get('vcRefId');
  const gclid = paramString.get('gclid');
  const fbclid = paramString.get('fbclid');
  const campaignId = paramString.get('campaign_id');
  if (source) setDataToLocalStorage(`${link}_utm_source`, source);
  if (medium) setDataToLocalStorage(`${link}_utm_medium`, medium);
  if (campaign) setDataToLocalStorage(`${link}_utm_campaign`, campaign);
  if (utmTerm) setDataToLocalStorage(`${link}_utm_term`, utmTerm);
  if (utmContent) setDataToLocalStorage(`${link}_utm_content`, utmContent);
  if (utmQuery) setDataToLocalStorage(`${link}_utm_query`, utmQuery);
  if (vcRefId) setDataToLocalStorage(`${link}_vcRefId`, vcRefId);
  if (gclid) setDataToLocalStorage(`${link}_gclid`, gclid);
  if (fbclid) setDataToLocalStorage(`${link}_fbclid`, fbclid);
  if (campaignId) setDataToLocalStorage(`__${link}_campaign_id__`, campaignId);

  utmParams.forEach((key) => {
    const value = allParamsObject[key];
    if (!value) return;
    setDataToLocalStorage(`${link}_${key}`, value);
  });

  if (DukaanData?.DUKAAN_LANDING_PAGE) {
    setDataToLocalStorage(
      SESSION_LANDING_PAGE_STORAGE_KEY(),
      DukaanData?.DUKAAN_LANDING_PAGE
    );
  }
};

window.generateRandomString = (length) => {
  let result = '';
  const characters =
    'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
  const charactersLength = characters.length;
  for (let i = 0; i < length; i++) {
    result += characters.charAt(Math.floor(Math.random() * charactersLength));
  }
  return result;
};

window.vibrate = (duration = 20) => {
  navigator.vibrate =
    navigator.vibrate ||
    navigator.webkitVibrate ||
    navigator.mozVibrate ||
    navigator.msVibrate;

  if (navigator.vibrate) {
    // vibration API supported
    navigator.vibrate(duration);
  }
};

window.redirectToAccount = () => {
  window.location = `/${DukaanData.DUKAAN_STORE.link}/account`;
};

window.redirectToLoyaltyPage = () => {
  window.location = `/${DukaanData.DUKAAN_STORE.link}/account/loyalty-points`;
};

window.redirectToAddresses = () => {
  window.location = `/${DukaanData.DUKAAN_STORE.link}/addresses`;
};

window.redirectToOrders = () => {
  window.location = `/${DukaanData.DUKAAN_STORE.link}/orders`;
};

window.redirectToWishlistPage = () => {
  window.location = `/${DukaanData.DUKAAN_STORE.link}/wishlist`;
};

window.removeWhiteSpace = (text) => {
  text = text.replace(/\s/g, '');
  return text;
};

window.handleBackClick = () => {
  if (window.history.length <= 2) {
    window.location = `${DukaanData.DUKAAN_BASE_URL || '/'}`;
  } else {
    window.history.back();
  }
};

window.getTickColor = (color) => {
  const { isLight } = colorLightOrDark(color);
  document.documentElement.style.setProperty(
    '--tick-color',
    isLight ? '#1a181e' : '#ffffff'
  );
};

window.colorLightOrDark = (color) => {
  if (!color) return 'light';

  // Check the format of the color, HEX or RGB?
  if (color.match(/^rgb/)) {
    // If HEX --> store the red, green, blue values in separate variables
    color = color.match(
      /^rgba?\((\d+),\s*(\d+),\s*(\d+)(?:,\s*(\d+(?:\.\d+)?))?\)$/
    );
    // eslint-disable-next-line prefer-destructuring
    r = color[1];
    // eslint-disable-next-line prefer-destructuring
    g = color[2];
    // eslint-disable-next-line prefer-destructuring
    b = color[3];
  } else {
    // If RGB --> Convert it to HEX: http://gist.github.com/983661
    color = +`0x${color.slice(1).replace(color.length < 5 && /./g, '$&$&')}`;
    r = color >> 16;
    g = (color >> 8) & 255;
    b = color & 255;
  }

  // HSP (Highly Sensitive Poo) equation from http://alienryderflex.com/hsp.html
  hsp = Math.sqrt(0.299 * (r * r) + 0.587 * (g * g) + 0.114 * (b * b));

  // Using the HSP value, determine whether the color is light or dark
  const isLight = hsp > 180;
  const isDark = !isLight;
  return { isLight, isDark };
};

window.calculateDiscount = (originalPrice, sellingPrice) =>
  (((originalPrice - sellingPrice) / originalPrice) * 100).toFixed(0);

window.handleBodyOverflow = () => {
  const elem = document.querySelector('body');
  const isOverflowHidden = elem.style.overflow === 'hidden';
  if (isOverflowHidden) {
    elem.style.overflow = '';
  } else {
    elem.style.overflow = 'hidden';
  }
};

window.pluralize = (num, singular, plural = `${singular}s`) => {
  if (DukaanData.DUKAAN_USER_SELECTED_LANGUAGE !== 'eng') return singular;

  if (num === 1) return singular;
  return plural;
};

window.copyTextToClipboard = (text, customMessage) => {
  const input = document.createElement('textarea');
  document.body.appendChild(input);
  input.value = text;
  input.textContent = text;
  input.select();
  document.execCommand('copy');
  document.body.removeChild(input);
  if (typeof enqueueSnackbar !== 'undefined') {
    if (customMessage) {
      enqueueSnackbar(customMessage, true);
    } else {
      enqueueSnackbar(
        DukaanData.DUKAAN_LANGUAGE.CODE__COUPONCODE_COPIED_TO_CLIPBOARD.injectText(
          {
            couponCode: text,
          }
        ),
        true
      );
    }
  }
};

window.formatPercent = (number) => {
  number = Number(number);
  return `${Math.round(number)}%`;
};

window.imageOnError = (event) => {
  const { target } = event;
  const originalSrc = target.src;

  if (
    target.src ===
    'https://api-enterprise.mydukaan.io/static/images/category-def.jpg'
  ) {
    return;
  }

  target.src =
    'https://api-enterprise.mydukaan.io/static/images/category-def.jpg';
  target.classList.add('error-img');

  const url = 'https://dms.mydukaan.io/api/create-index/';
  const { isMobile } = deviceType();
  const data = {
    src: originalSrc || '',
    store_id: window?.DukaanData?.DUKAAN_STORE?.id,
    store_link: window?.DukaanData?.DUKAAN_STORE?.link,
    user_agent: window.navigator.userAgent,
    is_mobile: isMobile,
    referrer: window.location.href,
  };

  fetch(url, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
    },
    body: JSON.stringify(data),
  })
    .then((response) => response.json())
    .then((data) => console.log(data))
    .catch((error) => console.error('Error:', error));
};

window.decodeBase64 = (s) => {
  const e = {};
  let i;
  let k;
  const v = [];
  let r = '';
  const w = String.fromCharCode;
  const n = [
    [65, 91],
    [97, 123],
    [48, 58],
    [43, 44],
    [47, 48],
  ];

  // eslint-disable-next-line guard-for-in, no-restricted-syntax
  for (z in n) {
    // eslint-disable-next-line prefer-destructuring
    for (i = n[z][0]; i < n[z][1]; i++) {
      v.push(w(i));
    }
  }
  for (i = 0; i < 64; i++) {
    e[v[i]] = i;
  }

  for (i = 0; i < s.length; i += 72) {
    let b = 0;
    let c;
    let x;
    let l = 0;
    const o = s.substring(i, i + 72);
    for (x = 0; x < o.length; x++) {
      c = e[o.charAt(x)];
      b = (b << 6) + c;
      l += 6;
      while (l >= 8) {
        r += w((b >>> (l -= 8)) % 256);
      }
    }
  }
  return r;
};

window.Base64 = {
  _keyStr: 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=',
  encode(e) {
    let t = '';
    let n;
    let r;
    let i;
    let s;
    let o;
    let u;
    let a;
    let f = 0;
    e = Base64._utf8_encode(e);
    while (f < e.length) {
      n = e.charCodeAt(f++);
      r = e.charCodeAt(f++);
      i = e.charCodeAt(f++);
      s = n >> 2;
      o = ((n & 3) << 4) | (r >> 4);
      u = ((r & 15) << 2) | (i >> 6);
      a = i & 63;
      if (Number.isNaN(r)) {
        // eslint-disable-next-line no-multi-assign
        u = a = 64;
      } else if (Number.isNaN(i)) {
        a = 64;
      }
      t =
        t +
        this._keyStr.charAt(s) +
        this._keyStr.charAt(o) +
        this._keyStr.charAt(u) +
        this._keyStr.charAt(a);
    }
    return t;
  },
  _utf8_encode(e) {
    e = e.replace(/\r\n/g, '\n');
    let t = '';
    for (let n = 0; n < e.length; n++) {
      const r = e.charCodeAt(n);
      if (r < 128) {
        t += String.fromCharCode(r);
      } else if (r > 127 && r < 2048) {
        t += String.fromCharCode((r >> 6) | 192);
        t += String.fromCharCode((r & 63) | 128);
      } else {
        t += String.fromCharCode((r >> 12) | 224);
        t += String.fromCharCode(((r >> 6) & 63) | 128);
        t += String.fromCharCode((r & 63) | 128);
      }
    }
    return t;
  },
};

window.encodeBase64 = (string) => Base64.encode(string);

window.setLanguageCookie = (value) => {
  const addressQuery = new URLSearchParams(window.location.search);
  const DUKAAN_LANGUAGE_COOKIE_NAME = `v1-${DukaanData.DUKAAN_STORE.link}-language`;
  const rawParamLang = addressQuery.get('lan');

  const updateLanguageUrl = (langVal) => {
    const url = new URL(window.location.href);
    const params = new URLSearchParams(url.search);
    params.set('lan', langVal);
    window.location.replace(
      `${
        window.location.origin + window.location.pathname
      }?${params.toString()}`
    );
  };

  if (rawParamLang !== null) {
    const paramLang =
      DukaanData.DUKAAN_STORE.store_languages.find(
        (sL) => sL.code_3 === rawParamLang
      ).code_3 || null;
    if (paramLang !== value) {
      const langVal =
        DukaanData.DUKAAN_STORE.store_languages.find(
          (sL) => sL.code_3 === value
        ).code_3 || null;

      updateLanguageUrl(langVal);
      return;
    }
  }
  document.cookie = `${DUKAAN_LANGUAGE_COOKIE_NAME}=${value}; path=/`;
  updateLanguageUrl(value);
};

window.getCookieValue = (name) =>
  document.cookie.match(`(^|;)\\s*${name}\\s*=\\s*([^;]+)`)?.pop() || '';

window.bestSellerSerializer = (data) => {
  const userLang = DukaanData.DUKAAN_LANGUAGE.DUKAAN_USER_SELECTED_LANGUAGE;
  return data.map((da) => ({
    ...da,
    ...(!da.isLanguageSerialized && {
      name: da?.languages?.[userLang]?.name || da.name,
      description: da?.languages?.[userLang]?.description || da.description,
      isLanguageSerialized: true,
    }),
    products: window.languageSerializer(da.products),
  }));
};

window.languageSerializer = (data, bagProduct = false) => {
  const dataIsArray = Array.isArray(data);
  const userLang = DukaanData.DUKAAN_USER_SELECTED_LANGUAGE;
  const rawData = dataIsArray ? [...data] : [data];
  let results = [];
  if (rawData.length === 0) return [];
  results = rawData.map((rD) => ({
    ...rD,
    ...((!rD.isLanguageSerialized || bagProduct) && {
      name: rD?.languages?.[userLang]?.name || rD.name,
      description: rD?.languages?.[userLang]?.description || rD.description,
      default_name: rD.name,
      isLanguageSerialized: true,
    }),
  }));
  return dataIsArray ? results : results[0];
};

window.String.prototype.injectText = function () {
  let formatted = this;
  // eslint-disable-next-line prefer-rest-params
  if (arguments.length && typeof arguments[0] === 'object') {
    // eslint-disable-next-line prefer-rest-params
    const vars = arguments[0];
    // eslint-disable-next-line no-restricted-syntax, guard-for-in
    for (const v in vars) {
      const regexp = new RegExp(`\\@${v}`, 'gi');
      formatted = formatted.replace(regexp, vars[v]);
    }
  }
  return formatted;
};

// ---------------------------------------------------------------------------------------------------------------------
// App utils
// ---------------------------------------------------------------------------------------------------------------------

window.APP_IDS = {
  REVIEWS_AND_RATINGS: '60f69a8a4197f652c03e4c59',
  COUNTDOWNTIMER: '60682faba1fbf915bed2e5b5',
};

window.initEventListeners = () => {
  sessionStorage.clear();
  document.addEventListener(LOCAL_STORAGE_UPDATED_EVENT_NAME, (event) => {
    const subscriberType = event.key.toLowerCase();
    if (subscriberType === PRODUCTS_STORAGE_KEY()) {
      handleProductUpdates(event);
    }
  });
  document.addEventListener(SESSION_STORAGE_UPDATED_EVENT_NAME, (event) => {
    const subscriberType = event.key.toLowerCase();

    if (subscriberType === 'active-product') {
      handleActiveProductVariantSelectionModal(event);
    }
    if (subscriberType === 'active-menu-category')
      handleMenuItemHoverChange(event);
  });

  document.addEventListener(window.DKN_PRODUCT_ADD_TO_BAG_EVENT_NAME, (e) => {
    const eventPayload = e.payload;

    // Facebook server side event starts
    const data = [
      {
        event_name: 'AddToCart',
        event_id: eventPayload.event_id,
        event_time: eventPayload.event_time,
        user_data: {
          client_ip_address: eventPayload?.user_data?.client_ip_address,
          client_user_agent: eventPayload?.user_data?.client_user_agent,
          ph: eventPayload?.user?.ph,
        },
        contents: eventPayload.items.map((item) => ({
          id: item.sku_id,
          quantity: item.quantity,
          item_price: item.selling_price,
          delivery_category: 'home_delivery',
        })),
        custom_data: {
          ...eventPayload.utm_data,
          ...eventPayload.custom_data,
          currency: eventPayload?.currency,
          value: eventPayload.items.reduce(
            (acc, item) => acc + item.selling_price * item.quantity,
            0
          ),
          content_name: eventPayload?.items?.[0].name,
          content_type: 'product',
          content_ids: eventPayload.items.map((item) => item.sku_id),
        },
        event_source_url: window.location.href,
        action_source: 'website',
        fbc: eventPayload?.cookie_data?.fbc,
        fbp: eventPayload?.cookie_data?.fbp,
      },
    ];
    const clientEventData = { ...(data[0] || {}) };
    clientEventData.user_data = {};

    if (window.fbq) {
      window?.fbq?.(
        'track',
        clientEventData.event_name,
        {
          content_name: eventPayload?.items?.[0].name,
          content_category: eventPayload?.items?.[0]?.categories?.[0],
          content_ids: eventPayload?.items?.[0]?.sku_id,
          content_type: 'product',
          value: eventPayload?.items?.[0]?.selling_price,
          currency: eventPayload?.currency,
        },
        {
          eventID: clientEventData.event_id,
        }
      );
    }

    window.sendConversionApiEvent(data);
    // Facebook server side event ends

    // GA4 Starts
    window.gtag ||= function () {
      // eslint-disable-next-line prefer-rest-params
      window.dataLayer.push(arguments);
    };

    gtag('event', 'add_to_cart', {
      currency: eventPayload?.currency,
      value: eventPayload.items.reduce(
        (acc, item) => acc + (item.selling_price || 0) * (item.quantity || 1),
        0
      ),
      items: eventPayload.items.map((item) => ({
        item_id: item.sku_id,
        item_name: item.name,
        item_brand: item.brands[0] || undefined,
        item_category: item.categories[0] || undefined,
        item_category2: item.categories[1] || undefined,
        item_category3: item.categories[2] || undefined,
        item_category4: item.categories[3] || undefined,
        item_category5: item.categories[4] || undefined,
        item_variant: item.attributes[0] || '',
        price: item.selling_price,
        quantity: item.quantity || 1,
      })),
    });
    // GA4 ends
  });

  document.addEventListener(window.DKN_PRODUCT_VIEW_CONTENT_EVENT_NAME, (e) => {
    const eventPayload = e.payload;

    // Facebook server side event starts
    const data = [
      {
        event_name: 'ViewContent',
        event_id: eventPayload.event_id,
        event_time: eventPayload.event_time,
        user_data: {
          client_ip_address: eventPayload?.user_data?.client_ip_address,
          client_user_agent: eventPayload?.user_data?.client_user_agent,
          ph: eventPayload?.user?.ph,
        },
        contents: eventPayload.items.map((item) => ({
          id: item.sku_id,
          item_price: item.selling_price,
          delivery_category: 'home_delivery',
        })),
        custom_data: {
          ...eventPayload.utm_data,
          ...eventPayload.custom_data,
          currency: eventPayload?.currency,
          content_name: eventPayload?.items?.[0].name,
          content_type: 'product',
          content_ids: eventPayload.items.map((item) => item.sku_id),
        },
        event_source_url: window.location.href,
        action_source: 'website',
        fbc: eventPayload?.cookie_data?.fbc,
        fbp: eventPayload?.cookie_data?.fbp,
      },
    ];
    const clientEventData = { ...(data[0] || {}) };
    clientEventData.user_data = {};

    if (window.fbq) {
      window?.fbq?.(
        'track',
        clientEventData.event_name,
        {
          content_name: eventPayload?.items?.[0].name,
          content_category: eventPayload?.items?.[0]?.categories?.[0],
          content_ids: eventPayload?.items?.[0]?.sku_id,
          content_type: 'product',
          value: eventPayload?.items?.[0]?.selling_price,
          currency: eventPayload?.currency,
        },
        {
          eventID: clientEventData.event_id,
        }
      );
    } else {
      window.dknCustomClientViewContentEvent = () => {
        if (!window.fbq) return;

        window?.fbq?.(
          'track',
          clientEventData.event_name,
          {
            content_name: eventPayload?.items?.[0].name,
            content_category: eventPayload?.items?.[0]?.categories?.[0],
            content_ids: eventPayload?.items?.[0]?.sku_id,
            content_type: 'product',
            value: eventPayload?.items?.[0]?.selling_price,
            currency: eventPayload?.currency,
          },
          {
            eventID: clientEventData.event_id,
          }
        );
      };
    }

    window.sendConversionApiEvent(data);
    // Facebook server side event ends

    // GA4 Starts
    window.gtag ||= function () {
      // eslint-disable-next-line prefer-rest-params
      window.dataLayer.push(arguments);
    };

    window.gtag('event', 'view_item', {
      currency: eventPayload?.currency,
      value: eventPayload.items.reduce(
        (acc, item) => acc + (item.selling_price || 0) * (item.quantity || 1),
        0
      ),
      items: eventPayload.items.map((item) => ({
        item_id: item.sku_id,
        item_name: item.name,
        item_brand: item.brands[0] || undefined,
        item_category: item.categories[0] || undefined,
        item_category2: item.categories[1] || undefined,
        item_category3: item.categories[2] || undefined,
        item_category4: item.categories[3] || undefined,
        item_category5: item.categories[4] || undefined,
        item_variant: item.attributes[0] || undefined,
        price: item.selling_price,
        quantity: item.quantity || 1,
      })),
    });
    // GA4 ends
  });
};

window.initServerSideProps = () => {
  const dataString = document.getElementById('__DUKAAN_DATA__').innerHTML;
  window.DukaanData = JSON.parse(dataString);
};

window.initEngine = () => {
  const key = `v3-${DukaanData.DUKAAN_STORE.link}-is-from-sceptre`;
  setDataToLocalStorage(key, 'true');
};

window.initBuyerSignature = () => {
  const currentBuyerSignature = getDataFromLocalStorage('__b_sig__', '');
  if (currentBuyerSignature) return;

  const generatedSignature = (Math.random() + 1).toString(36).substring(2);

  const randomHash = generateRandomString(6);
  const newBuyerSignature = `${generatedSignature}-${randomHash}`;
  setDataToLocalStorage('__b_sig__', newBuyerSignature);
};

window.initBuyerIPAddress = () => {
  const IP_INFO_TOKEN = 'fbdefc03bc7ce8';
  const { additional_meta: additionalMeta = {} } =
    DukaanData.DUKAAN_STORE || {};
  const {
    skip_ip_info: skipIPInfo,
    ipinfo_token: ipinfoToken,
    ip_api_url: ipApiUrl,
  } = additionalMeta;
  const ipAddressInfoFromLS = getDataFromLocalStorage(IP_INFO_STORAGE_KEY, '');

  if (skipIPInfo) return;

  if (!ipAddressInfoFromLS && typeof axios !== 'undefined') {
    axios
      .get(
        ipApiUrl || `https://ipinfo.io?token=${ipinfoToken || IP_INFO_TOKEN}`
      )
      .then(({ data: res = {} } = {}) => {
        if (!res.ip) return;

        const deviceBrand = getDeviceBrand();
        const deviceBrandIPHash = encodeBase64(`${deviceBrand}_${res.ip}`);
        const data = {
          ...res,
          device_brand_ip_hash: `dukaan-${deviceBrandIPHash}`,
        };

        setDataToLocalStorage(IP_INFO_STORAGE_KEY, data);
        const event = new Event('__ip_info__loaded__');
        event.payload = data;
        document.dispatchEvent(event);
      })
      .catch(() => {});
    return;
  }

  const event = new Event('__ip_info__loaded__');
  event.payload = ipAddressInfoFromLS;
  document.dispatchEvent(event);
};

window.customScriptInjector = () => {
  if (!DukaanData.IS_CUSTOM_DOMAIN) return;

  const xhr = new XMLHttpRequest();
  xhr.open(
    'GET',
    `https://apps.mydukaan.io/public/${DukaanData.DUKAAN_STORE.id}/plugins/62f203b85191ee45f1383776`
  );
  xhr.setRequestHeader('Accept', 'application/json');
  xhr.setRequestHeader('Content-Type', 'application/json');
  xhr.setRequestHeader(
    'x-requested-with',
    window?.DukaanData?.DUKAAN_SESSION_ID
  );
  xhr.onreadystatechange = function () {
    if (xhr.readyState === 4) {
      if (xhr.status === 200) {
        const result = JSON.parse(this.response);
        const finalResult = result?.result;
        finalResult.forEach((resultItem) => {
          const position = resultItem?.position;
          const script = resultItem?.script;
          const parent = document.querySelector(position);

          if (!parent || !script) return;

          if (script.includes('</script>')) {
            const scriptEl = document
              .createRange()
              .createContextualFragment(script);
            parent?.appendChild(scriptEl);
          } else {
            const elem = document.createElement('script');
            elem.innerHTML = script;
            parent?.appendChild(elem);
          }
        });
      }
    }
  };
  xhr.send();
};

window.setCouponFromQueryParams = () => {
  const paramString = new URLSearchParams(window.location.search);
  const queryCoupon = paramString.get('coupon');

  if (!queryCoupon) return;
  applyCoupon(queryCoupon);
};

window.APP_IDS = {
  ...(window.APP_IDS || {}),
  WISHLIST: '62862d034f1ca25e2256f6bb',
};

window.initAppsAndPlugins = ({ successCallback, errorCallback } = {}) => {
  if (window.APPS_API_CALL_FAILED) {
    if (errorCallback) errorCallback();
    return;
  }
  if (!window.APPS_API_CALLED) {
    const headers = {};
    if (localStorage && localStorage.al_to)
      headers.Authorization = `Bearer ${localStorage.al_to}`;
    headers['Content-Type'] = 'application/json';
    headers['x-requested-with'] = window?.DukaanData?.DUKAAN_SESSION_ID;
    fetch(
      `https://apps.mydukaan.io/public/v2/apps/store/${DukaanData.DUKAAN_STORE.id}/`,
      {
        method: 'GET',
        headers,
      }
    )
      .then((res) => res.json())
      .then((resp) => {
        const { store_apps_list: appList } = resp;
        if (!appList?.length) {
          return;
        }
        const availablePlugins = appList?.reduce((acc, item) => {
          if (item.isActive) {
            acc[item._id] = item;
          }
          return acc;
        }, {});
        window.APPS_API_CALLED = true;
        window.ACTIVE_APPS_LIST = {};

        const appIdKeys = Object.keys(window.APP_IDS);
        appIdKeys.forEach((appIdKey) => {
          window.ACTIVE_APPS_LIST[appIdKey] = !!(
            !!availablePlugins && availablePlugins[window.APP_IDS[appIdKey]]
          );
        });
      })
      .then(() => {
        if (typeof successCallback === 'function') successCallback();
      })
      .catch((err) => {
        window.APPS_API_CALL_FAILED = true;
        if (typeof errorCallback === 'function') errorCallback({ err });
      });
  } else if (typeof successCallback === 'function') successCallback();
};

const dukaanCategoryPageInitializer = () => {
  const filterCategoryParams = {
    CATEGORY_IDS: 'category_ids',
    SIZE: 'size',
    COLOR: 'color',
    PRICE_RANGES: 'price_ranges',
    PAGE_NUMBER: 'page_number',
    SORT_BY: 'sort_by',
    ATTRIBUTES_VALUE: 'sku_attrs',
    PRODUCT_ATTRS: 'product_attrs',
    QUERY: 'query',
    SHOW_PRODUCTS_HAVING_BRAND: 'show_products_having_brand',
    BRAND_IDS: 'brands',
    PAGE_TYPE: 'page_type',
  };

  if (typeof customCategoryInitializer !== 'undefined') {
    customCategoryInitializer();
  }
  if (typeof customAdvanceFiltersConfig !== 'undefined') {
    window.advanceFiltersConfig = window.customAdvanceFiltersConfig;
  }
  checkCouponSticky();
  checkStoreClosedSticky();
  const paramString = new URLSearchParams(window.location.search);
  const filtersDataFromParams = JSON.parse(paramString.get('filters')) || {};
  const selectedSortBy =
    paramString.get(filterCategoryParams.SORT_BY) ||
    window?.defaultSortByValue ||
    '';
  const selectedPage = paramString.get(filterCategoryParams.PAGE_NUMBER) || 1;
  const query = paramString.get(filterCategoryParams.QUERY) || 1;
  filtersDataFromParams[filterCategoryParams.PAGE_NUMBER] = selectedPage;
  filtersDataFromParams[filterCategoryParams.SORT_BY] = selectedSortBy;

  if (
    window?.advanceFiltersConfig?.searchTapConfig?.hasSearchTap &&
    query?.length > 0
  ) {
    return;
  }

  // if not search tap
  if (typeof getFiltersData === 'function') {
    getFiltersData({
      successCallback: () => {},
    });
  }

  if (typeof getProductCards === 'function') {
    getProductCards(filtersDataFromParams, parseInt(selectedPage, 10));
  }

  if (window.sortLabel) {
    window.sortLabel.textContent = sortButtonText(selectedSortBy);
  }
};

const dukaanPageInitializers = () => ({
  category: dukaanCategoryPageInitializer,
  search: dukaanCategoryPageInitializer,
  brand: dukaanCategoryPageInitializer,
  bundle: dukaanCategoryPageInitializer,
});

window.init = () => {
  // initLocalstorage();
  initSessionStorage();
  initServerSideProps();
  initBuyerIPAddress();
  initBuyerSignature();
  setStoreUTMCampaigns();
  setCouponFromQueryParams();

  if (typeof commonInitializer !== 'undefined') commonInitializer();
  initAppsAndPlugins({
    successCallback: () => {
      if (typeof dknInitWishlistPlugin === 'function') dknInitWishlistPlugin();
      // all the other plugin initializers can go here...
    },
  });

  const pageKey = DukaanData.DUKAAN_PAGE_KEY;
  if (pageKey && typeof dukaanPageInitializers()?.[pageKey] === 'function') {
    dukaanPageInitializers()[pageKey]();
  }
  if (typeof appInitializer !== 'undefined') appInitializer();
  customScriptInjector();
  initEventListeners();
  initEngine();
  initialProductUpdate();
  initAnalytics();
  setTimeout(() => {
    // initializeAPM();
  }, 500);
  // initLocalStorageBagLangugeSerializer();
};

window.handleRedirect = (productSlug) => {
  window.location.href += `/products/${productSlug}`;
};

window.handleCategories = () => {
  window.location.href += `/categories/`;
};

window.handleHome = () => {
  window.location.pathname = '/patankarfab';
  // console.log(window.location.pathname);
};

window.handleBack = () => {
  window.location.href = '';
};

window.onDrawerOpen = () => {
  const drawer = document.querySelector('.sidebar');
  const searchBar = document.querySelector('.mobileSearchbar');
  const header = document.querySelector('.mainHeader');
  const categoryTitle = document.querySelector('.titleSection');
  const mobileNavbar = document.querySelector('.mobileNavbar');
  const titleSection = document.querySelector('.titleSection');
  const cardWrapper = document.querySelector('.cardWrapper');

  titleSection.style.visibility = 'hidden';
  cardWrapper.style.visibility = 'hidden';
  mobileNavbar.style.visibility = 'hidden';
  header.style.visibility = 'hidden';
  categoryTitle.style.visibility = 'hidden';
  searchBar.style.position = 'static';

  drawer.style.position = 'fixed';
  drawer.style.zindex = 1000000;
  drawer.style.top = 0;
  drawer.style.left = 0;
  drawer.style.right = 0;
  drawer.style.bottom = 0;
  drawer.style.padding = '24px 26px';
  drawer.style.display = 'flex';
  drawer.style.flexDirection = 'column';
  drawer.style.backgroundColor = 'white';
};

window.onDrawerClose = () => {
  const drawer = document.querySelector('.navLinks');
  drawer.style.display = 'none';
};

// NEWSLETTER JS CODE
// Add "newsletter-input" ID to you form element
// Add "newsletter-status" ID to your request status element
// Add "onclick=subscribeToNewsletter()" to the buttons submitting the form

window.isEmailValid = (email) => {
  filter =
    /^(([^<>()[\]\\.,;:\s@"]+(\.[^<>()[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
  return filter.test(email);
};

window.subscribeToNewsletter = () => {
  const inputElem = document.getElementById('newsletter-input');
  const inputEmail = inputElem.value;
  if (isEmailValid(inputEmail)) {
    subscribeToMailchimp(inputEmail);
  } else {
    const statusElem = document.getElementById('newsletter-status');
    statusElem.classList.remove('hidden');
    statusElem.classList.remove('success');
    statusElem.classList.add('error');
    statusElem.innerHTML = `${DukaanData.DUKAAN_LANGUAGE.PLEASE_ENTER_A_VALID_EMAIL_ID}.`;
  }
};

window.subscribeToMailchimp = (inputEmail) => {
  const storeID = DukaanData.DUKAAN_STORE.id;
  const statusElem = document.getElementById('newsletter-status');
  const url = 'https://mailchimp.apps.mydukaan.io/api/subscribe';
  statusElem.classList.remove('hidden');
  const xhr = new XMLHttpRequest();
  xhr.open('POST', url);
  xhr.setRequestHeader('Accept', 'application/json');
  xhr.setRequestHeader('Content-Type', 'application/json');
  xhr.setRequestHeader(
    'x-requested-with',
    window?.DukaanData?.DUKAAN_SESSION_ID
  );
  xhr.onreadystatechange = function () {
    if (xhr.readyState === 4) {
      // eslint-disable-next-line eqeqeq
      if (xhr.status == 200) {
        statusElem.classList.add('success');
        statusElem.classList.remove('error');
        statusElem.innerHTML = `${DukaanData.DUKAAN_LANGUAGE.SUCCESSFULLY_SUBSCRIBED_WITH__EMAIL.injectText(
          {
            email: inputEmail,
          }
        )}`;
        // eslint-disable-next-line eqeqeq
      } else if (xhr.status == 400) {
        const res = JSON.parse(xhr.responseText);
        if (res?.msg?.includes('already subscribed.')) {
          statusElem.classList.add('success');
          statusElem.classList.remove('error');
          statusElem.innerHTML = `${
            DukaanData.DUKAAN_LANGUAGE?.ALREADY_SUBSCRIBED_WITH__EMAIL?.injectText(
              {
                email: inputEmail,
              }
            ) || 'Already subscribed'
          }`;
        }
      } else {
        statusElem.classList.remove('success');
        statusElem.classList.add('error');
        statusElem.innerHTML = `${DukaanData.DUKAAN_LANGUAGE.WE_COULD_NOT_PROCESS_YOUR_REQUEST_PLEASE_TRY_AGAIN}.`;
      }
    }
  };
  const data = `{"store_id":${storeID},"email": "${inputEmail}"}`;
  xhr.send(data);
};

// // Init sentry
// var l = function() {
//   var s = document.createElement('script');
//   s.type = 'text/javascript';
//   s.async = true;
//   s.src = 'https://sentry.mydukaan.io/js-sdk-loader/b83344075c0b4d0b8d52bd7b19f297dc.min.js';
//   s.crossOrigin = 'anonymous'
//   var x = document.getElementsByTagName('script')[0];
//   x.parentNode.insertBefore(s, x);
// };
// if (window.attachEvent) {
//   window.attachEvent('onload', l);
// } else {
//   window.addEventListener('load', l, false);
// }
// // end sentry
//
// // Init clarity
// (function(c,l,a,r,i,t,y){
//   c[a]=c[a]||function(){(c[a].q=c[a].q||[]).push(arguments)};
//   t=l.createElement(r);t.async=1;t.src="https://www.clarity.ms/tag/"+i;
//   y=l.getElementsByTagName(r)[0];y.parentNode.insertBefore(t,y);
// })(window, document, "clarity", "script", "c84cmyvqhz");
// // End clarity

if (window.attachEvent) {
  window.attachEvent('onDOMContentLoaded', init);
} else {
  window.addEventListener('DOMContentLoaded', init, false);
}

window.MENU_ITEM_TYPES = {
  PRODUCT: 'product',
  STORE_PAGE: 'storepage',
  CATEGORY: 'productcategory',
  ACCOUNT: 'account',
  CUSTOM_LINK: 'url',
  HOME_PAGE: 'home',
  CATEGORIES_PAGE: 'categories',
  BLOG: 'blog',
};

window.getMenuTarget = (item) => {
  if (item?.url === 'https://#' || item?.url === '#' || !item?.url) {
    return '';
  }
  switch (item.content_type) {
    case MENU_ITEM_TYPES.CUSTOM_LINK:
      return '_blank';
    default:
      return '';
  }
};

window.getMenuItemUrl = (item, storeLink) => {
  if (item?.url === 'https://#' || item?.url === '#') {
    return '#';
  }
  switch (item.content_type) {
    case MENU_ITEM_TYPES.HOME_PAGE:
      return storeLink;
    case MENU_ITEM_TYPES.CATEGORIES_PAGE:
      return categoriesURL(storeLink);
    case MENU_ITEM_TYPES.CATEGORY:
      return categoryURL(storeLink, item.content_object.slug);
    case MENU_ITEM_TYPES.PRODUCT:
      return productURL(storeLink, item.content_object.slug);
    case MENU_ITEM_TYPES.STORE_PAGE:
      return storePageURL(storeLink, item.content_object.slug);
    case MENU_ITEM_TYPES.CUSTOM_LINK:
      return item?.url || '#';
    case MENU_ITEM_TYPES.BLOG:
      return `/${storeLink}/blog`;
    default:
      return '';
  }
};

window.productURL = (storeLink, slug) => {
  if (storeLink.includes('.')) {
    return `/products/${slug}`;
  }
  return `/${storeLink}/products/${slug}`;
};

window.categoriesURL = (storeLink) => {
  if (storeLink.includes('.')) {
    return `/categories`;
  }
  return `/${storeLink}/categories`;
};

window.categoryURL = (storeLink, slug) => {
  if (storeLink.includes('.')) {
    return `/categories/${slug}`;
  }
  return `/${storeLink}/categories/${slug}`;
};

window.storePageURL = (storeLink, slug) => {
  if (storeLink.includes('.')) {
    return `/p/${slug}`;
  }
  return `/${storeLink}/p/${slug}`;
};

/*
 --------------------------------------------------------------------------
 general utils - refactor
 --------------------------------------------------------------------------
*/

/**
 * q$ is an object which has common functions that we use to perform various actions on the DOM for rendering/reading data
 * q$ has two types of functions for each functionality to perform actions if one or more nodes are selected
 * elem - has the value of the function called at every step
 * select - wrapper for querySelector
 * selectAll - wrapper for querySelectorAll
 * selectById - wrapper for getElementById
 * modifyInnerHTML - changes innerHTML value of element 'elem'
 * modifyInnerHTMLAll - changes innerHTML value of list of elements 'elem'
 * addClass - adds class names list to the element 'elem'
 * addClassAll - adds class names list to all nodes of 'elem' - used when selecting many nodes
 * removeClass - removes one class name from the element 'elem'
 * removeClassAll - removes one class name from all nodes of 'elem' - used when selecting many nodes
 * modifyTextContent - adds a content string to the textContent of 'elem'
 * modifyTextContentAll - adds a content string to the textContent of all nodes of 'elem' - used when selecting many nodes
 * setAttribute - sets a attribute and it's value to 'elem' after performing null checks
 * setAttributeAll - sets a attribute and it's value to all nodes of 'elem' after performing nullchecks - used when selecting many nodes
 * setDataAttribute - sets a data attribute and it's value to 'elem'
 * setDataAttributeAll - sets a data attribute and it's value to all nodes of 'elem' - used when selecting many nodes
 */

window.q$ = {
  elem: null,
  select(selector, element) {
    const mountElem = element || document;
    if (selector) this.elem = mountElem.querySelector(selector);
    return this;
  },
  selectAll(selector, element) {
    const mountElem = element || document;
    if (selector) this.elem = mountElem.querySelectorAll(selector);
    return this;
  },
  selectById(selector, element) {
    const mountElem = element || document;
    if (selector) this.elem = mountElem.getElementById(selector);
    return this;
  },
  modifyInnerHTML(content) {
    if (this.elem) {
      this.elem.innerHTML = content;
    }
    return this;
  },
  modifyInnerHTMLAll(content) {
    this.elem?.forEach((item) => {
      if (item) {
        item.innerHTML = content;
      }
    });
    return this;
  },
  addClass(...className) {
    this.elem?.classList?.add(...className);
    return this;
  },
  addClassAll(...className) {
    this.elem?.forEach((item) => item?.classList?.add(...className));
    return this;
  },
  removeClass(className) {
    this.elem?.classList?.remove(className);
    return this;
  },
  removeClassAll(className) {
    this.elem?.forEach((item) => item?.classList?.remove(className));
    return this;
  },
  modifyTextContent(content) {
    if (content && this.elem) {
      this.elem.textContent = content;
    }
    return this;
  },
  modifyTextContentAll(content) {
    if (content) {
      this.elem?.forEach((item) => {
        if (item) {
          item.textContent = content;
        }
      });
    }
    return this;
  },
  setAttribute(attrKey, attrVal) {
    if (attrKey && attrVal) {
      this.elem?.setAttribute(attrKey, attrVal);
    }
    return this;
  },
  setAttributeAll(attrKey, attrVal) {
    if (attrKey && attrVal) {
      this.elem?.forEach((item) => {
        item?.setAttribute(attrKey, attrVal);
      });
    }
    return this;
  },
  setStyleProperty(attrKey, attrVal, optional) {
    if (attrKey && attrVal) {
      this.elem?.style?.setProperty(attrKey, attrVal, optional);
    }
    return this;
  },
  setStylePropertyAll(attrKey, attrVal, optional) {
    if (attrKey && attrVal) {
      this.elem?.forEach((item) => {
        item?.style?.setProperty(attrKey, attrVal, optional);
      });
    }
    return this;
  },
  removeAttribute(attribute) {
    if (this?.elem && attribute) {
      this?.elem.removeAttribute(attribute);
    }
    return this;
  },
  removeAttributeAll(attribute) {
    if (attribute) {
      this.elem?.forEach((item) => {
        item?.removeAttribute(attribute);
      });
    }
    return this;
  },
  setDataAttribute(attrKey, attrVal) {
    if (attrKey && attrVal) {
      if (this.elem) {
        this.elem.dataset[attrKey] = attrVal;
      }
    }
    return this;
  },
  setDataAttributeAll(attrKey, attrVal) {
    if (attrKey && attrVal) {
      this.elem?.forEach((item) => {
        if (item) {
          item.dataset[attrKey] = attrVal;
        }
      });
    }
    return this;
  },
  getTemplateContent() {
    if (this.elem) {
      this.elem = document.importNode(this.elem.content, true);
    }
    return this;
  },
};

window.getProductPageUrl = (product) => {
  const { slug, metafields = [] } = product;
  const permalink = metafields?.find(
    (field) => field.key === 'product_permalink'
  )?.value_str;
  if (permalink && window?.storeConfig?.hasPermalinkBasedProductPageRoutes) {
    if (permalink?.includes('http') || permalink?.includes('https'))
      return permalink;
    return `${DukaanData.DUKAAN_BASE_URL}${permalink}`;
  }
  if (slug) return `${DukaanData.DUKAAN_BASE_URL}/products/${slug}`;
  return '#';
};

window.getBundlePageUrl = ({ slug }) => {
  if (slug) return `${DukaanData.DUKAAN_BASE_URL}/bundles/${slug}`;
  return '#';
};

window.getDiscountPercentValue = (sellingPrice, originalPrice) => {
  let discount = originalPrice - sellingPrice;
  if (discount > 0) {
    discount = ((originalPrice - sellingPrice) / originalPrice) * 100;
    discount = Math.round(discount);
  }
  return discount;
};

window.handleStartProductCarousel = (
  productCardCarouselWrapper,
  productCardCarousel
) => {
  const productCardProgressBar = window.q$.select(
    '.dkn-product-card-image-carousel-progress-bar',
    productCardCarouselWrapper
  ).elem;
  if (productCardProgressBar) {
    const slideLength = productCardCarousel.Components.Slides.getLength();
    productCardProgressBar.style['-webkit-animation-duration'] = `${
      1500 * slideLength
    }ms`;
    productCardProgressBar.classList.remove('hidden');
    productCardProgressBar.classList.add('splide-progress-bar-animation');
  }

  productCardCarousel.Components.Autoplay.play();
};

window.handleStopProductCarousel = (
  productCardCarouselWrapper,
  productCardCarousel
) => {
  const productCardProgressBar = window.q$.select(
    '.dkn-product-card-image-carousel-progress-bar',
    productCardCarouselWrapper
  ).elem;

  if (productCardProgressBar) {
    productCardProgressBar.style['-webkit-animation-duration'] = '0';
    productCardProgressBar.classList.add('hidden');
    productCardProgressBar.classList.remove('splide-progress-bar-animation');
  }

  productCardCarousel.go(0);
  productCardCarousel.Components.Autoplay.pause();
};

window.productCardImageCarouselRenderer = (
  product,
  productCard,
  imageSlideTemplateId = 'dkn-product-card-image-slide-template'
) => {
  const { all_images: productImagesArray } = product;
  const imageListContainer = window.q$.select(
    '.dkn-product-card-image-carousel',
    productCard
  ).elem;
  const productCardCarouselWrapper = window.q$.select(
    '#dkn-product-card-image-carousel-wrapper',
    productCard
  ).elem;

  if (imageListContainer && productImagesArray?.length > 1) {
    // render image carousel
    productImagesArray?.forEach((image) => {
      const imageSlideContainer = window.q$
        .selectById(imageSlideTemplateId)
        .getTemplateContent().elem;
      window.q$
        .select('.dkn-product-card-image-carousel-item', imageSlideContainer)
        .setAttribute(
          'src',
          `${window.getCdnUrl(
            image,
            window?.DukaanData?.PRODUCT_IMAGE_CDN_SIZE || 700
          )}`
        );
      imageListContainer.appendChild(imageSlideContainer);
    });

    // render progress bar
    const productCardProgressBar = window.q$.select(
      '.dkn-product-card-image-carousel-progress-bar',
      productCard
    ).elem;

    productCardProgressBar.style['-webkit-animation-duration'] = `${
      1500 * Number(productImagesArray?.length || 1)
    }ms`;

    // initialize splide
    const productCardCarousel = new Splide(productCardCarouselWrapper, {
      type: 'slide',
      autoplay: false,
      interval: 1500,
      arrows: false,
      pauseOnHover: false,
      pagination: false,
      rewind: true,
    }).mount();

    // add event listeners for mouse enter and remove
    productCardCarouselWrapper.addEventListener('mouseenter', () => {
      handleStartProductCarousel(
        productCardCarouselWrapper,
        productCardCarousel
      );
    });
    productCardCarouselWrapper.addEventListener('mouseleave', () => {
      handleStopProductCarousel(
        productCardCarouselWrapper,
        productCardCarousel
      );
    });

    window.q$
      .select('.dkn-product-card-only-image-wrapper', productCard)
      .addClass('hidden');
  } else {
    window.q$
      .select('.dkn-product-card-image-carousel-wrapper', productCard)
      .addClass('hidden');
  }
};

window.productRatingsAndReviewsInfoRenderer = (
  ratingsData,
  mountElem,
  options = {
    reviewInfoTemplateId: 'dkn-product-card-review-template',
  }
) => {
  const reviewInfoElem = mountElem;
  const { reviewInfoTemplateId, linkToReviewsPlugin = null } = options;
  let { starHeight: height, starWidth: width } = options;

  if (typeof options?.beforeRenderingReviewsFn === 'function') {
    options.beforeRenderingReviewsFn(mountElem, ratingsData);
  }

  const element = window.q$
    .selectById(reviewInfoTemplateId)
    .getTemplateContent().elem;

  const reviewSvgWrapperElem = window.q$.select(
    '.dkn-product-card-review-svg-wrapper',
    element
  ).elem;

  const { rating_average: avgRating = 0, total_count: totalRatingCount = 0 } =
    ratingsData || {};

  if (!avgRating) return;

  mountElem.classList.remove('d-none');
  const singleStar = (props) => {
    const {
      width,
      height,
      fill,
      customClass = 'not-overlapped',
      isFilled = true,
      viewBoxWidth = 24,
    } = props;
    if (isFilled) {
      return `
        <svg
        class="${customClass}"
        width="${width}"
        height="${height}"
        viewBox="0 0 ${viewBoxWidth} 24"
          fill="none"
          xmlns="http://www.w3.org/2000/svg"
        >
          <path
            d="M22.4276 9.48777C22.3337 9.19025 22.1528 8.92825 21.9086 8.73612C21.6643 8.54399 21.3681 8.4307 21.0588 8.4111L15.4901 8.02388L13.4276 2.78221C13.315 2.49359 13.1189 2.24567 12.8649 2.07056C12.6108 1.89544 12.3104 1.80118 12.0026 1.79999V1.79999C11.6948 1.80118 11.3944 1.89544 11.1403 2.07056C10.8862 2.24567 10.6902 2.49359 10.5776 2.78221L8.4776 8.05221L2.94635 8.4111C2.63745 8.43197 2.34187 8.54573 2.09785 8.73768C1.85383 8.92963 1.6726 9.19092 1.5776 9.48777C1.48004 9.78916 1.47434 10.1131 1.56123 10.4178C1.64812 10.7225 1.82362 10.9939 2.0651 11.1972L6.32135 14.8239L5.05572 19.8389C4.96816 20.1781 4.98392 20.5361 5.10095 20.8662C5.21798 21.1963 5.43088 21.4834 5.71197 21.69C5.98481 21.8873 6.30988 21.998 6.64557 22.0081C6.98126 22.0182 7.31231 21.9272 7.59635 21.7467L11.9932 18.9417H12.012L16.7463 21.9544C16.9892 22.1134 17.2723 22.1987 17.562 22.2C17.7985 22.1981 18.0314 22.1416 18.2428 22.0349C18.4542 21.9282 18.6386 21.774 18.7816 21.5843C18.9247 21.3946 19.0226 21.1744 19.068 20.9406C19.1133 20.7067 19.1049 20.4656 19.0432 20.2355L17.7026 14.7483L21.9401 11.1972C22.1816 10.9939 22.3571 10.7225 22.444 10.4178C22.5309 10.1131 22.5252 9.78916 22.4276 9.48777Z"
            fill="${fill}"
          />
        </svg>
      `;
    }
    return `<svg
      class="${customClass}"
      width="${width}"
      height="${height}"
        viewBox="0 0 24 24"
        fill="none"
        xmlns="http://www.w3.org/2000/svg"
      >
        <path
          d="M21.8025 9.68329L21.8025 9.6833L21.804 9.68789C21.8618 9.8666 21.8652 10.0588 21.8137 10.2396C21.7623 10.4199 21.6587 10.5799 21.5172 10.6993C21.5169 10.6995 21.5167 10.6998 21.5164 10.7L17.281 14.2502L16.9712 14.5099L17.0672 14.9026L18.4074 20.3898L18.4092 20.3968L18.411 20.4038C18.4471 20.5385 18.4521 20.6798 18.4255 20.8168C18.399 20.9538 18.3416 21.0825 18.2583 21.193C18.175 21.3036 18.0679 21.393 17.9457 21.4547C17.8247 21.5158 17.6918 21.5483 17.5569 21.55C17.3946 21.5485 17.2356 21.5003 17.0987 21.4106L17.0987 21.4106L17.0916 21.4061L12.3584 18.3933L12.1987 18.2917H12.0094H11.9906H11.8009L11.641 18.3937L7.24612 21.1981C7.24608 21.1981 7.24605 21.1982 7.24602 21.1982C7.07167 21.309 6.86899 21.3646 6.66384 21.3584C6.45948 21.3523 6.26109 21.2851 6.09388 21.1648C5.91919 21.0357 5.78614 20.8562 5.71272 20.6491C5.63898 20.441 5.62902 20.2152 5.68424 20.0013L5.68509 19.9979L6.9504 14.9829L7.04923 14.5912L6.74178 14.3292L2.48659 10.7025L2.48659 10.7025L2.48361 10.7C2.34166 10.5805 2.23782 10.4202 2.18631 10.2396C2.13478 10.0588 2.13817 9.8666 2.19601 9.68789L2.19666 9.68584C2.25226 9.51206 2.35809 9.35988 2.49963 9.24852C2.6409 9.13736 2.81139 9.07183 2.98904 9.05967C2.9893 9.05966 2.98955 9.05964 2.98981 9.05962L8.51797 8.70085L8.92774 8.67425L9.07972 8.29277L11.1792 3.02277L11.1792 3.02278L11.1809 3.01844C11.2465 2.85033 11.3603 2.70674 11.5069 2.6057C11.6527 2.50518 11.8244 2.45118 12 2.45C12.1756 2.45118 12.3473 2.50518 12.4931 2.6057C12.6397 2.70674 12.7535 2.85033 12.8191 3.01844L12.8198 3.02016L14.8818 8.26183L15.032 8.64383L15.4415 8.67231L21.0089 9.05954L21.0129 9.0598C21.1902 9.07104 21.3606 9.13603 21.5016 9.24695C21.6426 9.35793 21.7478 9.50986 21.8025 9.68329Z"
          stroke="${fill}"
          stroke-width="1.3"
        />
      </svg>`;
  };

  if (reviewSvgWrapperElem) {
    const { isMobile } = deviceType();
    if (!height) {
      height = isMobile ? 10 : 16;
    }
    if (!width) {
      width = isMobile ? 10 : 16;
    }
    const svgFillColor =
      getComputedStyle(document.documentElement).getPropertyValue(
        '--rating-star-filled-color'
      ) || '#FAB73B';
    const fullStarValue = Math.floor(avgRating);
    const halfStarValue = avgRating - fullStarValue;
    let starsHTML = '';

    for (let i = 0; i < 5; i += 1) {
      if (i < fullStarValue) {
        starsHTML += `
          <div class="rating-svg-wrapper">
            ${singleStar({
              fill: svgFillColor,
              width,
              height,
            })}
          </div>`;
      } else if (fullStarValue !== 0 && i === fullStarValue) {
        starsHTML += `
          <div class="rating-svg-wrapper">
            <div class="overlapped">
              ${singleStar({
                fill: svgFillColor,
                width,
                height,
                isFilled: false,
              })}
              ${singleStar({
                fill: svgFillColor,
                width: Math.floor(width * halfStarValue),
                height,
                customClass: 'overlapped',
                isFilled: true,
                viewBoxWidth: Math.floor(24 * halfStarValue),
              })}
            </div>
          </div>
        `;
      } else {
        starsHTML += `
          <div class="rating-svg-wrapper">
            ${singleStar({
              fill: svgFillColor,
              width,
              height,
              isFilled: false,
            })}
          </div>
        `;
      }
    }
    reviewSvgWrapperElem.innerHTML = starsHTML;
  }

  const reviewRatingTextElem = window.q$.select(
    '.dkn-product-card-review-rating-text',
    element
  ).elem;

  if (reviewRatingTextElem) {
    reviewRatingTextElem.textContent = Number(avgRating.toFixed(1));
  }

  const reviewCountTextElem = window.q$.select(
    '.dkn-product-card-review-count-text',
    element
  ).elem;
  if (reviewCountTextElem) {
    if (typeof options.getCustomReviewsCountText !== 'undefined') {
      reviewCountTextElem.textContent =
        options.getCustomReviewsCountText(totalRatingCount);
    } else {
      reviewCountTextElem.textContent = totalRatingCount;
    }

    if (linkToReviewsPlugin) {
      reviewCountTextElem.setAttribute('href', linkToReviewsPlugin);
    }
  }
  reviewInfoElem.appendChild(element);
};

window.closeProductVariantModal = () => {
  setDataToSessionStorage('active-product', '');
  setDataToSessionStorage('active-add-event-name', '');
};

window.closeMobileModal = (modalElementId = 'offcanvasLeftMenu') => {
  const offcanvasLeftMenuElem = window.q$.selectById(modalElementId).elem;
  if (!offcanvasLeftMenuElem) return;
  const modal = window.Offcanvas.getOrCreateInstance(offcanvasLeftMenuElem);
  modal.toggle();
};

window.stopEventPropagation = (event) => {
  event.stopPropagation();
};

window.dknGetLeastPriceSKU = (skus) => {
  if (!skus) return null;
  const sortedSKUSBasedOnSellingPrice = [...skus]?.sort(
    (a, b) => a.selling_price - b.selling_price
  );
  return sortedSKUSBasedOnSellingPrice[0];
};
/*
 --------------------------------------------------------------------------
 Product Renderer Utils
 --------------------------------------------------------------------------
*/

/**
 * rendering data targetting class names having the prefix 'dkn-product-card'
 * mountElem - the product list wrapper element where the product cards need to be appended
 * product - product details object
 * options - an object for customizing existing renderer
 * options.templateId - id of the template that will be picked from the dom
 * options.additionalRenderer(productCard, product, options) - callback func to override/add new functionalities to the card
 * options.getCustomDiscountText(discount) - callback func to override how discount value will look - expected to a string
 * options.getCustomOriginalPriceText(originalPrice) - callback to override the text of original price - returns string
 */

window.setProductCardImageFromSku = (skus, allImages, image) => {
  const activeSKU = dknGetFirstAvailableSKU(skus, true);
  const activeSKUImage = activeSKU?.primary_image;

  const finalImage =
    activeSKUImage && !activeSKUImage?.includes('category-def.jpg')
      ? activeSKUImage
      : allImages[0] || image;

  return finalImage;
};

window.productCardRenderer = (
  mountElem,
  product,
  options = {
    templateId: 'dkn-product-card-template',
  }
) => {
  const { templateId, productCardClasses = [] } = options;
  const {
    id,
    uuid,
    name,
    slug,
    image,
    selling_price: productSellingPrice,
    original_price: productOriginalPrice,
    all_images: allImages,
    description,
    meta,
    unit,
    base_qty: baseQty,
    skus,
  } = product;

  const foodTypeIcon = window.getFoodTypeIcon(meta);
  const isRestaurant =
    window.DukaanData?.DUKAAN_STORE?.store_category === 6 || false;

  const isTWT = window.DukaanData?.DUKAAN_STORE?.id === window.twt_store_id;

  const finalImage = isTWT
    ? setProductCardImageFromSku(skus, allImages, image)
    : allImages[0] || image;
  // const { selling_price: skuSellingPrice, original_price: skuOriginalPrice } =
  //   activeSKU || {};

  const sellingPrice = productSellingPrice;
  const originalPrice = productOriginalPrice;

  const discountType = product?.product_attributes?.find((attribute) => {
    return attribute.key === 'Discounting Type';
  });

  const discountPercent = window.getDiscountPercentValue(
    sellingPrice,
    originalPrice
  );

  const discountPrice = originalPrice - sellingPrice;

  // importing template of product card
  const productCard = window.q$
    .selectById(templateId)
    .getTemplateContent().elem;

  if (productCardClasses?.length) {
    window.q$
      .select('.dkn-product-card', productCard)
      .addClass(...productCardClasses);
  }

  const randomHashForProductCard = generateRandomString(10);

  // adding relevant data attributes
  window.q$
    .selectAll('[data-product-uuid]', productCard)
    .setDataAttributeAll('productUuid', uuid);
  window.q$
    .selectAll('[data-product-id]', productCard)
    .setDataAttributeAll('productId', id);

  // adding relevant data to all elements of product card
  if (!isRestaurant) {
    window.q$
      .selectAll('a', productCard)
      .setAttributeAll('href', window.getProductPageUrl(product));
  } else {
    window.q$.selectAll('a', productCard).removeAttributeAll('href');
    window.q$.selectAll('a', productCard).addClassAll('no-underline');
  }

  const dknOfferCard = window.q$.selectAll(
    '.dkn-product-card-offer',
    productCard
  );

  if (dknOfferCard) {
    const hasOffer = product.metafields?.find((metafield) => {
      return metafield.key === 'get_extra_off_text';
    });

    if (hasOffer) {
      if (window?.DukaanData?.DUKAAN_PAGE_KEY === 'search') {
        dknOfferCard
          ?.removeClassAll('hidden')
          .modifyTextContentAll(hasOffer.value);
      } else {
        dknOfferCard
          ?.removeClassAll('hidden')
          .modifyTextContentAll(hasOffer.value?.val?.[0]);
      }
    }
  }

  window.q$
    .selectAll('.dkn-product-card-name', productCard)
    .modifyTextContentAll(name);

  if (DukaanData.DUKAAN_CATEGORY?.name === 'CLEAN PROTEIN ADDA') {
    const primaryColor = product.metafields?.find((metafield) => {
      return metafield.key === 'primary_color';
    });

    const color = primaryColor?.value?.val?.[0] || '#6F1D46';

    window.q$
      .select('.dkn-product-card-name', productCard)
      .setStyleProperty('color', color);

    window.q$
      .select('.product-pack', productCard)
      .setStyleProperty('color', color);

    window.q$
      .select('.dkn-product-card-price-label', productCard)
      .setStyleProperty('color', color);

    window.q$
      .select('.image-wrapper', productCard)
      .setStyleProperty('border', `1px solid ${color}`);

    window.q$
      .select('.add-btn', productCard)
      .setStyleProperty('background', color);
  }

  if (product?.skus?.[0]?.inventory) {
    window.q$
      .selectAll('.dkn-product-inventory', productCard)
      .removeClass('hidden')
      .modifyTextContentAll(`${product.skus[0].inventory} Left In Stock`);
  }

  window.q$
    .selectAll('.dkn-product-card-image', productCard)
    .setAttributeAll('data-hash', randomHashForProductCard);
  window.q$
    .select('.dkn-product-card', productCard)
    .setAttribute('data-hash', randomHashForProductCard);

  if (!window?.storeConfig?.makeProductCardImageSizeDynamic) {
    window.q$
      .selectAll('.dkn-product-card-image', productCard)
      .setAttributeAll(
        'src',
        getCdnUrl(finalImage, window?.DukaanData?.PRODUCT_IMAGE_CDN_SIZE || 700)
      );
  }

  window.q$
    .selectAll('.dkn-product-card-image', productCard)
    .setAttributeAll('onerror', 'imageOnError(event)');

  if (description) {
    const santizedDescription = HtmlSanitizer?.SanitizeHtml(description);
    if (santizedDescription) {
      window.q$
        .selectAll('.dkn-product-card-description', productCard)
        .modifyInnerHTMLAll(santizedDescription);
    }
  } else {
    window.q$
      .selectAll('.dkn-product-card-description', productCard)
      .addClassAll('hidden');
  }

  if (foodTypeIcon) {
    window.q$
      .selectAll('.dkn-product-card-food-type-icon', productCard)
      .modifyInnerHTMLAll(window.getFoodTypeIcon(meta));
    window.q$
      .selectAll('.dkn-product-card-food-type-icon', productCard)
      .removeClassAll('hidden');
  } else {
    window.q$
      .selectAll('.dkn-product-card-food-type-icon', productCard)
      .addClassAll('hidden');
  }

  if (unit) {
    const unitText = `${DukaanData.DUKAAN_LANGUAGE.PER}${
      baseQty === 1 ? '' : ` ${baseQty}`
    } ${unit}`;
    window.q$
      .selectAll('.dkn-product-card-item-unit', productCard)
      .modifyTextContentAll(unitText);
  } else {
    window.q$
      .selectAll('.dkn-product-card-item-unit', productCard)
      .addClassAll('hidden');
  }

  // pricing related rendering
  let sellingPriceText = '';
  if (options.getCustomSellingPriceText) {
    sellingPriceText = options.getCustomSellingPriceText(sellingPrice);
  } else {
    sellingPriceText = window.formatMoney(sellingPrice);
  }
  window.q$
    .selectAll('.dkn-product-card-selling-price', productCard)
    .modifyTextContentAll(sellingPriceText);
  if (discountPercent > 0) {
    let originalPriceText = '';
    if (options.getCustomOriginalPriceText) {
      originalPriceText = options.getCustomOriginalPriceText(originalPrice);
    } else {
      originalPriceText = window.formatMoney(originalPrice);
    }
    window.q$
      .selectAll('.dkn-product-card-original-price', productCard)
      .modifyTextContentAll(originalPriceText);

    let discountText = '';
    if (discountType && discountType.value.val[0] === 'Absolute value') {
      discountText = `(${formatMoney(discountPrice)} OFF)`;
    } else if (options.getCustomDiscountText) {
      discountText = options.getCustomDiscountText(discountPercent);
    } else {
      discountText = `${discountPercent}% OFF`;
    }
    window.q$
      .selectAll('.dkn-product-card-discount', productCard)
      .modifyTextContentAll(discountText);
  } else {
    window.q$
      .selectAll('.dkn-product-card-original-price', productCard)
      .addClassAll('hidden');
    window.q$
      .selectAll('.dkn-product-card-discount', productCard)
      .addClassAll('hidden');
  }
  const showAddToBagButton =
    window.DukaanData?.DUKAAN_THEME_DATA?.meta?.advanced?.product
      ?.showAddToBagOnProductCard;

  const addToBagElements = window.q$.selectAll(
    'add-to-bag-button-with-variants', // need to rename this to dkn format later
    productCard
  ).elem;

  if (options?.addToBagEventName) {
    window.q$
      .selectAll('add-to-bag-button-with-variants', productCard)
      .setAttributeAll('data-add-event', options?.addToBagEventName);
    window.q$
      .selectAll('add-to-bag-button', productCard)
      .setAttributeAll('data-add-event', options?.addToBagEventName);
    window.q$
      .selectAll('add-to-bag-button-with-external-quantity-input', productCard)
      .setAttributeAll('data-add-event', options?.addToBagEventName);
  }

  if (addToBagElements) {
    if (
      (typeof showAddToBagButton !== 'undefined' && showAddToBagButton) ||
      typeof showAddToBagButton === 'undefined'
    ) {
      addToBagElements.forEach((addToBagElement) => {
        addToBagButtonWithVariantsRenderer(addToBagElement);
      });
    } else {
      addToBagElements.forEach((addToBagElement) => {
        addToBagElement.classList.add('hidden');
      });
    }
  }

  // brands related rendering
  if (product?.brands) {
    const brand = product.brands?.[0];

    // brand logo
    if (brand?.logo) {
      window.q$
        .selectAll('.dkn-product-card-brand-image', productCard)
        .setAttributeAll('src', window.getCdnUrl(brand.logo, 100));
    } else {
      window.q$
        .selectAll('.dkn-product-card-brand-image', productCard)
        .setAttributeAll('onerror', 'window.imageOnError(event)');
    }

    // brand name
    if (brand?.name) {
      window.q$
        .selectAll('.dkn-product-card-brand-name', productCard)
        .modifyTextContentAll(brand.name);
    } else {
      window.q$
        .selectAll('.dkn-product-card-brand-name', productCard)
        .addClassAll('hidden');
    }
  } else {
    window.q$
      .selectAll('.dkn-product-card-brand-details', productCard)
      .addClassAll('hidden');
  }

  // calling custom renderer if it exists
  if (
    options.additionalRenderer &&
    !window?.storeConfig?.makeProductCardImageSizeDynamic
  ) {
    options.additionalRenderer(productCard, product, options);
  }

  // productCardImageCarouselRenderer(product, productCard);
  mountElem.appendChild(productCard);

  if (
    window?.storeConfig?.makeProductCardImageSizeDynamic &&
    typeof getCustomProductCardImageUrl === 'function'
  ) {
    const productCardImages = mountElem.querySelectorAll(
      `img[data-hash="${randomHashForProductCard}"]`
    );
    productCardImages.forEach((productCardImage) => {
      const imageUrl = window.getCustomProductCardImageUrl(finalImage, {
        imageElement: productCardImage,
      });
      productCardImage.setAttribute('src', imageUrl);
    });

    // calling custom renderer if it exists
    if (options.additionalRenderer) {
      options.additionalRenderer(
        q$.select(`.dkn-product-card[data-hash="${randomHashForProductCard}"]`)
          .elem,
        product,
        options
      );
    }
  }
};

window.fetchRatingsDataFromProductIds = (productIds, mountElem, options) => {
  if (!productIds?.length) return;
  fetch(
    `${window.DukaanData.CLIENT_API_ENDPOINT}/api/product/buyer/product/review-stats/`,
    {
      method: 'post',
      body: JSON.stringify({ product_ids: productIds }),
      headers: {
        'Content-Type': 'application/json',
        'x-requested-with': window?.DukaanData?.DUKAAN_SESSION_ID,
      },
    }
  )
    .then((res) => res.json())
    .then((res) => {
      const { data: ratingsData } = res || [];
      ratingsData?.forEach((ratingData) => {
        const productId = ratingData.product_id;
        const parentElem = window.q$.select(
          `.dkn-product-card-review-info[data-product-id='${productId}']`,
          mountElem
        ).elem;
        // parentElem.innerHTML = null;
        window.productRatingsAndReviewsInfoRenderer(
          ratingData,
          parentElem,
          options
        );
      });
    })
    .catch(() => {});
};

window.productListRenderer = (mountElem, products, config) => {
  const {
    initialRendering = true,
    reviewInfoTemplateId = 'dkn-product-review-with-count-template',
  } = config || {};

  if (initialRendering) {
    mountElem.innerHTML = '';
  }

  products = window.languageSerializer(products);
  products.forEach((product) => {
    window.productCardRenderer(mountElem, product, config);
  });
  const productIds = products.map((product) => product.id);
  window.fetchProductCoupons(productIds);
  window.fetchRatingsDataFromProductIds(productIds, mountElem, {
    reviewInfoTemplateId,
    getCustomReviewsCountText: window.getCustomReviewsCountText,
    starHeight: window.productCardStarHeight,
    starWidth: window.productCardStarWidth,
  });

  if (typeof dknRenderWishlistButtons !== 'undefined') {
    window.dknRenderWishlistButtons(mountElem);
  }

  if (typeof dknRenderNotifyMeButtons !== 'undefined') {
    window.dknRenderNotifyMeButtons(mountElem);
  }
};

window.productListRendererWithSplide = (mountElem, products, config) => {
  mountElem.innerHTML = '';

  products.forEach((product) => {
    window.productCardRenderer(mountElem, product, config);
  });

  const productIds = products.map((product) => product.id);
  window.fetchProductCoupons(productIds);
  window.fetchRatingsDataFromProductIds(productIds, mountElem);

  if (typeof dknRenderWishlistButtons !== 'undefined') {
    window.dknRenderWishlistButtons(mountElem);
  }

  if (typeof dknRenderNotifyMeButtons !== 'undefined') {
    window.dknRenderNotifyMeButtons(mountElem);
  }
};

window.getProductIdsFromCategories = (categories = []) => {
  if (!(!!categories.length > 0)) return [];

  const productIds = categories
    .map((category) => category?.products)
    .flat()
    .reduce((prevValue, currentValue) => [...prevValue, currentValue?.id], []);

  return productIds;
};

window.fetchProductCoupons = async (productIds = []) => {
  fetch(
    `${window.DukaanData.CLIENT_API2_ENDPOINT}/api/product/buyer/${window.DukaanData.DUKAAN_STORE.id}/bxgy-coupon-details/`,
    {
      method: 'post',
      body: JSON.stringify({
        product_ids: productIds,
      }),
      headers: {
        'Content-Type': 'application/json',
        'x-requested-with': window?.DukaanData?.DUKAAN_SESSION_ID,
      },
    }
  )
    .then((res) => res.json())
    .then((res) => {
      const { data } = res;
      const {
        bxgy_allowed_product_ids: bxgyAllowedProductIds,
        coupon_data: couponData,
      } = data;
      const bxgyHash = bxgyAllowedProductIds?.reduce((previous, current) => {
        const obj = {
          [current]: {
            ...couponData,
            name: couponData.name.toUpperCase(),
          },
        };
        return [...previous, obj];
      }, []);

      bxgyHash?.forEach((bxgyItem) => {
        const [productID] = Object.keys(bxgyItem);
        const bxgyBadge = window.q$.selectAll(
          `.dkn-product-card-bxgy-badge[data-product-id='${productID}']`
        ).elem;
        if (bxgyBadge) {
          const productUUID = bxgyBadge[0]?.dataset?.productUuid;
          let product = DukaanData.PRODUCTS_MAP[productUUID];
          if (!!product && product.in_stock) {
            if (bxgyBadge?.length > 0) {
              bxgyBadge.forEach((bB) => {
                bB.classList.remove('hidden');
                bB.textContent = bxgyItem[productID].name;
              });
            }
            product = {
              ...product,
              coupon_data: [bxgyItem[productID]],
            };

            DukaanData.PRODUCTS_MAP = {
              ...DukaanData.PRODUCTS_MAP,
              [productUUID]: product,
            };
          }
        }
      });
    })
    .catch(() => {});
};

window.bestSellerCategoryCardListRenderer = (
  mountElement,
  categories,
  spliceCount = 10,
  options = {
    templateId: 'dkn-product-card-template',
    additionalRenderer: window.productCardAdditionalRenderer,
    getCustomDiscountText: window.getCustomDiscountText,
  }
) => {
  categories.forEach((category) => {
    if (getCategoryHasProducts(category)) {
      const {
        id,
        uuid,
        name,
        product_count: productCount,
        slug,
        parent_id: parentId,
        products,
      } = category;
      const bestSellerCategoryCard = window.q$
        .selectById('dkn-bestseller-category-card-template')
        .getTemplateContent().elem;
      window.q$
        .selectAll('[data-category-id]', bestSellerCategoryCard)
        .setAttributeAll('id', id);
      window.q$
        .selectAll('[data-category-id]', bestSellerCategoryCard)
        .setAttributeAll('uuid', uuid);
      window.q$
        .selectAll('.dkn-bestseller-category-card-name', bestSellerCategoryCard)
        .modifyTextContentAll(name);
      window.q$
        .selectAll(
          '.dkn-bestseller-category-card-count',
          bestSellerCategoryCard
        )
        .modifyTextContentAll(productCount);

      if (parentId) {
        const parentCategory = getSubCategoryParentData(parentId);
        if (parentCategory) {
          window.q$
            .selectAll(
              '.dkn-bestseller-category-card-subcat-name',
              bestSellerCategoryCard
            )
            .modifyTextContentAll(`(${parentCategory.name})`);
          window.q$
            .selectAll(
              '.dkn-bestseller-category-card-subcat-link',
              bestSellerCategoryCard
            )
            .setAttributeAll(
              'href',
              getCategoryCardLink(parentCategory, DukaanData.DUKAAN_BASE_URL)
            );

          window.q$
            .selectAll(
              '.dkn-bestseller-category-card-subcat',
              bestSellerCategoryCard
            )
            .setAttributeAll('title', parentCategory.name);
        }
      }
      if (productCount > spliceCount) {
        window.q$
          .selectAll(
            '.dkn-bestseller-category-card-view-all-btn',
            bestSellerCategoryCard
          )
          .removeClassAll('d-none');
      }
      window.q$
        .selectAll('.dkn-bestseller-category-card-link', bestSellerCategoryCard)
        .setAttributeAll(
          'href',
          `${DukaanData.DUKAAN_BASE_URL}/categories/${slug}`
        );
      window.productListRenderer(
        window.q$.select('dkn-category-product-list', bestSellerCategoryCard)
          .elem,
        products.splice(0, spliceCount),
        options
      );
      mountElement.appendChild(bestSellerCategoryCard);
    }
  });
};

window.handleToggleContent = (mountElemSelector) => {
  const mountElem = window.q$.select(mountElemSelector).elem;

  const upArrow = window.q$.select('.dkn-toggle-up-icon', mountElem).elem;
  const downArrow = window.q$.select('.dkn-toggle-down-icon', mountElem).elem;
  const toggleContent = window.q$.select('.dkn-toggle-content', mountElem).elem;

  if (upArrow.classList.contains('d-none')) {
    upArrow.classList.remove('d-none');
    downArrow.classList.add('d-none');
    toggleContent.classList.remove('d-none');
  } else {
    upArrow.classList.add('d-none');
    downArrow.classList.remove('d-none');
    toggleContent.classList.add('d-none');
  }
};

window.dknGetSearchUrl = (value) =>
  `${window.DukaanData.DUKAAN_BASE_URL}/search?query=${encodeURIComponent(
    value
  )}`;

window.dknInitSlider = ({
  sliderOverflowContainer = q$.selectById('dkn-slider-overflow-container').elem,
  sliderOuterContainer = q$.selectById('dkn-slider-outer-container').elem,
  offsetValue = 100,
  hideDisabledButtons = true,
} = {}) => {
  if (!sliderOverflowContainer || !sliderOuterContainer) return;

  const sliderPrevButton = sliderOuterContainer.querySelector(
    '.dkn-slider__arrow.dkn-slider__arrow--prev'
  );
  const sliderNextButton = sliderOuterContainer.querySelector(
    '.dkn-slider__arrow.dkn-slider__arrow--next'
  );
  if (
    sliderOverflowContainer.clientWidth < sliderOverflowContainer.scrollWidth
  ) {
    sliderNextButton.classList.remove('hidden');
    sliderNextButton.classList.add('dkn-slider__arrow-active');
    sliderNextButton.classList.remove('dkn-slider__arrow-inactive');
  } else {
    if (hideDisabledButtons) {
      sliderNextButton.classList.add('hidden');
    }
    sliderNextButton.classList.remove('dkn-slider__arrow-active');
    sliderNextButton.classList.add('dkn-slider__arrow-inactive');
  }

  if (sliderOverflowContainer.scrollLeft === 0) {
    if (hideDisabledButtons) {
      sliderPrevButton.classList.add('hidden');
    }
    sliderPrevButton.classList.remove('dkn-slider__arrow-active');
    sliderPrevButton.classList.add('dkn-slider__arrow-inactive');
  } else {
    sliderPrevButton.classList.remove('hidden');
    sliderPrevButton.classList.add('dkn-slider__arrow-active');
    sliderPrevButton.classList.remove('dkn-slider__arrow-inactive');
  }

  sliderOverflowContainer.addEventListener('scroll', (e) => {
    if (sliderOverflowContainer.scrollLeft === 0) {
      if (hideDisabledButtons) {
        sliderPrevButton.classList.add('hidden');
      }
      sliderPrevButton.classList.remove('dkn-slider__arrow-active');
      sliderPrevButton.classList.add('dkn-slider__arrow-inactive');
    } else {
      sliderPrevButton.classList.remove('hidden');
      sliderPrevButton.classList.add('dkn-slider__arrow-active');
      sliderPrevButton.classList.remove('dkn-slider__arrow-inactive');
    }

    if (
      sliderOverflowContainer.clientWidth + sliderOverflowContainer.scrollLeft <
      sliderOverflowContainer.scrollWidth
    ) {
      sliderNextButton.classList.remove('hidden');
      sliderNextButton.classList.add('dkn-slider__arrow-active');
      sliderNextButton.classList.remove('dkn-slider__arrow-inactive');
    } else {
      if (hideDisabledButtons) {
        sliderNextButton.classList.add('hidden');
      }
      sliderNextButton.classList.remove('dkn-slider__arrow-active');
      sliderNextButton.classList.add('dkn-slider__arrow-inactive');
    }
  });

  sliderPrevButton.addEventListener('click', (event) => {
    event.stopPropagation();
    dknHandleSliderPrevEvent(
      sliderOverflowContainer,
      sliderOuterContainer,
      offsetValue
    );
  });

  sliderNextButton.addEventListener('click', (event) => {
    event.stopPropagation();
    dknHandleSliderNextEvent(
      sliderOverflowContainer,
      sliderOuterContainer,
      offsetValue
    );
  });
};

window.dknHandleSliderNextEvent = (
  sliderOverflowContainer,
  sliderOuterContainer,
  offsetValue
) => {
  if (sliderOverflowContainer.scrollWidth > sliderOuterContainer.clientWidth) {
    // const x = sliderOverflowContainer.clientWidth - offsetValue;
    sliderOverflowContainer.scrollBy({ left: offsetValue, behavior: 'smooth' });
  }
};

window.dknHandleSliderPrevEvent = (
  sliderOverflowContainer,
  sliderOuterContainer,
  offsetValue
) => {
  if (sliderOverflowContainer.scrollLeft !== 0) {
    // const x = sliderOverflowContainer.clientWidth - offsetValue;
    sliderOverflowContainer.scrollBy({
      left: -offsetValue,
      behavior: 'smooth',
    });
  }
};

// ---------------------------------------------------------------------------------------------------------------------
// Get and Post functions wrapper
// ---------------------------------------------------------------------------------------------------------------------

window.httpGet = async (url, params = {}, options = {}) =>
  axios
    .get(url, {
      data: params,
      headers: {
        Authorization: localStorage.al_to
          ? `Bearer ${localStorage.al_to}`
          : undefined,
        'x-requested-with': window?.DukaanData?.DUKAAN_SESSION_ID,
        'Content-Type': 'application/json',
        ...options?.headers,
      },
    })
    .catch(() => {});

window.httpPost = async (url, params = {}, options = {}) =>
  axios
    .post(url, params, {
      headers: {
        Authorization: localStorage.al_to
          ? `Bearer ${localStorage.al_to}`
          : undefined,
        'x-requested-with': window?.DukaanData?.DUKAAN_SESSION_ID,
        'Content-Type': 'application/json',
        ...options?.headers,
      },
    })
    .catch(() => {});

// ---------------------------------------------------------------------------------------------------------------------
// New functions for fetching data
// ---------------------------------------------------------------------------------------------------------------------

window.dknSerializeProduct = (product) => {
  let serializedSKUs = dknSerializeSKUs(product?.skus || []);
  if (serializedSKUs?.length) {
    if (typeof getFormattedSKUS === 'function') {
      serializedSKUs = getFormattedSKUS(serializedSKUs);
    }
    if (typeof customSKUSerializer === 'function') {
      serializedSKUs = customSKUSerializer(serializedSKUs);
    }
  }

  const attributes = dknGetAllProductAttributeValues(serializedSKUs);
  const { addOnsList = [], addOns = [] } =
    dknGetSerializedAddons(product) || {};
  return {
    ...product,
    ...languageSerializer(product),
    skus: serializedSKUs,
    attributes,
    addOnsList,
    addOns,
  };
};

window.dknAddProductsToProductsHash = (products = []) => {
  if (!products?.length) return;

  const productsMap = products?.reduce((map, product) => {
    if (!product) return map;
    if (DukaanData?.PRODUCTS_MAP?.[product.uuid]?.skusApi) return map;
    map[product.uuid] = dknSerializeProduct(product);
    return map;
  }, {});

  DukaanData.PRODUCTS_MAP = {
    ...(DukaanData?.PRODUCTS_MAP || {}),
    ...(productsMap || {}),
  };
};

window.dknGetProductsFromAdvancedSearch = (payload = {}) => {
  const url = `${window.DukaanData.DUKAAN_ADVANCED_SEARCH_API_BASE_URL}/api/advanced-search/${window.DukaanData.DUKAAN_STORE.id}/`;
  return httpPost(url, payload);
};

// options can accept page_size and offset
window.dknGetProductsFromProductIds = (productIds = [], options = {}) =>
  dknGetProductsFromAdvancedSearch({
    offset: 0,
    product_ids: productIds,
    ...options,
  })
    .then((res) => {
      const products = res?.data?.data?.products;
      dknAddProductsToProductsHash(products);
      return languageSerializer(products);
    })
    .catch(() => {});

// options can accept page_size and offset
window.dknGetProductsFromCategoryIds = (categoryIds = [], options = {}) =>
  dknGetProductsFromAdvancedSearch({
    offset: 0,
    category_ids: categoryIds,
    ...options,
  })
    .then((res) => {
      const products = res?.data?.data?.products;
      dknAddProductsToProductsHash(products);
      return languageSerializer(products);
    })
    .catch(() => {});

window.dknGetSerializedThemeCustomConfigData = (themeData) => {
  if (!themeData?.length) return {};
  const serializedThemeData = {};
  themeData?.forEach((item) => {
    serializedThemeData[item.title] = dknGetSerializedCustomConfigItem(
      item.sections
    );
  });
  return serializedThemeData;
};

window.dknGetSerializedCustomConfigItem = (data) => {
  if (!data?.length) return {};
  const serializedData = {};
  data?.forEach((item) => {
    serializedData[item.title] = item;
  });
  return serializedData;
};

/**
 * dukaan's function to fetch products of a specific type (category or product) from advanced search api
 * @param {String} type - type of products to fetch, currently types are : product & category
 * @param {Function} cb - callback to call just after fetch to override the after function calls
 * @param {HTMLElement} mountElem - list item wrapper
 * @param {Array} ids - an array of ids (product or category)
 * @param {String} splideId - id of the splide for list items
 * @param {String} templateId - template id of the list item
 * @param {Object} restPayload - additional payload to add for advanced search api
 * @param {Object} options - options to pass to additional renderer and others
 */
window.dknFetchTypeProductsFromIds = ({
  type = 'category',
  cb,
  mountElem,
  ids = [],
  splideId,
  splideOptions = {},
  templateId = 'dkn-product-card-template',
  restPayload,
  options = {},
} = {}) => {
  if (!ids || !ids.length) {
    return;
  }

  let payload = {
    offset: 0,
    page_size: 8,
    category_ids: [],
  };

  if (type === 'category') {
    payload = {
      ...payload,
      category_ids: ids,
      show_out_of_stock_products: true,
      continue_selling_when_oos: true,
      ...restPayload,
    };
  } else if (type === 'product') {
    payload = {
      ...payload,
      product_ids: ids,
      page_size: 100,
      ...restPayload,
    };
  } else {
    return;
  }

  const promise = [
    fetch(
      `${window.DukaanData.DUKAAN_ADVANCED_SEARCH_API_BASE_URL}/api/advanced-search/${window.DukaanData.DUKAAN_STORE.id}/`,
      {
        method: 'post',
        body: JSON.stringify(payload),
        headers: {
          'Content-Type': 'application/json',
          'x-requested-with': window?.DukaanData?.DUKAAN_SESSION_ID,
        },
      }
    ),
  ];

  Promise.all(promise)
    .then((res) => Promise.all(res.map((r) => r.json())))
    .then(([advProductsRes]) => {
      const products = advProductsRes?.data?.products || [];
      const totalCount = advProductsRes?.data?.total_count;

      window.hashProductMapper(products);
      if (typeof cb === 'function') {
        cb({ products, totalCount });
        return;
      }

      productListRenderer(mountElem, products, {
        templateId,
        additionalRenderer: window.productCardAdditionalRenderer,
        getCustomDiscountText: window.getCustomDiscountText,
      });

      if (splideId !== undefined) {
        dknRenderProductsListSplide(products, splideId, splideOptions);
      }

      if (typeof options?.additionalRenderer === 'function') {
        options.additionalRenderer(mountElem, products, {
          templateId,
          additionalRenderer: window.productCardAdditionalRenderer,
        });
      }
    })
    .catch((err) => {
      console.error(err);
      //   cb({ products: [] });
    });
};

window.dknRenderProductsListSplide = (
  products,
  section = 'frequently-bought-products',
  splideOptions = {}
) => {
  const splideObj = new Splide(`#${section}`, {
    type: 'slide',
    autoplay: false,
    arrows: products.length > 2,
    pauseOnHover: false,
    perPage: 2,
    perMove: 1,
    gap: 24,
    pagination: false,
    classes: {
      pagination: `splide__pagination ${section}-pagination`,
    },
    breakpoints: {
      992: {
        perPage: 2,
        arrows: false,
        gap: 16,
        pagination: true,
        padding: { right: products.length > 1 ? 24 : 0 },
        classes: {
          pagination: `splide__pagination ${section}-pagination`,
        },
      },
    },
    ...splideOptions,
  }).mount();
};

window.dknRenderSingleStar = (props) => {
  const {
    mountElem,
    starWidth,
    starHeight,
    svgFillColor,
    customClass = 'not-overlapped',
    isFilled = true,
    viewBoxWidth = 24,
    filledStarTemplateId,
    unFilledStarTemplateId,
  } = props;
  if (isFilled) {
    const filledStar = q$
      .selectById(filledStarTemplateId)
      .getTemplateContent().elem;
    const filledSvg = q$.select('svg', filledStar).elem;
    filledSvg.setAttribute('width', starWidth);
    filledSvg.setAttribute('height', starHeight);
    filledSvg.setAttribute('color', svgFillColor);
    filledSvg.setAttribute('viewBox', `0 0 ${viewBoxWidth} 24`);
    filledSvg.classList.add(customClass);
    mountElem.appendChild(filledStar);
    return;
  }
  const unFilledStar = q$
    .selectById(unFilledStarTemplateId)
    .getTemplateContent().elem;
  const unfilledSvg = q$.select('svg', unFilledStar).elem;
  unfilledSvg.setAttribute('width', starWidth);
  unfilledSvg.setAttribute('height', starHeight);
  unfilledSvg.setAttribute('color', svgFillColor);
  unfilledSvg.setAttribute('viewBox', `0 0 ${viewBoxWidth} 24`);
  unfilledSvg.classList.add(customClass);
  mountElem.appendChild(unFilledStar);
};

window.dknGetStarListElement = (avgRating, options = {}) => {
  const {
    svgFillColor = '#FAB73B',
    mountElem: element = document.createElement('div'),
    filledStarTemplateId = 'dkn-filled-star-template',
    unFilledStarTemplateId = 'dkn-unfilled-star-template',
    singleStarWrapperTemplateId = 'dkn-single-star-wrapper-template',
  } = options;
  const { starHeight = 24, starWidth = 24 } = options;
  element.classList.add('dkn-star-list-for-reviews-and-ratings', 'flex');
  const fullStarValue = Math.floor(avgRating);
  const halfStarValue = avgRating - fullStarValue;

  for (let i = 0; i < 5; i += 1) {
    const singleStarWrapperContent = q$
      .selectById(singleStarWrapperTemplateId)
      .getTemplateContent().elem;
    const singleStarWrapper = q$.select(
      '.dkn-single-star-wrapper',
      singleStarWrapperContent
    ).elem;
    if (i < fullStarValue) {
      dknRenderSingleStar({
        mountElem: singleStarWrapper,
        starWidth,
        starHeight,
        svgFillColor,
        isFilled: true,
        filledStarTemplateId,
        unFilledStarTemplateId,
      });
      element.appendChild(singleStarWrapperContent);
    } else if (fullStarValue !== 0 && i === fullStarValue) {
      dknRenderSingleStar({
        mountElem: singleStarWrapper,
        starWidth,
        starHeight,
        svgFillColor,
        isFilled: false,
        filledStarTemplateId,
        unFilledStarTemplateId,
      });
      element.appendChild(singleStarWrapperContent);
      dknRenderSingleStar({
        mountElem: singleStarWrapper,
        starWidth: Math.floor(starWidth * halfStarValue),
        starHeight,
        svgFillColor,
        isFilled: true,
        customClass: 'overlapped',
        viewBoxWidth: Math.floor(starWidth * halfStarValue),
        filledStarTemplateId,
        unFilledStarTemplateId,
      });
      singleStarWrapper.classList.add('overlapped-stars');
      element.appendChild(singleStarWrapperContent);
    } else {
      dknRenderSingleStar({
        mountElem: singleStarWrapper,
        starWidth,
        starHeight,
        svgFillColor,
        isFilled: false,
        filledStarTemplateId,
        unFilledStarTemplateId,
      });
      element.appendChild(singleStarWrapperContent);
    }
  }

  return element;
};
