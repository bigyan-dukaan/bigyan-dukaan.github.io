window.CACHE_API_ENDPOINT = 'https://api2.mydukaan.io';

window.removeOverflowFromBody = () => {
  document.querySelector('body').classList.remove('overflow-hidden');
};

window.toggleSearchDrawer = (isMobile) => {
  if (!isMobile) {
    document.querySelector('#search-backdrop').classList.toggle('show');
  }
  document
    .querySelectorAll('#search-dropdown')
    .forEach((el) => el.classList.toggle('d-none'));
  document.querySelectorAll('.modal.megamenu-modal').forEach((el) => {
    el.classList.add('hidden');
  });

  document.querySelector('body').classList.toggle('overflow-hidden');
};

// fetch brands
window.fetchTopBrands = async ({
  cb = null,
  loadPoint = '',
  brandMaxCount,
}) => {
  const MAX_COUNT = brandMaxCount;
  let consolidatedBrands = [];

  const fetchFunction = async (offset = 1) => {
    const fetchUrl = `${window.DukaanData.CLIENT_API2_ENDPOINT}/api/product/buyer/${window.DukaanData.DUKAAN_STORE.link}/product-category-list/?offset=${offset}`;
    let categories = [];

    const resultJson = await fetch(fetchUrl, {
      method: 'get',
      headers: {
        'Content-Type': 'application/json',
        'x-requested-with': window?.DukaanData?.DUKAAN_SESSION_ID,
        // 'Content-Type': 'application/x-www-form-urlencoded',
      },
    });

    const res = await resultJson.json();

    if (res && res.results) {
      categories = res?.results;

      DukaanData.DUKAAN_CLIENT_CATEGORY_LIST = {
        ...DukaanData?.DUKAAN_CLIENT_CATEGORY_LIST,
        ...categories?.reduce((map, category) => {
          map[category.uuid] = { ...category };
          return map;
        }, {}),
      };

      consolidatedBrands = [...consolidatedBrands, ...categories];

      if (consolidatedBrands.length < MAX_COUNT) {
        await fetchFunction(consolidatedBrands.length);
      } else {
        return null;
      }
    }

    return '';
  };

  if (loadPoint !== null) {
    await fetchFunction();
    document.querySelectorAll(loadPoint)?.forEach((el) => (el.innerHTML = ''));
    cb(consolidatedBrands.splice(0, MAX_COUNT), loadPoint);
  }
};

// top brands renderer
window.renderTopBrands = (brands, loadPoint, options = {}) => {
  const { templateId = 'home-page-brands-template' } = options;

  const brandListElements = document.querySelectorAll(loadPoint);

  brandListElements.forEach((brandListEl) => {
    brandListEl.replaceChildren();

    const brandItemTemplate = document.getElementById(templateId);
    brands.forEach((brand) => {
      const container = brandListEl;

      const brandItemElement = document.importNode(
        brandItemTemplate.content,
        true
      );
      brandItemElement
        .querySelector('a')
        .setAttribute('href', `${getCategoryCardLink(brand)}`);

      brandItemElement
        .querySelector('.brand-image')
        .setAttribute('src', `${getCdnUrl(brand.image, 500)}`);

      container.appendChild(brandItemElement);
    });
  });
};

// Search predictions
window.fillPrediction = () => {};

window.renderPredictions = (predictions) => {
  const searchPredictionsElements = document.querySelectorAll(
    '.search-predictions'
  );

  document
    .querySelectorAll('.recent-searches')
    .forEach((rS) => rS.classList.add('hidden'));

  searchPredictionsElements.forEach((searchPredictionsElement) => {
    searchPredictionsElement.replaceChildren();
    searchPredictionsElement.classList.remove('hidden');
    document
      .querySelectorAll('.search-meta')
      .forEach((el) => el.classList.add('hidden'));

    if (predictions.length > 0) {
      const searchPredictionsTemplate = document.getElementById(
        'search-prediction-item'
      );

      const isResto = DukaanData.DUKAAN_STORE.store_category === 6;

      predictions.forEach((prediction) => {
        const categoryItemElement = document.importNode(
          searchPredictionsTemplate.content,
          true
        );

        if (isResto) {
          categoryItemElement
            .querySelector('.search-prediction-item')
            .setAttribute(
              'href',
              `${DukaanData.DUKAAN_BASE_URL}/search?q=${prediction.slug}`
            );
        } else {
          categoryItemElement
            .querySelector('.search-prediction-item')
            .setAttribute(
              'href',
              `${DukaanData.DUKAAN_BASE_URL}/products/${prediction.slug}`
            );
        }

        categoryItemElement
          .querySelector('.fill-prediction')
          .setAttribute(
            'onclick',
            `fillPrediction(event, '${prediction.name}')`
          );
        categoryItemElement.querySelector('.prediction-label').textContent =
          prediction.name;
        searchPredictionsElement.appendChild(categoryItemElement);
      });
    } else {
      const searchPredictionsTemplate = document.getElementById(
        'search-prediction-failed'
      );
      const predectionFailedElement = document.importNode(
        searchPredictionsTemplate.content,
        true
      );
      predectionFailedElement.querySelector('.no-prediction').textContent =
        'No Results';
      searchPredictionsElement.appendChild(predectionFailedElement);
    }
  });
};
// search input
window.debounce = (callback, timeout = 300) => {
  let timer;
  return (...args) => {
    clearTimeout(timer);
    timer = setTimeout(() => {
      callback.apply(this, args);
    }, timeout);
  };
};

window.handleEmptySearchInput = () => {
  document.querySelector('.search-input').value = '';
  document.querySelector('.search-predictions').classList.add('hidden');
  document.querySelector('.search-meta').classList.remove('hidden');
  document.querySelector('.input-wrapper svg').classList.add('hidden');
};

window.handleInputChange = (event) => {
  const query = event.target.value;

  if (query.length === 0) {
    handleEmptySearchInput();
    return;
  }
  if (query.length < 2) {
    return;
  }
  fetch(
    `${window.DukaanData.DUKAAN_ADVANCED_SEARCH_API_BASE_URL}/api/advanced-search/${window.DukaanData.DUKAAN_STORE.id}/`,
    {
      method: 'post',
      body: JSON.stringify({
        query,
        page_size: 16,
        search_fields: ['product_name'],
      }),
      headers: {
        Accept: 'application/json',
        'Content-Type': 'application/json',
        'x-requested-with': window?.DukaanData?.DUKAAN_SESSION_ID,
      },
    }
  )
    .then((res) => res.json())
    .then((res) => {
      const predictions = res?.data?.products || [];
      renderPredictions(predictions);
    })
    .catch(() => {});
};

window.onInputChange = (event) => {
  const query = event.target.value;
  if (query.length === 0) {
    document
      .querySelectorAll('.search-meta')
      .forEach((el) => el.classList.remove('hidden'));
    document
      .querySelectorAll('.search-predictions')
      .forEach((el) => el.classList.add('hidden'));
    renderRecentSearches();
  }
  if (event.target.value.length > 0 && event.keyCode === 13) {
    // on enter key
    handleQuerySearch(event);
    return;
  }
  // document.querySelector('.input-wrapper svg').classList.remove('hidden');
  debounce(handleInputChange(event), 300);
};

window.onInputClear = () => {
  handleEmptySearchInput();
};

// search categories
window.renderCategoryList = (
  categories,
  nextUrl,
  firstFetch,
  loadPoint,
  options = {},
  isBrand = false
) => {
  const {
    templateId = 'category-list-item',
    wrapperId = 'search-category-card-wrapper',
  } = options;

  if (categories.length === 0) {
    document
      .querySelectorAll('.category-no-result')
      ?.forEach((el) => el.classList.remove('hidden'));
    document
      .querySelectorAll('.category-no-result')
      ?.forEach((el) => el.classList.remove('hidden'));
    document
      .querySelectorAll('.search-content')
      ?.forEach((el) => el.classList.add('hidden'));
    return;
  }
  const categoryListElements = document.querySelectorAll(loadPoint);

  categoryListElements.forEach((categoryListEl) => {
    categoryListEl.replaceChildren();

    const categoryItemTemplate = document.getElementById(templateId);
    categories.forEach((category) => {
      const container = categoryListEl;
      let wrapper = null;

      if (wrapperId) {
        const wrapperElement = document.importNode(
          document.getElementById(wrapperId).content,
          true
        );
        wrapper = wrapperElement.querySelector('div');
      }

      const categoryItemElement = document.importNode(
        categoryItemTemplate.content,
        true
      );
      categoryItemElement
        .querySelector('a')
        .setAttribute(
          'href',
          isBrand
            ? `${DukaanData.DUKAAN_BASE_URL}/brands/${category.slug}`
            : `${getCategoryCardLink(category)}`
        );

      if (categoryItemElement.querySelector('.category-name')) {
        categoryItemElement.querySelector('.category-name').textContent =
          category.name;
      }
      if (category.image) {
        categoryItemElement
          .querySelector('.category-image')
          .setAttribute(
            'src',
            `${getCdnUrl(category.image || category.logo, 500)}`
          );
      } else {
        categoryItemElement
          .querySelector('.category-image')
          .setAttribute(
            'src',
            'https://api-enterprise.mydukaan.io/static/images/category-def.jpg'
          );

        categoryItemElement
          .querySelector('.category-image')
          .classList.add('.error-img');
      }

      if (wrapper) {
        wrapper.appendChild(categoryItemElement);
        container.appendChild(wrapper);
      } else {
        container.appendChild(categoryItemElement);
      }
    });
  });
};

window.renderRecentSearches = () => {
  const recentSearchList = getDataFromLocalStorageV2(getHistoryStoragekey());
  if (recentSearchList.length > 0) {
    document
      .querySelectorAll('.recent-searches')
      .forEach((el) => el.classList.remove('d-none'));
    const recentSearchListElements = document.querySelectorAll(
      '.recent-searches-list'
    );
    recentSearchListElements.forEach((recentSearchListEl) => {
      recentSearchListEl.replaceChildren();

      const recentSearchItemTemplate = document.getElementById(
        'recent-searches-template'
      );

      recentSearchList.forEach((search) => {
        const resentSearchItemElement = document.importNode(
          recentSearchItemTemplate.content,
          true
        );
        resentSearchItemElement.querySelector(
          '.recent-search-item-text'
        ).textContent = search.term;
        resentSearchItemElement
          .querySelector('.recent-search-item')
          .setAttribute('onclick', `handleQuerySearch(null, '${search.term}')`);
        recentSearchListEl.appendChild(resentSearchItemElement);
      });
    });
  } else {
    document
      .querySelectorAll('.recent-searches')
      .forEach((el) => el.classList.add('hidden'));
  }
};

window.getDataFromLocalStorageV2 = (key) =>
  JSON.parse(localStorage.getItem(key)) || [];

window.getHistoryStoragekey = () =>
  `v3-${window.DukaanData.DUKAAN_STORE.link}-search-history`;

window.setDataFromLocalStorage = (key, value) => {
  localStorage.setItem(getHistoryStoragekey(), JSON.stringify(value));
};

window.setHistory = (term) => {
  const prevHistory = getDataFromLocalStorageV2(getHistoryStoragekey());
  let newHistory;
  if (prevHistory.some((historyItem) => historyItem.term === term)) {
    newHistory = [
      { term },
      ...prevHistory.filter((historyItem) => historyItem.term !== term),
    ];
  } else {
    newHistory = [{ term }, ...prevHistory.slice(0, 3)];
  }
  setDataFromLocalStorage(getHistoryStoragekey(), newHistory);
  return newHistory;
};

window.handleQuerySearch = (e, query = '') => {
  let target = null;
  if (e !== null) {
    e.preventDefault();
    target = e.target;
  }
  const rawQuery = (query || target?.value)?.trim();
  if (Boolean(rawQuery) && rawQuery.length > 0) {
    setHistory(rawQuery);
    window.location.href = dknGetSearchUrl(rawQuery);
  }
};

window.clearRecentSearches = () => {
  localStorage.removeItem(getHistoryStoragekey());
  renderRecentSearches();
};

// fetch best before date
window.fetchBestBefore = (currentSKU) => {
  const fetchUrl = `${window.DukaanData.CLIENT_API_ENDPOINT}/api/metafields/buyer/metafield/${window.DukaanData.DUKAAN_STORE.link}/productsku/${currentSKU.id}/`;
  fetch(fetchUrl, {
    method: 'get',
    headers: {
      'Content-Type': 'application/json',
      'x-requested-with': window?.DukaanData?.DUKAAN_SESSION_ID,
    },
  })
    .then((res) => res.json())
    .then((res) => {
      if (res && res.results.length > 0) {
        document.querySelector('#bestBefore').classList.remove('d-none');
        document.querySelector('#bestBefore .best-before-value').textContent =
          res.results[0].value;
      } else {
        document.querySelector('#bestBefore').classList.add('d-none');
      }
      return res;
    })
    .catch(() => {});
};

window.handleCustomProductVariantChange = (product, activeSKU) => {
  fetchBestBefore(activeSKU);
};

// variant modal functions
window.handleModalChanges = (product, currentSKU) => {
  const element = document.querySelector('.product-variant-selection-modal');
  if (!element) return;
  // fetch best before
  fetchBestBefore(currentSKU);

  // updating placeholder
  // if (element.querySelector('.size-variant .dropdown-placeholder')) {
  //   element.querySelector('.size-variant .dropdown-placeholder').textContent =
  //     currentSKU.meta?.size?.value || 'Select a size variant';
  // }
  // if (element.querySelector('.color-variant .dropdown-placeholder')) {
  //   element.querySelector('.color-variant .dropdown-placeholder').textContent =
  //     currentSKU.meta?.color?.value || 'Select a color variant';
  // }

  // updating active item in variant dropdown
  // element
  //   .querySelectorAll('.variant-dropdown .form-input-container')
  //   .forEach((el) => {
  //     if (
  //       el.getAttribute('value') === currentSKU.meta?.size?.value ||
  //       el.getAttribute('value') === currentSKU.meta?.color?.value
  //     ) {
  //       el.classList.add('selected-variant');
  //     } else {
  //       el.classList.remove('selected-variant');
  //     }
  //   });

  // handleCloseAllModalDropdown();

  if (element.querySelector('.product-modal-badge .bxgy-badge')) {
    handleProductCardChange(element, product);
  }

  if (element.querySelector('.product-name')) {
    element.querySelector('.product-name').textContent = `${product.name}`;
  }

  if (
    product.brands &&
    product.brands.length > 0 &&
    element.querySelector('.brand-name')
  ) {
    element.querySelector(
      '.brand-name'
    ).textContent = `${product.brands[0].name}`;
  } else {
    element.querySelector('.brand-details').classList.add('d-none');
  }

  // renders product modal carousel with splide if exist.
  const productSplideTemplate = document.querySelector(
    '#product-modal-splide-container'
  );

  if (productSplideTemplate) {
    const productSplideList = element.querySelector('.splide__list');

    if (typeof splideSlider === 'undefined') {
      if (product.all_images?.length > 0) {
        product?.all_images.forEach((image) => {
          const productSplide = document.importNode(
            productSplideTemplate.content,
            true
          );
          productSplide
            .querySelector('.product-modal-splide-image')
            .setAttribute(
              'src',
              `${getCdnUrl(image || currentSKU.primary_image, 700)}`
            );
          productSplideList.appendChild(productSplide);
        });

        window.splideSlider = new Splide('#splide-product-modal-images', {
          type: 'slide',
          autoplay: false,
          arrows: true,
          pauseOnHover: false,
          pagination: false,
          interval: 1000,
          classes: {
            arrows: 'splide__arrows',
          },
        });
        window?.splideSlider?.mount();
      } else if (element.querySelector('.product-images')) {
        element.querySelector('.product-images').replaceChildren();
        const wrapper = element.querySelector('.product-images');
        wrapper.classList.add('d-flex', 'align-items-center', 'image-wrapper');
        const imgElem = document.createElement('img');
        imgElem.setAttribute('class', 'product-image');
        element.querySelector('.product-images').appendChild(imgElem);
        element
          .querySelector('.product-image')
          .setAttribute(
            'src',
            `${getCdnUrl(product.image || currentSKU.primary_image, 700)}`
          );
      }
    }
    if (!currentSKU?.primary_image.includes('category-def.jpg')) {
      const allImages = product?.all_images || product?.image;
      if (typeof splideSlideIndex !== 'undefined')
        splideSlideIndex(allImages, currentSKU.primary_image);
    }
  }

  const originalPrice = currentSKU?.original_price;
  const sellingPrice = currentSKU?.selling_price;

  if (element.querySelector('.product-selling-price')) {
    element.querySelector('.product-selling-price').textContent =
      formatMoney(sellingPrice);
  }

  if (element.querySelector('.product-original-price')) {
    if (originalPrice === sellingPrice) {
      element.querySelector('.product-original-price').classList.add('hidden');
    } else {
      element
        .querySelector('.product-original-price')
        .classList.remove('hidden');
      element.querySelector('.product-original-price').textContent =
        formatMoney(originalPrice);
    }
  }

  if (element.querySelector('.product-discount-badge')) {
    if (originalPrice === sellingPrice) {
      element.querySelector('.product-discount-badge').classList.add('hidden');
    } else {
      element
        .querySelector('.product-discount-badge')
        .classList.remove('hidden');
      const discount = window.calculateDiscount(originalPrice, sellingPrice);
      if (discount > 0) {
        element.querySelector(
          '.product-discount-badge'
        ).textContent = `(${discount}% OFF)`;
      }
    }
  }

  // if (element.querySelector('.color-variant') && currentSKU.meta.color) {
  //   element.querySelector('.color-variant label').textContent =
  //     currentSKU.meta.color.value;
  //   element.querySelector('.color-variant label').style.background = 'none';
  // } else {
  //   element.querySelector('.color-variant').classList.add('d-none');
  // }
};
// window.handleCloseAllModalDropdown = () => {
//   document.body.style.overflow = 'auto';
//   document
//     .querySelector('.product-modal-content #size-variant-dropdown')
//     ?.classList.add('d-none');
//   document
//     .querySelector('.product-modal-content #color-variant-dropdown')
//     ?.classList.add('d-none');
//   document
//     .querySelector('.product-modal-content .color-variant .custom-dropdown svg')
//     ?.classList.remove('open-arrow-state');
//   document
//     .querySelector(
//       '.product-modal-container .size-variant .custom-dropdown svg'
//     )
//     .classList.remove('open-arrow-state');
// };

// window.toggleModalSizeVariantDropdown = () => {
//   document
//     .querySelector('.product-modal-container #size-variant-dropdown')
//     .classList.toggle('d-none');
//   document.body.style.overflow =
//     document.body.style.overflow === 'hidden' ? 'auto' : 'hidden';
//   document
//     .querySelector(
//       '.product-modal-container .size-variant .custom-dropdown svg'
//     )
//     .classList.toggle('open-arrow-state');
// };

// window.toggleModalColorVariantDropdown = () => {
//   document
//     .querySelector('.product-modal-container #color-variant-dropdown')
//     .classList.toggle('d-none');
//   document.body.style.overflow =
//     document.body.style.overflow === 'hidden' ? 'auto' : 'hidden';
//   document
//     .querySelector(
//       '.product-modal-container .color-variant .custom-dropdown svg'
//     )
//     .classList.toggle('open-arrow-state');
// };

window.renderSubMenuList = (get) => {
  if (get?.id) {
    const menuItem = window.DukaanData.STORE_MENU.filter(
      (m) => m.id === +get.id
    );

    const selectedMenuName = menuItem[0].label;
    const subMenuList = menuItem[0].child;

    // let subMenuList = [];
    // let selectedMenuName = '';

    const subMenuSidebar = document.getElementById('sub-menu-container');
    subMenuSidebar.innerHTML = '';

    subMenuList.forEach((menu) => {
      const subMenuItemEl = document.importNode(
        document.querySelector('#sub-menu-item').content,
        true
      );
      subMenuItemEl
        .querySelector('a')
        .setAttribute('target', getMenuTarget(menu));
      subMenuItemEl
        .querySelector('a')
        .setAttribute(
          'href',
          selectedMenuName === 'Shop'
            ? `${DukaanData.DUKAAN_BASE_URL}/categories/${menu.slug}`
            : getMenuItemUrl(menu, DukaanData.DUKAAN_BASE_URL)
        );
      subMenuItemEl.querySelector('p').innerHTML = menu.label || menu.name;
      subMenuSidebar.appendChild(subMenuItemEl);
    });
  }
};

// on mouse leave
window.closeMegaModel = (elem) => {
  const modalDialog = elem.parentNode;
  modalDialog.classList.add('hidden');
  document.getElementsByTagName('body')[0].style.overflow = 'auto';
};

// on mouse enter
window.openMegaModal = (label, elem) => {
  const menu = DukaanData.STORE_MENU.find((m) => m.id === +label);
  if (menu.child.length > 0) {
    document.getElementsByTagName('body')[0].style.overflow = 'hidden';
  }
  document.querySelectorAll('.modal.megamenu-modal').forEach((el) => {
    el.classList.add('hidden');
  });
  const modalObj = DukaanData.STORE_MENU.find((el) => el.id === +label);
  if (modalObj && modalObj.child.length > 0) {
    const megaModel = document.querySelector(`.megamenu-modal.modal-${label}`);
    megaModel.classList.remove('hidden');
    megaModel.style.display = 'flex';
  }
};
window.renderProductCardSplide = (elements, count = 0) => {
  if (!elements || elements.length === 0) return;
  const splideElements = elements.length > 0 ? elements : [elements];
  splideElements.forEach((splideEl) => {
    new Splide(splideEl, {
      type: 'slide',
      autoplay: false,
      arrows: true,
      pauseOnHover: false,
      perPage: count > 4 ? 5 : 4,
      pagination: false,
      gap: 12,
      breakpoints: {
        768: {
          perPage: 2,
          arrows: false,
          gap: 8,
          drag: false,
        },
      },
    }).mount();
  });
};

window.initAOS = () => {
  const aosElements = document.querySelectorAll('[data-aos]');

  for (let i = 0; i < aosElements.length; i += 1) {
    const windowHeight = window.innerHeight;
    const revealTop = aosElements[i].getBoundingClientRect().top;
    const revealPoint = -75;
    if (revealTop < windowHeight - revealPoint) {
      aosElements[i].classList.add('aos-animate');
    }
  }
};

window.getCustomReviewsCountText = (totalRatingCount) =>
  totalRatingCount > 1
    ? `(${totalRatingCount} Reviews)`
    : `(${totalRatingCount} Review)`;

window.commonInitializer = () => {
  renderSubMenuList();
  checkCouponSticky();
  GAPage();

  fetchStoreCategoriesSearchDrawer = fetchStoreCategories();
  fetchStoreCategoriesSearchDrawer({
    cb: renderCategoryList,
    loadPoint: 'category-list-load-point.search-modal-category-list',
    wrapperId: 'search-category-card-wrapper',
  });
};

window.addEventListener('scroll', () => {
  initAOS();
});

// Header mega menu
// window.renderSubMenuChild = (elm, parentId) => {
//   document
//     .querySelectorAll('header .sub-menu-li')
//     .forEach((el) => el.classList.remove('active-tab'));

//   elm.classList.add('active-tab');
//   document
//     .querySelectorAll('.child-menu')
//     .forEach((el) => el.classList.add('d-none'));
//   document.getElementById(`${parentId}`).classList.remove('d-none');
// };

// window.closeSubMenuChild = () => {};

// // checking if any submenu tab is opened already
// window.checkAnyTabIsOpened = () => {
//   let tabOpened = false;
//   document.querySelectorAll('.child-menu').forEach((el) => {
//     if (!el.classList.contains('d-none')) {
//       tabOpened = true;
//     }
//   });
//   return tabOpened;
// };

// window.openMegaMenu = (elm) => {
//   document
//     .querySelectorAll('header .megamenu-modal')
//     .forEach((el) => el.classList.remove('show'));

//   const modalElm = elm.parentNode.children[1];
//   modalElm.classList.add('show');

//   document.querySelector('body').classList.add('overflow-hidden');

//   // if (!window.checkAnyTabIsOpened()) {
//   //   document.querySelector('.child-menu').classList.remove('d-none');
//   // }
// };

// window.closeMegaMenu = () => {
//   console.log('entered');
//   document
//     .querySelectorAll('header .megamenu-modal')
//     .forEach((el) => el.classList.remove('show'));
// };

// window.closeActiveTab = () => {
//   document.querySelector('body').classList.remove('overflow-hidden');
//   document.querySelector('#sub-menu-depth-1').classList.add('d-none');
//   document
//     .querySelectorAll('.child-menu')
//     .forEach((el) => el.classList.add('d-none'));
// };

// // mobile side bar toggle
window.handlePlusMinusMobile = () => {
  document.querySelector('.plus-icon').classList.toggle('d-none');
  document.querySelector('.minus-icon').classList.toggle('d-none');
};

// depth2 tab change
window.handleTabChange = (parentId, labelElm, depth1Id) => {
  const parentElm = document.querySelector(`#menu-${parentId}`);
  const depth2CategoryTab = parentElm.querySelector(`#depth2-${depth1Id}`);

  // active class for depth1
  parentElm
    .querySelectorAll('.depth1-category-tab')
    .forEach((el) => el.classList.remove('depth1-active-tab'));
  labelElm.classList.add('depth1-active-tab');

  // active class for depth2
  parentElm
    .querySelectorAll('.depth2-category-tab')
    .forEach((el) => el.classList.remove('depth2-active-tab'));
  depth2CategoryTab?.classList.add('depth2-active-tab');
};

document.addEventListener('click', (event) => {
  dknHandleOutsideClickForSelect(event);
});
