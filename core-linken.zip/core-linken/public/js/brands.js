window.printAlphabets = () => {
  const mountElm = document.querySelector('#alphabet-filter');
  const alphabetFilterTemplate = document.querySelector('#alphabets-filter');

  for (let i = 65; i < 91; i++) {
    const alphabetFilter = document.importNode(
      alphabetFilterTemplate.content,
      true
    );

    // A - Z
    const alphabet = String.fromCharCode(i);

    alphabetFilter.querySelector('h5.alphabet').textContent = alphabet;

    if (i === 65) {
      alphabetFilter
        .querySelector('.alphabet-filter-box')
        .classList.add('active-box');
    }

    mountElm.append(alphabetFilter);
  }
};

window.handleAlphabetFIlterChange = (elm) => {
  const id = elm.children[0].innerText.toLowerCase();

  // remove active class from all filter buttons
  document
    .querySelectorAll('.alphabet-filter-box')
    .forEach((el) => el.classList.remove('active-box'));

  elm.classList.add('active-box');

  if (!document.getElementById(id)) return;

  const filteredElm = document.getElementById(id);

  const headerHeight = document
    .getElementsByTagName('header')[0]
    .getBoundingClientRect().height;

  // filteredElm.querySelector('.list-wrapper').style.background =
  //   'rgba(0, 189, 241, 0.05)';

  const offset = 28;
  window.scrollTo({
    top:
      filteredElm.getBoundingClientRect().top -
      headerHeight +
      window.scrollY -
      offset,
  });

  // window.setTimeout(() => {
  //   filteredElm.querySelector('.list-wrapper').style.background = 'none';
  // }, 500);
};

window.renderAllBrandsList = (categories, loadPoint) => {
  categories.sort((a, b) => a.name.localeCompare(b.name));
  const mountElm = document.querySelector(loadPoint);
  const alphabetWiseCategoryListTemplate = document.querySelector(
    '#alphabet-wise-category-list'
  );
  const categoryNameTemplate = document.querySelector('#category-name');

  for (let i = 65; i < 91; i += 1) {
    const alphabet = String.fromCharCode(i).toLocaleLowerCase();

    const alphabetWiseCategoryList = document.importNode(
      alphabetWiseCategoryListTemplate.content,
      true
    );

    const filteredCategories = categories.filter((cat) =>
      cat.name.toLowerCase().startsWith(alphabet)
    );

    const isEmptyElm = !filteredCategories.length > 0;

    filteredCategories.forEach((category) => {
      const categoryName = document.importNode(
        categoryNameTemplate.content,
        true
      );

      categoryName.querySelector('p.category-name').textContent = category.name;
      categoryName
        .querySelector('a')
        .setAttribute(
          'href',
          `/${DukaanData.DUKAAN_STORE.link}/brands/${category.slug}`
        );
      alphabetWiseCategoryList
        .querySelector('category-name-load-point')
        .appendChild(categoryName);
    });

    if (!isEmptyElm) {
      alphabetWiseCategoryList.querySelector('.category-title').textContent =
        alphabet.toUpperCase();

      alphabetWiseCategoryList
        .querySelector('.alphabet-wise-category-list')
        .setAttribute('id', alphabet);

      mountElm.appendChild(alphabetWiseCategoryList);
    }
  }
};

window.fetchAllBrandsNames = () => {
  const offset = 0;
  const initialized = true;
  const offsetCount = 10;

  // eslint-disable-next-line no-undef, no-return-assign
  return (fetchFn = ({ cb, loadPoint } = {}) => {
    // const fetchUrl = `${window.DukaanData.CLIENT_API_ENDPOINT}/api/product/buyer/${DukaanData.DUKAAN_STORE.link}/categories-in-alphabetical-order/?page=1&page_size=10000`;
    const fetchUrl = `${window.DukaanData.CLIENT_API_ENDPOINT}/api/store/buyer/${DukaanData.DUKAAN_STORE.link}/product-brands/?page_size=-1`;

    fetch(fetchUrl, {
      method: 'get',
      headers: {
        'Content-Type': 'application/json',
        'x-requested-with': window?.DukaanData?.DUKAAN_SESSION_ID,
        // 'Content-Type': 'application/x-www-form-urlencoded',
      },
    })
      .then((res) => res.json())
      .then((res) => {
        if (res && res.results.length > 0) {
          const categories = res?.results || [];

          if (loadPoint) {
            document.querySelector(loadPoint).innerHTML = '';
            cb(categories, loadPoint);
          }
        }
      })
      .catch((err) => {
        console.log('fetchStoreCategories error : ', err);
        cb([], false);
      });
  });
};

window.fetchPopularBrands = () => {
  let offset = 0;
  let initialized = true;
  const offsetCount = 10;

  // overriding the default browser scroll behavior
  // document
  //   .querySelectorAll('.modal-overflow-container')
  //   ?.forEach((el) => el?.scrollTo(0, 0));

  // eslint-disable-next-line no-undef, no-return-assign
  return (fetchFn = ({
    nextUrl = false,
    cb,
    loadPoint = null,
    firstFetch = false,
    ...rest
  } = {}) => {
    const fetchUrl = `${window.DukaanData.CLIENT_API_ENDPOINT}/api/store/buyer/${DukaanData.DUKAAN_STORE.link}/product-brands/`;

    if (nextUrl) {
      offset += offsetCount;
      initialized = false;
    }

    if (initialized) offset += offsetCount;

    fetch(fetchUrl, {
      method: 'get',
      headers: {
        'Content-Type': 'application/json',
        'x-requested-with': window?.DukaanData?.DUKAAN_SESSION_ID,
        // 'Content-Type': 'application/x-www-form-urlencoded',
      },
    })
      .then((res) => res.json())
      .then((res) => {
        const categories = res?.results || [];
        const next = !(categories.length < offsetCount);
        DukaanData.DUKAAN_CLIENT_CATEGORY_LIST = {
          ...DukaanData?.DUKAAN_CLIENT_CATEGORY_LIST,
          ...categories?.reduce((map, category) => {
            map[category.uuid] = { ...category };
            return map;
          }, {}),
        };
        if (initialized && loadPoint !== null) {
          document
            .querySelectorAll(loadPoint)
            ?.forEach((el) => (el.innerHTML = ''));
          // document.querySelectorAll(".category-sidebar-list")?.forEach(el => el.innerHTML = "");
          // document.querySelectorAll(".category-list")?.forEach(el => el.innerHTML = "");
        }
        const filteredCategories = categories.splice(0, 9);

        cb(filteredCategories, next, firstFetch, loadPoint, rest, true);
      })
      .catch((err) => {
        console.log('fetchStoreCategories error : ', err);
        cb([], false);
      });
  });
};

window.appInitializer = () => {
  printAlphabets();

  const fetchBrandList = fetchPopularBrands();
  fetchBrandList({
    cb: renderCategoryList,
    loadPoint: 'brands-list-load-point',
    wrapperId: 'category-card-wrapper',
  });

  const fetchAllBrandsList = fetchAllBrandsNames();
  fetchAllBrandsList({
    cb: renderAllBrandsList,
    loadPoint: 'alphabet-wise-category-list-load-point',
  });
};
