window.fetchCategoryProductsPdp = ({
  ordering = '',
  page = 1,
  sorting = false,
} = {}) => {
  renderShimmer('healthxp-product-card-pdp', 4);
  fetch(
    `${window.DukaanData.CLIENT_API_ENDPOINT}/api/product/buyer/${DukaanData.DUKAAN_STORE.uuid}/product-list/v2/?category=${DukaanData.DUKAAN_CATEGORY.uuid}&ordering=${ordering}&search=&page=${page}&pop_fields=category_data,store_data`,
    {
      headers: {
        'Content-Type': 'application/json',
        'x-requested-with': window?.DukaanData?.DUKAAN_SESSION_ID,
        // 'Content-Type': 'application/x-www-form-urlencoded',
      },
    }
  )
    .then((res) => res.json())
    .then((res) => {
      const products = res.results;
      document
        .querySelectorAll('.healthxp-product-card-pdp')
        ?.forEach((el) => el.remove());

      if (res && !!res.results && !!res.results.length) {
        DukaanData.PRODUCTS_MAP = {
          ...DukaanData.PRODUCTS_MAP,
          ...products.reduce((map, product) => {
            if (DukaanData?.PRODUCTS_MAP?.[product.uuid]?.skusApi) return map;
            const serializedSKUs = serializeSKUs(product.skus || []);
            const attributes = getAllProductAttributeValues(serializedSKUs);
            map[product.uuid] = {
              ...product,
              skus: serializedSKUs,
              attributes,
            };
            return map;
          }, {}),
        };

        // remove existing elements if it is sorting
        // if (sorting) {
        const mountElem = document.querySelector('category-product-list-pdp');
        mountElem.innerHTML = '';
        // }

        const { isMobile } = deviceType();
        if (isMobile) {
          renderCategoryProducts(mountElem, res.results.splice(0, 4));
        } else {
          renderCategoryProducts(mountElem, res.results);
        }

        renderProductCardSplide(
          document.querySelector('#splide-category-product-list-pdp'),
          res.results.length
        );

        if (!res.next) {
          document.querySelector('#category-products-observer')?.remove();
        }
      }
    })
    .catch((err) => {
      // console.log(err);
      // renderCategoryProducts([]);
    });
};

window.toggleSizeVariantDropdown = () => {
  document
    .querySelector('.product-description-wrapper #size-variant-dropdown')
    ?.classList.toggle('d-none');
  document.body.style.overflow =
    document.body.style.overflow === 'hidden' ? 'auto' : 'hidden';
  document
    .querySelector(
      '.product-description-wrapper .size-variant .custom-dropdown svg'
    )
    ?.classList.toggle('open-arrow-state');
};

// window.toggleColorVariantDropdown = () => {
//   document
//     .querySelector('.product-description-wrapper #color-variant-dropdown')
//     ?.classList.toggle('d-none');
//   document.body.style.overflow =
//     document.body.style.overflow === 'hidden' ? 'auto' : 'hidden';
//   document
//     .querySelector(
//       '.product-description-wrapper  .color-variant .custom-dropdown svg'
//     )
//     ?.classList.toggle('open-arrow-state');
// };

window.handleCloseAllDropdown = () => {
  document.body.style.overflow = 'auto';
  document
    .querySelector('.product-description-wrapper #size-variant-dropdown')
    ?.classList.add('d-none');
  document
    .querySelector('.product-description-wrapper #color-variant-dropdown')
    ?.classList.add('d-none');
  document
    .querySelector(
      '.product-description-wrapper .color-variant .custom-dropdown svg'
    )
    ?.classList.remove('open-arrow-state');
  document
    .querySelector(
      '.product-description-wrapper .size-variant .custom-dropdown svg'
    )
    .classList.remove('open-arrow-state');
};

window.handleHealthxpVariantChange = (e) => {
  // document
  //   .querySelectorAll('.variant-dropdown .form-input-container')
  //   .forEach((el) => el.classList.remove('selected-variant'));
  // e.classList.add('selected-variant');

  // const { variant } = e.dataset;
  // const placeholder =
  //   e.parentNode.querySelector('label')?.textContent || 'Select a variant';

  // if (variant === 'size') {
  //   document.querySelector(
  //     '.custom-size-dropdown .dropdown-placeholder'
  //   ).textContent = placeholder;
  // } else {
  //   document.querySelector(
  //     '.custom-color-dropdown .dropdown-placeholder'
  //   ).textContent = placeholder;
  // }

  // handleCloseAllDropdown();
  handleProductVariantChange();
};

// window.customRatingsStatsRenderer = (reviewStats) => {
//   for (let i = 1; i <= 5; i += 1) {
//     const ratingData = reviewStats.rating_data.filter((e) => e.rating == i);
//     let ratingPercent = 0;
//     if (ratingData && ratingData.length > 0) {
//       ratingPercent = Math.round(
//         (ratingData[0].count * 100) / reviewStats.total_count
//       );
//     }
//     document.getElementById(`total-stars-${i}`).innerHTML = returnStarList(
//       16,
//       i
//     );
//     document.getElementById(`percent-${i}`).textContent =
//       ratingData[0]?.count || '0%';
//     document.getElementById(`bg-progress-${i}`).style.width = '100%';
//     document.getElementById(`progress-${i}`).style.backgroundColor = '#FAB73B';
//     document.getElementById(`progress-${i}`).style.width = `${ratingPercent}%`;
//   }
// };

// window.customSingleStar = (fill, width = 16, customClass = 'not-overlapped') =>
//   width === 24
//     ? `<svg class=${customClass} width="${width}" height="24" viewBox="0 0 ${width} 24" fill="none" xmlns="http://www.w3.org/2000/svg">
//     <path d="M12 20.0196L17.9971 23.808C18.9434 24.4056 20.1104 23.5175 19.8594 22.3919L18.2675 15.2508L23.567 10.4454C24.4022 9.68877 23.9557 8.25246 22.855 8.15519L15.879 7.5362L13.1502 0.796791C12.7193 -0.265597 11.2807 -0.265597 10.8498 0.796791L8.12099 7.5362L1.14504 8.15519C0.044341 8.25246 -0.402216 9.68877 0.432966 10.4454L5.73251 15.2508L4.1406 22.3919C3.88956 23.5175 5.05664 24.4056 6.00286 23.808L12 20.0196Z" fill="${fill}" />
//   </svg>
//   `
//     : `<svg class=${customClass} width="${width}" height="24" viewBox="0 0 ${width} 24" fill="none" xmlns="http://www.w3.org/2000/svg">
//     <path d="M8 13.3464L11.9981 15.872C12.6289 16.2704 13.407 15.6783 13.2396 14.928L12.1783 10.1672L15.7114 6.96363C16.2681 6.45918 15.9704 5.50164 15.2366 5.43679L10.586 5.02413L8.76679 0.531194C8.47955 -0.177065 7.52045 -0.177065 7.23321 0.531194L5.41399 5.02413L0.763362 5.43679C0.0295607 5.50164 -0.268144 6.45918 0.288644 6.96363L3.82167 10.1672L2.7604 14.928C2.59304 15.6783 3.37109 16.2704 4.00191 15.872L8 13.3464Z" fill="${fill}"/>
//   </svg>`;

window.appInitializer = () => {
  // for rendering shimmers
  renderProductCardSplide(
    document.querySelector('#splide-category-product-list-pdp')
  );

  fetchCategoryProductsPdp();
  const productFromServer = window.DukaanData.DUKAAN_PRODUCT;
  const serializedSKUs = serializeSKUs(productFromServer.skus || []);
  const attributes = getAllProductAttributeValues(serializedSKUs);
  const product = {
    ...productFromServer,
    skus: serializedSKUs,
    attributes,
  };
  window.DukaanData.PRODUCTS_DETAILS = product;
  window.DukaanData.PRODUCTS_MAP = {
    ...(DukaanData.PRODUCTS_MAP || []),
    [product.uuid]: product,
  };
  checkCouponSticky();
  checkStoreClosedSticky();
  if (typeof fetchPDPSizeChartData !== 'undefined') {
    fetchPDPSizeChartData();
  }
  retrieveSKUs(productFromServer, () => {
    if (typeof addSKUToBagFromQueryParams !== 'undefined') {
      addSKUToBagFromQueryParams();
    }
    const activeSKU = dknGetFirstAvailableSKU(
      DukaanData.PRODUCTS_MAP[productFromServer.uuid].skus
    );
    fetchBestBefore(activeSKU);
  });

  window.mainSplide = new Splide('#splide-product-main', {
    type: 'slide',
    rewind: true,
    pagination: false,
    arrows: false,
    width: 624,
    updateOnMove: true,
    fixedHeight: '572px',
    breakpoints: {
      768: {
        fixedHeight: '360px',
      },
    },
  });

  window.thumbnailSplide = new Splide('#splide-product-thumbnail', {
    autoplay: false,
    arrows: true,
    perPage: 3,
    gap: 16,
    pagination: false,
    isNavigation: true,
    fixedHeight: 112,
    fixedWidth: 112,
    direction: 'ltr',
    focus: 3,
    breakpoints: {
      768: {
        gap: 12,
        fixedWidth: 56,
        fixedHeight: 56,
        arrows: true,
      },
    },
  });

  mainSplide.sync(thumbnailSplide);
  mainSplide.mount();
  thumbnailSplide.mount();
  fetchCouponsAndOffersOnPDP();
  setFooterBottomMarginEqualToHeightOfPDPButtonWrapperClassElement();
  druidProductPageView();
};

// close dropdown on clicking outside..
// const sizeDropdown = document.querySelector('.custom-size-dropdown');
// const colorDropdown = document.querySelector('.custom-color-dropdown');

// document
//   .querySelector('.product-description-wrapper ')
//   .addEventListener('click', (event) => {
//     const isClickInsideSizeDropdown = sizeDropdown?.contains(event.target);
//     const isClickInsideColorDropdown = colorDropdown?.contains(event.target);

//     if (
//       document.querySelector('.size-variant') &&
//       !isClickInsideSizeDropdown &&
//       !document
//         .querySelector('.size-selection-list.variant-dropdown')
//         ?.classList.contains('d-none')
//     ) {
//       toggleSizeVariantDropdown();
//     }

//     if (
//       document.querySelector('.color-variant') &&
//       !isClickInsideColorDropdown &&
//       !document
//         .querySelector('.color-selection-list.variant-dropdown')
//         ?.classList.contains('d-none')
//     ) {
//       toggleColorVariantDropdown();
//     }
//   });

window.scrollToSKUImage = (activeSKU) => {
  const primaryImage = activeSKU.primary_image;
  const allImages = DukaanData.DUKAAN_PRODUCT.all_images;
  if (allImages.length > 0) {
    const index = allImages.indexOf(primaryImage);
    if (index >= 0) {
      window?.mainSplide?.go(index);
      window?.thumbnailSplide?.go(index);
    }
  }
};
