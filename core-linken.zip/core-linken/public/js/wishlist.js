window.PER_PAGE_PAGINATION_LIMIT = 30;
// window.breadcrumbSectionElement = document.querySelector(".breadcrumb-section");
window.myWishlistTextElements = document.querySelectorAll('.myWishlistText');
window.wishlistPagePaginationWrapperElem = document.getElementById(
  'wishlist-page-pagination-wrapper'
);
window.wishlistedVariantsListElement = document.querySelector(
  '.wishlisted-variants-list'
);
window.wishlistCardTemplate = document.getElementById('wishlist-card-template');

window.scrollToTopWishlistedVariants = (scrollToView = true) => {
  if (scrollToView) {
    const element = document.querySelector('.wishlists-section');
    const y = element.getBoundingClientRect().top + window.scrollY;
    window.scroll({
      top: y - 100,
      behavior: 'smooth',
    });
  }
};

window.fetchWishlistedVariants = ({ cb, pageNumber = 1 } = {}) => {
  const headers = {};
  if (localStorage && localStorage.al_to)
    headers.Authorization = `Bearer ${localStorage.al_to}`;
  headers['Content-Type'] = 'application/json';
  headers['x-requested-with'] = window?.DukaanData?.DUKAAN_SESSION_ID;

  wishlistPagePaginationWrapperElem.classList.add('hidden');
  fetch(
    `${window.DukaanData.CLIENT_API_ENDPOINT}/api/store/buyer/wishlist/${window.DukaanData.DUKAAN_STORE.id}/products/?page=${pageNumber}`,
    {
      method: 'GET',
      headers,
    }
  )
    .then((res) => res.json())
    .then((resp) => {
      const variants = resp?.results;
      const totalVariantsCount = resp?.count;

      DukaanData.PRODUCTS_MAP = {
        ...DukaanData.PRODUCTS_MAP,
        ...variants.reduce((map, product) => {
          const serializedSKUs = serializeSKUs(product.skus || []);
          const attributes = getAllProductAttributeValues(serializedSKUs);

          const previousSKUS = map[product.uuid]?.skus;
          let finalSKUS = [...serializedSKUs];
          if (previousSKUS?.length > 0) {
            finalSKUS = [...finalSKUS, ...previousSKUS];
          }
          map[product.uuid] = {
            ...product,
            skus: finalSKUS,
            attributes,
          };
          return map;
        }, {}),
      };

      wishlistedVariantsListElement.innerHTML = '';
      cb({ variants, totalVariantsCount, pageNumber });
    })
    .catch((err) => {
      cb({ variants: [], totalVariantsCount: 0, pageNumber });
      console.log('fetchWishlistedVariants error : ', err);
    });
};

/*
- runs only after successful delete api call
- takes current count from data attr -> subtracts it by 1 -> updates the UI -> updates the data attr.
*/
window.updateTotalWishlistCount = () => {
  const myWishlistTextElement = myWishlistTextElements[0];
  const updatedWishlistCount = myWishlistTextElement.dataset.wishlistCount - 1;
  if (updatedWishlistCount === 0) {
    showNoProductsLottie();
  }
  myWishlistTextElements.forEach((myWishlistTextEle) => {
    myWishlistTextEle.setAttribute('data-wishlist-count', updatedWishlistCount);
    myWishlistTextEle.textContent = `My wishlist (${updatedWishlistCount})`;
  });
  if (updatedWishlistCount >= 30) {
    const reminder = (updatedWishlistCount % PER_PAGE_PAGINATION_LIMIT) / 100;
    if (reminder === 0) {
      scrollToTopWishlistedVariants();
      fetchWishlistedVariants({ cb: renderWishlistPage });
    }
  }
};

window.showNoProductsLottie = () => {
  const wishlistsSectionElement = document.querySelector('.wishlists-section');
  wishlistsSectionElement.innerHTML = '';

  const noWishlistsFoundElement = document.getElementById('no-wishlists-found');
  noWishlistsFoundElement.classList.remove('hidden');
  noWishlistsFoundElement.classList.add('wishlists-section');
};

window.showHeader = (totalVariantsCount) => {
  // setting the count on page render + updating the data attr.
  myWishlistTextElements.forEach((myWishlistTextElement) => {
    myWishlistTextElement.classList.remove('hidden');
    myWishlistTextElement.textContent = `My wishlist (${totalVariantsCount})`;
    myWishlistTextElement.setAttribute(
      'data-wishlist-count',
      totalVariantsCount
    );
  });
};

// event handlers
window.handleOnClickDeleteButton = (wishlistID) => {
  const element = document.querySelector(`[data-wishlist-id="${wishlistID}"]`);
  if (element) {
    const overlayElement = element.querySelector('.overlay');
    overlayElement.classList.remove('hidden');
    overlayElement.classList.add('overlay-delete');

    window.dknDeleteWishlistProduct({
      wishlistID,
      successCb: () => {
        element.remove();
        window.updateTotalWishlistCount();
        window.enqueueSnackbar(
          DukaanData.DUKAAN_LANGUAGE.PRODUCT_REMOVED_FROM_WISHLIST,
          true,
          'success'
        );
      },
      errorCb: ({ err }) => {
        overlayElement.classList.add('hidden');
        overlayElement.classList.remove('overlay-delete');
        window.enqueueSnackbar(
          DukaanData.DUKAAN_LANGUAGE.FAILED_TO_REMOVE_PRODUCT_FROM_WISHLIST,
          true,
          'error'
        );
      },
    });
  }
};

window.handleOnPaginationButtonClick = (
  pageNumber,
  totalVariantsCount,
  pageSize
) => {
  scrollToTopWishlistedVariants();
  fetchWishlistedVariants({ cb: renderAllWishlistedVariants, pageNumber });
  renderWishlistPagePaginationButtons({
    pageNumber,
    totalVariantsCount,
    pageSize,
  });
};

// rendering logic

window.renderAllWishlistedVariants = ({ variants }) => {
  customTag('wishlisted-variants-list', (element) => {
    wishlistedVariantsRenderer({ element, variants });
  });
};

window.wishlistedVariantsRenderer = ({ element: mountElement, variants }) => {
  variants.forEach((variant) => {
    const wishlistCard = document.importNode(
      wishlistCardTemplate.content,
      true
    );

    const productUUID = variant.uuid;
    const { skus } = variant;
    const defaultSKU = skus[0];
    const activeProduct = window.DukaanData.PRODUCTS_MAP[productUUID];

    const productVariantElem = wishlistCard.querySelector('.product-variant');
    const productImageElem = wishlistCard.querySelector('.product-image');

    wishlistCard
      .querySelectorAll('a')
      .forEach((el) =>
        el.setAttribute(
          'href',
          `${DukaanData.DUKAAN_BASE_URL}/products/${variant.slug}`
        )
      );

    wishlistCard
      .querySelector('.wishlist-card')
      .setAttribute('data-wishlist-id', variant.wishlist_id);

    if (wishlistCard.querySelector('.product-name')) {
      wishlistCard.querySelector('.product-name').textContent = variant.name;
    }
    if (variant?.brand?.logo) {
      wishlistCard
        .querySelector('.dkn-product-card-brand-image')
        .setAttribute('src', window.getCdnUrl(variant.brand.logo, 100));
    } else {
      wishlistCard
        .querySelector('.dkn-product-card-brand-image')
        .setAttribute('onerror', 'window.imageOnError(event)');
    }

    if (productVariantElem) {
      const serializedSKUs = serializeSKUs(variant.skus || []);
      const attributes = getAllProductAttributeValues(serializedSKUs);

      const attributesLength = Object.keys(attributes).length;
      const sizeAttributeLength = attributes?.size?.length;
      const colorAttributeLength = attributes?.color?.length;

      if (!sizeAttributeLength && !colorAttributeLength) {
        const baseQty = activeProduct?.base_qty;
        const unit = activeProduct?.unit ? activeProduct.unit : '';

        if (baseQty) {
          const baseQtyElem = document.createElement('div');
          baseQtyElem.classList.add('product-variant-attr_base-qty');
          baseQtyElem.textContent = `${baseQty} ${unit}`;
          productVariantElem.appendChild(baseQtyElem);
        }
      } else {
        const colorAttributeElem = document.createElement('div');
        const sizeAttributeElem = document.createElement('div');
        const separaterElem = document.createElement('div');

        if (attributes?.size) {
          sizeAttributeElem.classList.add(
            'product-variant-attr_size',
            'ellipsis'
          );
          const [sizeAttr] = attributes.size;
          sizeAttributeElem.textContent = sizeAttr;
        }

        if (attributes?.color) {
          colorAttributeElem.classList.add('product-variant-attr_color');
          const [colorAttr] = attributes.color;
          colorAttributeElem.style.backgroundColor = colorAttr;
        }

        if (attributesLength > 1) {
          separaterElem.classList.add('product-variant-attr_separator');
        }
        productVariantElem.appendChild(colorAttributeElem);
        productVariantElem.appendChild(separaterElem);
        productVariantElem.appendChild(sizeAttributeElem);
      }
    }

    if (wishlistCard.querySelector('.product-image')) {
      const skuImage = defaultSKU.primary_image;

      if (skuImage.includes('category-def.jpg')) {
        productImageElem.setAttribute(
          'src',
          `${getCdnUrl(variant.image, 700)}`
        );
      } else {
        productImageElem.setAttribute('src', `${getCdnUrl(skuImage, 700)}`);
      }
    }

    const originalPrice = defaultSKU.original_price;
    const sellingPrice = defaultSKU.selling_price;
    const discount = (
      ((originalPrice - sellingPrice) / originalPrice) *
      100
    ).toFixed(0);
    if (discount > 0) {
      if (wishlistCard.querySelector('.product-discount')) {
        wishlistCard.querySelector(
          '.product-discount'
        ).textContent = `${discount}% OFF`;
      }
    } else {
      wishlistCard.querySelector('.product-discount')?.classList.add('d-none');
    }

    /*
      - for out of stock -> sku inventory should be 0
      - for in stock -> sku inventory should be null
    */
    const skuInventory = defaultSKU.inventory;

    if (wishlistCard.querySelector('.pricing-label')) {
      if (skuInventory === 0) {
        wishlistCard.querySelector('.pricing-label').classList.add('hidden');
        wishlistCard
          .querySelector('.out-of-stock-label')
          .classList.remove('hidden');
      }
    }

    if (wishlistCard.querySelector('.product-unit') !== null) {
      wishlistCard.querySelector('.product-unit').textContent = `per${
        variant.base_qty === 1 ? '' : ` ${variant.base_qty}`
      } ${variant.unit}`;
    }

    if (
      wishlistCard.querySelector('.dkn-product-card-selling-price') !== null
    ) {
      wishlistCard.querySelector(
        '.dkn-product-card-selling-price'
      ).textContent = formatMoney(sellingPrice);
    }

    if (
      wishlistCard.querySelector('.dkn-product-card-original-price') !== null
    ) {
      if (originalPrice === sellingPrice) {
        wishlistCard
          .querySelector('.dkn-product-card-original-price')
          .classList.add('hidden');
      } else {
        wishlistCard
          .querySelector('.dkn-product-card-original-price')
          .classList.remove('hidden');
        wishlistCard.querySelector(
          '.dkn-product-card-original-price'
        ).textContent = formatMoney(originalPrice);
      }
    }

    if (wishlistCard.querySelector('.product-discount') !== null) {
      if (originalPrice === sellingPrice) {
        wishlistCard.querySelector('.product-discount').classList.add('hidden');
      } else {
        wishlistCard
          .querySelector('.product-discount')
          .classList.remove('hidden');
        wishlistCard.querySelector(
          '.product-discount'
        ).textContent = `${Math.ceil(
          ((originalPrice - sellingPrice) / originalPrice) * 100
        )}% OFF`;
      }
    }

    const productBadges = (bxgyData, onSaleBool, skuInven) => {
      if (skuInven !== 0 && !skuInven) {
        // in stock variant
        if (bxgyData.length > 0) {
          const bxgyBadge = wishlistCard.querySelector('.bxgy-badge'); // BXGY class for product page
          if (bxgyBadge) {
            bxgyBadge.classList.remove('hidden');
            bxgyBadge.textContent = getBXGYText(variant.coupon_data);
          }
        } else if (onSaleBool) {
          const onSaleBadge = wishlistCard.querySelector('.on-sale-badge');
          if (onSaleBadge) {
            onSaleBadge.classList.remove('hidden');
          }
        }
      } else {
        const soldOutBadge = wishlistCard.querySelector('.sold-out-badge');
        if (soldOutBadge) {
          soldOutBadge.classList.remove('hidden');
        }
      }
    };

    productBadges(
      variant.coupon_data,
      originalPrice > sellingPrice,
      skuInventory
    );

    // wishlistCard.querySelector('.overlay').classList.add('hidden');

    wishlistCard
      .querySelector('.delete-wishlist-button')
      .setAttribute(
        'onclick',
        `handleOnClickDeleteButton('${variant.wishlist_id}')`
      );

    if (wishlistCard.querySelector('add-to-bag-button-with-variants')) {
      wishlistCard.querySelector(
        'add-to-bag-button-with-variants'
      ).dataset = `${formatMoney(sellingPrice)}`;
      const addToBagElement = wishlistCard.querySelector(
        'add-to-bag-button-with-variants'
      );
      addToBagElement.dataset.productUuid = variant.uuid;
      addToBagElement.dataset.skuUuid = variant.skus[0].uuid;
      addToBagButtonRenderer(addToBagElement);
    }
    mountElement.appendChild(wishlistCard);
  });
};

window.renderPageNoItem = (props) => {
  const { currPageNumber, isCurrentPage, totalVariantsCount, pageSize } = props;

  const pageNoItemTemplate = document.getElementById('page-no-item');
  const pageNoItem = document.importNode(pageNoItemTemplate.content, true);

  pageNoItem.querySelector('.wishlist-page__page-number').textContent =
    currPageNumber;

  pageNoItem
    .querySelector('.wishlist-page__page-no-item')
    .setAttribute(
      'onclick',
      `handleOnPaginationButtonClick(${currPageNumber}, ${totalVariantsCount}, ${pageSize})`
    );

  if (isCurrentPage)
    pageNoItem
      .querySelector('.wishlist-page__page-no-item')
      .classList.add('active');

  return pageNoItem;
};

window.renderSideArrows = (props) => {
  const { pageNumber, totalVariantsCount, pageSize, lastPageNumber } = props;

  const leftArrow = document.getElementById('left-arrow');
  const rightArrow = document.getElementById('right-arrow');

  if (pageNumber === 1) {
    leftArrow.querySelector('.disabled').classList.remove('hidden');
    rightArrow.querySelector('.active').classList.remove('hidden');

    rightArrow.setAttribute(
      'onclick',
      `handleOnPaginationButtonClick(${
        pageNumber + 1
      }, ${totalVariantsCount}, ${pageSize})`
    );

    leftArrow.querySelector('.active').classList.add('hidden');
    rightArrow.querySelector('.disabled').classList.add('hidden');
  }

  if (pageNumber === lastPageNumber) {
    leftArrow.querySelector('.active').classList.remove('hidden');
    rightArrow.querySelector('.disabled').classList.remove('hidden');

    leftArrow.setAttribute(
      'onclick',
      `handleOnPaginationButtonClick(${
        pageNumber - 1
      }, ${totalVariantsCount}, ${pageSize})`
    );

    leftArrow.querySelector('.disabled').classList.add('hidden');
    rightArrow.querySelector('.active').classList.add('hidden');
  }

  if (pageNumber !== 1 && pageNumber !== lastPageNumber) {
    leftArrow.querySelector('.active').classList.remove('hidden');
    rightArrow.querySelector('.active').classList.remove('hidden');

    leftArrow.querySelector('.disabled').classList.add('hidden');
    rightArrow.querySelector('.disabled').classList.add('hidden');

    leftArrow.setAttribute(
      'onclick',
      `handleOnPaginationButtonClick(${
        pageNumber - 1
      }, ${totalVariantsCount}, ${pageSize})`
    );
    rightArrow.setAttribute(
      'onclick',
      `handleOnPaginationButtonClick(${
        pageNumber + 1
      }, ${totalVariantsCount}, ${pageSize})`
    );
  }
};

window.renderWishlistPagePaginationButtons = (props) => {
  const { pageNumber, totalVariantsCount, pageSize } = props;

  if (totalVariantsCount <= pageSize) return;
  wishlistPagePaginationWrapperElem.classList.remove('hidden');

  const pageNumbersListElem = document.getElementById('page-numbers-list');
  pageNumbersListElem.innerHTML = '';

  const noOfPages = Math.ceil(Number(totalVariantsCount / pageSize));

  renderSideArrows({
    pageNumber,
    totalVariantsCount,
    pageSize,
    lastPageNumber: noOfPages,
  });

  if (noOfPages <= 4) {
    for (let i = 1; i <= noOfPages; i++) {
      pageNumbersListElem.append(
        renderPageNoItem({
          currPageNumber: i,
          isCurrentPage: i === pageNumber,
          totalVariantsCount,
          pageSize,
        })
      );
    }
  } else if (pageNumber <= 3) {
    const rightThreeDotsTemplate = document.getElementById('three-dots');
    const rightThreeDots = document.importNode(
      rightThreeDotsTemplate.content,
      true
    );

    for (let i = 1; i <= 3; i++) {
      pageNumbersListElem.append(
        renderPageNoItem({
          currPageNumber: i,
          isCurrentPage: i === pageNumber,
          totalVariantsCount,
          pageSize,
        })
      );
    }
    pageNumbersListElem.append(rightThreeDots);
    pageNumbersListElem.append(
      renderPageNoItem({
        currPageNumber: noOfPages,
        isCurrentPage: false,
        totalVariantsCount,
        pageSize,
      })
    );
  } else if (pageNumber >= noOfPages - 2) {
    const leftThreeDotsTemplate = document.getElementById('three-dots');
    const leftThreeDots = document.importNode(
      leftThreeDotsTemplate.content,
      true
    );

    pageNumbersListElem.append(
      renderPageNoItem({
        currPageNumber: 1,
        isCurrentPage: false,
        totalVariantsCount,
        pageSize,
      })
    );
    pageNumbersListElem.append(leftThreeDots);

    for (let i = noOfPages - 2; i <= noOfPages; i++) {
      pageNumbersListElem.append(
        renderPageNoItem({
          currPageNumber: i,
          isCurrentPage: i === pageNumber,
          totalVariantsCount,
          pageSize,
        })
      );
    }
  } else if (pageNumber + 3 === noOfPages) {
    const rightThreeDotsTemplate = document.getElementById('three-dots');
    const rightThreeDots = document.importNode(
      rightThreeDotsTemplate.content,
      true
    );
    const leftThreeDotsTemplate = document.getElementById('three-dots');
    const leftThreeDots = document.importNode(
      leftThreeDotsTemplate.content,
      true
    );
    pageNumbersListElem.append(
      renderPageNoItem({
        currPageNumber: 1,
        isCurrentPage: false,
        totalVariantsCount,
        pageSize,
      })
    );
    pageNumbersListElem.append(leftThreeDots);

    for (let i = pageNumber - 1; i <= pageNumber + 1; i++) {
      pageNumbersListElem.append(
        renderPageNoItem({
          currPageNumber: i,
          isCurrentPage: i === pageNumber,
          totalVariantsCount,
          pageSize,
        })
      );
    }

    pageNumbersListElem.append(rightThreeDots);
    pageNumbersListElem.append(
      renderPageNoItem({
        currPageNumber: noOfPages,
        isCurrentPage: false,
        totalVariantsCount,
        pageSize,
      })
    );
  } else if (pageNumber > 3 && pageNumber <= noOfPages - 3) {
    const rightThreeDotsTemplate = document.getElementById('three-dots');
    const rightThreeDots = document.importNode(
      rightThreeDotsTemplate.content,
      true
    );
    const leftThreeDotsTemplate = document.getElementById('three-dots');
    const leftThreeDots = document.importNode(
      leftThreeDotsTemplate.content,
      true
    );
    pageNumbersListElem.append(
      renderPageNoItem({
        currPageNumber: 1,
        isCurrentPage: false,
        totalVariantsCount,
        pageSize,
      })
    );
    pageNumbersListElem.append(leftThreeDots);

    for (let i = pageNumber; i <= pageNumber + 2; i++) {
      pageNumbersListElem.append(
        renderPageNoItem({
          currPageNumber: i,
          isCurrentPage: i === pageNumber,
          totalVariantsCount,
          pageSize,
        })
      );
    }

    pageNumbersListElem.append(rightThreeDots);
    pageNumbersListElem.append(
      renderPageNoItem({
        currPageNumber: noOfPages,
        isCurrentPage: false,
        totalVariantsCount,
        pageSize,
      })
    );
  }
};

window.renderWishlistPage = (props) => {
  const { variants, totalVariantsCount, pageNumber } = props;

  if (!totalVariantsCount) showNoProductsLottie();

  showHeader(totalVariantsCount);
  renderAllWishlistedVariants({ variants, pageNumber });

  renderWishlistPagePaginationButtons({
    pageNumber,
    totalVariantsCount,
    pageSize: PER_PAGE_PAGINATION_LIMIT,
  });
};

window.appInitializer = () => {
  scrollToTopWishlistedVariants();
  fetchWishlistedVariants({ cb: renderWishlistPage });
};
