window.fetchStoreCategoriesInit = null;
window.categoryList = [];

// blogs fetch
window.blogPageNumber = 1;
window.fetchBlogs = () => {
  const fetchUrl = `${window.DukaanData.CLIENT_API_ENDPOINT}/api/store/buyer/${window.DukaanData.DUKAAN_STORE.link}/blogs/?page=${blogPageNumber}`;

  fetch(fetchUrl, {
    method: 'get',
    headers: {
      'Content-Type': 'application/json',
      'x-requested-with': window?.DukaanData?.DUKAAN_SESSION_ID,
    },
  })
    .then((res) => res.json())
    .then((res) => {
      if (res && res.results.length > 0) {
        const blogs = res?.results.splice(0, 4) || [];
        renderBlogsList(blogs);
        document.querySelector('#blog-listing-home').classList.remove('d-none');
      }
    })
    .catch((e) => console.log(e));
};

// blogs renderer
window.renderBlogsList = (blogs) => {
  const blogsListWrapper = document.querySelector('.blogs-card-container');
  const blogCardTemplate = document.getElementById('blog-card');
  const shimmerElems = document.querySelectorAll('.blog-card-shimmer');
  if (shimmerElems) {
    shimmerElems.forEach((elem) => elem.remove());
  }

  blogs?.forEach((blog) => {
    const blogCard = document.importNode(blogCardTemplate.content, true);
    const { title, featured_image, content, link } = blog;
    const imageSource =
      featured_image ||
      'https://api-enterprise.mydukaan.io/static/images/category-def.jpg';
    const blogUrl = `${DukaanData.DUKAAN_BASE_URL}/blog/${link}`;
    blogCard.querySelector('.read-more').setAttribute('href', `${blogUrl}`);
    blogCard
      .querySelector('.blog-image img')
      .setAttribute('src', `${getCdnUrl(imageSource, 500)}`);
    blogCard.querySelector('.heading').textContent = title;
    const desc = blogCard.querySelector('.description');
    desc.innerHTML = content;
    const formattedDescription = desc.innerText;
    desc.innerHTML = formattedDescription;
    blogsListWrapper.appendChild(blogCard);
  });
};

document.addEventListener('DOMContentLoaded', () => {
  if (document.querySelector('#splide-banners'))
    new Splide('#splide-banners', {
      type: 'loop',
      autoplay: true,
      interval: 5000,
      arrows: false,
      breakpoints: { 768: { destroy: false } },
      pauseOnHover: false,
    }).mount();
});
document.addEventListener('DOMContentLoaded', () => {
  if (document.querySelector('#splide-mobile-banners'))
    new Splide('#splide-mobile-banners', {
      type: 'loop',
      autoplay: true,
      interval: 5000,
      arrows: false,
      breakpoints: { 768: { destroy: false } },
      pauseOnHover: false,
    }).mount();
});

window.fetchProductsFromIds = (sectionDetails, consolidatedProductIds) => {
  if (!consolidatedProductIds.length) return;

  const payload = {
    category_ids: [],
    offset: 0,
    page_size: 500,
    product_ids: consolidatedProductIds,
  };

  const promise = [
    fetch(
      `${window.DukaanData.DUKAAN_ADVANCED_SEARCH_API_BASE_URL}/api/advanced-search/${window.DukaanData.DUKAAN_STORE.id}/`,
      {
        method: 'post',
        body: JSON.stringify({ ...payload }),
        headers: {
          'Content-Type': 'application/json',
          'x-requested-with': window?.DukaanData?.DUKAAN_SESSION_ID,
          // 'Content-Type': 'application/x-www-form-urlencoded',
        },
      }
    ),
  ];
  Promise.all(promise)
    .then((res) => Promise.all(res.map((r) => r.json())))
    .then((res) => {
      if (res && res.length > 0) {
        const products = [];
        res.forEach((el) => {
          products.push(...el.data.products);
        });

        DukaanData.PRODUCTS_MAP = {
          ...DukaanData.PRODUCTS_MAP,
          ...products.reduce((map, product) => {
            const serializedSKUs = serializeSKUs(product.skus || []);
            const attributes = getAllProductAttributeValues(serializedSKUs);
            map[product.uuid] = {
              ...product,
              skus: serializedSKUs,
              attributes,
            };
            return map;
          }, {}),
        };

        sectionDetails.forEach((section) => {
          const sectionElm = document.querySelector(
            `.home-page-section[data-key='${section.key}']`
          );
          sectionElm.classList.remove('d-none');

          const mountElem = sectionElm.querySelector(
            `category-product-list-load-point`
          );

          const filteredProducts = products?.filter((el) =>
            section.value.includes(el.id.toString())
          );
          mountElem.innerHTML = '';
          renderCategoryProducts(mountElem, filteredProducts);

          renderProductCardSplide(
            document.querySelectorAll('.splide-category-product-list-home')
            // filteredProducts.length
          );
        });
      }
      // else {
      //   renderCategoryProducts(null, []);
      // }
    })
    .catch((err) => {
      // console.log(err);
      // renderCategoryProductList([]);
    });
};

window.fetchCategoriesFromIds = (
  sectionDetails,
  consolidatedCategoryIds,
  isBigCategoryCard
) => {
  if (!consolidatedCategoryIds.length) return;

  const payload = consolidatedCategoryIds.map((el) => +el);

  fetch(
    `${window.DukaanData.CLIENT_API_ENDPOINT}/api/product/buyer/category/retrieve-categories-details-from-categories-id/`,
    {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'x-requested-with': window?.DukaanData?.DUKAAN_SESSION_ID,
        // 'Content-Type': 'application/x-www-form-urlencoded',
      },
      body: JSON.stringify({ categories_ids: payload }),
    }
  )
    .then((res) => res.json())
    .then((res) => {
      if (res && res.data.length > 0) {
        const products = res.data;
        DukaanData.PRODUCTS_MAP = {
          ...DukaanData.PRODUCTS_MAP,
          ...products.reduce((map, product) => {
            const serializedSKUs = serializeSKUs(product.skus || []);
            const attributes = getAllProductAttributeValues(serializedSKUs);
            map[product.uuid] = {
              ...product,
              skus: serializedSKUs,
              attributes,
            };
            return map;
          }, {}),
        };

        if (isBigCategoryCard) {
          sectionDetails.forEach((section) => {
            const mountElem = document.querySelector(
              `.home-page-section[data-key='${section.key}'] big-card-category-load-point`
            );

            mountElem.classList.remove('d-none');

            const filteredCategories = products?.filter((el) =>
              section.value.includes(el.id.toString())
            );

            const filteredCategoriesWithoutDuplicates =
              filteredCategories?.filter(
                (x, i, arr) => arr.findIndex((y) => y.id === x.id) === i
              );

            const options = { templateId: 'big-card-category' };
            renderCategoryList(
              filteredCategoriesWithoutDuplicates,
              null,
              true,
              'big-card-category-load-point.homepage-bigcard-category-list',
              options
            );
          });
        } else {
          sectionDetails.forEach((section) => {
            const mountElem = document.querySelector(
              `.home-page-section[data-key='${section.key}'] category-list-load-point`
            );

            mountElem.classList.remove('d-none');

            const filteredCategories = products?.filter((el) =>
              section.value.includes(el.id.toString())
            );

            const options = { wrapperId: 'home-category-card-wrapper' };
            renderCategoryList(
              filteredCategories,
              null,
              true,
              'category-list-load-point.homepage-category-list',
              options
            );
          });

          console.log(filteredCategories);

          renderProductCardSplide(
            document.querySelectorAll('.splide-category-product-list-home')
            // filteredCategories.length
          );
        }
      }
      // else {
      //   renderCategoryProducts(null, []);
      // }
    })
    .catch((err) => {
      // console.log(err);
      // renderCategoryProductList([]);
    });
};

window.appInitializer = () => {
  druidStorePageView();
  const homePageSection = document.querySelectorAll('.home-page-section');
  const consolidatedProductIds = [];
  const consolidatedCategoryIds = [];
  const consolidatedBigCardCategoryIds = [];

  const productSectionDetails = [];
  const categorySectionDetails = [];
  const bigCardCategorySectionDetails = [];
  let brandMaxCount = 0;
  // initially mounting splide for shimmers
  renderProductCardSplide(
    document.querySelectorAll('.splide-category-product-list-home')
  );

  homePageSection.forEach((section) => {
    const sectionKey = section.dataset?.key.split(' ')[0].toLowerCase() || null;

    if (sectionKey === 'top') {
      const categoryIds =
        section.dataset?.ids?.split(',')?.filter((n) => n) || [];
      consolidatedCategoryIds.push(...categoryIds);

      categorySectionDetails.push({
        count: categoryIds?.length || 0,
        key: section.dataset?.key,
        value: categoryIds,
      });
    }

    if (sectionKey === 'category') {
      const categoryIds =
        section.dataset?.ids?.split(',')?.filter((n) => n) || [];
      consolidatedBigCardCategoryIds.push(...categoryIds);

      bigCardCategorySectionDetails.push({
        count: categoryIds?.length || 0,
        key: section.dataset?.key,
        value: categoryIds,
      });
    }

    if (sectionKey === 'product') {
      const productIds =
        section.dataset?.ids?.split(',')?.filter((n) => n) || [];
      consolidatedProductIds.push(...productIds);

      productSectionDetails.push({
        count: productIds?.length || 0,
        key: section.dataset?.key,
        value: productIds,
      });
    }

    if (sectionKey === 'brands') {
      brandMaxCount = section.dataset?.maxcount;
    }
  });

  fetchProductsFromIds(productSectionDetails, consolidatedProductIds);

  // for normal category
  fetchCategoriesFromIds(categorySectionDetails, consolidatedCategoryIds);

  // for big card category
  fetchCategoriesFromIds(
    bigCardCategorySectionDetails,
    consolidatedBigCardCategoryIds,
    true
  );

  fetchBlogs();

  // fetch top brands fn
  fetchTopBrands({
    cb: renderTopBrands,
    loadPoint: 'brands-list-load-point',
    brandMaxCount,
  });

  // rendering first section
  // document.querySelector('[data-aos]').classList.add('aos-animate');
};
