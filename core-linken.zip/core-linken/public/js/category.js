window.toggleSortbyDropdown = () => {
  document.getElementById('sortby-dropdown').classList.toggle('d-none');
  document.body.style.overflow =
    document.body.style.overflow === 'hidden' ? 'auto' : 'hidden';
  document
    .querySelector('.custom-dropdown svg')
    .classList.toggle('open-arrow-state');
};

window.closeSortbyDropdown = () => {
  document.getElementById('sortby-dropdown').classList.add('d-none');
  document.body.style.overflow =
    document.body.style.overflow === 'hidden' ? 'auto' : 'hidden';
  document
    .querySelector('.custom-dropdown svg')
    .classList.remove('open-arrow-state');
};

window.sortDropDownHandler = (sortByValue) => {
  const dropdownLabel = document.querySelector(
    `.advance-filter__radio-container[value="${sortByValue}"] ~ .dropdown-label `
  );
  document.querySelector('.sortby-value').textContent =
    dropdownLabel.textContent;

  document
    .querySelector('.sort-radio-button.checked')
    ?.classList.remove('checked');

  document
    .querySelector(`.advance-filter__radio-container[value="${sortByValue}"]`)
    .setAttribute('checked', true);

  toggleSortbyDropdown();
};

// close dropdown on clicking outside..
const specifiedElement = document.querySelector('.custom-dropdown');
document.addEventListener('click', (event) => {
  const isClickInside = specifiedElement.contains(event.target);
  if (
    !isClickInside &&
    document.body.style.overflow === 'hidden' &&
    !document.querySelector('.sort-by-dropdown.hidden')
  )
    closeSortbyDropdown();
});

window.customAdvanceFiltersConfig = {
  pagination: false,
  observerId: 'advance-filters-product-list-observer',
  renderSearchField: true,
  countForShowingSearchField: 10,
  showOutOfStockProducts: true,
  pushOosProductsToBottom: true,
  searchFields: ['product_name'],
};
