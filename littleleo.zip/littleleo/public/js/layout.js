window.showMenuDropdown = (event, parentId, index) => {
  const { target } = event;
  if (index === '0') {
    q$.selectAll(`.second-menu-item-list ul.menu-items-list`).addClassAll(
      'hidden'
    );
    q$.selectAll(`.third-menu-item-list ul.menu-items-list`).addClassAll(
      'hidden'
    );
    q$.selectAll(`.first-menu-item-list ul li`).removeClassAll(
      'active-nav-item'
    );
    q$.selectAll(`.second-menu-item-list ul li`).removeClassAll(
      'active-nav-item'
    );
    q$.selectAll(`.third-menu-item-list ul li`).removeClassAll(
      'active-nav-item'
    );
  } else if (index === '1') {
    q$.selectAll(`.third-menu-item-list ul.menu-items-list`).addClassAll(
      'hidden'
    );
    q$.selectAll(`.second-menu-item-list ul li`).removeClassAll(
      'active-nav-item'
    );
    q$.selectAll(`.third-menu-item-list ul li`).removeClassAll(
      'active-nav-item'
    );
  } else if (index === '2') {
    q$.selectAll(`.third-menu-item-list ul li`).removeClassAll(
      'active-nav-item'
    );
  }
  target.classList.add('active-nav-item');
  q$.select(
    `ul.menu-items-list[data-parent-dropdown-id="${parentId}"]`
  ).removeClass('hidden');
};

window.addEventListener('DOMContentLoaded', () => {
  axios
    .get(
      `https://apps.mydukaan.io/public/v2/apps/store/${DukaanData.DUKAAN_STORE.id}/`
    )
    .then((response) => {
      const { store_apps_list: appList } = response.data;
      const availablePlugins = appList?.reduce((acc, item) => {
        if (item.isActive) {
          // eslint-disable-next-line no-underscore-dangle
          acc[item._id] = item;
        }
        return acc;
      }, {});
      const isStoreLocatorPresent = Boolean(
        !!availablePlugins && availablePlugins[APP_IDS.STORE_LOCATOR]
      );
      const storeLocatorTags = document.querySelectorAll('.store-locator-link');
      if (isStoreLocatorPresent) {
        storeLocatorTags.forEach((tag) => tag.classList.remove('hidden'));
      } else {
        storeLocatorTags.forEach((tag) => tag.remove());
      }
    })
    .finally(() => {
      const menuItems = document.querySelectorAll(
        '.menu-dropdown:not(.menu-dropdown__button)'
      );
      const mainMenu = document.querySelector('.menu-main');
      const mainMenuWidth = mainMenu.offsetWidth;
      let menuWidth = 0;
      let i = 0;
      for (i = 0; i < menuItems.length; i += 1) {
        menuWidth += menuItems[i].offsetWidth + 24;
        if (
          menuWidth >=
          mainMenuWidth -
            document.querySelector('.menu-dropdown__button').offsetWidth
        ) {
          document.fonts.ready.then(() => {
            document
              .querySelector('.menu-dropdown__button')
              .classList.remove('hidden');
          });
          break;
        }
      }
    })
    .catch(() => {});
});
window.addEventListener('DOMContentLoaded', () => {
  const menuItems = document.querySelectorAll(
    '.menu-dropdown:not(.menu-dropdown__button)'
  );

  let i = 0;
  for (i = 0; i < menuItems.length; i += 1) {
    menuItems[i].addEventListener('mouseenter', (event) => {
      document.querySelectorAll('.menu-drop-ul')?.forEach((el) => {
        el?.classList.add('hidden');
      });
      const { target: parentMenuItem } = event;
      const menuId = parentMenuItem.dataset.menuId || '';
      const menuDropDown = document.getElementById(menuId);
      if (menuDropDown) {
        menuDropDown.classList.remove('hidden');
        menuDropDown.style.position = 'absolute';
        menuDropDown.style.top = '100%';
        if (!menuDropDown.classList.contains('overflow-menu-container')) {
          menuDropDown.style.left = `${
            parentMenuItem.getBoundingClientRect().left
          }px`;
        }
      }
      document.addEventListener('mousemove', (e) => {
        const { target: hoverTarget } = e;
        const mainHeader = document.querySelector('.header-main');
        if (
          !(
            menuDropDown?.contains(hoverTarget) ||
            mainHeader?.contains(hoverTarget)
          )
        ) {
          menuDropDown?.classList?.add('hidden');
          document.removeEventListener('mousemove', () => {}, true);
        }
      });
    });
  }
});
window.commonInitializer = () => {
  window.HISTORY_STORAGE_KEY = `v3-${window.DukaanData.DUKAAN_STORE.link}-search-history`;
  toggleCouponFooter();
  navContainerHandler();
  GAPage();
  // new mega menu fn
  initSidebarMenuItems();
};

window.navContainerHandler = async () => {
  const navLinksDiv = document.getElementById('navLinksDiv');
  if (!navLinksDiv) return;

  const navLinksDivWidth = document.getElementById('navLinksDiv')?.clientWidth;
  const navLinksUlWidth = document.getElementById('navLinksUl')?.scrollWidth;
  if (navLinksUlWidth > navLinksDivWidth && navLinksDiv.offsetHeight > 0) {
    const ready = await document.fonts.ready;
    if (ready) {
      const hamburgerMenu = document.getElementById('ham-icon');
      hamburgerMenu.classList.remove('hidden');
    }
  } else {
    const hamburgerMenu = document.getElementById('ham-icon');
    hamburgerMenu.classList.add('hidden');
  }
};

window.handleVariantChange = (productUUID) => {
  const element = document.querySelector('product-variant-selection-modal');
  const addToBagElement = element.querySelector('add-to-bag-button');
  const buyNowElement = element.querySelector('buy-now-button-load-point');
  const formData = new FormData(
    element.querySelector('form#variant-selection')
  );
  const data = [...formData.entries()].reduce((acc, [key, value]) => {
    if (key === 'addon') {
      if (acc[key]) {
        acc[key].push(value);
      } else {
        acc[key] = [value];
      }
    } else {
      acc[key] = value;
    }

    return acc;
  }, {});

  const product = DukaanData.PRODUCTS_MAP[productUUID];
  const { skus } = product;
  const currentSKU = skus.find(
    (sku) =>
      (!data.size || sku.meta.size.value === data.size) &&
      (!data.color || sku.meta.color.value === data.color)
  );
  if (!currentSKU) return;

  if (data.color) {
    const { isLight } = colorLightOrDark(data.color);
    document.documentElement.style.setProperty(
      '--tick-color',
      isLight ? '#1a181e' : '#ffffff'
    );
  }

  const sizeItem = element.querySelector(`label[for='m-size-${data.size}']`);

  if (sizeItem) {
    sizeItem.querySelector('input').checked = true;
    sizeItem.querySelector('.size-selling-price').textContent = formatMoney(
      currentSKU.selling_price
    );
    if (currentSKU.selling_price < currentSKU.original_price) {
      sizeItem.querySelector('.size-original-price').classList.remove('hidden');
      sizeItem.querySelector('.size-original-price').textContent = formatMoney(
        currentSKU.original_price
      );
    } else {
      sizeItem.querySelector('.size-original-price').classList.add('hidden');
    }
  }

  addToBagElement.dataset.productUuid = productUUID;
  addToBagElement.dataset.skuUuid = currentSKU.uuid;
  addToBagElement.dataset.addOns = data?.addon?.join(',');
  addToBagButtonRenderer(addToBagElement);

  if (buyNowElement) {
    buyNowElement.dataset.productUuid = productUUID;
    buyNowElement.dataset.skuUuid = currentSKU.uuid;
    buyNowElement.dataset.addOns = data?.addon?.join(',');
    buyNowButtonRenderer(buyNowElement);
  }
};

window.APP_IDS = {
  ...(window.APP_IDS || {}),
  STORE_LOCATOR: '6286104b4f1ca25e2256f6b7',
};

window.addEventListener('load', () => {
  axios
    .get(
      `https://apps.mydukaan.io/public/v2/apps/store/${DukaanData.DUKAAN_STORE.id}/`
    )
    .then((response) => {
      const { store_apps_list: appList } = response?.data || [];
      const availablePlugins = appList?.reduce((acc, item) => {
        if (item.isActive) {
          const { _id: id } = item;
          acc[id] = item;
        }
        return acc;
      }, {});
      const isStoreLocatorPresent = Boolean(
        !!availablePlugins && availablePlugins[APP_IDS.STORE_LOCATOR]
      );
      const storeLocatorTags = document.querySelectorAll('.store-locator-link');
      if (isStoreLocatorPresent) {
        storeLocatorTags.forEach((tag) => tag.classList.remove('hidden'));
      } else {
        storeLocatorTags.forEach((tag) => tag.remove());
      }
    });
});

window.getCustomDiscountText = (discount) => `${discount}% OFF`;

window.productCardAdditionalRenderer = (productCard) => {
  if (DukaanData.DUKAAN_STORE.store_category === 6) {
    window.q$
      .select('.dkn-product-card-item-unit', productCard)
      .addClass('hidden');
  } else {
    window.q$
      .select('.dkn-product-card-description', productCard)
      .addClass('hidden');
  }
};

window.handleModalChanges = (product, currentSKU) => {
  const isResto = DukaanData.DUKAAN_STORE.store_category === 6;
  const element = document.querySelector('product-variant-selection-modal');
  if (!element) return;
  const { name, image, description } = product;
  const { selling_price: sellingPrice, original_price: originalPrice } =
    currentSKU;

  if (product?.meta?.length > 0) {
    const foodIcon = getFoodTypeIcon(product?.meta);
    q$.select('.dkn-food-type-icon', element)
      .modifyInnerHTML(foodIcon)
      .removeClass('hidden');
  }
  const discount = getDiscountPercentValue(sellingPrice, originalPrice);
  q$.select('.dkn-product-name', element).modifyTextContent(name);
  q$.select('.dkn-product-selling-price', element).modifyTextContent(
    formatMoney(sellingPrice)
  );
  q$.select('.dkn-product-image', element).setAttribute(
    'src',
    `${getCdnUrl(
      image ||
        `${window.DukaanData.ENTERPRISE_API_ENDPOINT}/static/images/category-def.jpg`,
      100
    )}`
  );
  if (discount > 0) {
    q$.select('.dkn-product-original-price', element)
      .modifyTextContent(formatMoney(originalPrice))
      .removeClass('hidden');
    q$.select('.dkn-product-discount', element)
      .modifyTextContent(`(${discount}% OFF)`)
      .removeClass('hidden');
  } else {
    q$.select('.dkn-product-original-price', element).addClass('hidden');
    q$.select('.dkn-product-discount', element).addClass('hidden');
  }

  if (isResto && description) {
    const santizedDescription = HtmlSanitizer?.SanitizeHtml(description);
    q$.select('.dkn-product-description', element)
      .modifyInnerHTML(santizedDescription)
      .removeClass('hidden');
  } else {
    q$.select('.dkn-product-description', element).addClass('hidden');
  }
};

window.couponPageProductCardTemplateId = 'product-card-template';
