window.appInitializer = () => {
  hashProductMap(window.DukaanData.DUKAAN_CATALOG);
  fetchCouponsAndOffersOnIndex();

  window.HEADER_HEIGHT = 84;
  window.MENU_HEIGHT = DukaanData.STORE_MENU.length > 0 ? 48 : 0;
  window.ALL_CATEGORY_HEIGHT = -16;
  document.documentElement.style.setProperty(
    '--header-height',
    `${window.HEADER_HEIGHT}px`
  );
  document.documentElement.style.setProperty(
    '--menu-height',
    `${window.MENU_HEIGHT}px`
  );
  document.documentElement.style.setProperty(
    '--all-category-height',
    `${window.ALL_CATEGORY_HEIGHT}px`
  );

  fetchProductCoupons(getProductIdsFromCategories(DukaanData.DUKAAN_CATALOG));

  const categorySideBarItemsRenderer = (mountElem, categoriesList) => {
    const categorySidebarItemTemplate = document.getElementById(
      'categories-sidebar-item-template'
    );
    categoriesList.forEach((category) => {
      const categorySidebarItemCard = document.importNode(
        categorySidebarItemTemplate.content,
        true
      );
      categorySidebarItemCard.querySelector(
        '[data-category-sidebar-item-name]'
      ).textContent = category.name;
      categorySidebarItemCard.querySelector(
        '[data-category-sidebar-item-count]'
      ).textContent = `(${category.product_count})`;
      categorySidebarItemCard
        .querySelector('[data-category-item-name-id]')
        .setAttribute('name', category.uuid);
      categorySidebarItemCard
        .querySelector('[data-category-item-scroll-click]')
        .setAttribute(
          'onclick',
          `handleClickScroll(event, '${category.uuid}')`
        );
      mountElem.appendChild(categorySidebarItemCard);
    });
  };

  const categoryDrodpDownItemsRenderer = (mountElem, categoriesList) => {
    const categorySidebarItemTemplate = document.getElementById(
      'categories-dropdown-item-template'
    );
    categoriesList.forEach((category) => {
      const categorySidebarItemCard = document.importNode(
        categorySidebarItemTemplate.content,
        true
      );
      categorySidebarItemCard.querySelector(
        '[data-category-sidebar-item-name]'
      ).textContent = category.name;
      categorySidebarItemCard.querySelector(
        '[data-category-sidebar-item-count]'
      ).textContent = category.product_count;
      categorySidebarItemCard
        .querySelector('[data-category-item-name-id]')
        .setAttribute('name', category.uuid);
      categorySidebarItemCard
        .querySelector('[data-category-item-scroll-click]')
        .setAttribute(
          'onclick',
          `handleClickScroll(event, '${category.uuid}')`
        );

      mountElem.appendChild(categorySidebarItemCard);
    });
  };

  const renderCategorySideBarItems = (categoriesList) => {
    customTag('category-sidebar-item-load-point', (element) => {
      categorySideBarItemsRenderer(element, categoriesList);
    });
  };

  const renderCategoryDropdownItems = (categoriesList) => {
    customTag('category-dropdown-items-load-point', (element) => {
      categoryDrodpDownItemsRenderer(element, categoriesList);
    });
  };

  let loading = false;
  const offsetCount = DukaanData.DUKAAN_CATALOG_PROPS.offset;
  let { offset } = DukaanData.DUKAAN_CATALOG_PROPS;
  const offsetHardCut = DukaanData.DUKAAN_CATALOG_PROPS.maxCount;
  let hasMore = true;
  let observerApplied = false;

  const endFetchCallCommon = () => {
    document
      .querySelectorAll('category-sidebar-item-load-point .shimmer')
      .forEach((el) => el.remove());
    document
      .querySelector(
        'category-sidebar-item-load-point > .categories-sidebar-item'
      )
      .classList.add('active');
    window.addEventListener('scroll', handleScroll, false);
    window.addEventListener('scroll', handleCategoryButtonScroll, true);
  };

  const fetchBestSellers = async () => {
    if (loading) return;
    loading = true;
    const response = await fetch(
      `${window.DukaanData.CLIENT_API2_ENDPOINT}/api/store/buyer/${window.DukaanData.DUKAAN_STORE.link}/bestseller/v3/?offset=${offset}`
    );
    const res = await response?.json();
    const { results: rawResults = [] } = res || {};
    const count = rawResults?.length;
    const results = rawResults?.filter((rR) => rR.products.length > 0);
    hashProductMap(results);
    hashCategory(results);
    renderBestSellers(results, 9);
    renderCategorySideBarItems(results);
    renderCategoryDropdownItems(results);
    // fetchProductCoupons(getProductIdsFromCategories(results));

    if (!observerApplied) {
      if (offset < offsetHardCut) {
        if (count < offsetCount) {
          endFetchCallCommon();
          hasMore = false;
          if (observerApplied)
            removeScroller({ observeThis: 'bestseller-observer' });
          return;
        }
        hasMore = true;
        offset += offsetCount;
        loading = false;
        fetchBestSellers();
      } else {
        endFetchCallCommon();
        if (count < offsetCount) {
          hasMore = false;
          if (observerApplied)
            removeScroller({ observeThis: 'bestseller-observer' });
        } else {
          applyObserverCall();
        }
      }
    } else if (count < offsetCount) {
      hasMore = false;
      if (observerApplied)
        removeScroller({ observeThis: 'bestseller-observer' });
    } else {
      hasMore = true;
      offset += offsetCount;
      loading = false;
    }

    loading = false;
  };

  const applyObserverCall = () => {
    observerApplied = true;
    applyScroller({
      loading,
      hasMore,
      cb: fetchBestSellers,
      observeThis: 'bestseller-observer',
      loadPoint: document.querySelector('best-seller-load-point'),
    });
  };

  const handleCategoryButtonScroll = (event) => {
    const elem = document.querySelector('.mobileCategoriesList');
    if (elem !== undefined && elem !== null) {
      if (
        event.target.querySelector('body') &&
        event.target.querySelector('body').getBoundingClientRect().top > -100
      ) {
        elem.querySelector('.categoriesButton').classList.add('active');
      } else {
        elem.querySelector('.categoriesButton').classList.remove('active');
      }
    }
  };

  renderCategorySideBarItems(
    DukaanData.DUKAAN_CATALOG.filter((category) => category.products.length > 0)
  );

  fetchBestSellers().then(() => rightArrowShow());
  druidStorePageView();
};

window.renderCategoryButtonItems = (popoverElem) => {
  const categories = [...DukaanData.DUKAAN_CATALOG];
  const categoryTemplate = document.getElementById(
    'category-button-item-template'
  );
  const mountElem = popoverElem.querySelector(
    'category-button-items-load-point'
  );
  mountElem.replaceChildren();
  if (!!categoryTemplate && !!mountElem)
    categories.forEach((category) => {
      const categoryCard = document.importNode(categoryTemplate.content, true);
      if (categoryCard) {
        categoryCard
          .querySelector('[data-category-button-category-href')
          .setAttribute('href', `#${category.uuid}`);
        categoryCard
          .querySelector('[data-category-item-scroll-click]')
          .setAttribute(
            'onclick',
            `closeCategoryList(event, '${category.uuid}')`
          );
        categoryCard.querySelector(
          '[data-category-button-category-name'
        ).textContent = category.name;
        categoryCard.querySelector(
          '[data-category-button-product-count'
        ).textContent = category.product_count;
      }
      mountElem.appendChild(categoryCard);
    });
};

window.openCategoryList = () => {
  const popoverElement = document.getElementById('categoryPopupWrapper');
  popoverElement.replaceChildren();
  const popup = document.getElementById('category-popup');
  const item = document.importNode(popup.content, true);
  renderCategoryButtonItems(item);
  popoverElement.appendChild(item);
  document.body.style.overflow = 'hidden';
};

window.closeCategoryList = (event, categoryUUID) => {
  const popoverModal = document.getElementById('popover-modal');
  popoverModal.classList.add('display-none');
  document.body.style.overflow = 'initial';
  window.handleClickScroll(event, categoryUUID);
};

window.handleScroll = () => {
  const elems = document.querySelectorAll('.category-section');
  elems?.forEach((elem) => {
    if (
      elem.getBoundingClientRect().top <
      window.HEADER_HEIGHT + window.MENU_HEIGHT + window.ALL_CATEGORY_HEIGHT
    ) {
      const uuid = elem?.attributes?.id?.value;
      const catListEl = document.getElementsByName(uuid);
      const target = document.getElementById('categoryListStickyID');
      document
        .querySelectorAll('.categories-sidebar-item')
        .forEach((el) => el.classList.remove('active'));
      document
        .querySelectorAll('.categories-dropdown-item')
        .forEach((el) => el.classList.remove('active'));
      catListEl.forEach((el) => el.classList.add('active'));
      target?.scrollTo(catListEl[1].offsetLeft - 200, 0);
      if (target?.scrollLeft > 50) {
        document.querySelector('.leftIcon').classList.remove('hidden');
      } else {
        document.querySelector('.leftIcon').classList.add('hidden');
      }

      rightArrowShow();
    }
  });
};

window.handleClickScroll = (e, uuid) => {
  e.preventDefault();
  // toggle chevron only when item is clicked from the dropdown values
  const dropdownElem = document.querySelector('.category-dropdown');
  if (!dropdownElem.classList.contains('hidden')) {
    document.querySelector('.categorySvgDown').classList.toggle('hidden');
    document.querySelector('.categorySvgUp').classList.toggle('hidden');
  }

  const position =
    document.getElementById(uuid).offsetTop -
    (window.HEADER_HEIGHT +
      window.MENU_HEIGHT +
      window.ALL_CATEGORY_HEIGHT -
      1);
  window.scrollTo({
    top: position,
    behavior: 'smooth',
  });
};

window.handleShowAllCategoryDropdown = (event) => {
  event.stopPropagation();
  const elem = document.querySelector('.category-dropdown');

  document.querySelector('.categorySvgDown').classList.toggle('hidden');
  document.querySelector('.categorySvgUp').classList.toggle('hidden');

  elem.classList.toggle('hidden');
  document.body.addEventListener('click', () => {
    elem.classList.add('hidden');
  });
};
window.rightArrowShow = () => {
  const categoryContainer = document.querySelector('.category');
  const categories = document.getElementById('categoryListStickyID');
  const allCategories = document.querySelector('.allCategories');

  if (
    categories.scrollWidth + allCategories.clientWidth >
    categoryContainer.clientWidth
  ) {
    document.querySelector('.rightIcon').classList.remove('hidden');
  } else {
    document.querySelector('.rightIcon').classList.add('hidden');
  }
};
window.handleright = () => {
  const target = document.getElementById('categoryListStickyID');
  const width = target.clientWidth - 200;
  target.scrollBy({ left: width, behavior: 'smooth' });
  document.querySelector('.leftIcon').classList.remove('hidden');
};

window.handleleft = () => {
  const target = document.getElementById('categoryListStickyID');
  target.scrollTo({ left: 0, behavior: 'smooth' });
  document.querySelector('.leftIcon').classList.add('hidden');
};
