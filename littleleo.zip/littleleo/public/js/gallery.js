window.appInitializer = () => {
  const currentUrl = window.location.href;
  if (currentUrl.includes('gallery')) {
    document.querySelector('.active-home').classList.add('hidden');
    document.querySelector('.disable-home').classList.remove('hidden');
    document.querySelector('.bottom-active').style.color = '#999999';
  }
};

window.openGallery = (e) => {
  document.getElementById('gallery-modal').classList.remove('hidden');
  const imgUrl = e.querySelector('img').src;
  const imgWrapper = document.querySelectorAll('.splide-images');
  const homePageImg = document.querySelectorAll('.secondaryImgBanner');

  let imgIndex = 0;

  for (let i = 0; i < imgWrapper.length; i += 1) {
    if (imgWrapper[i].src === imgUrl) {
      imgIndex = i;
    }
  }

  for (let i = 0; i < homePageImg.length; i += 1) {
    if (homePageImg[i].src === imgUrl) {
      imgIndex = i + 1;
    }
  }

  const main = new Splide('#main-carousel', {
    type: 'fade',
    rewind: true,
    pagination: false,
    arrows: true,
    start: imgIndex,
  });

  const thumbnails = new Splide('#thumbnail-carousel', {
    fixedWidth: 64,
    fixedHeight: 64,
    gap: 4,
    rewind: true,
    start: imgIndex,
    pagination: false,
    isNavigation: true,
    arrows: false,
    breakpoints: {
      600: {
        fixedWidth: 40,
        fixedHeight: 40,
      },
    },
  });

  main.sync(thumbnails);
  main.mount();
  thumbnails.mount();

  window.closeGallery = () => {
    document.getElementById('gallery-modal').classList.add('hidden');
    main.destroy();
    thumbnails.destroy();
  };
};
