window.categoryNavButton = document.querySelector('[data-button="categories"]');
if (categoryNavButton) {
  categoryNavButton.classList?.add('active');
  categoryNavButton.querySelector('.not-active-svg')?.classList.add('hidden');
  categoryNavButton.querySelector('.active-svg')?.classList.remove('hidden');
}

window.renderCategoriesList = (categories, nextUrl, firstFetch) => {
  if (categories?.length === 0 && firstFetch) {
    document
      .getElementById('main-categories-container')
      .classList.add('hidden');
    document.getElementById('no-categories-found').classList.remove('hidden');
    return;
  }
  customTag('categories-list-template', (element) =>
    categoriesRenderer(element, categories, nextUrl)
  );
};

window.categoriesRenderer = (mountElement, categories, nextUrl) => {
  document
    .querySelectorAll('.category-list-shimmer-item')
    ?.forEach((el) => el.remove());

  const categoryCardTemplate = document.getElementById(
    'categories-card-template'
  );

  categories.forEach((category) => {
    const categoryCard = document.importNode(
      categoryCardTemplate.content,
      true
    );

    const categoryUrl = `${DukaanData.DUKAAN_BASE_URL}/categories/${category.slug}`;
    // if (category.subcategories_count > 0) {
    //   categoryUrl = `${categoryUrl}/subcategories`;
    // }

    categoryCard
      .querySelectorAll('a')
      .forEach((el) => el.setAttribute('href', categoryUrl));

    categoryCard
      .querySelector('.product-category-image img')
      .setAttribute('src', `${getCdnUrl(category.image, 250)}`);
    categoryCard.querySelector('.product-category-name').textContent =
      category.name;

    mountElement.appendChild(categoryCard);
  });

  const currentEventObserver = document.getElementById(
    'categories-list-observer'
  );

  if (nextUrl) {
    if (currentEventObserver) {
      currentEventObserver?.remove();
    }

    const newObserverElement = document.createElement('div');
    newObserverElement.setAttribute('id', 'categories-list-observer');
    mountElement.appendChild(newObserverElement);

    const observerElement = document.getElementById('categories-list-observer');

    const observer = new IntersectionObserver(
      (entries) => {
        if (entries[0].isIntersecting) {
          // renderShimmer(
          //   'categories-list-template',
          //   'categories-card-shimmer',
          //   9,
          // );
          fetchStoreCategoriesInit({ nextUrl, cb: renderCategoriesList });
        }
      },
      {
        threshold: 1,
      }
    );
    observer.observe(observerElement);
  } else {
    currentEventObserver?.remove();
  }
};

window.fetchStoreCategoriesInit = null;

window.appInitializer = () => {
  fetchStoreCategoriesInit = fetchStoreCategories();
  fetchStoreCategoriesInit({ cb: renderCategoriesList, firstFetch: true });
};
