window.SIMILAR_PRODUCT_LIMIT = 0;
window.splideCarousel = null;
window.thumbnailSplide = null;

window.scrollToSKUImage = (activeSKU) => {
  const primaryImage = activeSKU?.primary_image;
  const allImages = DukaanData?.DUKAAN_PRODUCT?.all_images;
  if (allImages?.length && splideCarousel && thumbnailSplide) {
    const index = allImages?.indexOf(primaryImage);
    if (index >= 0) {
      window?.splideCarousel?.go(index);
      window?.thumbnailSplide?.go(index);
    }
  }
};

window.appInitializer = () => {
  const { isMobile } = deviceType();
  SIMILAR_PRODUCT_LIMIT = isMobile ? 6 : 12;

  const productFromServer = DukaanData.DUKAAN_PRODUCT;
  const serializedSKUs = serializeSKUs(productFromServer.skus || []);
  const attributes = getAllProductAttributeValues(serializedSKUs);
  const product = {
    ...productFromServer,
    skus: serializedSKUs,
    attributes,
  };
  window.DukaanData.PRODUCTS_DETAILS = product;
  window.DukaanData.PRODUCTS_MAP = {
    ...(DukaanData.PRODUCTS_MAP || []),
    [product.uuid]: product,
  };
  productPageCommonFnCalls(product);

  /** Product Slider JS * */

  window.splideCarousel = new Splide('#main-carousel', {
    pagination: false,
    arrows: false,
  });
  splideCarousel.on('click', (e) => {
    playProductVideo(e);
  });
  if (document.querySelector('#splide-product-thumbnail')) {
    window.thumbnailSplide = new Splide('#splide-product-thumbnail', {
      type: 'slide',
      autoplay: false,
      arrows: false,
      rewind: true,
      direction: 'ltr',
      gap: 9,
      perPage: 8,
      pagination: false,
      isNavigation: true,
      updateOnMove: true,
      breakpoints: {
        768: {
          gap: 8,
          direction: 'ltr',
          arrows: false,
        },
      },
    });

    window.thumbnailSplide.on('click', () => {
      window.pauseAllProductVideos();
    });

    window?.splideCarousel?.mount();
    window?.thumbnailSplide?.mount();
    window?.splideCarousel?.sync(window.thumbnailSplide);
  }
};
