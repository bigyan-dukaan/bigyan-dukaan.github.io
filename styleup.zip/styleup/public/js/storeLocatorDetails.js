window.getMapLocation = (lat, long) =>
  `https://www.google.com/maps/search/?api=1&query=${lat}%2C${long}`;

window.renderStoreDetails = (store) => {
  document.querySelector('.store-details').classList.remove('d-none');

  const container = document.querySelector('.store-details');
  container.querySelector('.store-name').textContent =
    store.store_details.store_name;
  document.querySelector('.store-name-breadcrumb').textContent =
    store.store_details.store_name;
  container.querySelector('.store-address').textContent =
    store.store_details.store_address;
  container.querySelector(
    '.store-contact-number'
  ).innerHTML = `<a style="color: inherit;" href="tel://${store.store_details.contact_number.replace(
    '-',
    ''
  )}">
    ${store.store_details.contact_number}
  </a>`;
  container.querySelector(
    '.store-timings'
  ).textContent = `${store.store_timings[0].from_time} - ${store.store_timings[0].to_time} (Monday - sunday)`;
  container
    .querySelector('.store-location-link')
    .setAttribute(
      'href',
      `${getMapLocation(
        store.store_details.latitude,
        store.store_details.longitude
      )}`
    );
};

window.fetchStores = () => {
  const fetchUrl = `https://store-locator.apps.mydukaan.io/store/styleup`;
  fetch(fetchUrl, {
    method: 'get',
    headers: {
      'Content-Type': 'application/json',
      'x-requested-with': window?.DukaanData?.DUKAAN_SESSION_ID,
    },
  })
    .then((res) => res.json())
    .then((res) => {
      const paths = window.location.pathname.split('/');
      const storeId = paths[paths.length - 1];

      if (res && res.data && res.data.stores.length > 0) {
        const currentStore = res.data.stores.filter(
          (store) => store.document_id === storeId
        )[0];
        renderStoreDetails(currentStore);
      }
    });
};

window.appInitializer = () => {
  fetchStores();
};
