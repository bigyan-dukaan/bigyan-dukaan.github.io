// window.blogPageNumber = 1;

// const formatBlogTime = (time) => {
//   const months = [
//     'Jan',
//     'Feb',
//     'Mar',
//     'Apr',
//     'May',
//     'Jun',
//     'Jul',
//     'Aug',
//     'Sep',
//     'Oct',
//     'Nov',
//     'Dec',
//   ];
//   const date = new Date(time);
//   const yyyy = date.getFullYear();
//   let mm = months[date.getMonth()];
//   let dd = date.getDate();

//   if (dd < 10) dd = `0${dd}`;
//   if (mm < 10) mm = `0${mm}`;

//   return `${dd} ${mm} ${yyyy}`;
// };

// window.fetchAllBlogs = () => {
//   const fetchUrl = `${window.DukaanData.CLIENT_API_ENDPOINT}/api/store/buyer/${window.DukaanData.DUKAAN_STORE.link}/blogs/?page=${blogPageNumber}`;

//   fetch(fetchUrl, {
//     method: 'get',
//     headers: {
//       'Content-Type': 'application/json',
//       'x-requested-with': window?.DukaanData?.DUKAAN_SESSION_ID,
//     },
//   })
//     .then((res) => res.json())
//     .then((res) => {
//       // console.log(res);
//       const blogs = res?.results || [];
//       const next = res?.next || null;
//       renderBlogs(blogs, next);
//     })
//     .catch((e) => console.log(e));
// };

// window.renderBlogs = (blogs) => {
//   console.log(blogs);

//   const container = document.querySelector('.blogs-list-wrapper');
//   const template = document.querySelector('#blog-card-template');

//   blogs.forEach((blog) => {
//     const blogCard = document.importNode(template.content, true);
//     blogCard.querySelector('.blog-name').textContent = blog.title;
//     blogCard
//       .querySelector('.blog-image')
//       .setAttribute(
//         'src',
//         getCdnUrl(blog.featured_image)
//       );
//     blogCard.querySelector('.blog-date').textContent = formatBlogTime(
//       blog.modified_at
//     );

//     container.appendChild(blogCard);
//   });
// };

// window.appInitializer = () => {
//   fetchAllBlogs();
// };
