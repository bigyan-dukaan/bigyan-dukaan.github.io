window.STORES = [];
window.MARKERS = [];
window.mapObj = null;
window.SELECTED_STATE = '';
window.SELECTED_CITY = '';
const { isMobile } = deviceType();

// utility
window.getFilteredStores = ({ state, city }) => {
  let filteredStores = window.STORES;

  if (state) {
    filteredStores = filteredStores.filter(
      (store) =>
        store.store_details.state.toLowerCase().trim() ===
        state.toLowerCase().trim()
    );
  }

  if (city) {
    filteredStores = filteredStores.filter(
      (store) =>
        store.store_details.city.toLowerCase().trim() ===
        city.toLowerCase().trim()
    );
  }

  return filteredStores;
};

window.initTooltip = () => {
  const body = document.querySelector('body');
  const mapTooltipTemplate = document.querySelector('#map-tooltip');

  const stateTooltip = document.importNode(mapTooltipTemplate.content, true);
  stateTooltip.querySelector('div').classList.add('state-tooltip');
  const pointerTooltip = document.importNode(mapTooltipTemplate.content, true);
  pointerTooltip.querySelector('div').classList.add('pointer-tooltip');

  body.appendChild(stateTooltip);
  body.appendChild(pointerTooltip);
};

window.removeActiveClassFromMarkers = () =>
  document
    .querySelectorAll('.store-pointer-icon')
    .forEach((el) => el.classList.remove('active'));

// dom
window.handleToggleStateDropdown = () => {
  document.querySelector('#state-dropdown').classList.toggle('d-none');
};

window.handleToggleCityDropdown = () => {
  if (
    !document
      .querySelector('.filter-dropdown.city-filter .placeholder-text')
      .classList.contains('disabled')
  )
    document.querySelector('#city-dropdown').classList.toggle('d-none');
};

window.handleCloseAllDropdowns = () => {
  document.querySelector('#state-dropdown').classList.add('d-none');
  document.querySelector('#city-dropdown').classList.add('d-none');
};

window.handleCloseDropdown = (el) => {
  if (!el) return;
  el.classList.add('d-none');
};

window.handleSplideCardChange = (event) => {
  const activeCardStoreId = event.slide
    .querySelector('.address-card')
    .getAttribute('id');

  const filteredStores = window.STORES.filter(
    (el) => el.document_id === activeCardStoreId
  );

  removeActiveClassFromMarkers();

  filteredStores.forEach((store) => {
    const { state } = store.store_details;
    const { city } = store.store_details;

    document
      .querySelector(`[state='${state}'][city='${city}']`)
      .classList.add('active');
  });
};

window.handleSplideArrowClick = (event, isPrev = false) => {
  let activeCardStoreId = document
    .querySelector('.splide__slide.is-next .address-card')
    ?.getAttribute('id');

  if (isPrev) {
    activeCardStoreId = document
      .querySelector('.splide__slide.is-prev .address-card')
      .getAttribute('id');
  }

  const filteredStores = window.STORES.filter(
    (el) => el.document_id === activeCardStoreId
  );

  removeActiveClassFromMarkers();

  filteredStores.forEach((store) => {
    const { state } = store.store_details;
    const { city } = store.store_details;

    document
      .querySelector(`[state='${state}'][city='${city}']`)
      .classList.add('active');
  });
};

window.renderStates = (statesList) => {
  const dropdownElementTemplate = document.querySelector('#dropdown-element');
  const dropdownContainer = document.querySelector('#state-dropdown');

  const modifiedArray = statesList.filter(
    (value, index, self) =>
      index ===
      self.findIndex((t) => t.store_details.state === value.store_details.state)
  );

  modifiedArray.forEach((store) => {
    const dropdownElement = document.importNode(
      dropdownElementTemplate.content,
      true
    );
    dropdownElement
      .querySelector('label')
      .setAttribute('id', `${store.store_details.state}`);
    dropdownElement
      .querySelector('label')
      .setAttribute('onclick', 'handleStateFilterChange(this)');
    dropdownElement.querySelector(
      'p'
    ).textContent = `${store.store_details.state}`;
    dropdownContainer.appendChild(dropdownElement);
  });
};

window.renderCities = (cityList) => {
  const dropdownElementTemplate = document.querySelector('#dropdown-element');
  const dropdownContainer = document.querySelector('#city-dropdown');

  dropdownContainer.innerHTML = '';

  const modifiedArray = cityList.filter(
    (value, index, self) =>
      index ===
      self.findIndex((t) => t.store_details.city === value.store_details.city)
  );

  modifiedArray.forEach((store) => {
    const dropdownElement = document.importNode(
      dropdownElementTemplate.content,
      true
    );
    dropdownElement
      .querySelector('label')
      .setAttribute('id', `${store.store_details.city}`);
    dropdownElement
      .querySelector('label')
      .setAttribute('onclick', 'handleCityFilterChange(this)');
    dropdownElement.querySelector(
      'p'
    ).textContent = `${store.store_details.city}`;
    dropdownContainer.appendChild(dropdownElement);
  });
};

window.handleRenderAddressCards = (stores) => {
  const addressCardTemplate = document.querySelector('#address-card');
  const mountElement = document.querySelectorAll(
    '.store-address-card-wrapper .splide__list'
  );

  mountElement.forEach((elm) => {
    elm.innerHTML = '';

    stores.forEach((store) => {
      const addressCard = document.importNode(
        addressCardTemplate.content,
        true
      );

      addressCard.querySelector('.store-name').textContent =
        store.store_details.store_name;
      addressCard.querySelector('.store-address').textContent =
        store.store_details.store_address;
      addressCard.querySelector(
        '.store-contact-number a'
      ).textContent = `${store.store_details.contact_number}`;
      addressCard
        .querySelector('.store-contact-number a')
        .setAttribute(
          'href',
          `tel://${store.store_details.contact_number.replace('-', '')}`
        );
      addressCard
        .querySelector('.store-details-page-link')
        .setAttribute(
          'href',
          `/${window.DukaanData.DUKAAN_STORE.link}/store-locator/${store.document_id}`
        );
      addressCard
        .querySelector('.address-card')
        .setAttribute('id', store.document_id);

      elm.appendChild(addressCard);
    });
  });

  if (isMobile) {
    handleRenderAddressCardSplide('#splide-address-card-mobile');
  } else {
    handleRenderAddressCardSplide('#splide-address-card');
  }
};

window.handleRenderAddressCardSplide = (splideId) => {
  const addressCardSplide = new Splide(splideId, {
    type: 'slide',
    arrows: true,
    pagination: true,
    perPage: 1,
    breakpoints: {
      768: {
        arrows: false,
      },
    },
  });

  addressCardSplide.on('active', (e) => {
    handleSplideCardChange(e);
  });

  addressCardSplide.mount();
};

window.handleCityFilterChange = (event) => {
  if (event.id) {
    window.SELECTED_CITY = event.id;
    document.querySelector('#city-dropdown-placeholder').textContent = event.id;

    // remove disabled state from submit button
    document.querySelector('#filter-submit-btn').classList.remove('disabled');
  } else {
    // disabling the city filter
    document
      .querySelector('.filter-dropdown.city-filter .placeholder-text')
      .classList.add('disabled');
    // remove disabled state from submit button
    document.querySelector('#filter-submit-btn').classList.add('disabled');
  }

  handleCloseAllDropdowns();
};

window.handleStateFilterChange = (event) => {
  window.SELECTED_STATE = event.id;
  window.SELECTED_CITY = '';

  const isStateAvailable = window.STORES.some(
    (el) =>
      el.store_details.state.toLowerCase().trim() ===
      event.id.toLowerCase().trim()
  );

  document.querySelector('#city-dropdown-placeholder').textContent =
    'Select a city';

  if (!isStateAvailable) {
    document.querySelector('#state-dropdown-placeholder').textContent =
      'Select a state';
    return;
  }

  document.querySelector('#state-dropdown-placeholder').textContent = event.id;

  // filter city on state
  const filteredCities = window.STORES.filter(
    (store) =>
      store.store_details.state.toLowerCase().trim() ===
      event.id.toLowerCase().trim()
  );

  // remove disabled state from city filter
  document
    .querySelector('.filter-dropdown.city-filter .placeholder-text')
    .classList.remove('disabled');

  // remove disabled state from submit button
  document.querySelector('#filter-submit-btn').classList.remove('disabled');

  renderCities(filteredCities);
  handleCloseAllDropdowns();
};

window.handleSubmitFilter = () => {
  const filteredStores = getFilteredStores({
    state: window.SELECTED_STATE,
    city: window.SELECTED_CITY,
  });

  // resetting splide pagination
  if (document.querySelector('.splide__pagination'))
    document.querySelector('.splide__pagination').innerHTML = '';

  // remove all markers
  document.querySelectorAll('.store-pointer-icon').forEach((el) => el.remove());

  filteredStores.forEach((store) => {
    const storeLatLong = [
      store.store_details.longitude,
      store.store_details.latitude,
    ];

    addMarker(
      window.projection(storeLatLong),
      store.store_details.state,
      store.store_details.city
    );
  });

  // highlighting first store
  // eslint-disable-next-line no-restricted-syntax
  for (const el of document.querySelectorAll(`.store-pointer-icon`)) {
    if (
      el.getAttribute('state').toLowerCase().trim() ===
      window.SELECTED_STATE.toLowerCase().trim()
    ) {
      el.classList.add('active');
      break;
    }
  }

  handleRenderAddressCards(filteredStores);
};

window.fetchStoreData = (map) => {
  const fetchUrl = `https://store-locator.apps.mydukaan.io/store/styleup`;
  fetch(fetchUrl, {
    method: 'get',
    headers: {
      'Content-Type': 'application/json',
      'x-requested-with': window?.DukaanData?.DUKAAN_SESSION_ID,
    },
  })
    .then((res) => res.json())
    .then((storeData) => {
      window.STORES = storeData.data.stores;

      renderStates(window.STORES);
      renderCities(window.STORES);
      renderStoreLocatorMap();

      if (isMobile) {
        const imageElement = document.querySelector('#map-load-point');
        // pinchZoom(imageElement);
        new window.MobileZoomGesture(imageElement, {});
        // const pz = new MobileZoomGesture.default(imageElement, {});÷
      } else {
        svgPanZoomContainer();
      }

      storeData.data.stores.forEach((element) => {
        const { latitude } = element.store_details;
        const { longitude } = element.store_details;
      });
    });
};

window.handleDropdownOutsideClick = (...elements) => {
  elements.forEach((el) => {
    document.addEventListener('click', (event) => {
      const isClickInside = el.contains(event.target);
      if (!isClickInside)
        handleCloseDropdown(el.querySelector('.custom-dropdown'));
    });
  });
};

window.renderStoreLocatorMap = () => {
  d3.select('#map-load-point svg').remove(); // Without this, D3 just keeps appending new svgs each time.

  let width = 593;
  let height = 640;
  // const containerWidth = 796;
  // const scaleX = 100 + (width / +containerWidth) * 100;

  if (isMobile) {
    width = 328;
    height = 430;
    // containerWidth = 796;
    // scaleX = 140;
  }

  const json = data;

  window.projection = d3.geoMercator().fitSize([width, height], json);
  const path = d3.geoPath().projection(projection);

  // returns a d3 selection of parent-DOM-element-for-d3 (which continues down the method chain...)
  const d3SelectionOfSVGCanvas = d3
    .select('#map-load-point')
    .append('svg')
    .attr('class', 'my-canvas')
    .attr('width', width)
    .attr('height', height)
    .append('g');

  const stateTooltip = document.querySelector('.state-tooltip');

  d3SelectionOfSVGCanvas
    .selectAll('path')
    .data(json.features)
    .enter()
    .append('path')
    .attr('d', path)
    .attr('state', (d) => d.properties.ST_NM)
    .attr('onclick', 'handleStateClick(this)')
    .style('fill', () => '#E1E1E1')
    .style('stroke', '#fff')
    .style('stroke-width', 1.20407)
    .on('mouseover', function (d) {
      d3.select(this)
        .style('opacity', 1)
        .style('fill', () => '#fff')
        .style('stroke', '#f4f5f4')
        .style('stroke-width', 1.20407)
        .style('transition', 'ease-in-out 200ms');

      const state = d.properties.ST_NM;
      const storeCount = window.STORES.filter(
        (el) =>
          el.store_details.state.toLowerCase().trim() ===
          state.toLowerCase().trim()
      ).length;

      if (storeCount) {
        stateTooltip.textContent = `${storeCount} ${pluralize(
          storeCount,
          'store',
          'stores'
        )} found in ${state}`;
        stateTooltip.style.visibility = 'visible';
      }
    })
    .on('mousemove', () => {
      const tooltipWidth = document
        .querySelector('.state-tooltip')
        .getBoundingClientRect().width;

      stateTooltip.style.top = `${d3.event.pageY - 50}px`;
      stateTooltip.style.left = `${d3.event.pageX - tooltipWidth / 2}px`;
    })
    .on('mouseout', function () {
      d3.select(this)
        .style('fill', () => '#E1E1E1')
        .style('stroke', '#fff');
      stateTooltip.style.visibility = 'hidden';
    });
  // add pointers to svg
  STORES.forEach((store) => {
    const storeLatLong = [
      store.store_details.longitude,
      store.store_details.latitude,
    ];

    addMarker(
      projection(storeLatLong),
      store.store_details.state,
      store.store_details.city
    );
  });
};

window.addMarker = ([x, y], state, city) => {
  const pointerTemplate = document.querySelector('#store-pointer');
  const pointer = document.importNode(pointerTemplate.content, true);
  const container = document.querySelector('#map-load-point .my-canvas g');

  pointer.querySelector('svg').setAttribute('y', y - 18);
  pointer.querySelector('svg').setAttribute('x', x - 13);
  pointer.querySelector('svg').setAttribute('state', state);
  pointer.querySelector('svg').setAttribute('city', city);

  pointer
    .querySelector('svg')
    .setAttribute('onmouseover', 'handleStorePointerClick(this)');

  pointer
    .querySelector('svg')
    .setAttribute('onmousemove', 'handleStorePointMouseMove(this)');

  pointer
    .querySelector('svg')
    .setAttribute('onmouseout', 'handleStorePointMouseOut(this)');

  if (isMobile) {
    pointer.querySelector('svg').setAttribute('width', '6');
    pointer.querySelector('svg').setAttribute('x', x - 3);
    pointer.querySelector('svg').setAttribute('y', y - 15);
  }

  container.appendChild(pointer);
};

window.handleStorePointMouseMove = (elm) => {
  const pointerTooltip = document.querySelector('.pointer-tooltip');

  const tooltipWidth = document
    .querySelector('.pointer-tooltip')
    .getBoundingClientRect().width;

  const pointerElmDimension = elm.getBoundingClientRect();

  let elementDistanceFromTop = 0;
  if (isMobile) {
    elementDistanceFromTop = window.pageYOffset;
  }

  pointerTooltip.style.top = `${
    pointerElmDimension.top + elementDistanceFromTop - 50
  }px`;
  pointerTooltip.style.left = `${
    pointerElmDimension.left - tooltipWidth / 2
  }px`;
};

window.handleStorePointMouseOut = () => {
  const pointerTooltip = document.querySelector('.pointer-tooltip');
  pointerTooltip.style.visibility = 'hidden';
};

// onclick map triggers
window.handleStorePointerClick = (e) => {
  const state = e.getAttribute('state');
  const city = e.getAttribute('city');
  const pointerTooltip = document.querySelector('.pointer-tooltip');

  if (pointerTooltip) {
    pointerTooltip.textContent = `Styleup - ${city}`;
    pointerTooltip.style.visibility = 'visible';
  }

  // resetting splide pagination
  if (document.querySelector('.splide__pagination'))
    document.querySelector('.splide__pagination').innerHTML = '';

  // remove all active class
  document
    .querySelectorAll('.store-pointer-icon')
    .forEach((el) => el.classList.remove('active'));

  e.classList.add('active');
  handleStateFilterChange({ id: state });
  handleCityFilterChange({ id: city });

  const filteredStores = getFilteredStores({
    state,
    city,
  });

  handleRenderAddressCards(filteredStores);
};

window.handleStateClick = (e) => {
  const state = e.getAttribute('state');

  const filteredStores = getFilteredStores({
    state,
  });

  // resetting splide pagination
  if (document.querySelector('.splide__pagination'))
    document.querySelector('.splide__pagination').innerHTML = '';

  removeActiveClassFromMarkers();

  // highlighting first store
  // eslint-disable-next-line no-restricted-syntax
  for (const el of document.querySelectorAll(`.store-pointer-icon`)) {
    if (
      el.getAttribute('state').toLowerCase().trim() ===
      state.toLowerCase().trim()
    ) {
      el.classList.add('active');
      break;
    }
  }

  handleStateFilterChange({ id: state });
  handleCityFilterChange({ id: filteredStores[0]?.store_details.city || '' });

  handleRenderAddressCards(filteredStores);
};

window.pinchZoom = (imageElement) => {
  const start = {};
  const imageElementScale = 1;

  console.log('remove touch end');
  console.log('touch working asd');

  imageElement.addEventListener(
    'touchstart',
    (evt) => handleProductImageModalTouchStart(evt, imageElement, start),
    { passive: false }
  );
  imageElement.addEventListener(
    'touchmove',
    (evt) =>
      handleProductImageModalTouchMove(
        evt,
        imageElement,
        start,
        imageElementScale
      ),
    {
      passive: false,
    }
  );
  // imageElement.addEventListener(
  //   'touchend',
  //   (evt) => handleProductImageModalTouchEnd(evt, imageElement),
  //   {
  //     passive: false,
  //   }
  // );
};

// Calculate distance between two fingers
window.distanceBtwPointers = (evt) =>
  Math.hypot(
    evt.touches[0].pageX - evt.touches[1].pageX,
    evt.touches[0].pageY - evt.touches[1].pageY
  );

window.handleProductImageModalTouchStart = (evt, imageElement, start) => {
  if (evt.touches.length === 2) {
    evt.preventDefault(); // Prevent page scroll

    // Calculate where the fingers have started on the X and Y axis
    start.x = (evt.touches[0].pageX + evt.touches[1].pageX) / 2;
    start.y = (evt.touches[0].pageY + evt.touches[1].pageY) / 2;
    start.distance = distanceBtwPointers(evt);
    start.scale = imageElement.dataSet?.scale || 0;
  }
};

window.handleProductImageModalTouchMove = (evt, imageElement, start) => {
  if (evt.touches.length === 2) {
    evt.preventDefault(); // Prevent page scroll

    let scale;

    const deltaDistance = distanceBtwPointers(evt);
    scale = deltaDistance / start.distance + start.scale;

    imageElementScale = Math.min(Math.max(1, scale), 5);

    // Calculate how much the fingers have moved on the X and Y axis
    const deltaX =
      ((evt.touches[0].pageX + evt.touches[1].pageX) / 2 - start.x) * 2; // x2 for accelarated movement
    const deltaY =
      ((evt.touches[0].pageY + evt.touches[1].pageY) / 2 - start.y) * 2; // x2 for accelarated movement

    // Transform the image to make it grow and move with fingers
    const transform = `translate3d(${deltaX}px, ${deltaY}px, 0) scale(${imageElementScale})`;
    imageElement.style.transform = transform;
    imageElement.dataSet.scale = imageElementScale;
    imageElement.style.WebkitTransform = transform;
  }
};

window.handleProductImageModalTouchEnd = (evt, imageElement) => {
  if (evt.touches.length === 2) {
    evt.preventDefault();
    // imageElement.style.transform = '';
    // imageElement.style.WebkitTransform = '';
  }
};

window.appInitializer = () => {
  const stateFilterBtn = document.querySelector(
    '#state-filter-dropdown-btn'
  ).parentNode;

  const cityFIlterBtn = document.querySelector(
    '#city-filter-dropdown-btn'
  ).parentNode;

  handleDropdownOutsideClick(stateFilterBtn, cityFIlterBtn);

  fetchStoreData(mapObj);
  initTooltip();
};
