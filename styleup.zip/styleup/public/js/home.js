window.fetchBestSellerCategories = () => {
  // Common function
  let offset = 0;
  let initialized = true;
  const offsetCount = 10;

  // overriding the default browser scroll behavior
  document
    .querySelectorAll('.modal-overflow-container')
    ?.forEach((el) => el?.scrollTo(0, 0));

  // eslint-disable-next-line no-undef, no-return-assign
  return (fetchFn = ({
    nextUrl = false,
    cb,
    loadPoint = null,
    firstFetch = false,
  } = {}) => {
    // const fetchUrl = `https://edge-api.mydukaan.io/api/store/buyer/${window.DukaanData.DUKAAN_STORE.link}/bestseller/v3/`;
    const fetchUrl = `${window.DukaanData.CLIENT_API2_ENDPOINT}/api/product/buyer/${window.DukaanData.DUKAAN_STORE.link}/product-category-list/?offset=${offset}`;

    if (nextUrl) {
      offset += offsetCount;
      initialized = false;
    }

    if (initialized) offset += offsetCount;

    fetch(fetchUrl, {
      method: 'get',
      headers: {
        'Content-Type': 'application/json',
        'x-requested-with': window?.DukaanData?.DUKAAN_SESSION_ID,
        // 'Content-Type': 'application/x-www-form-urlencoded',
      },
    })
      .then((res) => res.json())
      .then((res) => {
        const bestsellerCategories = res?.results || [];
        const next = !(bestsellerCategories.length < offsetCount);
        DukaanData.DUKAAN_CLIENT_CATEGORY_LIST = {
          ...DukaanData?.DUKAAN_CLIENT_CATEGORY_LIST,
          ...bestsellerCategories?.reduce((map, category) => {
            map[category.uuid] = { ...category };
            return map;
          }, {}),
        };

        const customBestsellerCategories = bestsellerCategories.splice(0, 2);
        cb(customBestsellerCategories, next);
      })
      .catch((err) => {
        console.log('fetchStoreCategories error : ', err);
        cb([], false);
      });
  });
};

window.fetchBestSellerCategoriesInit = null;

window.appInitializer = () => {
  druidStorePageView();
  fetchBestSellerCategoriesInit = fetchBestSellerCategories();
  fetchBestSellerCategoriesInit({
    cb: renderSubCategoryList,
    firstFetch: true,
    loadpoint: 'subcategory-section-load-point',
  });
};
