// set navbar active element
window.handleNavActiveClass = (header, activeClass) => {
  const menu = {
    home: '/',
    storeLocator: 'store-locator/',
    blog: 'blog/',
    contactUs: 'contact-us/',
    aboutUs: 'about-us/',
  };

  const btns = [...header.children];
  // const current = document.getElementsByClassName('active');

  let pathname = window.location.pathname
    .split(`/${DukaanData.DUKAAN_STORE.link}`)?.[1]
    ?.replace(/\/$/, '') // removing the trailing slash
    ?.trim()
    .split('/')
    .splice(-1);

  pathname += '/';

  if (btns.length > 1) {
    let active = '';
    Object.entries(menu).forEach((el) => {
      if (pathname === el[1]) {
        const [activeEl] = el;
        active = activeEl;
      }
    });

    [...btns].forEach((el) => {
      el.classList.remove(activeClass);
    });
    if (active) {
      const elements = [...btns].filter((el) => el.id === active);
      elements.forEach((ele) => {
        ele.classList.add(activeClass);
      });
    } else if (pathname === '/') {
      [...btns].forEach((ele) => {
        if (ele.id === 'home') {
          ele.classList.add(activeClass);
        }
      });
    }
  }
};

// utility
window.isHomePage = () => {
  const paths = window.location.pathname.split(
    `${window.DukaanData.DUKAAN_STORE.link}`
  );
  const currentPath = paths[paths.length - 1];

  return (
    !window.DukaanData?.DUKAAN_CATEGORY &&
    (currentPath === '' || currentPath === '/')
  );
};

// category renderer
window.fetchStoreCategoriesInit = null;

window.renderCategoriesList = (categories) => {
  customTag('category-card-load-point', (element) =>
    categoriesRenderer(element, categories)
  );
};

window.categoriesRenderer = (mountElement, categories) => {
  mountElement.innerHTML = '';

  const categoryCardTemplate = document.getElementById(
    'category-card-template'
  );

  categories.splice(0, 2);

  categories = categories.filter((el) => el.subcategories_count > 0);

  categories?.forEach((category) => {
    const categoryCard = document.importNode(
      categoryCardTemplate.content,
      true
    );

    categoryCard
      .querySelector('.category_popup-image')
      .setAttribute('src', getCdnUrl(category.image, 500));
    categoryCard.querySelector('.product-category-name').textContent =
      category.name;
    categoryCard
      .querySelector('.category-link')
      .setAttribute(
        'href',
        `/${window.DukaanData.DUKAAN_STORE.link}/categories/${category.slug}/subcategories`
      );

    mountElement.appendChild(categoryCard);
  });
};

// sub category section renderer
window.fetchStyleupSubCategories = () => {
  // Common function
  let offset = 0;
  let initialized = true;
  const offsetCount = 10;

  // overriding the default browser scroll behavior
  document
    .querySelectorAll('.modal-overflow-container')
    ?.forEach((el) => el?.scrollTo(0, 0));

  // eslint-disable-next-line no-undef, no-return-assign
  return (fetchFn = ({
    nextUrl = false,
    cb,
    loadPoint = null,
    firstFetch = false,
  } = {}) => {
    //  getting sub categories
    const fetchUrl = `${window.DukaanData.CLIENT_API2_ENDPOINT}/api/product/buyer/${window.DukaanData.DUKAAN_STORE.link}/product-category-list/?parent_slug=${window.DukaanData.DUKAAN_CATEGORY.slug}`;

    if (nextUrl) {
      offset += offsetCount;
      initialized = false;
    }

    if (initialized) offset += offsetCount;

    fetch(fetchUrl, {
      method: 'get',
      headers: {
        'Content-Type': 'application/json',
        'x-requested-with': window?.DukaanData?.DUKAAN_SESSION_ID,
        // 'Content-Type': 'application/x-www-form-urlencoded',
      },
    })
      .then((res) => res.json())
      .then((res) => {
        const subCategories = res?.results || [];
        const next = !(subCategories.length < offsetCount);
        DukaanData.DUKAAN_CLIENT_CATEGORY_LIST = {
          ...DukaanData?.DUKAAN_CLIENT_CATEGORY_LIST,
          ...subCategories?.reduce((map, category) => {
            map[category.uuid] = { ...category };
            return map;
          }, {}),
        };
        cb(subCategories, next);
      })
      .catch((err) => {
        console.log('fetchStoreCategories error : ', err);
        cb([], false);
      });
  });
};

window.renderSubCategoryList = (categories) => {
  customTag('subcategory-section-load-point', (element) =>
    subCategoryRenderer(element, categories)
  );
};

window.subCategoryRenderer = (mountElement, subCategories) => {
  mountElement.innerHTML = '';

  const subCategoryCardTemplate = document.getElementById(
    'subcategory-section-template'
  );
  subCategories?.forEach((subCategory) => {
    const subCategoryCard = document.importNode(
      subCategoryCardTemplate.content,
      true
    );

    subCategoryCard.querySelector('.sub-category-name').textContent =
      subCategory.name;

    if (subCategory.description) {
      subCategoryCard.querySelector('.sub-category-description').innerHTML =
        subCategory.description;
    }

    subCategoryCard
      .querySelector('.sub-category-section-container')
      .setAttribute('id', `${subCategory.slug}`);

    mountElement.appendChild(subCategoryCard);

    fetchStyleupProductsInit = fetchStyleupProducts(
      subCategory.uuid,
      subCategory.id
    );
    fetchStyleupProductsInit({
      cb: renderProductCardList,
      firstFetch: true,
      loadPoint: 'product-card-load-point',
    });
  });
};

// product card fetch and renderer
window.fetchStyleupProducts = (subCategoryUUID, subCategoryID) => {
  // initial product splide render for shimmers
  renderProductCardSplide();

  // Common function
  let offset = 0;
  let initialized = true;
  const offsetCount = 10;

  // overriding the default browser scroll behavior
  document
    .querySelectorAll('.modal-overflow-container')
    ?.forEach((el) => el?.scrollTo(0, 0));

  // eslint-disable-next-line no-undef, no-return-assign
  return (fetchFn = ({
    nextUrl = false,
    cb,
    loadPoint = null,
    firstFetch = false,
    page = 1,
  } = {}) => {
    // by default gets products
    const fetchUrl = `${window.DukaanData.DUKAAN_ADVANCED_SEARCH_API_BASE_URL}/api/advanced-search/${DukaanData.DUKAAN_STORE.id}/`;
    if (nextUrl) {
      offset += offsetCount;
      initialized = false;
    }

    if (initialized) offset += offsetCount;

    fetch(fetchUrl, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'x-requested-with': window?.DukaanData?.DUKAAN_SESSION_ID,
        // 'Content-Type': 'application/x-www-form-urlencoded',
      },
      body: JSON.stringify({
        category_ids: [subCategoryID],
        page_number: page,
      }),
    })
      .then((res) => res.json())
      .then((res) => {
        const products = res?.data?.products || [];
        const next = !(products.length < offsetCount);
        DukaanData.DUKAAN_CLIENT_CATEGORY_LIST = {
          ...DukaanData?.DUKAAN_CLIENT_CATEGORY_LIST,
          ...products?.reduce((map, category) => {
            map[category.uuid] = { ...category };
            return map;
          }, {}),
        };
        if (firstFetch && loadPoint !== null) {
          document
            .querySelector(
              `#${DukaanData.DUKAAN_CLIENT_CATEGORY_LIST[subCategoryUUID].slug}`
            )
            .querySelector(loadPoint).innerHTML = '';
        }
        cb(products, next, subCategoryUUID, subCategoryID);
      })
      .catch((err) => {
        console.log('fetchStoreCategories error : ', err);
        cb([], false, subCategoryUUID, subCategoryID);
      });
  });
};

window.renderProductCardList = (products, next, subCategoryUUID) => {
  const container = document.querySelector(
    `#${DukaanData.DUKAAN_CLIENT_CATEGORY_LIST[subCategoryUUID].slug}`
  );
  const productCardLoadPoint = container.querySelector(
    'product-card-load-point'
  );

  if (!products?.length) {
    productCardLoadPoint.innerHTML = '';
    return;
  }

  productCardRendererStyleUp(products, productCardLoadPoint, subCategoryUUID);
};

window.productCardRendererStyleUp = (
  products,
  mountElement,
  subCategoryUUID
) => {
  let productCardTemplate = document.getElementById('product-card-template');

  let customProducts = products;

  // if current path is home page
  if (window.isHomePage()) {
    productCardTemplate = document.getElementById(
      'bestseller-product-card-template'
    );
    customProducts = products.slice(0, 4);
  }

  customProducts?.forEach(async (product) => {
    const productCard = document.importNode(productCardTemplate.content, true);

    if (customProducts.length === 1) {
      productCard
        .querySelector('.product-card img')
        .setAttribute('src', getCdnUrl(product.image, 1200, 500));
    } else {
      productCard
        .querySelector('.product-card img')
        .setAttribute('src', getCdnUrl(product.image, 700));
    }

    productCard.querySelector(
      '.product-card .product-card-name'
    ).textContent = `${product.name}`;

    productCard
      .querySelector('.product-card .dkn-product-link')
      .setAttribute('href', 'https://styleup.in/styleup/store-locator');

    productCard.querySelector(
      '.product-card p'
    ).textContent = `from ${formatMoney(product.original_price)}`;

    // if (product?.metafields?.[0]?.value?.val) {
    //   productCard
    //     .querySelectorAll('.product-card .dkn-product-link')
    //     .forEach((el) => {
    //       el.setAttribute('href', product.metafields[0].value.val);
    //     });
    // }

    mountElement.appendChild(productCard);

    renderProductCardSplide();
  });
};

window.renderProductCardSplide = () => {
  document.querySelectorAll('.splide-product-card').forEach((eachSPlide) => {
    const splideLength = eachSPlide.querySelectorAll('.splide__slide').length;
    new Splide(eachSPlide, {
      arrows: splideLength > 3,
      pagination: false,
      breakpoints: {
        768: {
          gap: 12,
          perPage: splideLength > 2 ? 2 : splideLength,
          arrows: false,
          padding: { right: splideLength > 2 ? 36 : 16 },
        },
      },
      perPage: splideLength > 3 ? 3 : splideLength,
      gap: 48,
    }).mount();
  });
};

// footer renderer
window.handleFooterIcons = (event) => {
  event.querySelector('.minus').classList.toggle('d-none');
  event.querySelector('.plus').classList.toggle('d-none');
};

// common
window.commonInitializer = () => {
  const desktopHeader = document.getElementById('desktop-header-nav-bar');
  const desktopActiveClass = 'header-item-selected';

  handleNavActiveClass(desktopHeader, desktopActiveClass);
  fetchStoreCategoriesInit = fetchStoreCategories();
  fetchStoreCategoriesInit({
    cb: renderCategoriesList,
    firstFetch: true,
    loadpoint: 'category-card-load-point',
  });
};

// splide initializer
const splideCount = document.querySelector(
  '#splide-banners div ul'
)?.childElementCount;

document.addEventListener('DOMContentLoaded', () => {
  if (document.getElementById('splide-banners') !== null)
    new Splide('#splide-banners', {
      type: splideCount > 1 ? 'loop' : 'fade',
      autoplay: true,
      interval: 2000,
      arrows: false,
      pagination: splideCount > 1,
    }).mount();
});

document.addEventListener('DOMContentLoaded', () => {
  if (document.getElementById('splide-mobile-banners') !== null)
    new Splide('#splide-mobile-banners', {
      type: splideCount > 1 ? 'loop' : 'fade',
      autoplay: true,
      pauseOnHover: false,
      interval: 2700,
      arrows: false,
      pagination: splideCount > 1,
    }).mount();
});

document.addEventListener('DOMContentLoaded', () => {
  if (document.getElementById('instagram-post') !== null)
    new Splide('#instagram-post', {
      type: 'loop',
      autoplay: false,
      interval: 2700,
      arrows: true,
      pagination: false,
      gap: 8,
      breakpoints: {
        768: {
          gap: 0,
          arrows: false,
        },
      },
    }).mount();
});
