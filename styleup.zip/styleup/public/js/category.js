window.fetchSubCategoriesInit = null;

window.appInitializer = () => {
  fetchSubCategoriesInit = fetchStyleupSubCategories();
  fetchSubCategoriesInit({
    cb: renderSubCategoryList,
    firstFetch: true,
    loadpoint: 'subcategory-section-load-point',
  });
};
