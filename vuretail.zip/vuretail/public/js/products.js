window.customCounterRender = (count) => `All Products (${count})`;

window.customCategoryInitializer = () => {
  // init sort dropdown
  const paramString = new URLSearchParams(window.location.search);
  const defaultOrdering = paramString.get('sort_by') || 'relevance';
  window.q$
    .select('.dkn-sort-by-selected-option-label')
    .modifyTextContent(window.getSortTypeText(defaultOrdering));

  const selectedOption = window.q$.select(
    `.dkn-dropdown-option[value="${defaultOrdering}"]`
  ).elem;

  if (selectedOption) {
    window.q$
      .select('.dkn-dropdown-sort-radio-button', selectedOption)
      .addClass('selected');
    window.q$
      .select('.dkn-dropdown-sort-label', selectedOption)
      .addClass('selected');
  }
};

// additional renderer for adv. filter products
window.productCardAdditionalRenderer = (productCard, product) => {
  const { selling_price: sellingPrice } = product;

  window.q$
    .selectAll('.dkn-product-card-selling-price', productCard)
    .modifyTextContentAll(`From ${window.formatMoney(sellingPrice)}`);

  window.q$
    .selectAll('.dkn-product-link', productCard)
    .setAttributeAll(
      'href',
      `${getProductPageUrl(product)}?product_slug=${product.slug}`
    );
};

window.getModifiedProducts = (products) => {
  const slugs = Object.values(window.VU_PRODUCT_SLUGS || {});
  return products.filter((p) => slugs.includes(p.slug)) || [];
};
