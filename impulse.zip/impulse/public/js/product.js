window.productCardTemplateId = 'dkn-product-splide-card-template';
window.SIMILAR_PRODUCT_LIMIT = 12;
window.mainCarousel = null;
window.thumbnails = null;

window.scrollToSKUImage = (activeSKU) => {
  const primaryImage = activeSKU.primary_image;
  const allImages = DukaanData.DUKAAN_PRODUCT.all_images;
  if (allImages.length > 0) {
    const index = allImages.indexOf(primaryImage);
    if (index >= 0) {
      if (typeof mainSplide !== 'undefined') {
        mainSplide.go(index);
        document
          .getElementById(`pdp-image-${index + 1}`)
          ?.scrollIntoView({ behavior: 'smooth', block: 'center' });
      }
    }
  }
};

// this function is getting called from dukaan-products for similar products..
window.renderProductsListSplide = (
  products,
  section = 'splide-similar-products'
) => {
  const splideObj = new Splide(`#${section}`, {
    type: 'slide',
    autoplay: false,
    arrows: products.length > 4,
    pauseOnHover: false,
    perPage: 4,
    perMove: 1,
    gap: 24,
    pagination: false,
    classes: {
      pagination: `splide__pagination ${section}-pagination`,
    },
    breakpoints: {
      992: {
        perPage: 2,
        arrows: false,
        pagination: false,
        gap: 16,
        padding: { right: products.length > 1 ? 30 : 0 },
        classes: {
          pagination: `splide__pagination ${section}-pagination`,
        },
      },
    },
  });
  splideObj.mount();
};

window.appInitializer = () => {
  const productFromServer = DukaanData.DUKAAN_PRODUCT;
  const serializedSKUs = serializeSKUs(productFromServer.skus || []);
  const attributes = getAllProductAttributeValues(serializedSKUs);
  const product = {
    ...productFromServer,
    skus: serializedSKUs,
    attributes,
  };
  window.DukaanData.PRODUCTS_DETAILS = product;
  window.DukaanData.PRODUCTS_MAP = {
    ...(DukaanData.PRODUCTS_MAP || []),
    [product.uuid]: product,
  };

  productPageCommonFnCalls(product);

  // checkInputQuantity();

  // renderVariantFormOnPDP(productFromServer);
  if (
    document.querySelector('#splide-product-main') &&
    document.querySelector('#splide-product-thumbnail')
  ) {
    window.mainSplide = new Splide('#splide-product-main', {
      type: 'slide',
      autoplay: false,
      pagination: false,
      arrows: false,
      updateOnMove: true,
      breakpoints: {
        992: {
          pagination: false,
          width: '100%',
        },
      },
    });
    window.mainSplide.on('click', (e) => {
      window.playProductVideo(e);
    });
    window.thumbnailSplide = new Splide('#splide-product-thumbnail', {
      autoplay: false,
      arrows: false,
      direction: 'ttb',
      perPage: 3,
      gap: 16,
      height: 'calc(100% - 100px)',
      pagination: false,
      isNavigation: true,
      classes: {
        prev: 'active',
      },
      breakpoints: {
        992: {
          arrows: false,
          gap: 0,
          perPage: 6,
          direction: 'ltr',
        },
      },
    });
    window.thumbnailSplide.on('click', () => {
      window.pauseAllProductVideos();
    });
    window.mainSplide.sync(window.thumbnailSplide);
    window.mainSplide.mount();
    window.thumbnailSplide.mount();
  }
};

// ratings related renderers
window.customReviewsInfoRenderer = (reviewStats) => {
  const ratingContainer = document.getElementById('rating-info-pdp');
  ratingContainer.innerHTML = '';
  window.productRatingsAndReviewsInfoRenderer(reviewStats, ratingContainer, {
    reviewInfoTemplateId: 'dkn-product-review-with-count-template',
    getCustomReviewsCountText: window.getCustomReviewsCountText,
    starHeight: 18,
    starWidth: 18,
  });
  window.q$
    .select('.pdp-tabs-header-item.item-reviews')
    .modifyTextContent(
      `${DukaanData.DUKAAN_LANGUAGE.REVIEWS} (${reviewStats.total_count})`
    );
};
window.customCustomerRatingTextRenderer = ({ total_count: totalCount }) => {
  window.q$.select('.customerRatingText').modifyTextContent(
    DukaanData.DUKAAN_LANGUAGE.BASED_ON__REVIEWCOUNT_REVIEWS.injectText({
      reviewCount: totalCount,
    })
  );
};
