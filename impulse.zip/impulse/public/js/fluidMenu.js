window.addEventListener('DOMContentLoaded', () => {
  axios
    .get(
      `https://apps.mydukaan.io/public/v2/apps/store/${DukaanData.DUKAAN_STORE.id}/`
    )
    .then((response) => {
      const { store_apps_list: appList } = response.data;
      const availablePlugins = appList?.reduce((acc, item) => {
        if (item.isActive) {
          acc[item._id] = item;
        }
        return acc;
      }, {});
      const isStoreLocatorPresent = Boolean(
        !!availablePlugins && availablePlugins[APP_IDS.STORE_LOCATOR]
      );
      const storeLocatorTags = document.querySelectorAll('.store-locator-link');
      if (isStoreLocatorPresent) {
        storeLocatorTags.forEach((tag) => tag.classList.remove('hidden'));
      } else {
        storeLocatorTags.forEach((tag) => tag.remove());
      }
    })
    .finally(() => {
      const menuItems = document.querySelectorAll(
        '.menu-dropdown:not(.menu-dropdown__button)'
      );
      const mainMenu = document.querySelector('.menu-main');
      const mainMenuWidth = mainMenu.offsetWidth;
      let menuWidth = 0;
      let i = 0;
      for (i = 0; i < menuItems.length; i += 1) {
        menuWidth += menuItems[i].offsetWidth + 24;
        if (
          menuWidth >=
          mainMenuWidth -
            document.querySelector('.menu-dropdown__button').offsetWidth
        ) {
          document.fonts.ready.then(() => {
            document
              .querySelector('.menu-dropdown__button')
              .classList.remove('hidden');
          });
          break;
        }
      }
    })
    .catch(() => {});
});

window.dknGetPagePathFromUrl = (url) => {
  if (
    DukaanData.DUKAAN_PAGE_KEY &&
    DukaanData.DUKAAN_PAGE_KEY !== 'store_page' &&
    DukaanData.DUKAAN_PAGE_KEY !== 'category'
  ) {
    return DukaanData.DUKAAN_PAGE_KEY;
  }

  const parsedUrl = new URL(url);
  const pathSegments = parsedUrl.pathname.split('/').filter(Boolean);
  return pathSegments[pathSegments.length - 1];
};

window.dknRenderMenuDropdowns = () => {
  const menuItems = document.querySelectorAll('.dkn-header-menu-item');

  let i = 0;
  for (i = 0; i < menuItems.length; i += 1) {
    menuItems[i].addEventListener('mouseenter', (event) => {
      document.querySelectorAll('.header-menu-item-dropdown')?.forEach((el) => {
        el?.classList.add('hidden');
      });
      const { target: parentMenuItem } = event;
      const dropdownId = parentMenuItem.dataset.dropdownId || '';
      const menuDropDown = document.getElementById(dropdownId);
      if (menuDropDown) {
        menuDropDown.classList.remove('hidden');
        menuDropDown.style.position = 'absolute';
        menuDropDown.style.top = `calc(100% - 20px)`;
        menuDropDown.style.left = `${
          parentMenuItem.getBoundingClientRect().left
        }px`;
      }
      document.addEventListener('mousemove', (e) => {
        const { target: hoverTarget } = e;
        const mainHeader = document.querySelector('.dkn-header-menu-list');
        if (
          !(
            menuDropDown?.contains(hoverTarget) ||
            mainHeader?.contains(hoverTarget)
          )
        ) {
          menuDropDown?.classList?.add('hidden');
          document.removeEventListener('mousemove', () => {}, true);
        }
      });
    });
  }
};

window.handleActiveNavStateMobile = () => {
  const mobileNavBar = window.q$.select('#mobile-bottom-nav-bar').elem;
  if (DukaanData?.DUKAAN_PAGE_KEY === 'home') {
    const homeSvg = window.q$.select('.home-svg-mobile-nav', mobileNavBar).elem;
    const homeSvgFilled = window.q$.select(
      '.home-svg-mobile-nav-filled',
      mobileNavBar
    ).elem;
    const homeLabel = window.q$.select(
      '.home-mob-nav-label',
      mobileNavBar
    ).elem;
    homeLabel.classList.add('mob-nav-label-active');
    homeSvg.classList.add('hidden');
    homeSvgFilled.classList.remove('hidden');
  } else if (DukaanData?.DUKAAN_PAGE_KEY === 'categories') {
    const shopSvg = window.q$.select('#shop-svg-mobile-nav').elem;
    const shopSvgFilled = window.q$.select('.shop-svg-mobile-nav-filled').elem;
    const shopLabel = window.q$.select('.shop-mob-nav-label').elem;
    shopLabel.classList.add('mob-nav-label-active');
    shopSvg.classList.add('hidden', 'mob-nav-label-active');
    shopSvgFilled.classList.remove('hidden');
  }
};

window.dknHandleHeaderMenuActiveState = (headerMenuItems, activeClass) => {
  if (headerMenuItems.length <= 0) return;

  const pagePath = dknGetPagePathFromUrl(window.location.href);

  headerMenuItems.forEach((menu) => {
    const menuId = menu.dataset.menuId || null;

    if (menuId === pagePath) {
      menu.classList.add(activeClass);
    } else {
      menu.classList.remove(activeClass);
    }
  });
};

window.dknRenderDesktopHeaderHamburger = (headerMenu, headerMenuItems) => {
  if (!headerMenu) return;

  const mainMenuWidth = headerMenu.offsetWidth;
  let menuWidth = 0;
  let i = 0;
  for (i = 0; i < headerMenuItems.length; i += 1) {
    // adding 24 for right margin in each item
    menuWidth += headerMenuItems[i].offsetWidth + 24;
    if (menuWidth >= mainMenuWidth) {
      document.fonts.ready.then(() => {
        window.q$
          .select('.dkn-header-menu-item-hamburger')
          .removeClass('hidden');
      });
      break;
    }
  }
};

window.dknHandleHeaderButtonActiveState = () => {
  const pagePath = dknGetPagePathFromUrl(window.location.href);

  // active state for search and wishlist icon
  const headerSearchIcon = document.querySelector('.dkn-header-search-icon');
  const headerSearchIconFilled = document.querySelector(
    '.dkn-header-search-icon-filled'
  );

  const headerWishlistIcon = document.querySelector(
    '.dkn-header-wishlist-icon'
  );
  const headerWishlistIconFilled = document.querySelector(
    '.dkn-header-wishlist-icon-filled'
  );

  if (pagePath === 'search') {
    headerSearchIcon.classList.add('d-none');
    headerSearchIconFilled.classList.remove('d-none');
  }

  if (pagePath === 'wishlist') {
    headerWishlistIcon.classList.add('d-none');
    headerWishlistIconFilled.classList.remove('d-none');
  }
};

window.dknInitHeader = () => {
  const headerMenu = q$.select('#dkn-desktop-header .dkn-header-menu').elem;

  const headerMenuItems = q$.selectAll(
    '#dkn-desktop-header .dkn-header-menu-list .dkn-header-menu-item'
  ).elem;

  const activeClass = 'dkn-header-menu-item-active';

  dknHandleHeaderMenuActiveState(headerMenuItems, activeClass);
  dknRenderDesktopHeaderHamburger(headerMenu, headerMenuItems);
  dknHandleHeaderButtonActiveState();
  dknRenderMenuDropdowns();

  handleActiveNavStateMobile();
};
